// Markdown Preview with Mermaid Diagram Support

import { useEffect, useRef, useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import mermaid from 'mermaid';

// Initialize Mermaid
mermaid.initialize({
  startOnLoad: false,
  theme: 'default',
  securityLevel: 'loose',
  fontFamily: 'system-ui, sans-serif',
});

// Mermaid diagram component
function MermaidDiagram({ chart }: { chart: string }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [svg, setSvg] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const renderDiagram = async () => {
      if (!chart.trim()) return;

      try {
        const id = `mermaid-${Math.random().toString(36).substr(2, 9)}`;
        const { svg } = await mermaid.render(id, chart);
        setSvg(svg);
        setError(null);
      } catch (err) {
        setError('Diagram rendering error');
        console.error('Mermaid error:', err);
      }
    };

    renderDiagram();
  }, [chart]);

  if (error) {
    return (
      <div style={{
        padding: '12px',
        backgroundColor: '#f9fafb',
        borderRadius: '6px',
        border: '1px dashed #d1d5db',
        color: '#6b7280',
        fontSize: '13px',
        textAlign: 'center',
      }}>
        <span style={{ opacity: 0.6 }}>Diagram preview unavailable</span>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      dangerouslySetInnerHTML={{ __html: svg }}
      style={{
        display: 'flex',
        justifyContent: 'center',
        padding: '16px',
        backgroundColor: '#f8fafc',
        borderRadius: '8px',
        overflow: 'auto',
      }}
    />
  );
}

// GitHub-style markdown preview
const styles = {
  preview: {
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif',
    fontSize: '14px',
    lineHeight: '1.6',
    color: '#24292f',
    padding: '24px',
    backgroundColor: 'white',
  },
  h1: {
    fontSize: '2em',
    fontWeight: '600',
    borderBottom: '1px solid #d0d7de',
    paddingBottom: '0.3em',
    marginBottom: '16px',
    marginTop: '24px',
  },
  h2: {
    fontSize: '1.5em',
    fontWeight: '600',
    borderBottom: '1px solid #d0d7de',
    paddingBottom: '0.3em',
    marginBottom: '16px',
    marginTop: '24px',
  },
  h3: {
    fontSize: '1.25em',
    fontWeight: '600',
    marginBottom: '16px',
    marginTop: '24px',
  },
  p: {
    marginBottom: '16px',
  },
  ul: {
    paddingLeft: '2em',
    marginBottom: '16px',
  },
  ol: {
    paddingLeft: '2em',
    marginBottom: '16px',
  },
  li: {
    marginBottom: '4px',
  },
  table: {
    borderCollapse: 'collapse' as const,
    width: '100%',
    marginBottom: '16px',
  },
  th: {
    border: '1px solid #d0d7de',
    padding: '8px 12px',
    backgroundColor: '#f6f8fa',
    fontWeight: '600',
    textAlign: 'left' as const,
  },
  td: {
    border: '1px solid #d0d7de',
    padding: '8px 12px',
  },
  code: {
    backgroundColor: 'rgba(175, 184, 193, 0.2)',
    padding: '0.2em 0.4em',
    borderRadius: '6px',
    fontSize: '85%',
    fontFamily: 'ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace',
  },
  pre: {
    backgroundColor: '#f6f8fa',
    padding: '16px',
    borderRadius: '6px',
    overflow: 'auto',
    marginBottom: '16px',
  },
  blockquote: {
    borderLeft: '4px solid #d0d7de',
    padding: '0 16px',
    color: '#57606a',
    marginBottom: '16px',
  },
  hr: {
    border: 'none',
    borderTop: '1px solid #d0d7de',
    margin: '24px 0',
  },
  strong: {
    fontWeight: '600',
  },
  checkbox: {
    marginRight: '8px',
  },
};

interface MarkdownPreviewProps {
  content: string;
}

export default function MarkdownPreview({ content }: MarkdownPreviewProps) {
  return (
    <div style={styles.preview}>
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          h1: ({ children }) => <h1 style={styles.h1}>{children}</h1>,
          h2: ({ children }) => <h2 style={styles.h2}>{children}</h2>,
          h3: ({ children }) => <h3 style={styles.h3}>{children}</h3>,
          p: ({ children }) => <p style={styles.p}>{children}</p>,
          ul: ({ children }) => <ul style={styles.ul}>{children}</ul>,
          ol: ({ children }) => <ol style={styles.ol}>{children}</ol>,
          li: ({ children, ...props }) => {
            // Handle task list items
            const checked = (props as any).checked;
            if (typeof checked === 'boolean') {
              return (
                <li style={{ ...styles.li, listStyle: 'none', marginLeft: '-1.5em' }}>
                  <input type="checkbox" checked={checked} readOnly style={styles.checkbox} />
                  {children}
                </li>
              );
            }
            return <li style={styles.li}>{children}</li>;
          },
          table: ({ children }) => <table style={styles.table}>{children}</table>,
          th: ({ children }) => <th style={styles.th}>{children}</th>,
          td: ({ children }) => <td style={styles.td}>{children}</td>,
          code: ({ children, className }) => {
            const match = /language-(\w+)/.exec(className || '');
            const language = match ? match[1] : '';

            // Handle Mermaid diagrams
            if (language === 'mermaid') {
              return <MermaidDiagram chart={String(children).trim()} />;
            }

            // Inline code vs code block
            const isBlock = className !== undefined;
            if (isBlock) {
              return (
                <pre style={styles.pre}>
                  <code style={{ ...styles.code, backgroundColor: 'transparent', padding: 0 }}>
                    {children}
                  </code>
                </pre>
              );
            }
            return <code style={styles.code}>{children}</code>;
          },
          pre: ({ children }) => <>{children}</>,
          blockquote: ({ children }) => <blockquote style={styles.blockquote}>{children}</blockquote>,
          hr: () => <hr style={styles.hr} />,
          strong: ({ children }) => <strong style={styles.strong}>{children}</strong>,
          a: ({ href, children }) => (
            <a href={href} style={{ color: '#0969da', textDecoration: 'none' }} target="_blank" rel="noopener noreferrer">
              {children}
            </a>
          ),
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
}
