/**
 * Blueprint Regeneration Bug — Reproduction & Fix Validation Tests
 *
 * Bug: When user has a refined epic in the Epic Editor and clicks
 * "Regenerate blueprint", the ENTIRE epic content disappears and gets
 * replaced with the wizard's 17-stage template (all sections show
 * "_To be defined_").
 *
 * Root cause:
 * - regenerateBlueprint() calls runSkill('generate', { data: state.data })
 *   which rebuilds the entire epic from scratch
 * - state.data may be empty/stale (not synced with editor content)
 * - The result overwrites editableEpic, destroying user's refined content
 *
 * Fix:
 * - Parse current editableEpic for diagram data (not stale state.data)
 * - After diagram generation, surgically replace ONLY section 6
 *   (Architecture Diagrams) using replaceSectionInEpic()
 * - Never call runSkill('generate') from regenerateBlueprint
 */
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import {
  runSkill,
  setConfig,
  parseEpicToStageData,
  generateIntelligentBlueprint,
  disableThrottlingForTests,
  enableThrottling,
} from '../skills';
import { type AppConfig, DEFAULT_CONFIG } from '../config';
import type { RefinedData } from '../types';
import { EPIC_SECTIONS } from '../types';

// Mock callAI
vi.mock('../config', async () => {
  const actual = await vi.importActual('../config');
  return {
    ...actual,
    callAI: vi.fn()
  };
});

// ============================================================================
// Helper: Replicate App.tsx's replaceSectionInEpic logic for testing
// (Same logic as App.tsx line 2623)
// ============================================================================
function replaceSectionInEpic(epic: string, sectionNum: number, newContent: string): string {
  const section = EPIC_SECTIONS.find(s => s.num === sectionNum);
  if (!section) return epic;

  const escapedTitle = section.title.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(
    `(##\\s*${sectionNum}\\.\\s*${escapedTitle}[\\s\\S]*?)(?=##\\s*\\d+\\.|$)`,
    'i'
  );

  return epic.replace(regex, newContent + '\n\n');
}

// ============================================================================
// Sample epic that simulates a user's refined content loaded in the editor
// ============================================================================
const REFINED_EPIC = `# My Authentication Platform

*Generated on 2/18/2026*

---

## 1. Objective

Build a comprehensive authentication platform with MFA, OAuth, and SSO support
for enterprise customers. This replaces the legacy auth system.

## 2. Background & Context

The current authentication system was built in 2019 and lacks modern security
features. Customer complaints have increased 300% YoY regarding login issues.

## 3. Scope

### 3.1 In Scope
- Multi-factor authentication (TOTP, SMS, WebAuthn)
- OAuth 2.0 / OIDC provider
- SSO with SAML 2.0

### 3.2 Out of Scope
- Biometric authentication (Phase 2)
- Legacy system migration tooling

## 4. Assumptions

- AWS infrastructure will be used for all services
- Team has experience with Keycloak and similar IdP platforms

## Epic Status

| Field | Value |
|---|---|
| **Status** | In Progress |
| **Owner** | Jane Smith |
| **Last Updated** | 2/15/2026 |

## 5. High-Level Architecture Overview

Microservice architecture with API Gateway, Auth Service, Token Service,
and User Directory. Redis for session caching, PostgreSQL for user data.

## 6. Architecture Diagrams

\`\`\`mermaid
flowchart TD
    A[Client] --> B[API Gateway]
    B --> C[Auth Service]
    C --> D[Token Service]
    C --> E[User DB]
\`\`\`

> *Diagram auto-generated from epic content. Regenerate in Blueprint tab to update.*

## 7. Team & Roles

| Role | Responsibility |
|------|----------------|
| Jane Smith | Tech Lead |
| Bob Johnson | Backend Engineer |
| Alice Chen | Security Engineer |

## 8. Environments & CI/CD Strategy

Three environments: dev, staging, production. GitLab CI/CD with Terraform
for infrastructure. Blue-green deployments for zero-downtime releases.

## 9. Data Security & Access Controls

All PII encrypted at rest (AES-256) and in transit (TLS 1.3).
RBAC with fine-grained permissions. SOC 2 Type II compliance required.

## 10. Data Stores, Services & Interfaces

- PostgreSQL 15 for user data and credentials
- Redis 7.x for session cache and rate limiting
- Kafka for audit event streaming

## 11. Key Features & User Stories

### Key Features
- Multi-factor authentication with multiple methods
- Single sign-on across enterprise applications
- Self-service password reset with security questions

### User Stories

**US-001: Implement MFA Authentication** 🔴
> As a security-conscious user, I want to enable multi-factor authentication, so that my account is protected.

**US-002: Configure SSO Integration** 🟡
> As an IT administrator, I want to configure SSO with our IdP, so that employees can use single sign-on.

## 12. Non-Functional Requirements (NFRs)

| ID | Requirement | Priority |
|---|---|---|
| NFR-1 | Authentication latency < 200ms p99 | P0 |
| NFR-2 | 99.99% uptime SLA | P0 |
| NFR-3 | Support 10M concurrent sessions | P1 |

## 13. Dependencies & Risks

### 13.1 Dependencies
- AWS KMS for encryption key management
- Corporate LDAP directory

### 13.2 Risks
- Legacy system data migration complexity
- Regulatory compliance timeline

## 14. Deliverables

- [ ] Auth service with MFA support
- [ ] OAuth/OIDC provider endpoints
- [ ] SSO SAML 2.0 integration
- [ ] Admin dashboard for user management

## 15. Next Steps

1. Finalize architecture review with security team
2. Set up development environment and CI/CD pipeline
3. Begin Sprint 1: Core auth service scaffold

## 16. Definition of Done (DoD)

- [ ] All acceptance criteria met
- [ ] Unit test coverage > 80%
- [ ] Security penetration test passed
- [ ] Documentation updated

## 17. Approvals & Sign-Offs

| Approver | Role | Status |
|----------|------|--------|
| CTO | Executive Sponsor | Pending |
| CISO | Security Approval | Pending |
`;

// ============================================================================
// BUG REPRODUCTION: The old behavior destroys epic content
// ============================================================================
describe('Bug reproduction: Regenerate blueprint destroys epic content', () => {
  beforeEach(() => {
    setConfig({ ...DEFAULT_CONFIG, aiProvider: 'mock' });
    disableThrottlingForTests();
  });

  afterEach(() => {
    enableThrottling();
    vi.restoreAllMocks();
  });

  describe('Root cause: runSkill("generate") rebuilds entire epic from stale data', () => {
    it('should demonstrate that empty state.data produces blank template', async () => {
      // This is what happens when user loads epic from GitLab — state.data is empty
      const emptyData: RefinedData = {};

      const result = await runSkill('generate', {
        data: emptyData,
        projectName: 'Untitled Project',
      }) as { epic: string };

      // All sections default to "_To be defined_" — the user's content is gone
      const toBeDefinedCount = (result.epic.match(/_To be defined_/g) || []).length;
      expect(toBeDefinedCount).toBeGreaterThan(5);

      // The user's refined content (e.g. "MFA", "OAuth", "Jane Smith") is nowhere
      expect(result.epic).not.toContain('MFA');
      expect(result.epic).not.toContain('OAuth');
      expect(result.epic).not.toContain('Jane Smith');
    });

    it('should demonstrate that runSkill("generate") ignores editableEpic content', async () => {
      // Even with partial state.data, the epic is rebuilt from scratch
      const partialData: RefinedData = {
        objective: { original: 'Auth', refined: 'Build authentication' },
      };

      const result = await runSkill('generate', {
        data: partialData,
        projectName: 'Auth Platform',
      }) as { epic: string };

      // Only Objective has content; all other sections say "_To be defined_"
      expect(result.epic).toContain('Build authentication');
      const toBeDefinedCount = (result.epic.match(/_To be defined_/g) || []).length;
      expect(toBeDefinedCount).toBeGreaterThan(5);

      // None of the user's refined content from the editor survives
      expect(result.epic).not.toContain('300% YoY');
      expect(result.epic).not.toContain('Keycloak');
      expect(result.epic).not.toContain('Blue-green deployments');
    });
  });

  describe('Root cause: state.data is not synced with editor content', () => {
    it('should show parseEpicToStageData extracts data from editor content', () => {
      // This is the CORRECT way to get data — parse from current epic
      const { data, projectName } = parseEpicToStageData(REFINED_EPIC);

      expect(projectName).toBe('My Authentication Platform');

      // Data should contain content from the refined epic
      const objectiveContent = data['objective']?.refined || '';
      expect(objectiveContent).toContain('authentication');
    });

    it('should show parseEpicToStageData preserves rich section content', () => {
      const { data } = parseEpicToStageData(REFINED_EPIC);

      // The parser should extract meaningful content from sections
      // This verifies that parsing the editor content is viable for diagram generation
      const hasContent = Object.values(data).some(
        field => field?.refined && field.refined.length > 20
      );
      expect(hasContent).toBe(true);
    });
  });
});

// ============================================================================
// FIX VALIDATION: Surgical section replacement
// ============================================================================
describe('Fix validation: Surgical diagram replacement preserves epic content', () => {
  describe('replaceSectionInEpic correctly updates only section 6', () => {
    it('should replace section 6 content without affecting other sections', () => {
      const newDiagramSection = `## 6. Architecture Diagrams\n\n\`\`\`mermaid\nflowchart LR\n    X[New] --> Y[Diagram]\n\`\`\`\n\n> *Diagram auto-generated from epic content. Regenerate in Blueprint tab to update.*\n`;

      const updatedEpic = replaceSectionInEpic(REFINED_EPIC, 6, newDiagramSection);

      // Section 6 should have the new diagram
      expect(updatedEpic).toContain('X[New] --> Y[Diagram]');

      // Old diagram should be gone
      expect(updatedEpic).not.toContain('A[Client] --> B[API Gateway]');

      // ALL other sections must be preserved
      expect(updatedEpic).toContain('# My Authentication Platform');
      expect(updatedEpic).toContain('comprehensive authentication platform with MFA');
      expect(updatedEpic).toContain('current authentication system was built in 2019');
      expect(updatedEpic).toContain('Multi-factor authentication (TOTP, SMS, WebAuthn)');
      expect(updatedEpic).toContain('Biometric authentication (Phase 2)');
      expect(updatedEpic).toContain('AWS infrastructure');
      expect(updatedEpic).toContain('Microservice architecture with API Gateway');
      expect(updatedEpic).toContain('Jane Smith');
      expect(updatedEpic).toContain('Three environments: dev, staging, production');
      expect(updatedEpic).toContain('AES-256');
      expect(updatedEpic).toContain('PostgreSQL 15');
      expect(updatedEpic).toContain('US-001: Implement MFA Authentication');
      expect(updatedEpic).toContain('Authentication latency < 200ms p99');
      expect(updatedEpic).toContain('AWS KMS');
      expect(updatedEpic).toContain('Auth service with MFA support');
      expect(updatedEpic).toContain('Finalize architecture review');
      expect(updatedEpic).toContain('Unit test coverage > 80%');
      expect(updatedEpic).toContain('CTO');
    });

    it('should preserve section count after replacement', () => {
      const newDiagramSection = `## 6. Architecture Diagrams\n\n\`\`\`mermaid\nflowchart TD\n    Z[Updated]\n\`\`\`\n`;
      const updatedEpic = replaceSectionInEpic(REFINED_EPIC, 6, newDiagramSection);

      // Count section headers — should be the same
      const originalSections = REFINED_EPIC.match(/^## \d+\./gm) || [];
      const updatedSections = updatedEpic.match(/^## \d+\./gm) || [];

      expect(updatedSections.length).toBe(originalSections.length);
    });

    it('should handle epic without section 6 gracefully', () => {
      const epicWithoutSection6 = `# Test Project

## 1. Objective
Build something.

## 5. High-Level Architecture Overview
Some architecture.

## 7. Team & Roles
Team info.`;

      const newDiagramSection = `## 6. Architecture Diagrams\n\n\`\`\`mermaid\nflowchart TD\n    A --> B\n\`\`\`\n`;
      const result = replaceSectionInEpic(epicWithoutSection6, 6, newDiagramSection);

      // If section 6 doesn't exist, epic should be returned unchanged
      // (the diagram still shows in the Blueprint tab)
      expect(result).toContain('Build something.');
      expect(result).toContain('Some architecture.');
      expect(result).toContain('Team info.');
    });
  });

  describe('Full regeneration flow preserves content', () => {
    it('should preserve user story content when diagram is updated', () => {
      const newDiagramSection = `## 6. Architecture Diagrams\n\n\`\`\`mermaid\nflowchart TD\n    A[Updated Diagram]\n\`\`\`\n`;
      const updatedEpic = replaceSectionInEpic(REFINED_EPIC, 6, newDiagramSection);

      // User stories must survive
      expect(updatedEpic).toContain('US-001: Implement MFA Authentication');
      expect(updatedEpic).toContain('US-002: Configure SSO Integration');
      expect(updatedEpic).toContain('security-conscious user');
      expect(updatedEpic).toContain('IT administrator');
    });

    it('should preserve NFR table when diagram is updated', () => {
      const newDiagramSection = `## 6. Architecture Diagrams\n\n\`\`\`mermaid\nflowchart TD\n    A[New]\n\`\`\`\n`;
      const updatedEpic = replaceSectionInEpic(REFINED_EPIC, 6, newDiagramSection);

      expect(updatedEpic).toContain('Authentication latency < 200ms p99');
      expect(updatedEpic).toContain('99.99% uptime SLA');
      expect(updatedEpic).toContain('10M concurrent sessions');
    });

    it('should preserve team roles when diagram is updated', () => {
      const newDiagramSection = `## 6. Architecture Diagrams\n\n\`\`\`mermaid\nflowchart TD\n    A[New]\n\`\`\`\n`;
      const updatedEpic = replaceSectionInEpic(REFINED_EPIC, 6, newDiagramSection);

      expect(updatedEpic).toContain('Jane Smith');
      expect(updatedEpic).toContain('Bob Johnson');
      expect(updatedEpic).toContain('Alice Chen');
    });

    it('should preserve Epic Status metadata when diagram is updated', () => {
      const newDiagramSection = `## 6. Architecture Diagrams\n\n\`\`\`mermaid\nflowchart TD\n    A[New]\n\`\`\`\n`;
      const updatedEpic = replaceSectionInEpic(REFINED_EPIC, 6, newDiagramSection);

      expect(updatedEpic).toContain('In Progress');
      expect(updatedEpic).toContain('Jane Smith');
    });

    it('should correctly embed new mermaid code block', () => {
      const newDiagram = 'flowchart LR\n    Auth[Auth Service] --> Token[Token Service]\n    Auth --> UserDB[(PostgreSQL)]';
      const newDiagramSection = `## 6. Architecture Diagrams\n\n\`\`\`mermaid\n${newDiagram}\n\`\`\`\n\n> *Diagram auto-generated from epic content. Regenerate in Blueprint tab to update.*\n`;
      const updatedEpic = replaceSectionInEpic(REFINED_EPIC, 6, newDiagramSection);

      expect(updatedEpic).toContain('Auth[Auth Service] --> Token[Token Service]');
      expect(updatedEpic).toContain('Auth --> UserDB[(PostgreSQL)]');
      expect(updatedEpic).toContain('```mermaid');
    });
  });
});

// ============================================================================
// EDGE CASES
// ============================================================================
describe('Edge cases for blueprint regeneration', () => {
  it('should handle epic with custom/non-standard section 6 header', () => {
    const epicCustomHeader = `# Test

## 1. Objective
Objective here.

## 6.  Architecture Diagrams

Old diagram content.

## 7. Team & Roles
Team.`;

    // Note: extra space after "6." — regex should still match
    const newContent = `## 6. Architecture Diagrams\n\nnew diagram\n`;
    const result = replaceSectionInEpic(epicCustomHeader, 6, newContent);

    expect(result).toContain('new diagram');
    expect(result).not.toContain('Old diagram content');
  });

  it('should handle very large epic content without performance issues', () => {
    // Create a large epic by repeating content
    let largeEpic = REFINED_EPIC;
    for (let i = 0; i < 5; i++) {
      largeEpic += `\n\nAdditional detailed content block ${i}. `.repeat(100);
    }

    const start = performance.now();
    const newContent = `## 6. Architecture Diagrams\n\nnew diagram\n`;
    const result = replaceSectionInEpic(largeEpic, 6, newContent);
    const duration = performance.now() - start;

    expect(result).toContain('new diagram');
    expect(duration).toBeLessThan(100); // Should be fast (< 100ms)
  });

  it('should handle empty editableEpic gracefully', () => {
    const emptyEpic = '';
    const newContent = `## 6. Architecture Diagrams\n\nnew diagram\n`;
    const result = replaceSectionInEpic(emptyEpic, 6, newContent);

    // Should return empty string unchanged (no section to replace)
    expect(result).toBe('');
  });
});
