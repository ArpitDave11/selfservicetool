/**
 * Category Validation Tests — Multi-Category Quality Assessment
 *
 * IMPORTANT: These tests require a real AI API key (OpenAI or Azure OpenAI).
 * They are NOT included in the default test suite.
 *
 * Run with:
 *   OPENAI_API_KEY=sk-... npx vitest run src/test/category-validation.test.ts --reporter=verbose
 *
 * Or configure the key in localStorage via the app's Settings tab first.
 */

// @vitest-environment node

import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { readFileSync } from 'fs';
import { resolve } from 'path';
import {
  runPremiumPipeline,
  setConfig,
  disableThrottlingForTests,
  enableThrottling
} from '../skills';
import {
  type PipelineResult,
  type ValidationOutput,
  type ExtractedRequirement
} from '../types';
import { type AppConfig, DEFAULT_CONFIG } from '../config';

// ===== CONFIGURATION =====
const API_KEY = process.env.OPENAI_API_KEY || '';
const SKIP_REASON = !API_KEY ? 'OPENAI_API_KEY not set — skipping real AI tests' : '';

// ===== FIXTURES =====
const FIXTURES_DIR = resolve(__dirname, 'fixtures');

interface CategoryFixture {
  category: string;
  filename: string;
  expectedMinRequirements: number;
}

const CATEGORY_FIXTURES: CategoryFixture[] = [
  { category: 'integration_spec', filename: 'broadridge-reference-epic.md', expectedMinRequirements: 5 },
  { category: 'technical_design', filename: 'tech-design-auth-service.md', expectedMinRequirements: 4 },
  { category: 'feature_specification', filename: 'feature-spec-mobile-checkout.md', expectedMinRequirements: 4 },
  { category: 'api_specification', filename: 'api-spec-payment-gateway.md', expectedMinRequirements: 4 },
  { category: 'infrastructure_design', filename: 'infra-design-k8s-migration.md', expectedMinRequirements: 4 },
  { category: 'migration_plan', filename: 'migration-plan-postgres-upgrade.md', expectedMinRequirements: 4 },
  { category: 'business_requirement', filename: 'business-req-digital-transformation.md', expectedMinRequirements: 4 }
];

// ===== QUALITY CHECKS =====
interface QualityResult {
  category: string;
  filename: string;
  passed: boolean;
  iterationsRun: number;
  auditScore: number;
  requirementsExtracted: number;
  storiesGenerated: number;
  storiesWithReqTags: number;
  traceabilityCoverage: number;
  hardFails: number;
  failureReasons: string[];
  duration: number;
  checks: Record<string, { passed: boolean; detail: string }>;
}

function runQualityChecks(result: PipelineResult, expectedCategory: string): QualityResult['checks'] {
  const checks: Record<string, { passed: boolean; detail: string }> = {};
  const reqs = result.comprehension.extractedRequirements || [];
  const stories = result.mandatory.userStories;
  const validation = result.validation;
  const epic = result.mandatory.assembledEpic.markdown;

  // Q1: Requirements extracted
  checks['Q1_requirements_extracted'] = {
    passed: reqs.length >= 3,
    detail: `${reqs.length} requirements extracted`
  };

  // Q2: No generic template components in diagram
  const diagram = result.mandatory.architectureDiagram;
  const genericNodes = ['Component A', 'Service B', 'Database C', 'Module X'];
  const hasGeneric = genericNodes.some(n => diagram.includes(n));
  checks['Q2_no_generic_diagram_nodes'] = {
    passed: !hasGeneric,
    detail: hasGeneric ? 'Found generic placeholder nodes' : 'All nodes are source-specific'
  };

  // Q3: Stories generated
  checks['Q3_stories_generated'] = {
    passed: stories.length >= 3,
    detail: `${stories.length} user stories generated`
  };

  // Q4: Story format ("As a..., I want..., so that...")
  const storiesWithBadFormat = stories.filter(s => {
    const hasGoal = s.goal && s.goal.length > 3;
    const hasBenefit = s.benefit && s.benefit.length > 3;
    return !hasGoal || !hasBenefit;
  });
  checks['Q4_story_format'] = {
    passed: storiesWithBadFormat.length === 0,
    detail: storiesWithBadFormat.length > 0
      ? `${storiesWithBadFormat.length} stories with bad format`
      : 'All stories have proper format'
  };

  // Q5: No "Decision/Tradeoff" pattern
  const hasDecisionTradeoff = /\*\*Decision\*\*:.*\*\*Tradeoff?\*\*:/s.test(epic);
  checks['Q5_no_decision_tradeoff'] = {
    passed: !hasDecisionTradeoff,
    detail: hasDecisionTradeoff ? 'Found banned Decision/Tradeoff pattern' : 'Clean'
  };

  // Q6: Diagram type is flowchart LR (not sankey)
  const diagramType = result.mandatory.diagramType;
  checks['Q6_diagram_type'] = {
    passed: diagramType !== 'sankey',
    detail: `Diagram type: ${diagramType}`
  };

  // Q7: No placeholder text
  const hasPlaceholders = /\[TODO\]|\[TBD\]|\[PLACEHOLDER\]|lorem ipsum/i.test(epic);
  checks['Q7_no_placeholders'] = {
    passed: !hasPlaceholders,
    detail: hasPlaceholders ? 'Found placeholder text' : 'No placeholders'
  };

  // Q8: Audit score >= 85
  checks['Q8_audit_score'] = {
    passed: (validation?.auditScore ?? 0) >= 85,
    detail: `Score: ${validation?.auditScore ?? 'N/A'}`
  };

  // Q9: All stories have [Req #N] tags
  const storiesWithTags = stories.filter(s => s.reqTags && s.reqTags.length > 0);
  checks['Q9_stories_req_tags'] = {
    passed: storiesWithTags.length === stories.length,
    detail: `${storiesWithTags.length}/${stories.length} stories tagged`
  };

  // Q10: Traceability coverage >= 80%
  checks['Q10_traceability'] = {
    passed: (validation?.traceabilityCoverage ?? 0) >= 80,
    detail: `${validation?.traceabilityCoverage ?? 0}% coverage`
  };

  // Q11: No hard fails
  checks['Q11_no_hard_fails'] = {
    passed: (validation?.hardFailCount ?? 0) === 0,
    detail: `${validation?.hardFailCount ?? 0} hard fails`
  };

  // Q12: Word count reasonable (not bloated)
  const wordCount = result.mandatory.assembledEpic.wordCount;
  checks['Q12_word_count'] = {
    passed: wordCount >= 500 && wordCount <= 8000,
    detail: `${wordCount} words`
  };

  return checks;
}

// ===== TESTS =====
describe('Category Validation — Real AI Pipeline Tests', () => {
  beforeAll(() => {
    if (!API_KEY) return;
    disableThrottlingForTests();
    setConfig({
      ...DEFAULT_CONFIG,
      aiProvider: 'openai',
      openAI: {
        ...DEFAULT_CONFIG.openAI,
        enabled: true,
        apiKey: API_KEY
      }
    });
  });

  afterAll(() => {
    enableThrottling();
  });

  // Collect all results for final report
  const allResults: QualityResult[] = [];

  for (const fixture of CATEGORY_FIXTURES) {
    describe(`Category: ${fixture.category}`, () => {
      it.skipIf(!API_KEY)(`should process ${fixture.filename} through full pipeline`, async () => {
        const epicContent = readFileSync(resolve(FIXTURES_DIR, fixture.filename), 'utf-8');

        const startTime = Date.now();
        const result = await runPremiumPipeline(epicContent);
        const duration = Date.now() - startTime;

        const reqs = result.comprehension.extractedRequirements || [];
        const stories = result.mandatory.userStories;
        const validation = result.validation;

        const checks = runQualityChecks(result, fixture.category);
        const allChecksPassed = Object.values(checks).every(c => c.passed);

        const qualityResult: QualityResult = {
          category: fixture.category,
          filename: fixture.filename,
          passed: allChecksPassed,
          iterationsRun: result.iterationsRun || 1,
          auditScore: validation?.auditScore ?? 0,
          requirementsExtracted: reqs.length,
          storiesGenerated: stories.length,
          storiesWithReqTags: stories.filter(s => s.reqTags && s.reqTags.length > 0).length,
          traceabilityCoverage: validation?.traceabilityCoverage ?? 0,
          hardFails: validation?.hardFailCount ?? 0,
          failureReasons: validation?.failureReasons ?? [],
          duration,
          checks
        };

        allResults.push(qualityResult);

        // Print results for this fixture
        console.log(`\n===== ${fixture.category}: ${fixture.filename} =====`);
        console.log(`Duration: ${(duration / 1000).toFixed(1)}s | Iterations: ${qualityResult.iterationsRun}`);
        console.log(`Requirements: ${qualityResult.requirementsExtracted} | Stories: ${qualityResult.storiesGenerated} (${qualityResult.storiesWithReqTags} tagged)`);
        console.log(`Audit: ${qualityResult.auditScore}/100 | Traceability: ${qualityResult.traceabilityCoverage}% | Hard fails: ${qualityResult.hardFails}`);
        console.log('Checks:');
        for (const [name, check] of Object.entries(checks)) {
          console.log(`  ${check.passed ? 'PASS' : 'FAIL'} ${name}: ${check.detail}`);
        }
        if (qualityResult.failureReasons.length > 0) {
          console.log('Failure reasons:', qualityResult.failureReasons.slice(0, 5).join('; '));
        }

        // Core assertions — these should all pass
        expect(reqs.length).toBeGreaterThanOrEqual(fixture.expectedMinRequirements);
        expect(stories.length).toBeGreaterThanOrEqual(3);
        expect(result.stagesCompleted).toContain(6);
      }, 300000); // 5 min per fixture (up to 5 iterations)
    });
  }

  // Final summary after all tests
  it.skipIf(!API_KEY)('should print final quality report', () => {
    if (allResults.length === 0) return;

    console.log('\n\n========================================');
    console.log('    CATEGORY VALIDATION FINAL REPORT');
    console.log('========================================\n');

    console.log('| Category | File | Pass | Score | Reqs | Stories | Tagged | Coverage | Iterations | Time |');
    console.log('|----------|------|------|-------|------|---------|--------|----------|------------|------|');

    for (const r of allResults) {
      console.log(
        `| ${r.category} | ${r.filename.replace('.md', '')} | ${r.passed ? 'PASS' : 'FAIL'} | ${r.auditScore} | ${r.requirementsExtracted} | ${r.storiesGenerated} | ${r.storiesWithReqTags} | ${r.traceabilityCoverage}% | ${r.iterationsRun} | ${(r.duration / 1000).toFixed(0)}s |`
      );
    }

    const totalPassed = allResults.filter(r => r.passed).length;
    console.log(`\nTotal: ${totalPassed}/${allResults.length} categories passed`);

    // Per-check summary
    console.log('\nPer-check summary:');
    const checkNames = allResults.length > 0 ? Object.keys(allResults[0].checks) : [];
    for (const name of checkNames) {
      const passed = allResults.filter(r => r.checks[name]?.passed).length;
      console.log(`  ${name}: ${passed}/${allResults.length} passed`);
    }
  });
});
