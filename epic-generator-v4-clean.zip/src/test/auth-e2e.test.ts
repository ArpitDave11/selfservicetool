/**
 * End-to-End Authentication Test using Puppeteer
 *
 * Tests the full auth flow including:
 * - Login page rendering
 * - Mock auth flow
 * - Console log verification
 * - No infinite loops
 */

import puppeteer, { Browser, Page } from 'puppeteer';

const APP_URL = 'http://localhost:3002';
const TIMEOUT = 30000;

describe('Auth E2E Tests', () => {
  let browser: Browser;
  let page: Page;
  const consoleLogs: string[] = [];
  const consoleErrors: string[] = [];

  beforeAll(async () => {
    browser = await puppeteer.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox'],
    });
  });

  afterAll(async () => {
    if (browser) {
      await browser.close();
    }
  });

  beforeEach(async () => {
    page = await browser.newPage();
    consoleLogs.length = 0;
    consoleErrors.length = 0;

    // Capture all console messages
    page.on('console', (msg) => {
      const text = msg.text();
      consoleLogs.push(`[${msg.type()}] ${text}`);
      if (msg.type() === 'error') {
        consoleErrors.push(text);
      }
    });

    // Capture page errors
    page.on('pageerror', (error) => {
      consoleErrors.push(`Page Error: ${error.message}`);
    });
  });

  afterEach(async () => {
    // Print console logs for debugging
    console.log('\n=== Console Logs ===');
    consoleLogs.forEach(log => console.log(log));

    if (consoleErrors.length > 0) {
      console.log('\n=== Console Errors ===');
      consoleErrors.forEach(err => console.log(err));
    }

    if (page) {
      await page.close();
    }
  });

  test('should load the page and show appropriate auth state', async () => {
    console.log('Navigating to:', APP_URL);

    // Navigate to the app
    const response = await page.goto(APP_URL, {
      waitUntil: 'networkidle0',
      timeout: TIMEOUT
    });

    expect(response?.status()).toBe(200);

    // Wait for React to render
    await page.waitForSelector('body', { timeout: TIMEOUT });
    await new Promise(resolve => setTimeout(resolve, 2000)); // Extra wait for React

    // Take screenshot for debugging
    await page.screenshot({
      path: '/Users/arpit/Desktop/Project_BKP/epic-generator-v4/test-screenshot-1.png',
      fullPage: true
    });

    // Get page content
    const bodyHTML = await page.evaluate(() => document.body.innerHTML);
    console.log('\n=== Page HTML (first 2000 chars) ===');
    console.log(bodyHTML.substring(0, 2000));

    // Check what's rendered
    const pageText = await page.evaluate(() => document.body.innerText);
    console.log('\n=== Page Text ===');
    console.log(pageText.substring(0, 1000));

    // Check for various states
    const hasLoginButton = await page.evaluate(() => {
      return document.body.innerText.includes('Sign in with Microsoft');
    });

    const hasEpicGenerator = await page.evaluate(() => {
      return document.body.innerText.includes('Epic Generator');
    });

    const hasMockBadge = await page.evaluate(() => {
      return document.body.innerText.includes('MOCK AUTH MODE');
    });

    const hasAuthError = await page.evaluate(() => {
      return document.body.innerText.includes('Authentication Error');
    });

    const hasLoading = await page.evaluate(() => {
      return document.body.innerText.includes('Authenticating');
    });

    console.log('\n=== Auth State Detection ===');
    console.log('Has Login Button:', hasLoginButton);
    console.log('Has Epic Generator:', hasEpicGenerator);
    console.log('Has Mock Badge:', hasMockBadge);
    console.log('Has Auth Error:', hasAuthError);
    console.log('Has Loading:', hasLoading);

    // Check for infinite loop indicators (repeated log messages)
    const authLogs = consoleLogs.filter(log => log.includes('[Auth]') || log.includes('[MockAuth]'));
    console.log('\n=== Auth Related Logs ===');
    authLogs.forEach(log => console.log(log));

    // Verify no excessive re-renders (indicates infinite loop)
    const renderCount = consoleLogs.filter(log =>
      log.includes('initializeAuth') || log.includes('Mock login')
    ).length;
    console.log('Auth initialization calls:', renderCount);
    expect(renderCount).toBeLessThan(5); // Should not have many re-initializations

  }, TIMEOUT);

  test('should test mock login flow if login page is shown', async () => {
    await page.goto(APP_URL, { waitUntil: 'networkidle0', timeout: TIMEOUT });
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Check if login button exists
    const loginButton = await page.$('button');

    if (loginButton) {
      const buttonText = await page.evaluate(el => el?.innerText, loginButton);
      console.log('Found button with text:', buttonText);

      if (buttonText?.includes('Sign in')) {
        console.log('Clicking login button...');
        await loginButton.click();

        // Wait for auth to complete
        await new Promise(resolve => setTimeout(resolve, 3000));

        // Take screenshot after login
        await page.screenshot({
          path: '/Users/arpit/Desktop/Project_BKP/epic-generator-v4/test-screenshot-2-after-login.png',
          fullPage: true
        });

        const pageTextAfterLogin = await page.evaluate(() => document.body.innerText);
        console.log('\n=== Page Text After Login ===');
        console.log(pageTextAfterLogin.substring(0, 1000));
      }
    } else {
      console.log('No login button found - app may have loaded directly');
    }
  }, TIMEOUT);
});
