# Content Quality Analysis Fix Plan

## Root Cause Analysis

After analyzing the test output, I identified **3 root causes**:

### Issue 1: Critique Modal Parsing Captures Garbage (CSS/Mermaid Styles)

**Evidence:**
```json
"issues": [
  "family:Frutiger,Helvetica Neue,Arial,sans",
  "serif;font-size:16px;fill:#333;",
  "#mermaid-hsu1iw1f1 .edge-animation",
  "dasharray:9,5!important;stroke-dashoffset:900;"
]
```

**Root Cause:** The `page.evaluate()` that extracts modal text is capturing the **full document body** including:
- Mermaid diagram inline styles
- CSS class definitions
- SVG element attributes

**Location:** `refine-critique-analysis.puppeteer.test.ts` lines 1151-1268

---

### Issue 2: Section Title Extraction Picks Up CI/CD Pipeline Steps

**Evidence:**
```json
"sectionFeedback": [
  { "sectionTitle": "Code Commit", "score": 5 },
  { "sectionTitle": "Build", "score": 5 },
  { "sectionTitle": "Test", "score": 5 },
  { "sectionTitle": "Deploy", "score": 5 }
]
```

**Root Cause:** The regex `block.match(/^(\d+)\.\s+([A-Z][A-Za-z\s&]+)/)` matches:
```
1. Code Commit
2. Build (Dockerize)
3. Test (Unit/Integration)
4. Deploy (Staging)
```
From the CI/CD Pipeline Diagram in the epic content.

**Location:** `refine-critique-analysis.puppeteer.test.ts` lines 1197-1236

---

### Issue 3: Issue Text Splitting Produces Fragments

**Evidence:**
```json
"issues": [
  "promptly. Runbooks provide step",
  "service communication within the mesh.",
  "256 and in transit using TLS 1.2 or higher."
]
```

**Root Cause:** Splitting on `[-•]\s*` captures random text fragments that happen to start after a hyphen or bullet.

---

## Fix Plan

### Fix 1: Filter Out CSS/Mermaid Content Before Parsing

**Function:** `extractCritiqueFromModal()`

**Current Input (problematic):**
```
AI Critique Report
Overall Score: 8/10
...
#mermaid-hsu1iw1f1 .edge{stroke-width:1px;}
font-family:Frutiger,Helvetica Neue,Arial,sans-serif;
```

**Expected Output (after filter):**
```
AI Critique Report
Overall Score: 8/10
...
```

**Implementation:**
```typescript
function sanitizeModalText(text: string): string {
  // Remove Mermaid CSS/SVG content
  let cleaned = text
    // Remove CSS rules: selector { properties }
    .replace(/#mermaid[^}]+}/g, '')
    // Remove font-family declarations
    .replace(/font-family:[^;]+;/g, '')
    // Remove CSS properties like stroke-width, fill, etc.
    .replace(/(stroke|fill|font|text|border|padding|margin|width|height|animation)[^;]*;/gi, '')
    // Remove @keyframes blocks
    .replace(/@keyframes[^}]+}/g, '')
    // Remove hex colors that aren't meaningful
    .replace(/#[a-f0-9]{3,6}(?![a-zA-Z])/gi, '')
    // Remove !important declarations
    .replace(/!important/gi, '')
    // Remove SVG/CSS class selectors
    .replace(/\.[a-z-]+\s*\{[^}]*\}/gi, '')
    // Clean up multiple spaces/newlines
    .replace(/\s+/g, ' ')
    .trim();

  return cleaned;
}
```

**Example:**
- Input: `"font-family:Frutiger,Helvetica Neue,Arial,sans-serif;font-size:16px;"`
- Output: `""`

---

### Fix 2: Improve Section Title Extraction

**Function:** `extractSectionFeedback()`

**Current Regex (problematic):**
```typescript
const headerMatch = block.match(/^(\d+)\.\s+([A-Z][A-Za-z\s&]+)/);
```

**Problem:** Matches numbered list items from epic content like:
```
1. Code Commit
2. Build (Dockerize)
```

**Fixed Approach:**
```typescript
function extractSectionFeedback(modalText: string, epicSections: EpicSection[]): CritiqueFeedback[] {
  const feedback: CritiqueFeedback[] = [];
  const epicTitles = new Set(epicSections.map(s => s.title.toLowerCase()));

  // Only match sections that exist in the epic OR are standard critique sections
  const validSectionPatterns = [
    ...Array.from(epicTitles),
    'executive summary',
    'business context',
    'technical scope',
    'success metrics',
    'timeline',
    'dependencies',
    'risks',
    'architecture',
    'user stories'
  ];

  for (const pattern of validSectionPatterns) {
    // Look for section with score like "Executive Summary: 8/10" or "Executive Summary (8/10)"
    const regex = new RegExp(
      `${escapeRegex(pattern)}[:\\s]+(?:score[:\\s]+)?(\\d+(?:\\.\\d+)?)[\\s/]*(?:10|out of 10)?`,
      'i'
    );
    const match = modalText.match(regex);

    if (match) {
      feedback.push({
        sectionTitle: pattern,
        score: parseFloat(match[1]),
        status: getStatusFromScore(parseFloat(match[1])),
        issues: extractIssuesForSection(modalText, pattern),
        suggestions: extractSuggestionsForSection(modalText, pattern)
      });
    }
  }

  return feedback;
}
```

**Example:**
- Epic sections: `["Executive Summary", "Business Context", "Technical Scope"]`
- Modal text: `"Executive Summary: 8/10 - Good coverage..."`
- Output: `[{ sectionTitle: "Executive Summary", score: 8, ... }]`

---

### Fix 3: Better Issue/Suggestion Extraction

**Function:** `extractIssuesForSection()`

**Current Approach (problematic):**
```typescript
const issues = issuesText
  .split(/[-•]\s*/)
  .map(s => s.trim())
  .filter(s => s.length > 5 && s.length < 300);
```

**Problem:** Splits on any hyphen, capturing fragments like:
- `"service communication within the mesh."`
- `"256 and in transit using TLS 1.2"`

**Fixed Approach:**
```typescript
function extractIssuesForSection(modalText: string, sectionTitle: string): string[] {
  const issues: string[] = [];

  // Find the section block in the modal
  const sectionPattern = new RegExp(
    `${escapeRegex(sectionTitle)}[^]*?(?=(?:##|\\n\\n[A-Z][a-z]+:)|$)`,
    'i'
  );
  const sectionMatch = modalText.match(sectionPattern);
  if (!sectionMatch) return [];

  const sectionText = sectionMatch[0];

  // Look for issue patterns
  const issuePatterns = [
    // "Issue: description" or "Issues: - item - item"
    /(?:issue|problem|concern|weakness|gap)[s]?:\s*([^]+?)(?=suggestion|strength|score|\n\n|$)/gi,
    // Bullet points starting with ❌, ⚠️, or similar
    /[❌⚠️🔴]\s*([^\n]+)/g,
    // "Missing: X" or "Lacks: Y"
    /(?:missing|lacks|needs|requires):\s*([^\n]+)/gi
  ];

  for (const pattern of issuePatterns) {
    let match;
    while ((match = pattern.exec(sectionText)) !== null) {
      const issue = match[1].trim();
      // Filter out CSS/garbage
      if (isValidFeedbackText(issue)) {
        issues.push(issue);
      }
    }
  }

  return issues;
}

function isValidFeedbackText(text: string): boolean {
  // Must be at least 10 characters
  if (text.length < 10) return false;

  // Must not contain CSS patterns
  if (/font-|stroke|fill:|border|mermaid|keyframes|#[a-f0-9]{6}/i.test(text)) return false;

  // Must contain at least 3 real words
  const words = text.split(/\s+/).filter(w => /^[a-zA-Z]{3,}$/.test(w));
  if (words.length < 3) return false;

  // Should not be mostly punctuation
  const punctuationRatio = (text.match(/[^a-zA-Z0-9\s]/g) || []).length / text.length;
  if (punctuationRatio > 0.3) return false;

  return true;
}
```

**Example:**
- Input: `"Executive Summary: 8/10\nIssue: Missing quantified ROI projections\n❌ No timeline for expected benefits"`
- Output: `["Missing quantified ROI projections", "No timeline for expected benefits"]`

---

### Fix 4: Use Dedicated Modal Selector Instead of Full Body

**Current Approach (problematic):**
```typescript
const modal = document.querySelector('[role="dialog"]') ||
              document.querySelector('.modal') ||
              document.querySelector('[class*="modal"]');
const modalText = modal?.textContent || pageText;
```

**Problem:** Falls back to `pageText` which includes everything.

**Fixed Approach:**
```typescript
// In page.evaluate():
const critiqueModal = document.querySelector('[data-testid="critique-modal"]') ||
                      document.querySelector('.critique-report-modal') ||
                      document.querySelector('[role="dialog"][aria-label*="critique" i]');

if (!critiqueModal) {
  console.error('Critique modal not found');
  return null;
}

// Get only the modal content, excluding any embedded styles
const modalContent = critiqueModal.cloneNode(true) as HTMLElement;

// Remove style elements and SVGs from the clone
modalContent.querySelectorAll('style, svg, script').forEach(el => el.remove());

// Get clean text
const modalText = modalContent.textContent || '';
```

---

### Fix 5: Add Data Attribute to Critique Modal (App.tsx)

To make modal selection reliable, add a data attribute:

**Location:** `App.tsx` - critique modal rendering

```tsx
{showCritiqueReport && critiqueReport && (
  <div
    className="critique-report-modal"
    data-testid="critique-modal"
    role="dialog"
    aria-label="AI Critique Report"
  >
    {/* modal content */}
  </div>
)}
```

---

## Implementation Order

| Step | File | Function | Description |
|------|------|----------|-------------|
| 1 | `App.tsx` | Modal render | Add `data-testid="critique-modal"` |
| 2 | Test file | `sanitizeModalText()` | Add CSS/garbage filter |
| 3 | Test file | `extractCritiqueFromModal()` | Use dedicated selector, remove SVGs |
| 4 | Test file | `extractSectionFeedback()` | Match only valid epic sections |
| 5 | Test file | `extractIssuesForSection()` | Use proper issue patterns |
| 6 | Test file | `isValidFeedbackText()` | Add validation helper |

---

## Expected Results After Fix

### Before Fix:
```
Critique Quality Score: 45/100
Is Critique Relevant: NO ❌
Unmatched Sections: 8 (Code Commit, Build, Test, Deploy...)
Generic Feedback: 46
Vague Issues: "font-family:Frutiger...", "mermaid-hsu1iw1f1..."
```

### After Fix:
```
Critique Quality Score: 85/100
Is Critique Relevant: YES ✓
Matched Sections: 12 (Executive Summary, Business Context, Technical Scope...)
Specific Feedback: 15
Actionable Suggestions: 8
```

---

## Verification Steps

1. Run E2E test: `npm run test:e2e:headed`
2. Check report for:
   - No CSS/Mermaid content in issues
   - Section titles matching actual epic sections
   - Issues are complete sentences
   - Critique Quality Score > 70
3. Verify modal content is captured correctly in screenshots
