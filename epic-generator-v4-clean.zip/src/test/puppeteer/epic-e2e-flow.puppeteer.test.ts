/**
 * Epic Generator - E2E: Epic Editor → Refine with AI
 *
 * Simple flow:
 * 1. Open app → Sign in (mock auth)
 * 2. Configure OpenAI API key (auto or manual)
 * 3. Epic Editor → Paste epic content → Click Refine
 * 4. Wait for AI refinement → Save result
 *
 * Run modes:
 *   AUTO:   OPENAI_API_KEY=sk-... npm run test:e2e
 *   MANUAL: PUPPETEER_HEADLESS=false npm run test:e2e
 *           (enter API key in browser during 60s wait)
 */

import puppeteer, { Browser, Page } from 'puppeteer';
import { describe, test, expect, beforeAll, afterAll } from 'vitest';
import { writeFileSync, appendFileSync } from 'fs';
import { resolve } from 'path';

// ============================================
// CONFIG
// ============================================

const PORT = 3099;
const BASE_URL = `http://localhost:${PORT}`;
const HEADLESS = process.env.PUPPETEER_HEADLESS !== 'false';
const SLOW_MO = HEADLESS ? 0 : 20;

// Broadridge Cash Management — Data Mesh Onboarding
// Tests: requirement preservation, data pipeline diagrams, story coverage for all 7 requirements
const DRAFT_EPIC = `# Broadridge Cash Management — Data Mesh Onboarding

## Current Scenario
In our Data Mesh, we have an Azure Ingestion Container where data files come to the datafiles directory and Control Files come to the Controlfile directory after data file is received. The Control File is information about the data file having a single record containing Count, Business Date, Checksum etc which we use for validation that no data is lost when file coming from Upstream. We have a data pipeline which gets triggered by the Control File and reads both data file and control file and does all validation and writes as a parquet output file. It can handle csv, text, parquet file as input. The checksum handled in our pipeline is SHA256.

We have another process where:
1. Broadridge a third party sends a Cash Management data file to SFG which is a SFTP server
2. After datafile is sent, Broadridge sends a notification message to Kafka
3. ESL service pulls the file from SFG and puts the file on Axway
4. After ESL service puts the data in Axway it puts another notification on Kafka
5. This second Kafka Notification triggers MF Job
6. MF Job reads the data file which has records and fields enclosed in *. MF Job does the transformation using Java where it removes the * from fields and records.

We need to bring the Cash Management File to Data Mesh. We need to enhance our pipeline by incorporating the below features:

1. Enhance the existing pipeline to handle MD5 Checksum alongside SHA256 as Broadridge sends MD5 Checksum in Kafka Message. Our registry file needs to add another column which mentions which file needs which kind of checksum to be validated and based on that pipeline should use that validation.
2. Currently the pipeline reads CSV files and parses based on the delimiter in Registry. The Registry and pipeline needs to be modified to handle fields and records which are enclosed in * and parse and write to parquet.
3. Currently the file from Axway gets deleted after MF pulls the file from Axway. This needs to be modified so Datamesh pipeline can pull the file. The deletion in Axway needs to be disabled.
4. We need to create a Pipeline which will pull the file from Axway. This pipeline will read the file from Axway and Copy to our Ingestion/Datafiles as well as create the Control File from Kafka Message.
5. Set-up Process to Trigger the new pipeline when the Kafka Notification is put by ESL Service.
6. Use the schema file from Broadridge to enforce schema while creating the Parquet file.
7. Set-up Connection between Datamesh and Axway.

The existing file process to Mainframe will remain not to disturb current Mainframe Downstream Consumption. New Consumers like DHARMA and others will consume files from MESH.`;

// The 7 requirements that MUST appear in the output
const REQUIRED_TOPICS = [
  { id: 'Req1', keyword: 'md5', description: 'MD5 checksum support alongside SHA256' },
  { id: 'Req2', keyword: 'enclosed in', altKeyword: 'enclos', description: 'Parse *-enclosed fields/records' },
  { id: 'Req3', keyword: 'delet', description: 'Disable Axway file deletion after MF pull' },
  { id: 'Req4', keyword: 'control file from kafka', altKeyword: 'kafka m', description: 'Create Control File from Kafka message' },
  { id: 'Req5', keyword: 'kafka notification', altKeyword: 'kafka trigger', description: 'Kafka-triggered pipeline' },
  { id: 'Req6', keyword: 'schema file', altKeyword: 'enforce schema', description: 'Enforce Broadridge schema on Parquet' },
  { id: 'Req7', keyword: 'connection between', altKeyword: 'connectivity', description: 'Set up Axway-DataMesh connectivity' },
];

// ============================================
// HELPERS
// ============================================

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

/** Log file for this test run */
const LOG_FILE = resolve(process.cwd(), 'e2e-test-run.log');
const testStartTime = Date.now();

function log(msg: string) {
  const elapsed = ((Date.now() - testStartTime) / 1000).toFixed(1);
  const line = `[${elapsed}s] ${msg}`;
  console.log(line);
  appendFileSync(LOG_FILE, line + '\n');
}

// Initialize log file
writeFileSync(LOG_FILE, `=== E2E Test Run: ${new Date().toISOString()} ===\n`);

/** Click a button by its visible text */
async function clickButton(page: Page, text: string, timeout = 5_000): Promise<boolean> {
  try {
    await page.waitForFunction(
      (t: string) => {
        const buttons = document.querySelectorAll('button');
        for (const btn of buttons) {
          if (btn.textContent?.includes(t) && !btn.hasAttribute('disabled')) return true;
        }
        return false;
      },
      { timeout },
      text
    );

    return await page.evaluate((t: string) => {
      const buttons = document.querySelectorAll('button');
      for (const btn of buttons) {
        if (btn.textContent?.includes(t) && !btn.hasAttribute('disabled')) {
          (btn as HTMLElement).click();
          return true;
        }
      }
      return false;
    }, text);
  } catch {
    return false;
  }
}

// ============================================
// TESTS
// ============================================

describe('Epic E2E: Editor → Refine with AI', () => {
  let browser: Browser;
  let page: Page;

  beforeAll(async () => {
    browser = await puppeteer.launch({
      headless: HEADLESS,
      slowMo: SLOW_MO,
      args: ['--no-sandbox', '--disable-setuid-sandbox', '--window-size=1440,900'],
      defaultViewport: { width: 1440, height: 900 },
    });

    page = await browser.newPage();
    page.setDefaultTimeout(30_000);

    page.on('console', msg => {
      const text = msg.text();
      if (msg.type() === 'error') {
        if (!text.includes('404') && !text.includes('favicon')) {
          log(`[BROWSER ERROR] ${text}`);
        }
      }
      // Capture pipeline stage progress logs
      if (text.includes('[Stage') || text.includes('[Pipeline') || text.includes('[Smart Refine') || text.includes('[Premium')) {
        log(`[PIPELINE] ${text.substring(0, 200)}`);
      }
    });
  }, 30_000);

  afterAll(async () => {
    if (page) await page.close();
    if (browser) await browser.close();
  });

  // ----------------------------------------
  // TEST 1: Open app and authenticate
  // ----------------------------------------
  test('Step 1: Open app and sign in', async () => {
    await page.goto(BASE_URL, { waitUntil: 'networkidle2' });

    // Clear stale AI config from previous runs
    await page.evaluate(() => {
      const keysToRemove = [];
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && (key.includes('ai') || key.includes('openai') || key.includes('azure') || key.includes('config') || key.includes('provider'))) {
          keysToRemove.push(key);
        }
      }
      keysToRemove.forEach(k => localStorage.removeItem(k));
    });
    log('  Cleared previous AI config from localStorage');

    await page.reload({ waitUntil: 'networkidle2' });

    const pageContent = await page.content();
    if (pageContent.includes('Sign in with Microsoft')) {
      log('  Auth wall detected — clicking Sign in...');
      await clickButton(page, 'Sign in with Microsoft', 10_000);
      await delay(3000);
      log('  Mock auth complete');
    }

    await page.waitForFunction(
      () => document.body.innerText.includes('FRAME') || document.body.innerText.includes('Epic Planner'),
      { timeout: 10_000 }
    );
    log('✓ App loaded successfully');
  }, 30_000);

  // ----------------------------------------
  // TEST 2: Configure OpenAI API key
  // ----------------------------------------
  test('Step 2: Configure OpenAI API key', async () => {
    const apiKey = process.env.OPENAI_API_KEY || '';

    if (apiKey) {
      // Auto-configure: set OpenAI config directly in localStorage
      log(`  Auto-configuring OpenAI (key: ${apiKey.substring(0, 7)}...${apiKey.substring(apiKey.length - 4)})`);

      await page.evaluate((key: string) => {
        const config = {
          aiProvider: 'openai',
          openAI: {
            enabled: true,
            apiKey: key,
            model: 'gpt-4o',
            organizationId: '',
            maxTokens: 4096,
            temperature: 0.7,
            baseUrl: 'https://api.openai.com/v1',
          },
          azureOpenAI: {
            enabled: false,
            endpoint: '',
            deploymentName: '',
            apiKey: '',
            apiVersion: '2024-02-15-preview',
            maxTokens: 4096,
            temperature: 0.7,
          },
          gitlab: {
            enabled: false,
            baseUrl: 'http://devcloud.ubs.net',
            projectId: '',
            accessToken: '',
            branch: 'main',
            epicFilePath: 'docs/epics/',
            rootGroupId: '557797',
            selectedPodId: '',
            selectedEpicId: '',
            crewLabelPrefix: 'crew::',
            podLabelPrefix: 'pod::',
            authMode: 'pat',
            oauthClientId: '',
          },
        };
        localStorage.setItem('epic-generator-config', JSON.stringify(config));
      }, apiKey);

      // Reload to pick up the new config
      await page.reload({ waitUntil: 'networkidle2' });
      await delay(1000);

      // Handle auth wall after reload
      const pageContent = await page.content();
      if (pageContent.includes('Sign in with Microsoft')) {
        await clickButton(page, 'Sign in with Microsoft', 10_000);
        await delay(3000);
      }

      log('  ✓ OpenAI configured via env var');
    } else {
      // Manual mode: open Settings and wait for user to enter API key
      log('  No OPENAI_API_KEY env var — switching to manual mode');

      const settingsClicked = await clickButton(page, 'Settings', 5_000);
      if (settingsClicked) {
        log('  Settings tab opened');
      }
      await delay(1000);

      log('');
      log('╔══════════════════════════════════════════════════════════════╗');
      log('║                                                              ║');
      log('║   WAITING 60 SECONDS — Please configure AI in the browser   ║');
      log('║                                                              ║');
      log('║   1. Click "OpenAI" in the AI Provider section               ║');
      log('║   2. Paste your API key (sk-...) in the API Key field        ║');
      log('║   3. Settings auto-save — just wait for countdown            ║');
      log('║                                                              ║');
      log('║   TIP: Set OPENAI_API_KEY env var for auto-configure         ║');
      log('║                                                              ║');
      log('╚══════════════════════════════════════════════════════════════╝');
      log('');

      for (let i = 60; i > 0; i -= 10) {
        log(`  ⏳ ${i} seconds remaining...`);
        await delay(10_000);
      }

      log('  ✓ Wait complete');
    }

    // Verify AI is enabled by checking the config in localStorage
    const aiEnabled = await page.evaluate(() => {
      const stored = localStorage.getItem('epic-generator-config');
      if (stored) {
        const cfg = JSON.parse(stored);
        return (cfg.aiProvider === 'openai' && cfg.openAI?.enabled) ||
               (cfg.aiProvider === 'azure' && cfg.azureOpenAI?.enabled) ||
               cfg.openAI?.enabled || cfg.azureOpenAI?.enabled;
      }
      return false;
    });

    log(`  AI enabled in config: ${aiEnabled}`);
    if (!aiEnabled) {
      log('  ⚠ WARNING: AI not configured — Refine button will not appear!');
    }

    log('✓ Step 2 complete');
  }, 120_000);

  // ----------------------------------------
  // TEST 3: Go to Epic Editor, paste content, click Refine
  // ----------------------------------------
  test('Step 3: Paste epic into editor and refine with AI', async () => {
    // Navigate to Epic Editor tab
    log('  Navigating to Epic Editor tab...');

    // Log all visible buttons for debugging
    const visibleButtons = await page.evaluate(() => {
      const buttons = document.querySelectorAll('button');
      return Array.from(buttons).map(b => b.textContent?.trim().replace(/\s+/g, ' ') || '').filter(t => t.length > 0 && t.length < 50);
    });
    log(`  Visible buttons: ${visibleButtons.join(' | ')}`);

    // Click "Epic Editor" tab button (use exact text to avoid ambiguity)
    const epicClicked = await clickButton(page, 'Epic Editor', 5_000);
    log(`  Epic Editor click result: ${epicClicked}`);

    if (!epicClicked) {
      // Fallback: try clicking via evaluate with more flexible matching
      log('  Fallback: trying direct DOM click...');
      await page.evaluate(() => {
        const buttons = document.querySelectorAll('button');
        for (const btn of buttons) {
          const text = btn.textContent?.trim().replace(/\s+/g, ' ') || '';
          if (text.includes('Epic Editor')) {
            (btn as HTMLElement).click();
            return;
          }
        }
      });
    }
    await delay(1500);

    // Take a debug screenshot to see current state
    const navScreenshot = resolve(process.cwd(), 'e2e-after-nav.png');
    await page.screenshot({ path: navScreenshot, fullPage: false });
    log(`  Navigation screenshot: ${navScreenshot}`);

    // Check what tab we're on
    const pageState = await page.evaluate(() => {
      const body = document.body.innerText;
      return {
        hasTextarea: document.querySelectorAll('textarea').length,
        hasNoEpicLoaded: body.includes('No Epic Loaded'),
        hasStartWriting: body.includes('Start writing'),
        bodySnippet: body.substring(0, 200).replace(/\s+/g, ' '),
      };
    });
    log(`  Page state: textareas=${pageState.hasTextarea}, noEpicLoaded=${pageState.hasNoEpicLoaded}`);

    // Find the epic editor textarea and focus it
    const editorPlaceholder = 'Start writing your epic here, or load one from GitLab...';
    await page.waitForFunction(
      (ph: string) => {
        const els = document.querySelectorAll('textarea');
        for (const el of els) {
          if (el.getAttribute('placeholder') === ph) return true;
        }
        return false;
      },
      { timeout: 15_000 },
      editorPlaceholder
    );
    log('  Found epic editor textarea');

    // Focus the textarea and paste the draft epic content
    await page.evaluate((ph: string, content: string) => {
      const els = document.querySelectorAll('textarea');
      for (const el of els) {
        if (el.getAttribute('placeholder') === ph) {
          el.scrollIntoView({ block: 'center' });
          el.focus();
          // Use native setter to set the value, then dispatch React-compatible events
          const nativeSetter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')?.set;
          if (nativeSetter) {
            nativeSetter.call(el, content);
            el.dispatchEvent(new Event('input', { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
          }
          break;
        }
      }
    }, editorPlaceholder, DRAFT_EPIC);

    await delay(500);

    // Verify content was set
    const contentLength = await page.evaluate((ph: string) => {
      const els = document.querySelectorAll('textarea');
      for (const el of els) {
        if (el.getAttribute('placeholder') === ph) return el.value.length;
      }
      return 0;
    }, editorPlaceholder);

    log(`  ✓ Epic content pasted into editor (${contentLength} chars)`);
    expect(contentLength).toBeGreaterThan(10);

    await delay(1000);

    // Wait for Refine button to appear (requires AI to be enabled)
    log('  Waiting for Refine button...');
    try {
      await page.waitForFunction(
        () => {
          const buttons = document.querySelectorAll('button');
          for (const btn of buttons) {
            const text = btn.textContent?.trim() || '';
            if (text === 'Refine' && !btn.hasAttribute('disabled')) return true;
          }
          return false;
        },
        { timeout: 10_000 }
      );
      log('  Refine button found');
    } catch {
      // Log visible buttons for debugging
      const btns = await page.evaluate(() => {
        return Array.from(document.querySelectorAll('button'))
          .map(b => b.textContent?.trim().replace(/\s+/g, ' ') || '')
          .filter(t => t.length > 0 && t.length < 30);
      });
      log(`  ⚠ Refine button NOT found! Visible buttons: ${btns.join(' | ')}`);
      log('  ⚠ This usually means AI is not configured. Set OPENAI_API_KEY env var.');
      throw new Error('Refine button not found — AI not configured');
    }

    // Click Refine button (Premium Pipeline)
    log('  Clicking Refine...');
    const refineClicked = await clickButton(page, 'Refine', 5_000);
    log(`  Refine click result: ${refineClicked}`);

    log('  ✓ Refine clicked — waiting for AI pipeline...');
    log('  This may take 2-5 minutes...');

    // Wait for the refine pipeline to complete
    // The "Refine" button text changes while running, then returns to "Refine"
    try {
      // First wait for it to START (button changes from "Refine")
      await page.waitForFunction(
        () => {
          const buttons = document.querySelectorAll('button');
          for (const btn of buttons) {
            if (btn.textContent?.includes('Running') || btn.textContent?.includes('Refining') || btn.textContent?.includes('Analyzing')) return true;
          }
          return false;
        },
        { timeout: 10_000 }
      );
      log('  Pipeline started...');
    } catch {
      log('  (Pipeline may have started — watching for completion)');
    }

    // Now wait for it to FINISH
    try {
      await page.waitForFunction(
        () => {
          // Check the smart refine overlay is gone
          const bodyText = document.body.innerText;
          if (bodyText.includes('Refining Epic...')) return false;
          if (bodyText.includes('Running Premium')) return false;
          if (bodyText.includes('Running...')) return false;
          // Check refine button is back and clickable
          const buttons = document.querySelectorAll('button');
          for (const btn of buttons) {
            if (btn.textContent?.trim() === 'Refine' && !btn.hasAttribute('disabled')) return true;
          }
          return false;
        },
        { timeout: 600_000 } // 10 min max
      );
      log('  ✓ Pipeline complete!');
    } catch {
      log('  ⚠ Pipeline timed out after 10 minutes');
    }

    await delay(2000);

    // Extract the refined epic
    const refinedContent = await page.evaluate((ph: string) => {
      const els = document.querySelectorAll('textarea');
      for (const el of els) {
        if (el.getAttribute('placeholder') === ph) return el.value;
      }
      return '';
    }, editorPlaceholder);

    log(`  Refined epic: ${refinedContent.length} chars, ${refinedContent.split('\n').length} lines`);

    if (refinedContent && refinedContent.length > 100) {
      const outPath = resolve(process.cwd(), 'generated-epic-e2e.md');
      writeFileSync(outPath, refinedContent, 'utf-8');
      log(`  ✓ Saved to: ${outPath}`);
    }

    // Screenshot
    const screenshotPath = resolve(process.cwd(), 'e2e-final-state.png');
    await page.screenshot({ path: screenshotPath, fullPage: false });
    log(`  Screenshot: ${screenshotPath}`);

    expect(refinedContent.length).toBeGreaterThan(100);

    // =============================================
    // QUALITY VALIDATION — check refined output
    // =============================================
    const content = refinedContent.toLowerCase();

    // Q1: ALL 7 requirements must be mentioned in the output
    log('  === REQUIREMENT COVERAGE ===');
    let reqsCovered = 0;
    const reqsMissing: string[] = [];
    for (const req of REQUIRED_TOPICS) {
      const found = content.includes(req.keyword) || (req.altKeyword && content.includes(req.altKeyword));
      if (found) {
        reqsCovered++;
        log(`  ✓ ${req.id}: ${req.description}`);
      } else {
        reqsMissing.push(req.id);
        log(`  ✗ ${req.id}: ${req.description} — MISSING`);
      }
    }
    log(`  Requirements covered: ${reqsCovered}/${REQUIRED_TOPICS.length}`);

    // Q2: Diagram should NOT contain generic template components
    const genericDiagramTerms = ['stripe', 'sendgrid', 'oauth provider', 'mobile app'];
    const genericInDiagram: string[] = [];
    for (const term of genericDiagramTerms) {
      if (content.includes(term)) {
        genericInDiagram.push(term);
      }
    }
    log(`  [Q2] Generic template components in output: ${genericInDiagram.length} — ${genericInDiagram.join(', ') || 'none'}`);

    // Q3: Diagram should contain project-specific terms
    const diagramExpectedTerms = ['broadridge', 'axway', 'kafka', 'azure', 'parquet'];
    const diagramTermsFound: string[] = [];
    for (const term of diagramExpectedTerms) {
      if (content.includes(term)) {
        diagramTermsFound.push(term);
      }
    }
    log(`  [Q3] Project-specific terms: ${diagramTermsFound.length}/${diagramExpectedTerms.length} — ${diagramTermsFound.join(', ')}`);

    // Q4: Check for filler phrases
    const fillerPhrases = [
      'this is crucial for', 'this approach ensures', 'in today\'s fast-paced',
      'this comprehensive approach', 'leveraging cutting-edge', 'best-in-class',
    ];
    const fillerFound = fillerPhrases.filter(p => content.includes(p));
    log(`  [Q4] Filler phrases: ${fillerFound.length} — ${fillerFound.join(', ') || 'none'}`);

    // Q5: User stories should cover requirements (check story content)
    const storyPointMatches = refinedContent.match(/\[\d+pt\]/g) || [];
    log(`  [Q5] Stories with point estimates: ${storyPointMatches.length}`);

    // Q6: Should NOT declare user requirements as "out of scope" or "non-goal"
    const badScopeDecisions = ['not redesigning', 'no pipeline changes', 'not changing', 'polling'];
    const wrongDecisions = badScopeDecisions.filter(d => content.includes(d));
    log(`  [Q6] Wrong scope decisions: ${wrongDecisions.length} — ${wrongDecisions.join(', ') || 'none'}`);

    // Q7: Section count
    const sectionHeaders = refinedContent.match(/^##\s+/gm) || [];
    log(`  [Q7] Total ## sections: ${sectionHeaders.length}`);

    // Q8: Decision/Tradeoff mechanical pattern count
    const decisionTradeoffMatches = refinedContent.match(/\*\*Decision\*\*:|Decision:|Tradeoff:|__Decision__:|__Tradeoff__:/gi) || [];
    log(`  [Q8] "Decision/Tradeoff" mechanical patterns: ${decisionTradeoffMatches.length} (target: 0)`);

    // Q9: Diagram type should be flowchart for data pipeline, NOT sankey
    const diagramBlock = refinedContent.match(/```mermaid\n([\s\S]*?)```/);
    const diagramType = diagramBlock ? diagramBlock[1].trim().split('\n').find(l => !l.startsWith('%%'))?.trim() : 'unknown';
    const isSankey = diagramType?.startsWith('sankey');
    log(`  [Q9] Diagram type: ${diagramType?.substring(0, 30)} — ${isSankey ? 'BAD (sankey for data pipeline)' : 'OK'}`);

    // Q10: Story grammar — "I want [verb]" should be "I want to [verb]"
    // Match "I want" followed by a word that is NOT "to" (catches both "I want Validate" and "I want validate")
    const storyGoalMatches = refinedContent.match(/I want\s+(?!to\s)[a-zA-Z]+/g) || [];
    log(`  [Q10] Story grammar issues ("I want [verb]" missing "to"): ${storyGoalMatches.length} — ${storyGoalMatches.slice(0, 3).join(', ') || 'none'}`);

    // Summary
    log('');
    log('  === QUALITY SUMMARY ===');
    log(`  Requirements covered: ${reqsCovered}/${REQUIRED_TOPICS.length} ${reqsMissing.length > 0 ? '— MISSING: ' + reqsMissing.join(', ') : ''}`);
    log(`  Generic template components: ${genericInDiagram.length} (target: 0)`);
    log(`  Project terms found: ${diagramTermsFound.length}/${diagramExpectedTerms.length}`);
    log(`  Filler phrases: ${fillerFound.length} (target: 0)`);
    log(`  Story points: ${storyPointMatches.length}`);
    log(`  Wrong scope decisions: ${wrongDecisions.length} (target: 0)`);
    log(`  Decision/Tradeoff patterns: ${decisionTradeoffMatches.length} (target: 0)`);
    log(`  Diagram type: ${isSankey ? 'FAIL (sankey)' : 'OK'}`);
    log(`  Story grammar issues: ${storyGoalMatches.length} (target: 0)`);
    log(`  Sections: ${sectionHeaders.length}`);
    log('  ========================');

  }, 900_000); // 15 min timeout (60s setup + 10 min pipeline + buffer)

  // ----------------------------------------
  // TEST 4: Open Issue Modal and create issues
  // ----------------------------------------
  test('Step 4: Create issues from user stories', async () => {
    log('  === Step 4: Issue Creation from User Stories ===');

    // The "Issues" button requires mock mode (MOCK_GITLAB_ENABLED=true) or GitLab enabled
    // Mock mode is already on (shouldUseMockGitLab() returns true)

    // Check if "Issues" button exists and is enabled
    log('  Looking for Issues button...');
    const issuesButtonExists = await page.evaluate(() => {
      const buttons = document.querySelectorAll('button');
      for (const btn of buttons) {
        const text = btn.textContent?.trim() || '';
        if (text === 'Issues') {
          return { found: true, disabled: btn.hasAttribute('disabled') };
        }
      }
      return { found: false, disabled: true };
    });

    log(`  Issues button: found=${issuesButtonExists.found}, disabled=${issuesButtonExists.disabled}`);

    if (!issuesButtonExists.found) {
      log('  ⚠ Issues button not found — skipping issue creation test');
      return;
    }

    if (issuesButtonExists.disabled) {
      log('  ⚠ Issues button disabled — mock mode may not be active');
      return;
    }

    // Click the Issues button
    const issuesClicked = await clickButton(page, 'Issues', 5_000);
    log(`  Issues button clicked: ${issuesClicked}`);
    await delay(2000);

    // Take screenshot of the modal
    const modalScreenshot = resolve(process.cwd(), 'e2e-issue-modal.png');
    await page.screenshot({ path: modalScreenshot, fullPage: false });
    log(`  Modal screenshot: ${modalScreenshot}`);

    // Wait for the Issue modal to appear
    const modalVisible = await page.waitForFunction(
      () => {
        const body = document.body.innerText;
        return body.includes('Create Issues from User Stories') || body.includes('User Stories');
      },
      { timeout: 10_000 }
    ).then(() => true).catch(() => false);

    if (!modalVisible) {
      // Check if we got a toast error instead
      const toastText = await page.evaluate(() => {
        const toasts = document.querySelectorAll('[class*="toast"], [role="alert"]');
        return Array.from(toasts).map(t => t.textContent?.trim()).join(' | ');
      });
      log(`  ⚠ Modal didn't appear. Toast: ${toastText || 'none'}`);

      // Even if modal didn't appear, verify parseUserStoriesFromEpic works in the browser
      const parseResult = await page.evaluate(() => {
        // Check browser console for parse output
        return document.body.innerText.substring(0, 500);
      });
      log(`  Page state: ${parseResult.substring(0, 200)}`);
      expect(modalVisible).toBe(true);
      return;
    }

    log('  ✓ Issue creation modal opened');

    // Verify stories are parsed and displayed in the modal
    const modalContent = await page.evaluate(() => {
      const body = document.body.innerText;
      // Count how many US-XXX patterns appear in the modal
      const storyMatches = body.match(/US-\d{3}/g) || [];
      // Check for story titles
      const hasStoryContent = body.includes('As a') || body.includes('I want');
      return {
        storyCount: storyMatches.length,
        hasStoryContent,
        snippet: body.substring(body.indexOf('Create Issues'), body.indexOf('Create Issues') + 800).replace(/\s+/g, ' ')
      };
    });

    log(`  Stories in modal: ${modalContent.storyCount}`);
    log(`  Has story content: ${modalContent.hasStoryContent}`);
    log(`  Modal snippet: ${modalContent.snippet.substring(0, 300)}`);

    expect(modalContent.storyCount).toBeGreaterThan(0);

    // Check if stories are correctly parsed (not garbled)
    const storyDetails = await page.evaluate(() => {
      // Look for story checkboxes or list items in the modal
      const allText = document.body.innerText;
      const stories: string[] = [];
      const lines = allText.split('\n');
      for (const line of lines) {
        if (line.includes('US-') && (line.includes('As a') || line.includes('I want') || line.trim().length > 20)) {
          stories.push(line.trim().substring(0, 120));
        }
      }
      return stories;
    });

    log(`  Parsed story details (${storyDetails.length} found):`);
    storyDetails.forEach((s, i) => log(`    [${i}] ${s}`));

    // Verify stories are parsed — input has 5 original + AI may add more
    expect(storyDetails.length).toBeGreaterThan(0);

    // Now try to create issues — click "Create X Issues" button
    // First check if there's a "Select All" button to select all stories
    const selectAllClicked = await page.evaluate(() => {
      const buttons = document.querySelectorAll('button');
      for (const btn of buttons) {
        const text = btn.textContent?.trim() || '';
        if (text.includes('Select All') && !btn.hasAttribute('disabled')) {
          (btn as HTMLElement).click();
          return true;
        }
      }
      return false;
    });
    log(`  Select All clicked: ${selectAllClicked}`);
    await delay(500);

    // Find and click the "Create X Issues" button
    log('  Looking for Create Issues button...');
    const createButtonInfo = await page.evaluate(() => {
      const buttons = document.querySelectorAll('button');
      for (const btn of buttons) {
        const text = btn.textContent?.trim() || '';
        if (text.includes('Create') && text.includes('Issue') && !btn.hasAttribute('disabled')) {
          return { found: true, text, disabled: false };
        }
      }
      // Also check disabled state
      for (const btn of buttons) {
        const text = btn.textContent?.trim() || '';
        if (text.includes('Create') && text.includes('Issue')) {
          return { found: true, text, disabled: btn.hasAttribute('disabled') };
        }
      }
      return { found: false, text: '', disabled: true };
    });

    log(`  Create button: found=${createButtonInfo.found}, text="${createButtonInfo.text}", disabled=${createButtonInfo.disabled}`);

    if (createButtonInfo.found && !createButtonInfo.disabled) {
      // Click Create Issues
      const createClicked = await page.evaluate(() => {
        const buttons = document.querySelectorAll('button');
        for (const btn of buttons) {
          const text = btn.textContent?.trim() || '';
          if (text.includes('Create') && text.includes('Issue') && !btn.hasAttribute('disabled')) {
            (btn as HTMLElement).click();
            return true;
          }
        }
        return false;
      });
      log(`  Create Issues clicked: ${createClicked}`);

      // Wait for issue creation to complete (mock mode is fast)
      // Look for success toast or progress completion
      await page.waitForFunction(
        () => {
          const body = document.body.innerText;
          return body.includes('Issues Created') ||
                 body.includes('Created') ||
                 body.includes('Error') ||
                 body.includes('Failed');
        },
        { timeout: 120_000 } // 2 min — AI generates descriptions for each issue
      ).catch(() => log('  ⚠ Timed out waiting for issue creation'));

      await delay(2000);

      // Take final screenshot
      const finalScreenshot = resolve(process.cwd(), 'e2e-issues-created.png');
      await page.screenshot({ path: finalScreenshot, fullPage: false });
      log(`  Final screenshot: ${finalScreenshot}`);

      // Check for success/error
      const result = await page.evaluate(() => {
        const body = document.body.innerText;
        const hasSuccess = body.includes('Issues Created');
        const hasError = body.includes('Error') || body.includes('Failed');
        // Look for mock GitLab log messages
        return { hasSuccess, hasError, snippet: body.substring(0, 300) };
      });

      log(`  Result: success=${result.hasSuccess}, error=${result.hasError}`);

      if (result.hasSuccess) {
        log('  ✓ Issues created successfully!');
      } else if (result.hasError) {
        log('  ⚠ Issue creation had errors');
      }

      // At minimum, verify the modal worked and didn't crash
      expect(result.hasSuccess || result.hasError).toBe(true);
    } else {
      log('  ⚠ Create Issues button not clickable — stories may not be selected');
      // Still a success that the modal opened and showed stories
    }

    log('  ✓ Step 4 complete');
  }, 300_000); // 5 min timeout
});
