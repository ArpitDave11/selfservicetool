/**
 * AI Refinement Functions Tests
 *
 * Tests for:
 * 1. aiRefineField - AI-powered field refinement
 * 2. generateUserStories - Generates 15-20 user stories
 * 3. generateNFRs - Generates non-functional requirements
 * 4. generateRisks - Generates project risks
 * 5. generateSecurityRequirements - Generates security requirements
 * 6. refineInput - Main skill that delegates to specialized generators
 */

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import type { AppConfig } from '../config';

// Mock the config module - must be before imports
vi.mock('../config', () => ({
  callAI: vi.fn(),
}));

// Import after mocking
import { callAI } from '../config';
import {
  setConfig,
  aiRefineField,
  generateUserStories,
  generateNFRs,
  generateRisks,
  generateSecurityRequirements,
  runSkill,
} from '../skills';

// Type-safe mock
const mockCallAI = callAI as ReturnType<typeof vi.fn>;

// Mock AppConfig for testing
const createMockConfig = (aiEnabled: boolean = true): AppConfig => ({
  aiProvider: aiEnabled ? 'openai' : 'none',
  openAI: {
    enabled: aiEnabled,
    apiKey: 'sk-test-key',
    model: 'gpt-4o',
    maxTokens: 4096,
    temperature: 0.7,
    baseUrl: 'https://api.openai.com/v1',
  },
  azureOpenAI: {
    enabled: false,
    endpoint: '',
    deploymentName: '',
    apiKey: '',
    apiVersion: '2024-02-15-preview',
    maxTokens: 4096,
    temperature: 0.7,
  },
  gitlab: {
    enabled: false,
    baseUrl: '',
    projectId: '',
    accessToken: '',
    branch: '',
    epicFilePath: '',
    rootGroupId: '',
    selectedPodId: '',
    selectedEpicId: '',
    crewLabelPrefix: 'crew::',
    podLabelPrefix: 'pod::',
  },
});

// Sample context for testing
const sampleContext: Record<string, string> = {
  projectName: 'E-Commerce Platform',
  objective: 'Build a modern e-commerce platform with real-time inventory',
  features: '1. Shopping cart\n2. Payment processing\n3. Inventory management',
  architectureOverview: 'Microservices architecture with React frontend and Node.js backend',
  inScope: '- Product catalog\n- User authentication\n- Order processing',
  dataStores: 'PostgreSQL for main data, Redis for caching',
  dependencies: 'Payment gateway API, Shipping provider API',
};

describe('AI Refinement Functions', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  afterEach(() => {
    // Reset config to null after each test by casting
    // This ensures clean state between tests
    (setConfig as (c: AppConfig | null) => void)(null as unknown as AppConfig);
  });

  // ===========================================
  // aiRefineField Tests
  // ===========================================
  describe('aiRefineField', () => {
    describe('when AI config is available', () => {
      beforeEach(() => {
        setConfig(createMockConfig(true));
      });

      it('should call AI with correct prompts for background field', async () => {
        const mockResponse = 'Enhanced background with business justification';
        mockCallAI.mockResolvedValueOnce(mockResponse);

        const result = await aiRefineField('background', 'Initial background', sampleContext);

        expect(mockCallAI).toHaveBeenCalledTimes(1);
        expect(result).toBe(mockResponse);

        // Verify system prompt contains key instructions
        const systemPrompt = mockCallAI.mock.calls[0][1];
        expect(systemPrompt).toContain('expert technical writer');
        expect(systemPrompt).toContain('DO NOT duplicate');
      });

      it('should include context in user prompt', async () => {
        mockCallAI.mockResolvedValueOnce('Enhanced content');

        await aiRefineField('objective', 'Build a platform', sampleContext);

        const userPrompt = mockCallAI.mock.calls[0][2];
        expect(userPrompt).toContain('E-Commerce Platform');
        expect(userPrompt).toContain('Microservices architecture');
      });

      it('should handle different field types with specific prompts', async () => {
        const fields = ['inScope', 'outOfScope', 'assumptions', 'features', 'deliverables'];

        for (const field of fields) {
          mockCallAI.mockResolvedValueOnce(`Enhanced ${field}`);
          await aiRefineField(field, `Test ${field}`, sampleContext);
        }

        expect(mockCallAI).toHaveBeenCalledTimes(fields.length);
      });

      it('should return trimmed response from AI', async () => {
        mockCallAI.mockResolvedValueOnce('  Enhanced content with whitespace  \n\n');

        const result = await aiRefineField('background', 'input', sampleContext);

        expect(result).toBe('Enhanced content with whitespace');
      });
    });

    describe('when AI config is not available (null)', () => {
      beforeEach(() => {
        // Don't set any config - currentConfig remains null
        (setConfig as (c: AppConfig | null) => void)(null as unknown as AppConfig);
      });

      it('should return original input as fallback', async () => {
        const originalInput = 'Original user input';
        const result = await aiRefineField('background', originalInput, sampleContext);

        expect(result).toBe(originalInput);
        expect(mockCallAI).not.toHaveBeenCalled();
      });

      it('should not make AI calls', async () => {
        await aiRefineField('objective', 'Some objective', sampleContext);

        expect(mockCallAI).not.toHaveBeenCalled();
      });
    });

    describe('error handling', () => {
      beforeEach(() => {
        setConfig(createMockConfig(true));
      });

      it('should return original input when AI call fails', async () => {
        mockCallAI.mockRejectedValueOnce(new Error('API Error'));

        const originalInput = 'Original content';
        const result = await aiRefineField('background', originalInput, sampleContext);

        expect(result).toBe(originalInput);
      });

      it('should log error when AI call fails', async () => {
        const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
        mockCallAI.mockRejectedValueOnce(new Error('Network timeout'));

        await aiRefineField('objective', 'Test', sampleContext);

        expect(consoleSpy).toHaveBeenCalled();
        const errorCall = consoleSpy.mock.calls[0];
        expect(errorCall[0]).toContain('aiRefineField');
        consoleSpy.mockRestore();
      });
    });

    describe('empty input handling', () => {
      beforeEach(() => {
        setConfig(createMockConfig(true));
      });

      it('should handle empty string input', async () => {
        mockCallAI.mockResolvedValueOnce('Generated content for empty input');

        const result = await aiRefineField('background', '', sampleContext);

        expect(result).toBe('Generated content for empty input');
        // Verify the prompt indicates empty content
        const userPrompt = mockCallAI.mock.calls[0][2];
        expect(userPrompt).toContain('(empty)');
      });

      it('should handle whitespace-only input', async () => {
        mockCallAI.mockResolvedValueOnce('Generated content');

        await aiRefineField('background', '   ', sampleContext);

        expect(mockCallAI).toHaveBeenCalled();
      });
    });
  });

  // ===========================================
  // generateUserStories Tests
  // ===========================================
  describe('generateUserStories', () => {
    describe('when AI config is available', () => {
      beforeEach(() => {
        setConfig(createMockConfig(true));
      });

      it('should generate user stories from context', async () => {
        const mockStories = `### Shopping Cart Stories
As a customer, I want to add items to my cart, so that I can purchase multiple items at once.
As a customer, I want to update quantities in my cart, so that I can adjust my order.`;

        mockCallAI.mockResolvedValueOnce(mockStories);

        const result = await generateUserStories(sampleContext);

        expect(result).toBe(mockStories);
        expect(mockCallAI).toHaveBeenCalledTimes(1);
      });

      it('should include system prompt for 15-20 stories', async () => {
        mockCallAI.mockResolvedValueOnce('Stories');

        await generateUserStories(sampleContext);

        const systemPrompt = mockCallAI.mock.calls[0][1];
        expect(systemPrompt).toContain('15-20');
        expect(systemPrompt).toContain('As a');
      });

      it('should include project features in user prompt', async () => {
        mockCallAI.mockResolvedValueOnce('Stories');

        await generateUserStories(sampleContext);

        const userPrompt = mockCallAI.mock.calls[0][2];
        expect(userPrompt).toContain('Shopping cart');
        expect(userPrompt).toContain('Payment processing');
      });
    });

    describe('existing content handling', () => {
      beforeEach(() => {
        setConfig(createMockConfig(true));
      });

      it('should append new stories to existing ones', async () => {
        const existingStories = 'As a user, I want to login, so that I can access my account.';
        const newStories = 'As a user, I want to checkout, so that I can complete my purchase.';

        mockCallAI.mockResolvedValueOnce(newStories);

        const result = await generateUserStories(sampleContext, existingStories);

        expect(result).toContain(existingStories);
        expect(result).toContain('Additional User Stories');
        expect(result).toContain(newStories);
      });

      it('should instruct AI not to duplicate existing stories', async () => {
        const existingStories = 'Existing story content';
        mockCallAI.mockResolvedValueOnce('New stories');

        await generateUserStories(sampleContext, existingStories);

        const userPrompt = mockCallAI.mock.calls[0][2];
        expect(userPrompt).toContain('DO NOT DUPLICATE');
        expect(userPrompt).toContain(existingStories);
      });

      it('should return only AI response when no existing stories', async () => {
        mockCallAI.mockResolvedValueOnce('Brand new stories');

        const result = await generateUserStories(sampleContext, '');

        expect(result).toBe('Brand new stories');
        expect(result).not.toContain('Additional User Stories');
      });
    });

    describe('fallback behavior when no config', () => {
      beforeEach(() => {
        // Clear config
        (setConfig as (c: AppConfig | null) => void)(null as unknown as AppConfig);
      });

      it('should return existing stories when no AI config', async () => {
        const existingStories = 'Existing user stories';
        const result = await generateUserStories(sampleContext, existingStories);

        expect(result).toBe(existingStories);
        expect(mockCallAI).not.toHaveBeenCalled();
      });

      it('should return default message when no AI config and no existing', async () => {
        const result = await generateUserStories(sampleContext, '');

        expect(result).toBe('User stories to be defined based on features.');
        expect(mockCallAI).not.toHaveBeenCalled();
      });
    });

    describe('error handling', () => {
      beforeEach(() => {
        setConfig(createMockConfig(true));
      });

      it('should return existing stories on error', async () => {
        mockCallAI.mockRejectedValueOnce(new Error('API Error'));
        const existingStories = 'Existing stories';

        const result = await generateUserStories(sampleContext, existingStories);

        expect(result).toBe(existingStories);
      });

      it('should return default message on error with no existing', async () => {
        mockCallAI.mockRejectedValueOnce(new Error('API Error'));

        const result = await generateUserStories(sampleContext, '');

        expect(result).toBe('User stories to be defined.');
      });
    });
  });

  // ===========================================
  // generateNFRs Tests
  // ===========================================
  describe('generateNFRs', () => {
    describe('when AI config is available', () => {
      beforeEach(() => {
        setConfig(createMockConfig(true));
      });

      it('should generate NFRs from context', async () => {
        const mockNFRs = `### Performance
- Response time < 500ms for 95th percentile
- Support 10,000 concurrent users`;

        mockCallAI.mockResolvedValueOnce(mockNFRs);

        const result = await generateNFRs(sampleContext);

        expect(result).toBe(mockNFRs);
      });

      it('should include architecture in prompt for relevant NFRs', async () => {
        mockCallAI.mockResolvedValueOnce('NFRs');

        await generateNFRs(sampleContext);

        const userPrompt = mockCallAI.mock.calls[0][2];
        expect(userPrompt).toContain('Microservices');
        expect(userPrompt).toContain('PostgreSQL');
      });

      it('should request measurable values in system prompt', async () => {
        mockCallAI.mockResolvedValueOnce('NFRs');

        await generateNFRs(sampleContext);

        const systemPrompt = mockCallAI.mock.calls[0][1];
        expect(systemPrompt).toContain('MEASURABLE');
        expect(systemPrompt).toContain('Performance');
        expect(systemPrompt).toContain('Scalability');
      });
    });

    describe('existing content handling', () => {
      beforeEach(() => {
        setConfig(createMockConfig(true));
      });

      it('should enhance without duplicating existing NFRs', async () => {
        const existingNFRs = '- Response time < 200ms';
        mockCallAI.mockResolvedValueOnce('Enhanced NFRs');

        await generateNFRs(sampleContext, existingNFRs);

        const userPrompt = mockCallAI.mock.calls[0][2];
        expect(userPrompt).toContain("don't duplicate");
        expect(userPrompt).toContain(existingNFRs);
      });
    });

    describe('fallback behavior when no config', () => {
      beforeEach(() => {
        (setConfig as (c: AppConfig | null) => void)(null as unknown as AppConfig);
      });

      it('should return existing NFRs when no AI config', async () => {
        const existingNFRs = 'Existing NFRs';
        const result = await generateNFRs(sampleContext, existingNFRs);

        expect(result).toBe(existingNFRs);
        expect(mockCallAI).not.toHaveBeenCalled();
      });

      it('should return default message when no AI config and no existing', async () => {
        const result = await generateNFRs(sampleContext);

        expect(result).toBe('NFRs to be defined.');
        expect(mockCallAI).not.toHaveBeenCalled();
      });
    });

    describe('error handling', () => {
      beforeEach(() => {
        setConfig(createMockConfig(true));
      });

      it('should return existing NFRs on error', async () => {
        mockCallAI.mockRejectedValueOnce(new Error('API Error'));
        const existingNFRs = 'Existing NFRs';

        const result = await generateNFRs(sampleContext, existingNFRs);

        expect(result).toBe(existingNFRs);
      });

      it('should return default message on error with no existing', async () => {
        mockCallAI.mockRejectedValueOnce(new Error('API Error'));

        const result = await generateNFRs(sampleContext);

        expect(result).toBe('NFRs to be defined.');
      });
    });
  });

  // ===========================================
  // generateRisks Tests
  // ===========================================
  describe('generateRisks', () => {
    describe('when AI config is available', () => {
      beforeEach(() => {
        setConfig(createMockConfig(true));
      });

      it('should generate risks with likelihood and mitigation', async () => {
        const mockRisks = `### Technical Risks
- **Third-party API dependency**
  - Likelihood: Medium
  - Impact: High
  - Mitigation: Implement circuit breakers and fallback mechanisms`;

        mockCallAI.mockResolvedValueOnce(mockRisks);

        const result = await generateRisks(sampleContext);

        expect(result).toBe(mockRisks);
      });

      it('should include dependencies in prompt', async () => {
        mockCallAI.mockResolvedValueOnce('Risks');

        await generateRisks(sampleContext);

        const userPrompt = mockCallAI.mock.calls[0][2];
        expect(userPrompt).toContain('Payment gateway API');
        expect(userPrompt).toContain('Shipping provider API');
      });

      it('should request 5-8 risks in system prompt', async () => {
        mockCallAI.mockResolvedValueOnce('Risks');

        await generateRisks(sampleContext);

        const systemPrompt = mockCallAI.mock.calls[0][1];
        expect(systemPrompt).toContain('5-8');
        expect(systemPrompt).toContain('Likelihood');
        expect(systemPrompt).toContain('Mitigation');
      });
    });

    describe('fallback behavior when no config', () => {
      beforeEach(() => {
        (setConfig as (c: AppConfig | null) => void)(null as unknown as AppConfig);
      });

      it('should return existing risks when no AI config', async () => {
        const existingRisks = 'Existing risks';
        const result = await generateRisks(sampleContext, existingRisks);

        expect(result).toBe(existingRisks);
        expect(mockCallAI).not.toHaveBeenCalled();
      });

      it('should return default message when no AI config and no existing', async () => {
        const result = await generateRisks(sampleContext);

        expect(result).toBe('Risks to be assessed.');
        expect(mockCallAI).not.toHaveBeenCalled();
      });
    });

    describe('error handling', () => {
      beforeEach(() => {
        setConfig(createMockConfig(true));
      });

      it('should return existing risks on error', async () => {
        mockCallAI.mockRejectedValueOnce(new Error('API Error'));
        const existingRisks = 'Existing risks';

        const result = await generateRisks(sampleContext, existingRisks);

        expect(result).toBe(existingRisks);
      });

      it('should return default message on error with no existing', async () => {
        mockCallAI.mockRejectedValueOnce(new Error('API Error'));

        const result = await generateRisks(sampleContext);

        expect(result).toBe('Risks to be assessed.');
      });
    });
  });

  // ===========================================
  // generateSecurityRequirements Tests
  // ===========================================
  describe('generateSecurityRequirements', () => {
    describe('when AI config is available', () => {
      beforeEach(() => {
        setConfig(createMockConfig(true));
      });

      it('should generate security requirements from context', async () => {
        const mockSecurity = `### Authentication & Authorization
- OAuth 2.0 with JWT tokens
- Role-based access control (RBAC)

### Data Protection
- AES-256 encryption at rest
- TLS 1.3 for data in transit`;

        mockCallAI.mockResolvedValueOnce(mockSecurity);

        const result = await generateSecurityRequirements(sampleContext);

        expect(result).toBe(mockSecurity);
      });

      it('should include data stores in prompt', async () => {
        mockCallAI.mockResolvedValueOnce('Security');

        await generateSecurityRequirements(sampleContext);

        const userPrompt = mockCallAI.mock.calls[0][2];
        expect(userPrompt).toContain('PostgreSQL');
        expect(userPrompt).toContain('Redis');
      });

      it('should cover key security areas in system prompt', async () => {
        mockCallAI.mockResolvedValueOnce('Security');

        await generateSecurityRequirements(sampleContext);

        const systemPrompt = mockCallAI.mock.calls[0][1];
        expect(systemPrompt).toContain('Authentication');
        expect(systemPrompt).toContain('Authorization');
        expect(systemPrompt).toContain('Data Protection');
        expect(systemPrompt).toContain('Audit');
      });
    });

    describe('fallback behavior when no config', () => {
      beforeEach(() => {
        (setConfig as (c: AppConfig | null) => void)(null as unknown as AppConfig);
      });

      it('should return existing security when no AI config', async () => {
        const existingSecurity = 'Existing security requirements';
        const result = await generateSecurityRequirements(sampleContext, existingSecurity);

        expect(result).toBe(existingSecurity);
        expect(mockCallAI).not.toHaveBeenCalled();
      });

      it('should return default message when no AI config and no existing', async () => {
        const result = await generateSecurityRequirements(sampleContext);

        expect(result).toBe('Security requirements to be defined.');
        expect(mockCallAI).not.toHaveBeenCalled();
      });
    });

    describe('error handling', () => {
      beforeEach(() => {
        setConfig(createMockConfig(true));
      });

      it('should return existing security on error', async () => {
        mockCallAI.mockRejectedValueOnce(new Error('API Error'));
        const existingSecurity = 'Existing security';

        const result = await generateSecurityRequirements(sampleContext, existingSecurity);

        expect(result).toBe(existingSecurity);
      });

      it('should return default message on error with no existing', async () => {
        mockCallAI.mockRejectedValueOnce(new Error('API Error'));

        const result = await generateSecurityRequirements(sampleContext);

        expect(result).toBe('Security requirements to be defined.');
      });
    });
  });

  // ===========================================
  // refineInput (via runSkill) Tests
  // ===========================================
  describe('refineInput via runSkill', () => {
    describe('special field routing', () => {
      beforeEach(() => {
        setConfig(createMockConfig(true));
      });

      it('should return projectName unchanged without AI call', async () => {
        const projectName = 'My Project';
        const result = await runSkill('refine', {
          stageId: 'project',
          fieldName: 'projectName',
          input: projectName,
          context: sampleContext,
        });

        expect((result as { refined: string }).refined).toBe(projectName);
        expect(mockCallAI).not.toHaveBeenCalled();
      });

      it('should route userStories to generateUserStories', async () => {
        mockCallAI.mockResolvedValueOnce('Generated stories');

        const result = await runSkill('refine', {
          stageId: 'features',
          fieldName: 'userStories',
          input: '',
          context: sampleContext,
        });

        expect((result as { refined: string }).refined).toBe('Generated stories');
        const systemPrompt = mockCallAI.mock.calls[0][1];
        expect(systemPrompt).toContain('15-20');
      });

      it('should route nfrs to generateNFRs', async () => {
        mockCallAI.mockResolvedValueOnce('Generated NFRs');

        const result = await runSkill('refine', {
          stageId: 'features',
          fieldName: 'nfrs',
          input: '',
          context: sampleContext,
        });

        expect((result as { refined: string }).refined).toBe('Generated NFRs');
        const systemPrompt = mockCallAI.mock.calls[0][1];
        expect(systemPrompt).toContain('Non-Functional Requirements');
      });

      it('should route risks to generateRisks', async () => {
        mockCallAI.mockResolvedValueOnce('Generated risks');

        const result = await runSkill('refine', {
          stageId: 'delivery',
          fieldName: 'risks',
          input: '',
          context: sampleContext,
        });

        expect((result as { refined: string }).refined).toBe('Generated risks');
        const systemPrompt = mockCallAI.mock.calls[0][1];
        expect(systemPrompt).toContain('risk analyst');
      });

      it('should route security to generateSecurityRequirements', async () => {
        mockCallAI.mockResolvedValueOnce('Generated security');

        const result = await runSkill('refine', {
          stageId: 'team_env',
          fieldName: 'security',
          input: '',
          context: sampleContext,
        });

        expect((result as { refined: string }).refined).toBe('Generated security');
        const systemPrompt = mockCallAI.mock.calls[0][1];
        expect(systemPrompt).toContain('security architect');
      });

      it('should route other fields to aiRefineField', async () => {
        mockCallAI.mockResolvedValueOnce('Enhanced background');

        const result = await runSkill('refine', {
          stageId: 'project',
          fieldName: 'background',
          input: 'Initial background',
          context: sampleContext,
        });

        expect((result as { refined: string }).refined).toBe('Enhanced background');
        const systemPrompt = mockCallAI.mock.calls[0][1];
        expect(systemPrompt).toContain('expert technical writer');
      });
    });

    describe('diagram node generation', () => {
      beforeEach(() => {
        setConfig(createMockConfig(true));
      });

      it('should include diagramNode in result', async () => {
        mockCallAI.mockResolvedValueOnce('Enhanced content');

        const result = await runSkill('refine', {
          stageId: 'project',
          fieldName: 'background',
          input: 'Test content',
          context: sampleContext,
        });

        expect((result as { diagramNode: string }).diagramNode).toBeDefined();
      });

      it('should generate appropriate diagram node for projectName', async () => {
        const result = await runSkill('refine', {
          stageId: 'project',
          fieldName: 'projectName',
          input: 'My Project Name',
          context: sampleContext,
        });

        const diagramNode = (result as { diagramNode: string }).diagramNode;
        expect(diagramNode).toContain('Project');
      });

      it('should generate architecture diagram node', async () => {
        mockCallAI.mockResolvedValueOnce('Enhanced architecture');

        const result = await runSkill('refine', {
          stageId: 'architecture',
          fieldName: 'architectureOverview',
          input: 'Some architecture',
          context: sampleContext,
        });

        const diagramNode = (result as { diagramNode: string }).diagramNode;
        expect(diagramNode).toContain('Architecture');
      });
    });

    describe('fallback formatting when no AI config', () => {
      beforeEach(() => {
        (setConfig as (c: AppConfig | null) => void)(null as unknown as AppConfig);
      });

      it('should format bullet list fields correctly', async () => {
        const input = 'Item 1\nItem 2\nItem 3';

        const result = await runSkill('refine', {
          stageId: 'objective_scope',
          fieldName: 'inScope',
          input,
          context: sampleContext,
        });

        const refined = (result as { refined: string }).refined;
        expect(refined).toContain('- Item 1');
        expect(refined).toContain('- Item 2');
      });

      it('should format numbered list fields correctly', async () => {
        const input = 'Feature one\nFeature two\nFeature three';

        const result = await runSkill('refine', {
          stageId: 'features',
          fieldName: 'features',
          input,
          context: sampleContext,
        });

        const refined = (result as { refined: string }).refined;
        expect(refined).toContain('1.');
        expect(refined).toContain('2.');
      });

      it('should format checklist fields correctly', async () => {
        const input = 'Task 1\nTask 2';

        const result = await runSkill('refine', {
          stageId: 'features',
          fieldName: 'deliverables',
          input,
          context: sampleContext,
        });

        const refined = (result as { refined: string }).refined;
        expect(refined).toContain('- [ ]');
      });

      it('should preserve existing bullet formatting', async () => {
        const input = '- Already formatted\n- Another item';

        const result = await runSkill('refine', {
          stageId: 'objective_scope',
          fieldName: 'inScope',
          input,
          context: sampleContext,
        });

        const refined = (result as { refined: string }).refined;
        expect(refined).toBe('- Already formatted\n- Another item');
      });
    });

    describe('AI failure fallback', () => {
      beforeEach(() => {
        setConfig(createMockConfig(true));
      });

      it('should return original input when AI fails for standard fields', async () => {
        // aiRefineField has its own error handling that returns original input
        // The refineInput function receives this fallback value
        const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
        mockCallAI.mockRejectedValueOnce(new Error('AI unavailable'));

        const input = 'Item 1\nItem 2';
        const result = await runSkill('refine', {
          stageId: 'objective_scope',
          fieldName: 'inScope',
          input,
          context: sampleContext,
        });

        // aiRefineField catches error and returns original input
        const refined = (result as { refined: string }).refined;
        expect(refined).toBe(input);

        consoleSpy.mockRestore();
      });

      it('should preserve original input when AI fails for any field', async () => {
        const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
        mockCallAI.mockRejectedValueOnce(new Error('AI unavailable'));

        const input = 'Step one\nStep two';
        const result = await runSkill('refine', {
          stageId: 'features',
          fieldName: 'features',
          input,
          context: sampleContext,
        });

        // aiRefineField catches error and returns original input
        const refined = (result as { refined: string }).refined;
        expect(refined).toBe(input);

        consoleSpy.mockRestore();
      });

      it('should still include diagramNode even when AI fails', async () => {
        const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
        mockCallAI.mockRejectedValueOnce(new Error('AI unavailable'));

        const result = await runSkill('refine', {
          stageId: 'project',
          fieldName: 'background',
          input: 'Some background',
          context: sampleContext,
        });

        expect((result as { diagramNode: string }).diagramNode).toBeDefined();

        consoleSpy.mockRestore();
      });
    });
  });

  // ===========================================
  // Context Passing Tests
  // ===========================================
  describe('context passing', () => {
    beforeEach(() => {
      setConfig(createMockConfig(true));
    });

    it('should pass all context fields to AI', async () => {
      mockCallAI.mockResolvedValueOnce('Enhanced');

      await aiRefineField('architectureOverview', 'Input', {
        projectName: 'Test Project',
        objective: 'Test objective',
        features: 'Test features',
        architectureOverview: 'Test architecture',
      });

      const userPrompt = mockCallAI.mock.calls[0][2];
      expect(userPrompt).toContain('Test Project');
      expect(userPrompt).toContain('Test objective');
      expect(userPrompt).toContain('Test features');
      expect(userPrompt).toContain('Test architecture');
    });

    it('should handle missing context fields gracefully', async () => {
      mockCallAI.mockResolvedValueOnce('Enhanced');

      await aiRefineField('background', 'Input', {});

      const userPrompt = mockCallAI.mock.calls[0][2];
      expect(userPrompt).toContain('Not specified');
    });

    it('should use empty context without errors', async () => {
      mockCallAI.mockResolvedValueOnce('Result');

      const result = await aiRefineField('objective', 'Input', {});

      expect(result).toBe('Result');
    });

    it('should include scope in generateUserStories context', async () => {
      mockCallAI.mockResolvedValueOnce('Stories');

      await generateUserStories(sampleContext);

      const userPrompt = mockCallAI.mock.calls[0][2];
      expect(userPrompt).toContain('Product catalog');
      expect(userPrompt).toContain('User authentication');
    });
  });

  // ===========================================
  // Integration-style Tests
  // ===========================================
  describe('integration scenarios', () => {
    beforeEach(() => {
      setConfig(createMockConfig(true));
    });

    it('should handle complete refinement workflow', async () => {
      // Simulate refining multiple fields in sequence
      mockCallAI
        .mockResolvedValueOnce('Enhanced background')
        .mockResolvedValueOnce('Enhanced objective')
        .mockResolvedValueOnce('Generated user stories');

      const background = await aiRefineField('background', 'Initial', sampleContext);
      const objective = await aiRefineField('objective', 'Build something', sampleContext);
      const stories = await generateUserStories(sampleContext, '');

      expect(background).toBe('Enhanced background');
      expect(objective).toBe('Enhanced objective');
      expect(stories).toBe('Generated user stories');
      expect(mockCallAI).toHaveBeenCalledTimes(3);
    });

    it('should maintain consistent behavior across rapid parallel calls', async () => {
      mockCallAI.mockResolvedValue('Consistent response');

      const promises = [
        aiRefineField('background', 'Input 1', sampleContext),
        aiRefineField('objective', 'Input 2', sampleContext),
        aiRefineField('features', 'Input 3', sampleContext),
      ];

      const results = await Promise.all(promises);

      results.forEach(result => {
        expect(result).toBe('Consistent response');
      });
      expect(mockCallAI).toHaveBeenCalledTimes(3);
    });

    it('should handle mixed success and failure scenarios', async () => {
      const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {});

      mockCallAI
        .mockResolvedValueOnce('Success 1')
        .mockRejectedValueOnce(new Error('Failure'))
        .mockResolvedValueOnce('Success 2');

      const result1 = await aiRefineField('background', 'Input 1', sampleContext);
      const result2 = await aiRefineField('objective', 'Input 2', sampleContext);
      const result3 = await aiRefineField('features', 'Input 3', sampleContext);

      expect(result1).toBe('Success 1');
      expect(result2).toBe('Input 2'); // Fallback to original
      expect(result3).toBe('Success 2');

      consoleSpy.mockRestore();
    });
  });

  // ===========================================
  // Edge Cases Tests
  // ===========================================
  describe('edge cases', () => {
    beforeEach(() => {
      setConfig(createMockConfig(true));
    });

    it('should handle very long input text', async () => {
      const longInput = 'A'.repeat(10000);
      mockCallAI.mockResolvedValueOnce('Processed long input');

      const result = await aiRefineField('background', longInput, sampleContext);

      expect(result).toBe('Processed long input');
      const userPrompt = mockCallAI.mock.calls[0][2];
      expect(userPrompt).toContain(longInput);
    });

    it('should handle special characters in input', async () => {
      const specialInput = 'Test with special chars: <script>alert("xss")</script> & "quotes" \'apostrophes\'';
      mockCallAI.mockResolvedValueOnce('Processed special chars');

      const result = await aiRefineField('background', specialInput, sampleContext);

      expect(result).toBe('Processed special chars');
    });

    it('should handle unicode characters', async () => {
      const unicodeInput = 'Test with unicode: 日本語 한국어 العربية 🚀';
      mockCallAI.mockResolvedValueOnce('Processed unicode');

      const result = await aiRefineField('background', unicodeInput, sampleContext);

      expect(result).toBe('Processed unicode');
    });

    it('should handle newlines and tabs in input', async () => {
      const multilineInput = 'Line 1\n\tTabbed line\n\nDouble newline\rCarriage return';
      mockCallAI.mockResolvedValueOnce('Processed multiline');

      const result = await aiRefineField('background', multilineInput, sampleContext);

      expect(result).toBe('Processed multiline');
    });

    it('should handle unknown field names gracefully', async () => {
      mockCallAI.mockResolvedValueOnce('Enhanced unknown field');

      const result = await aiRefineField('unknownField', 'Some content', sampleContext);

      expect(result).toBe('Enhanced unknown field');
    });
  });
});
