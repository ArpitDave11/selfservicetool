/**
 * Issue Creation Tests
 *
 * Tests for:
 * 1. GitLab Issue API functions (createGitLabIssue, linkIssueToEpic, fetchEpicIssues)
 * 2. User story parsing from epic content
 * 3. Duplicate detection logic
 * 4. Issue creation UI components
 * 5. Issues button visibility and state
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import React from 'react';
import type { ParsedUserStory } from '../types';

// ============================================
// Mock Data
// ============================================

const mockParsedStories: ParsedUserStory[] = [
  {
    id: 'story-1',
    rawText: 'As a user, I want to login so that I can access my account',
    title: 'User Login',
    description: 'Implement user login functionality',
    persona: 'user',
    goal: 'login',
    benefit: 'access my account',
    hasExistingIssue: false,
  },
  {
    id: 'story-2',
    rawText: 'As an admin, I want to manage users so that I can control access',
    title: 'User Management',
    description: 'Admin user management features',
    persona: 'admin',
    goal: 'manage users',
    benefit: 'control access',
    hasExistingIssue: false,
  },
  {
    id: 'story-3',
    rawText: 'As a user, I want to reset password so that I can recover my account',
    title: 'Password Reset',
    description: 'Password reset functionality',
    persona: 'user',
    goal: 'reset password',
    benefit: 'recover my account',
    hasExistingIssue: true,
    matchedIssueId: 100,
    matchedIssueIid: 50,
    similarityScore: 85,
  },
];

const mockExistingIssues = [
  { id: 100, iid: 50, title: 'Password Recovery Feature', state: 'opened', web_url: 'https://gitlab.com/issues/50' },
  { id: 101, iid: 51, title: 'User Profile Page', state: 'opened', web_url: 'https://gitlab.com/issues/51' },
];

const mockEpicWithUserStories = `# Epic: User Authentication System

## 1. Objective
Build secure authentication for the platform.

## 11. Key Features & User Stories

### User Stories
- As a user, I want to login so that I can access my account
- As an admin, I want to manage users so that I can control access
- As a user, I want to reset password so that I can recover my account

### Acceptance Criteria
- Users can login with email/password
- Admins can view all users
- Password reset via email

## 12. Non-Functional Requirements
- 99.9% uptime
`;

const mockEpicWithoutUserStories = `# Epic: Simple Feature

## 1. Objective
A simple feature implementation.

## 2. Background
Some background context.

## 3. Scope
### In Scope
- Basic functionality
`;

// ============================================
// GitLab Issue API Tests
// ============================================

describe('GitLab API - Create Issue', () => {
  // Simulated createGitLabIssue function logic (matches new signature)
  // Now uses rootGroupId to find projects automatically
  const createGitLabIssue = async (
    config: { enabled: boolean; accessToken: string; rootGroupId: string },
    params: {
      title: string;
      description?: string;
      labels?: string[];
    }
  ) => {
    if (!config.enabled || !config.accessToken) {
      return { success: false, error: 'GitLab not configured' };
    }

    if (!config.rootGroupId) {
      return { success: false, error: 'Group ID is required' };
    }

    if (!params.title) {
      return { success: false, error: 'Title is required' };
    }

    // Simulate finding a project in the group and creating issue
    const newIssue = {
      id: Date.now(),
      iid: Math.floor(Math.random() * 1000) + 100,
      title: params.title,
      description: params.description || '',
      state: 'opened' as const,
      labels: params.labels || [],
      web_url: `https://gitlab.com/project/issues/${Date.now()}`,
    };

    return { success: true, data: newIssue };
  };

  it('should create issue with required fields', async () => {
    const result = await createGitLabIssue(
      { enabled: true, accessToken: 'token', rootGroupId: '123' },
      { title: 'New Test Issue' }
    );

    expect(result.success).toBe(true);
    expect(result.data!.title).toBe('New Test Issue');
    expect(result.data!.web_url).toBeDefined();
  });

  it('should create issue with all fields', async () => {
    const result = await createGitLabIssue(
      { enabled: true, accessToken: 'token', rootGroupId: '123' },
      {
        title: 'Full Issue',
        description: '# Issue Description\n\nDetailed description here.',
        labels: ['feature', 'epic-generator'],
      }
    );

    expect(result.success).toBe(true);
    expect(result.data!.description).toBe('# Issue Description\n\nDetailed description here.');
    expect(result.data!.labels).toContain('feature');
  });

  it('should fail when title is missing', async () => {
    const result = await createGitLabIssue(
      { enabled: true, accessToken: 'token', rootGroupId: '123' },
      { title: '' }
    );

    expect(result.success).toBe(false);
    expect(result.error).toBe('Title is required');
  });

  it('should fail when GitLab not configured', async () => {
    const result = await createGitLabIssue(
      { enabled: false, accessToken: '', rootGroupId: '' },
      { title: 'Test Issue' }
    );

    expect(result.success).toBe(false);
    expect(result.error).toBe('GitLab not configured');
  });

  it('should fail when group ID is missing', async () => {
    const result = await createGitLabIssue(
      { enabled: true, accessToken: 'token', rootGroupId: '' },
      { title: 'Test Issue' }
    );

    expect(result.success).toBe(false);
    expect(result.error).toBe('Group ID is required');
  });
});

describe('GitLab API - Link Issue to Epic', () => {
  // Simulated linkIssueToEpic function logic
  const linkIssueToEpic = async (
    config: { enabled: boolean; accessToken: string; rootGroupId: string },
    epicIid: number,
    issueId: number
  ) => {
    if (!config.enabled || !config.accessToken || !config.rootGroupId) {
      return { success: false, error: 'GitLab not configured' };
    }

    if (!epicIid) {
      return { success: false, error: 'Epic IID is required' };
    }

    if (!issueId) {
      return { success: false, error: 'Issue ID is required' };
    }

    // Simulate successful link
    return { success: true };
  };

  it('should link issue to epic successfully', async () => {
    const result = await linkIssueToEpic(
      { enabled: true, accessToken: 'token', rootGroupId: '123' },
      101,
      500
    );

    expect(result.success).toBe(true);
  });

  it('should fail when GitLab not configured', async () => {
    const result = await linkIssueToEpic(
      { enabled: false, accessToken: '', rootGroupId: '' },
      101,
      500
    );

    expect(result.success).toBe(false);
    expect(result.error).toBe('GitLab not configured');
  });

  it('should fail when epic IID is missing', async () => {
    const result = await linkIssueToEpic(
      { enabled: true, accessToken: 'token', rootGroupId: '123' },
      0,
      500
    );

    expect(result.success).toBe(false);
    expect(result.error).toBe('Epic IID is required');
  });

  it('should fail when issue ID is missing', async () => {
    const result = await linkIssueToEpic(
      { enabled: true, accessToken: 'token', rootGroupId: '123' },
      101,
      0
    );

    expect(result.success).toBe(false);
    expect(result.error).toBe('Issue ID is required');
  });
});

describe('GitLab API - Fetch Epic Issues', () => {
  // Simulated fetchEpicIssues function logic
  const fetchEpicIssues = async (
    config: { enabled: boolean; accessToken: string; rootGroupId: string },
    epicIid: number
  ) => {
    if (!config.enabled || !config.accessToken || !config.rootGroupId) {
      return { success: false, error: 'GitLab not configured' };
    }

    if (!epicIid) {
      return { success: false, error: 'Epic IID is required' };
    }

    // Simulate returning existing issues
    return { success: true, data: mockExistingIssues };
  };

  it('should fetch issues linked to an epic', async () => {
    const result = await fetchEpicIssues(
      { enabled: true, accessToken: 'token', rootGroupId: '123' },
      101
    );

    expect(result.success).toBe(true);
    expect(result.data).toHaveLength(2);
    expect(result.data![0].title).toBe('Password Recovery Feature');
  });

  it('should fail when GitLab not configured', async () => {
    const result = await fetchEpicIssues(
      { enabled: false, accessToken: '', rootGroupId: '' },
      101
    );

    expect(result.success).toBe(false);
    expect(result.error).toBe('GitLab not configured');
  });

  it('should fail when epic IID is missing', async () => {
    const result = await fetchEpicIssues(
      { enabled: true, accessToken: 'token', rootGroupId: '123' },
      0
    );

    expect(result.success).toBe(false);
    expect(result.error).toBe('Epic IID is required');
  });
});

// ============================================
// User Story Parsing Tests
// ============================================

describe('User Story Parsing', () => {
  // Simulated parseUserStoriesFromEpic function logic
  const parseUserStoriesFromEpic = (epicContent: string): ParsedUserStory[] => {
    const stories: ParsedUserStory[] = [];

    // Find the User Stories section (Section 11)
    const section11Match = epicContent.match(/##\s*11\.\s*Key Features\s*&?\s*User Stories[\s\S]*?(?=##\s*\d+\.|$)/i);

    if (!section11Match) {
      return stories;
    }

    const section11Content = section11Match[0];

    // Pattern: "As a [persona], I want [goal] so that [benefit]"
    // Using greedy match for goal until "so that"
    const userStoryPattern = /As\s+(?:a|an)\s+([^,]+),\s*I\s+want\s+(?:to\s+)?(.+?)\s+so\s+that\s+(.+?)(?:\n|$)/gi;

    let match;
    let index = 0;
    while ((match = userStoryPattern.exec(section11Content)) !== null) {
      const [fullMatch, persona, goal, benefit] = match;

      stories.push({
        id: `story-${index++}`,
        rawText: fullMatch.trim(),
        title: goal.trim().charAt(0).toUpperCase() + goal.trim().slice(1),
        description: fullMatch.trim(),
        persona: persona?.trim(),
        goal: goal?.trim(),
        benefit: benefit?.trim(),
        hasExistingIssue: false,
      });
    }

    // Also match simple bullet points if no "As a" patterns found
    if (stories.length === 0) {
      const bulletPattern = /[-*]\s+(.+?)(?:\n|$)/g;
      while ((match = bulletPattern.exec(section11Content)) !== null) {
        const text = match[1].trim();
        if (text.length > 10) {
          stories.push({
            id: `story-${index++}`,
            rawText: text,
            title: text.substring(0, 50) + (text.length > 50 ? '...' : ''),
            description: text,
            hasExistingIssue: false,
          });
        }
      }
    }

    return stories;
  };

  it('should parse standard user stories from epic content', () => {
    const stories = parseUserStoriesFromEpic(mockEpicWithUserStories);

    expect(stories.length).toBeGreaterThan(0);
    expect(stories[0].persona).toBe('user');
    expect(stories[0].goal).toContain('login');
  });

  it('should return empty array when Section 11 not found', () => {
    const stories = parseUserStoriesFromEpic(mockEpicWithoutUserStories);

    expect(stories).toHaveLength(0);
  });

  it('should extract persona, goal, and benefit from user stories', () => {
    const stories = parseUserStoriesFromEpic(mockEpicWithUserStories);

    const adminStory = stories.find(s => s.persona === 'admin');
    expect(adminStory).toBeDefined();
    expect(adminStory!.goal).toContain('manage users');
    expect(adminStory!.benefit).toContain('control access');
  });

  it('should generate unique IDs for each story', () => {
    const stories = parseUserStoriesFromEpic(mockEpicWithUserStories);

    const ids = stories.map(s => s.id);
    const uniqueIds = new Set(ids);
    expect(uniqueIds.size).toBe(ids.length);
  });

  it('should capitalize the story title from goal', () => {
    const stories = parseUserStoriesFromEpic(mockEpicWithUserStories);

    stories.forEach(story => {
      expect(story.title.charAt(0)).toBe(story.title.charAt(0).toUpperCase());
    });
  });
});

// ============================================
// Duplicate Detection Tests
// ============================================

describe('Duplicate Detection', () => {
  // Simulated duplicate detection logic
  const markDuplicates = (
    stories: ParsedUserStory[],
    existingIssues: Array<{ id: number; iid: number; title: string }>
  ): ParsedUserStory[] => {
    return stories.map(story => {
      // Simple title similarity check
      const storyTitleLower = story.title.toLowerCase();

      for (const issue of existingIssues) {
        const issueTitleLower = issue.title.toLowerCase();

        // Check for keyword overlap
        const storyWords = storyTitleLower.split(/\s+/);
        const issueWords = issueTitleLower.split(/\s+/);
        const overlap = storyWords.filter(w => w.length > 3 && issueWords.includes(w));

        if (overlap.length >= 2 || issueTitleLower.includes(storyTitleLower) || storyTitleLower.includes(issueTitleLower)) {
          return {
            ...story,
            hasExistingIssue: true,
            matchedIssueId: issue.id,
            matchedIssueIid: issue.iid,
            similarityScore: Math.min(100, overlap.length * 30 + 40),
          };
        }
      }

      return story;
    });
  };

  it('should mark stories that match existing issues', () => {
    const stories: ParsedUserStory[] = [
      {
        id: 'story-1',
        rawText: 'Password reset feature',
        title: 'Password Recovery',
        description: 'Password reset',
        hasExistingIssue: false,
      },
    ];

    const existingIssues = [
      { id: 100, iid: 50, title: 'Password Recovery Feature' },
    ];

    const result = markDuplicates(stories, existingIssues);

    expect(result[0].hasExistingIssue).toBe(true);
    expect(result[0].matchedIssueId).toBe(100);
    expect(result[0].matchedIssueIid).toBe(50);
  });

  it('should not mark unique stories as duplicates', () => {
    const stories: ParsedUserStory[] = [
      {
        id: 'story-1',
        rawText: 'Dark mode theme',
        title: 'Dark Mode Theme',
        description: 'Add dark mode',
        hasExistingIssue: false,
      },
    ];

    const existingIssues = [
      { id: 100, iid: 50, title: 'Password Recovery Feature' },
    ];

    const result = markDuplicates(stories, existingIssues);

    expect(result[0].hasExistingIssue).toBe(false);
    expect(result[0].matchedIssueId).toBeUndefined();
  });

  it('should return stories unchanged when no existing issues', () => {
    const stories: ParsedUserStory[] = [
      {
        id: 'story-1',
        rawText: 'New feature',
        title: 'New Feature',
        description: 'A new feature',
        hasExistingIssue: false,
      },
    ];

    const result = markDuplicates(stories, []);

    expect(result[0].hasExistingIssue).toBe(false);
  });

  it('should calculate similarity score for matches', () => {
    const stories: ParsedUserStory[] = [
      {
        id: 'story-1',
        rawText: 'User profile page',
        title: 'User Profile Page',
        description: 'Profile page',
        hasExistingIssue: false,
      },
    ];

    const existingIssues = [
      { id: 101, iid: 51, title: 'User Profile Page' },
    ];

    const result = markDuplicates(stories, existingIssues);

    expect(result[0].similarityScore).toBeDefined();
    expect(result[0].similarityScore).toBeGreaterThan(0);
  });
});

// ============================================
// Issue Creation UI Component Tests
// ============================================

describe('Issues Button Visibility', () => {
  const IssuesButton = ({
    hasEpic,
    gitlabEnabled,
    onClick,
  }: {
    hasEpic: boolean;
    gitlabEnabled: boolean;
    onClick: () => void;
  }) => (
    <button
      data-testid="issues-button"
      onClick={onClick}
      disabled={!hasEpic || !gitlabEnabled}
      title={
        !hasEpic
          ? 'Load or create an epic first'
          : !gitlabEnabled
          ? 'Enable GitLab in Settings first'
          : 'Create GitLab issues from user stories'
      }
    >
      Issues
    </button>
  );

  it('should be disabled when no epic is loaded', () => {
    const onClick = vi.fn();
    render(
      <IssuesButton hasEpic={false} gitlabEnabled={true} onClick={onClick} />
    );

    const button = screen.getByTestId('issues-button');
    expect(button).toBeDisabled();
    expect(button).toHaveAttribute('title', 'Load or create an epic first');
  });

  it('should be disabled when GitLab is not enabled', () => {
    const onClick = vi.fn();
    render(
      <IssuesButton hasEpic={true} gitlabEnabled={false} onClick={onClick} />
    );

    const button = screen.getByTestId('issues-button');
    expect(button).toBeDisabled();
    expect(button).toHaveAttribute('title', 'Enable GitLab in Settings first');
  });

  it('should be enabled when epic exists and GitLab is enabled', () => {
    const onClick = vi.fn();
    render(
      <IssuesButton hasEpic={true} gitlabEnabled={true} onClick={onClick} />
    );

    const button = screen.getByTestId('issues-button');
    expect(button).not.toBeDisabled();
    expect(button).toHaveAttribute('title', 'Create GitLab issues from user stories');
  });

  it('should call onClick when clicked and enabled', () => {
    const onClick = vi.fn();
    render(
      <IssuesButton hasEpic={true} gitlabEnabled={true} onClick={onClick} />
    );

    fireEvent.click(screen.getByTestId('issues-button'));
    expect(onClick).toHaveBeenCalled();
  });

  it('should not call onClick when clicked and disabled', () => {
    const onClick = vi.fn();
    render(
      <IssuesButton hasEpic={false} gitlabEnabled={true} onClick={onClick} />
    );

    fireEvent.click(screen.getByTestId('issues-button'));
    expect(onClick).not.toHaveBeenCalled();
  });
});

describe('Issue Creation Modal', () => {
  const IssueCreationModal = ({
    isOpen,
    stories,
    selectedIds,
    onToggleStory,
    onSelectAll,
    onClose,
    onCreate,
    isCreating,
  }: {
    isOpen: boolean;
    stories: ParsedUserStory[];
    selectedIds: string[];
    onToggleStory: (id: string) => void;
    onSelectAll: (selectAll: boolean) => void;
    onClose: () => void;
    onCreate: () => void;
    isCreating: boolean;
  }) => {
    if (!isOpen) return null;

    const newStories = stories.filter(s => !s.hasExistingIssue);
    const duplicateStories = stories.filter(s => s.hasExistingIssue);

    return (
      <div data-testid="issue-modal">
        <h3 data-testid="modal-title">Create Issues from User Stories</h3>

        <div data-testid="story-count">
          User Stories ({stories.length})
        </div>

        <button
          data-testid="select-all-button"
          onClick={() => onSelectAll(selectedIds.length !== newStories.length)}
        >
          {selectedIds.length === newStories.length ? 'Deselect All' : 'Select All'}
        </button>

        {stories.map(story => (
          <div key={story.id} data-testid={`story-item-${story.id}`}>
            <input
              type="checkbox"
              data-testid={`story-checkbox-${story.id}`}
              checked={selectedIds.includes(story.id)}
              disabled={story.hasExistingIssue}
              onChange={() => onToggleStory(story.id)}
            />
            <span data-testid={`story-title-${story.id}`}>{story.title}</span>
            {story.hasExistingIssue && (
              <span data-testid={`duplicate-badge-${story.id}`}>
                Duplicate ({story.similarityScore}%)
              </span>
            )}
          </div>
        ))}

        <div data-testid="selection-count">
          {selectedIds.length} of {newStories.length} new stories selected
        </div>

        <button data-testid="cancel-button" onClick={onClose}>
          Cancel
        </button>
        <button
          data-testid="create-button"
          onClick={onCreate}
          disabled={selectedIds.length === 0 || isCreating}
        >
          {isCreating ? 'Creating...' : `Create ${selectedIds.length} Issues`}
        </button>
      </div>
    );
  };

  it('should not render when isOpen is false', () => {
    render(
      <IssueCreationModal
        isOpen={false}
        stories={mockParsedStories}
        selectedIds={[]}
        onToggleStory={vi.fn()}
        onSelectAll={vi.fn()}
        onClose={vi.fn()}
        onCreate={vi.fn()}
        isCreating={false}
      />
    );

    expect(screen.queryByTestId('issue-modal')).not.toBeInTheDocument();
  });

  it('should render when isOpen is true', () => {
    render(
      <IssueCreationModal
        isOpen={true}
        stories={mockParsedStories}
        selectedIds={[]}
        onToggleStory={vi.fn()}
        onSelectAll={vi.fn()}
        onClose={vi.fn()}
        onCreate={vi.fn()}
        isCreating={false}
      />
    );

    expect(screen.getByTestId('issue-modal')).toBeInTheDocument();
    expect(screen.getByTestId('modal-title')).toHaveTextContent('Create Issues from User Stories');
  });

  it('should display correct story count', () => {
    render(
      <IssueCreationModal
        isOpen={true}
        stories={mockParsedStories}
        selectedIds={[]}
        onToggleStory={vi.fn()}
        onSelectAll={vi.fn()}
        onClose={vi.fn()}
        onCreate={vi.fn()}
        isCreating={false}
      />
    );

    expect(screen.getByTestId('story-count')).toHaveTextContent(`User Stories (${mockParsedStories.length})`);
  });

  it('should show duplicate badge for stories with existing issues', () => {
    render(
      <IssueCreationModal
        isOpen={true}
        stories={mockParsedStories}
        selectedIds={[]}
        onToggleStory={vi.fn()}
        onSelectAll={vi.fn()}
        onClose={vi.fn()}
        onCreate={vi.fn()}
        isCreating={false}
      />
    );

    expect(screen.getByTestId('duplicate-badge-story-3')).toBeInTheDocument();
    expect(screen.getByTestId('duplicate-badge-story-3')).toHaveTextContent('Duplicate (85%)');
  });

  it('should disable checkbox for duplicate stories', () => {
    render(
      <IssueCreationModal
        isOpen={true}
        stories={mockParsedStories}
        selectedIds={[]}
        onToggleStory={vi.fn()}
        onSelectAll={vi.fn()}
        onClose={vi.fn()}
        onCreate={vi.fn()}
        isCreating={false}
      />
    );

    expect(screen.getByTestId('story-checkbox-story-3')).toBeDisabled();
    expect(screen.getByTestId('story-checkbox-story-1')).not.toBeDisabled();
  });

  it('should call onToggleStory when checkbox clicked', () => {
    const onToggleStory = vi.fn();
    render(
      <IssueCreationModal
        isOpen={true}
        stories={mockParsedStories}
        selectedIds={[]}
        onToggleStory={onToggleStory}
        onSelectAll={vi.fn()}
        onClose={vi.fn()}
        onCreate={vi.fn()}
        isCreating={false}
      />
    );

    fireEvent.click(screen.getByTestId('story-checkbox-story-1'));
    expect(onToggleStory).toHaveBeenCalledWith('story-1');
  });

  it('should call onSelectAll when select all button clicked', () => {
    const onSelectAll = vi.fn();
    render(
      <IssueCreationModal
        isOpen={true}
        stories={mockParsedStories}
        selectedIds={[]}
        onToggleStory={vi.fn()}
        onSelectAll={onSelectAll}
        onClose={vi.fn()}
        onCreate={vi.fn()}
        isCreating={false}
      />
    );

    fireEvent.click(screen.getByTestId('select-all-button'));
    expect(onSelectAll).toHaveBeenCalledWith(true);
  });

  it('should show "Deselect All" when all new stories are selected', () => {
    render(
      <IssueCreationModal
        isOpen={true}
        stories={mockParsedStories}
        selectedIds={['story-1', 'story-2']} // All new stories selected
        onToggleStory={vi.fn()}
        onSelectAll={vi.fn()}
        onClose={vi.fn()}
        onCreate={vi.fn()}
        isCreating={false}
      />
    );

    expect(screen.getByTestId('select-all-button')).toHaveTextContent('Deselect All');
  });

  it('should disable create button when no stories selected', () => {
    render(
      <IssueCreationModal
        isOpen={true}
        stories={mockParsedStories}
        selectedIds={[]}
        onToggleStory={vi.fn()}
        onSelectAll={vi.fn()}
        onClose={vi.fn()}
        onCreate={vi.fn()}
        isCreating={false}
      />
    );

    expect(screen.getByTestId('create-button')).toBeDisabled();
  });

  it('should enable create button when stories are selected', () => {
    render(
      <IssueCreationModal
        isOpen={true}
        stories={mockParsedStories}
        selectedIds={['story-1']}
        onToggleStory={vi.fn()}
        onSelectAll={vi.fn()}
        onClose={vi.fn()}
        onCreate={vi.fn()}
        isCreating={false}
      />
    );

    expect(screen.getByTestId('create-button')).not.toBeDisabled();
  });

  it('should show creating state during issue creation', () => {
    render(
      <IssueCreationModal
        isOpen={true}
        stories={mockParsedStories}
        selectedIds={['story-1']}
        onToggleStory={vi.fn()}
        onSelectAll={vi.fn()}
        onClose={vi.fn()}
        onCreate={vi.fn()}
        isCreating={true}
      />
    );

    expect(screen.getByTestId('create-button')).toHaveTextContent('Creating...');
    expect(screen.getByTestId('create-button')).toBeDisabled();
  });

  it('should call onClose when cancel button clicked', () => {
    const onClose = vi.fn();
    render(
      <IssueCreationModal
        isOpen={true}
        stories={mockParsedStories}
        selectedIds={[]}
        onToggleStory={vi.fn()}
        onSelectAll={vi.fn()}
        onClose={onClose}
        onCreate={vi.fn()}
        isCreating={false}
      />
    );

    fireEvent.click(screen.getByTestId('cancel-button'));
    expect(onClose).toHaveBeenCalled();
  });

  it('should call onCreate when create button clicked', () => {
    const onCreate = vi.fn();
    render(
      <IssueCreationModal
        isOpen={true}
        stories={mockParsedStories}
        selectedIds={['story-1', 'story-2']}
        onToggleStory={vi.fn()}
        onSelectAll={vi.fn()}
        onClose={vi.fn()}
        onCreate={onCreate}
        isCreating={false}
      />
    );

    fireEvent.click(screen.getByTestId('create-button'));
    expect(onCreate).toHaveBeenCalled();
  });

  it('should display correct selection count', () => {
    render(
      <IssueCreationModal
        isOpen={true}
        stories={mockParsedStories}
        selectedIds={['story-1']}
        onToggleStory={vi.fn()}
        onSelectAll={vi.fn()}
        onClose={vi.fn()}
        onCreate={vi.fn()}
        isCreating={false}
      />
    );

    expect(screen.getByTestId('selection-count')).toHaveTextContent('1 of 2 new stories selected');
  });
});

// ============================================
// Story Selection Logic Tests
// ============================================

describe('Story Selection Logic', () => {
  it('should toggle story selection correctly', () => {
    let selectedIds: string[] = [];

    const toggleStory = (id: string) => {
      if (selectedIds.includes(id)) {
        selectedIds = selectedIds.filter(sid => sid !== id);
      } else {
        selectedIds = [...selectedIds, id];
      }
    };

    // Select first story
    toggleStory('story-1');
    expect(selectedIds).toContain('story-1');

    // Select second story
    toggleStory('story-2');
    expect(selectedIds).toContain('story-1');
    expect(selectedIds).toContain('story-2');

    // Deselect first story
    toggleStory('story-1');
    expect(selectedIds).not.toContain('story-1');
    expect(selectedIds).toContain('story-2');
  });

  it('should select all new stories (excluding duplicates)', () => {
    const stories = mockParsedStories;
    let selectedIds: string[] = [];

    const selectAll = (selectAll: boolean) => {
      if (selectAll) {
        selectedIds = stories
          .filter(s => !s.hasExistingIssue)
          .map(s => s.id);
      } else {
        selectedIds = [];
      }
    };

    // Select all
    selectAll(true);
    expect(selectedIds).toContain('story-1');
    expect(selectedIds).toContain('story-2');
    expect(selectedIds).not.toContain('story-3'); // This is a duplicate

    // Deselect all
    selectAll(false);
    expect(selectedIds).toHaveLength(0);
  });
});

// ============================================
// Integration Tests
// ============================================

describe('Issue Creation Workflow', () => {
  it('should filter out duplicate stories before creation', () => {
    const stories = mockParsedStories;
    const selectedIds = ['story-1', 'story-2', 'story-3'];

    // Filter out duplicates
    const storiesToCreate = stories.filter(
      s => selectedIds.includes(s.id) && !s.hasExistingIssue
    );

    expect(storiesToCreate).toHaveLength(2);
    expect(storiesToCreate.find(s => s.id === 'story-3')).toBeUndefined();
  });

  it('should calculate correct counts for modal display', () => {
    const stories = mockParsedStories;

    const totalCount = stories.length;
    const newStoriesCount = stories.filter(s => !s.hasExistingIssue).length;
    const duplicatesCount = stories.filter(s => s.hasExistingIssue).length;

    expect(totalCount).toBe(3);
    expect(newStoriesCount).toBe(2);
    expect(duplicatesCount).toBe(1);
  });
});
