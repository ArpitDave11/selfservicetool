/**
 * Epic Group ID Mismatch Test
 *
 * This test reproduces the exact scenario described by the user:
 * - Two epics with the same iid (229) exist in different groups
 * - Group 478446 → epic id: 841693 → description: null, state: opened
 * - Group 557797 → epic id: 520625 → has content, state: closed
 *
 * The bug: App loads from wrong group (478446) instead of correct group (557797)
 * because find() returns the first match by iid, not considering group_id.
 *
 * Run: npm run test:run -- epicGroupIdMismatch
 */

import { describe, test, expect, beforeEach } from 'vitest';

// ===========================================
// MOCK DATA: Two epics with SAME iid in DIFFERENT groups
// ===========================================
interface MockEpic {
  id: number;
  iid: number;
  group_id: number;
  title: string;
  description: string | null;
  state: 'opened' | 'closed';
  web_url: string;
  _links?: {
    self: string;
    group: string;
    epic_issues: string;
  };
}

const SCENARIO_EPICS: MockEpic[] = [
  // WRONG EPIC: Empty epic in subgroup (this is found FIRST by iid)
  {
    id: 841693,
    iid: 229,  // SAME iid as the correct epic!
    group_id: 478446,  // Subgroup
    title: 'Empty Epic in Subgroup',
    description: null,  // No content
    state: 'opened',
    web_url: 'https://gitlab.com/groups/parent/subgroup/-/epics/229',
    _links: {
      self: 'https://gitlab.com/api/v4/groups/478446/epics/229',
      group: 'https://gitlab.com/api/v4/groups/478446',
      epic_issues: 'https://gitlab.com/api/v4/groups/478446/epics/229/issues',
    },
  },
  // CORRECT EPIC: Epic with content in parent group
  {
    id: 520625,
    iid: 229,  // SAME iid as the wrong epic!
    group_id: 557797,  // Parent group
    title: 'Epic with Full Content',
    description: '# Full Epic Content\n\nThis is the epic with actual content.',
    state: 'closed',  // Note: closed state may block updates!
    web_url: 'https://gitlab.com/groups/parent/-/epics/229',
    _links: {
      self: 'https://gitlab.com/api/v4/groups/557797/epics/229',
      group: 'https://gitlab.com/api/v4/groups/557797',
      epic_issues: 'https://gitlab.com/api/v4/groups/557797/epics/229/issues',
    },
  },
];

// Simulated loaded epic lists (as they would appear in the app)
let loadEpicResults: MockEpic[] = [];
let gitlabEpics: MockEpic[] = [];

describe('Epic Group ID Mismatch Investigation', () => {
  beforeEach(() => {
    // Reset lists
    loadEpicResults = [...SCENARIO_EPICS];
    gitlabEpics = [];
  });

  // ===========================================
  // TEST 1: Demonstrate the BUG
  // ===========================================
  test('BUG: find() by iid returns WRONG epic when duplicates exist', () => {
    console.log('\n' + '='.repeat(60));
    console.log('TEST 1: Demonstrating the Bug');
    console.log('='.repeat(60));

    const targetIid = 229;

    // This is the CURRENT buggy code from App.tsx line 2171:
    const epicFromList = gitlabEpics.find(e => e.iid === targetIid) ||
                         loadEpicResults.find(e => e.iid === targetIid);

    console.log('\nSearching for epic with iid:', targetIid);
    console.log('\nEpics in loadEpicResults:');
    loadEpicResults.forEach((e, i) => {
      console.log(`  [${i}] iid=${e.iid}, group_id=${e.group_id}, id=${e.id}, title="${e.title.substring(0, 30)}..."`);
    });

    console.log('\nResult of find(e => e.iid === 229):');
    console.log('  Found:', epicFromList ? `id=${epicFromList.id}, group_id=${epicFromList.group_id}` : 'null');

    // The bug: find() returns the FIRST match (index 0 = wrong epic)
    expect(epicFromList?.group_id).toBe(478446);  // WRONG GROUP!
    expect(epicFromList?.id).toBe(841693);  // WRONG EPIC ID!
    expect(epicFromList?.description).toBeNull();  // NO CONTENT!

    console.log('\n❌ BUG CONFIRMED: find() returned the WRONG epic!');
    console.log('   Expected: group_id=557797 (epic with content)');
    console.log('   Got:      group_id=478446 (empty epic)');
    console.log('\n   This is why "nothing changes" - updates go to the empty epic!');
  });

  // ===========================================
  // TEST 2: Show what happens during update
  // ===========================================
  test('BUG: Update uses wrong group_id', () => {
    console.log('\n' + '='.repeat(60));
    console.log('TEST 2: Update Flow with Wrong Group ID');
    console.log('='.repeat(60));

    const targetIid = 229;

    // Step 1: Find epic (buggy code)
    const epicFromList = loadEpicResults.find(e => e.iid === targetIid);
    const epicGroupId = epicFromList?.group_id ? String(epicFromList.group_id) : '557797';

    console.log('\nStep 1: Find epic by iid');
    console.log('  Found group_id:', epicGroupId);

    // Step 2: Construct update URL
    const updateUrl = `/api/v4/groups/${epicGroupId}/epics/${targetIid}`;

    console.log('\nStep 2: Construct update URL');
    console.log('  URL:', updateUrl);

    // Step 3: Show which epic gets updated
    const epicThatWillBeUpdated = SCENARIO_EPICS.find(
      e => e.group_id === Number(epicGroupId) && e.iid === targetIid
    );

    console.log('\nStep 3: Which epic will be updated?');
    console.log('  Epic ID:', epicThatWillBeUpdated?.id);
    console.log('  Title:', epicThatWillBeUpdated?.title);
    console.log('  Description:', epicThatWillBeUpdated?.description || '(null)');

    // The bug: We're updating the WRONG epic!
    expect(updateUrl).toBe('/api/v4/groups/478446/epics/229');  // WRONG URL!
    expect(epicThatWillBeUpdated?.description).toBeNull();  // EMPTY EPIC!

    console.log('\n❌ BUG: PUT request will update the EMPTY epic!');
    console.log('   Wrong URL: PUT /api/v4/groups/478446/epics/229 (empty epic)');
    console.log('   Correct:   PUT /api/v4/groups/557797/epics/229 (epic with content)');
  });

  // ===========================================
  // TEST 3: Demonstrate the FIX using _links.self
  // ===========================================
  test('FIX: Extract correct group_id from _links.self', () => {
    console.log('\n' + '='.repeat(60));
    console.log('TEST 3: Proposed Fix using _links.self');
    console.log('='.repeat(60));

    // The correct epic we want to update
    const correctEpic = SCENARIO_EPICS[1];  // id=520625, group=557797

    console.log('\nCorrect epic _links.self:', correctEpic._links?.self);

    // Extract group_id from _links.self URL
    function extractGroupIdFromSelfLink(selfLink: string): string | null {
      // URL format: https://gitlab.com/api/v4/groups/{group_id}/epics/{iid}
      const match = selfLink.match(/\/groups\/(\d+)\/epics\//);
      return match ? match[1] : null;
    }

    const extractedGroupId = extractGroupIdFromSelfLink(correctEpic._links!.self);

    console.log('Extracted group_id:', extractedGroupId);

    expect(extractedGroupId).toBe('557797');  // CORRECT GROUP!

    // Now construct the correct update URL
    const correctUpdateUrl = `/api/v4/groups/${extractedGroupId}/epics/${correctEpic.iid}`;

    console.log('\n✅ FIX: Use extracted group_id for update URL');
    console.log('   Correct URL:', correctUpdateUrl);

    expect(correctUpdateUrl).toBe('/api/v4/groups/557797/epics/229');
  });

  // ===========================================
  // TEST 4: Show additional issue - closed epic
  // ===========================================
  test('ISSUE: Target epic is CLOSED', () => {
    console.log('\n' + '='.repeat(60));
    console.log('TEST 4: Additional Issue - Epic State');
    console.log('='.repeat(60));

    const correctEpic = SCENARIO_EPICS[1];

    console.log('\nCorrect epic state:', correctEpic.state);

    // GitLab may reject updates to closed epics
    expect(correctEpic.state).toBe('closed');

    console.log('\n⚠️  WARNING: The epic with content is CLOSED');
    console.log('   GitLab may reject or ignore updates to closed epics.');
    console.log('   May need to reopen before updating:');
    console.log('   PUT /api/v4/groups/557797/epics/229 { "state_event": "reopen" }');
  });

  // ===========================================
  // TEST 5: Propose complete fix
  // ===========================================
  test('PROPOSED FIX: Complete solution', () => {
    console.log('\n' + '='.repeat(60));
    console.log('TEST 5: Proposed Complete Fix');
    console.log('='.repeat(60));

    console.log('\n📋 ROOT CAUSE:');
    console.log('   1. Two epics with same iid=229 in different groups');
    console.log('   2. find(e => e.iid === epicIid) returns FIRST match');
    console.log('   3. First match is from wrong group (478446)');
    console.log('   4. Update URL uses wrong group_id');
    console.log('   5. Empty epic (id=841693) is updated instead of content epic (id=520625)');

    console.log('\n📋 PROPOSED FIX:');
    console.log('   1. Add _links to GitLabEpic interface');
    console.log('   2. When loading epic details, store _links.self');
    console.log('   3. Extract group_id from _links.self instead of using group_id field');
    console.log('   4. Helper function: extractGroupIdFromSelfLink(epic._links.self)');

    console.log('\n📋 CODE CHANGE (src/App.tsx):');
    console.log(`
    // BEFORE (buggy):
    const epicFromList = gitlabEpics.find(e => e.iid === epicIid);
    const epicGroupId = epicFromList?.group_id ? String(epicFromList.group_id) : config.gitlab.rootGroupId;

    // AFTER (fixed):
    // When epic is loaded via fetchEpicDetails, use _links.self for authoritative group_id
    function getCanonicalGroupId(epic: GitLabEpic): string {
      if (epic._links?.self) {
        const match = epic._links.self.match(/\\/groups\\/(\\d+)\\/epics\\//);
        if (match) return match[1];
      }
      return String(epic.group_id);
    }
    const epicGroupId = getCanonicalGroupId(selectedGitLabEpic);
    `);

    console.log('\n📋 ADDITIONAL FIX (handle closed epic):');
    console.log(`
    // Check if epic is closed before updating
    if (selectedGitLabEpic.state === 'closed') {
      // Option 1: Show warning to user
      showToast('warning', 'Epic is Closed', 'Reopening epic before update...');

      // Option 2: Reopen first, then update
      await updateGitLabEpic(config.gitlab, epicIid, { state_event: 'reopen' }, epicGroupId);
    }
    `);

    expect(true).toBe(true);  // Documentation test
  });

  // ===========================================
  // TEST 6: Simulate correct flow
  // ===========================================
  test('VERIFICATION: Correct flow with fix applied', () => {
    console.log('\n' + '='.repeat(60));
    console.log('TEST 6: Verification - Correct Flow');
    console.log('='.repeat(60));

    // Simulate loading the CORRECT epic (id=520625)
    // In real app, this would come from fetchEpicDetails response
    const selectedGitLabEpic = SCENARIO_EPICS[1];  // The correct epic with content

    console.log('\nSimulating correct epic loaded:');
    console.log('  id:', selectedGitLabEpic.id);
    console.log('  iid:', selectedGitLabEpic.iid);
    console.log('  group_id (from field):', selectedGitLabEpic.group_id);
    console.log('  _links.self:', selectedGitLabEpic._links?.self);

    // Extract canonical group_id from _links.self
    function getCanonicalGroupId(epic: MockEpic): string {
      if (epic._links?.self) {
        const match = epic._links.self.match(/\/groups\/(\d+)\/epics\//);
        if (match) return match[1];
      }
      return String(epic.group_id);
    }

    const epicGroupId = getCanonicalGroupId(selectedGitLabEpic);

    console.log('\nExtracted canonical group_id:', epicGroupId);

    // Construct correct update URL
    const updateUrl = `/api/v4/groups/${epicGroupId}/epics/${selectedGitLabEpic.iid}`;

    console.log('Update URL:', updateUrl);

    // Verify it's the correct URL
    expect(epicGroupId).toBe('557797');
    expect(updateUrl).toBe('/api/v4/groups/557797/epics/229');

    console.log('\n✅ With the fix, update goes to the CORRECT epic!');
  });
});

// ===========================================
// SUMMARY
// ===========================================
describe('Investigation Summary', () => {
  test('prints final summary', () => {
    console.log('\n' + '='.repeat(70));
    console.log('EPIC GROUP ID MISMATCH - INVESTIGATION SUMMARY');
    console.log('='.repeat(70));

    console.log(`
┌─────────────────────────────────────────────────────────────────────┐
│                         THE PROBLEM                                  │
├─────────────────────────────────────────────────────────────────────┤
│ Two epics have the SAME iid (229) but exist in DIFFERENT groups:    │
│                                                                      │
│   Group 478446 → Epic ID 841693                                      │
│     - description: null (empty)                                      │
│     - state: opened                                                  │
│                                                                      │
│   Group 557797 → Epic ID 520625                                      │
│     - description: (has full content)                                │
│     - state: closed                                                  │
│                                                                      │
│ The app uses find(e => e.iid === 229) which returns the FIRST       │
│ match (group 478446), so updates go to the EMPTY epic.              │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                         THE FIX                                      │
├─────────────────────────────────────────────────────────────────────┤
│ 1. Add _links to GitLabEpic interface                                │
│                                                                      │
│ 2. Extract canonical group_id from _links.self:                      │
│    URL: "https://gitlab.com/api/v4/groups/557797/epics/229"         │
│    → group_id = "557797"                                             │
│                                                                      │
│ 3. Use canonical group_id for ALL API operations                     │
│                                                                      │
│ 4. Handle closed epic state if needed                                │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                      FILES TO MODIFY                                 │
├─────────────────────────────────────────────────────────────────────┤
│ 1. src/config.ts                                                     │
│    - Add _links to GitLabEpic interface                              │
│    - Add helper: extractGroupIdFromSelfLink()                        │
│                                                                      │
│ 2. src/App.tsx                                                       │
│    - Use canonical group_id from _links.self                         │
│    - Update handleUpdateGitLabEpic() to use canonical group_id       │
│    - Optionally: handle closed epic state                            │
└─────────────────────────────────────────────────────────────────────┘
`);

    expect(true).toBe(true);
  });
});
