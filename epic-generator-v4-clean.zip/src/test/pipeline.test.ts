import { describe, it, expect, vi, beforeEach, afterEach, beforeAll, afterAll } from 'vitest';
import {
  CATEGORY_CONFIGS,
  STORY_STYLE_PROMPTS,
  TONE_INSTRUCTIONS,
  runStage1Comprehension,
  runStage2Classification,
  runStage3Structural,
  runStage4Refinement,
  runStage5Mandatory,
  runStage6Validation,
  runPremiumPipeline,
  runPipelineAsCritique,
  setConfig,
  disableThrottlingForTests,
  enableThrottling
} from '../skills';
import {
  type EpicCategory,
  type CategoryConfig,
  type ComprehensionOutput,
  type ClassificationOutput,
  type StructuralOutput,
  type RefinementOutput,
  type MandatoryOutput,
  type PipelineResult,
  type PipelineUserStory,
  type ExtractedRequirement,
  type ValidationOutput,
  type EpicQualityReport
} from '../types';
import { type AppConfig, DEFAULT_CONFIG } from '../config';

// Mock the callAI function
vi.mock('../config', async () => {
  const actual = await vi.importActual('../config');
  return {
    ...actual,
    callAI: vi.fn()
  };
});

import { callAI } from '../config';
const mockCallAI = vi.mocked(callAI);

// Sample epic content for testing
const sampleEpicContent = `# Project Alpha

## 1. Objective
Build a scalable user authentication service for the platform.

## 2. Background & Context
The current authentication system is monolithic and doesn't support modern SSO requirements.

## 3. Scope
### In Scope
- User registration and login
- OAuth 2.0 integration
- JWT token management

### Out of Scope
- User profile management
- Payment integration

## 5. High-Level Architecture Overview
The service will use a microservice architecture with Redis for session caching.

## 11. Key Features & User Stories
- As a user, I want to login with my email so that I can access my account
- As a developer, I want API documentation so that I can integrate authentication
`;

// Mock responses for each stage
const mockComprehensionResponse = JSON.stringify({
  projectEssence: 'A scalable user authentication service replacing the monolithic system with modern SSO support.',
  keyEntities: [
    { entity: 'AuthService', type: 'service', relationships: ['Redis', 'UserDB'], description: 'Main authentication microservice' },
    { entity: 'Redis', type: 'database', relationships: ['AuthService'], description: 'Session cache' }
  ],
  detectedGaps: ['No monitoring strategy defined', 'Missing error handling approach'],
  implicitRisks: ['Migration from monolith may cause downtime', 'Session invalidation complexity'],
  semanticSections: [
    { sectionNum: 1, sectionTitle: 'Objective', semanticPurpose: 'Define the goal', keyTopics: ['authentication', 'scalability'], references: [], implicitContent: ['Expected scale not mentioned'] }
  ]
});

const mockClassificationResponse = JSON.stringify({
  primaryCategory: 'technical_design',
  confidence: 0.92,
  reasoning: 'Document focuses on system architecture and technical implementation details'
});

const mockStructuralResponse = JSON.stringify({
  sectionScores: [
    { sectionTitle: 'Objective', completeness: 8, relevance: 9, placement: 10, overallScore: 9 },
    { sectionTitle: 'Background', completeness: 7, relevance: 8, placement: 9, overallScore: 8 }
  ],
  transformationPlan: [
    { sectionTitle: 'Objective', action: 'keep', rationale: 'Section meets quality standards' },
    { sectionTitle: 'Background', action: 'restructure', rationale: 'Needs more technical context' }
  ],
  proposedOutline: ['Objective', 'Background', 'Architecture', 'NFRs']
});

const mockRefinementResponse = JSON.stringify({
  refinedContent: '## 1. Objective\n\nBuild a highly scalable user authentication service...',
  changes: ['Added scalability metrics', 'Clarified scope'],
  todosAdded: [],
  terminologyFixes: ['auth -> authentication']
});

const mockUserStoriesResponse = JSON.stringify({
  stories: [
    {
      id: 'US-001',
      persona: 'end user',
      goal: 'login with email',
      benefit: 'access my account securely',
      acceptanceCriteria: ['User can enter email and password', 'System validates credentials'],
      priority: 'high',
      sourceSection: 11,
      reqTags: [1, 2]
    }
  ],
  totalRequirements: 5,
  uncoveredRequirements: ['Admin user management']
});

const mockRequirementExtractionResponse = JSON.stringify({
  extractedRequirements: [
    { reqNum: 1, description: 'Build scalable user authentication service', sourceSection: 'Objective', sourceText: 'Build a scalable user authentication service', category: 'functional' },
    { reqNum: 2, description: 'Support OAuth 2.0 integration', sourceSection: 'Scope', sourceText: 'OAuth 2.0 integration', category: 'functional' },
    { reqNum: 3, description: 'JWT token management', sourceSection: 'Scope', sourceText: 'JWT token management', category: 'functional' }
  ],
  requirementCount: 3,
  gapAnalysis: [
    { reqNum: 1, hasEnoughDetail: true, openQuestions: [], detailLevel: 'complete' },
    { reqNum: 2, hasEnoughDetail: false, openQuestions: ['Which OAuth providers?'], detailLevel: 'partial' },
    { reqNum: 3, hasEnoughDetail: false, openQuestions: ['Token expiry policy?'], detailLevel: 'partial' }
  ],
  validOpenQuestions: ['Which OAuth providers should be supported?', 'What is the JWT token expiry policy?']
});

const mockValidationResponse = JSON.stringify({
  traceabilityTable: [
    { reqNum: 1, description: 'Build scalable auth', documentSections: ['Objective'], userStoryIds: ['US-001'], status: 'covered' },
    { reqNum: 2, description: 'OAuth 2.0', documentSections: ['Scope'], userStoryIds: ['US-001'], status: 'covered' },
    { reqNum: 3, description: 'JWT tokens', documentSections: ['Scope'], userStoryIds: ['US-002'], status: 'covered' }
  ],
  auditChecklist: [
    { category: 'requirements', rule: 'All requirements traced', passed: true, detail: '3/3 covered' },
    { category: 'stories', rule: 'All stories have reqTags', passed: true, detail: '1/1 tagged' }
  ],
  auditScore: 92,
  failureReasons: []
});

const mockValidationFailResponse = JSON.stringify({
  traceabilityTable: [
    { reqNum: 1, description: 'Build scalable auth', documentSections: [], userStoryIds: [], status: 'missing' }
  ],
  auditChecklist: [
    { category: 'requirements', rule: 'All requirements traced', passed: false, detail: '0/3 covered' }
  ],
  auditScore: 45,
  failureReasons: ['Requirement #1 not traced to any section', 'Requirement #3 not covered by any user story']
});

describe('Premium 7-Stage Pipeline', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    // Set up config for AI calls
    setConfig({
      ...DEFAULT_CONFIG,
      aiProvider: 'openai',
      openAI: {
        ...DEFAULT_CONFIG.openAI,
        enabled: true,
        apiKey: 'test-key'
      }
    });
  });

  afterEach(() => {
    vi.resetAllMocks();
  });

  // ===========================================
  // CATEGORY CONFIGS TESTS
  // ===========================================

  describe('CATEGORY_CONFIGS', () => {
    it('should have all 7 epic categories defined', () => {
      const categories: EpicCategory[] = [
        'business_requirement',
        'technical_design',
        'feature_specification',
        'api_specification',
        'infrastructure_design',
        'migration_plan',
        'integration_spec'
      ];

      categories.forEach(category => {
        expect(CATEGORY_CONFIGS[category]).toBeDefined();
      });
    });

    it('should have required properties for each category config', () => {
      Object.entries(CATEGORY_CONFIGS).forEach(([category, config]) => {
        expect(config.requiredSections).toBeInstanceOf(Array);
        expect(config.requiredSections.length).toBeGreaterThan(0);
        expect(config.tone).toBeDefined();
        expect(config.storyStyle).toBeDefined();
        expect(config.architectureFocus).toBeDefined();
      });
    });

    it('should have different required sections for different categories', () => {
      const businessSections = CATEGORY_CONFIGS.business_requirement.requiredSections;
      const technicalSections = CATEGORY_CONFIGS.technical_design.requiredSections;
      const apiSections = CATEGORY_CONFIGS.api_specification.requiredSections;

      // Business requirements should have different sections than API spec
      expect(businessSections).not.toEqual(apiSections);
      expect(technicalSections).not.toEqual(businessSections);
    });
  });

  describe('STORY_STYLE_PROMPTS', () => {
    it('should have prompts for all story styles', () => {
      const styles = ['business', 'technical', 'feature', 'api', 'infrastructure', 'migration', 'integration'];

      styles.forEach(style => {
        expect(STORY_STYLE_PROMPTS[style]).toBeDefined();
        expect(STORY_STYLE_PROMPTS[style]).toContain('As a');
      });
    });
  });

  describe('TONE_INSTRUCTIONS', () => {
    it('should have instructions for all tone types', () => {
      const tones = ['executive-friendly', 'precise-technical', 'user-focused', 'ops-focused', 'procedural'];

      tones.forEach(tone => {
        expect(TONE_INSTRUCTIONS[tone]).toBeDefined();
        expect(TONE_INSTRUCTIONS[tone].length).toBeGreaterThan(10);
      });
    });
  });

  // ===========================================
  // STAGE 1: DEEP COMPREHENSION TESTS
  // ===========================================

  describe('Stage 1: Deep Comprehension', () => {
    it('should extract project essence from epic content', async () => {
      mockCallAI.mockResolvedValueOnce(mockComprehensionResponse);
      mockCallAI.mockResolvedValueOnce(mockRequirementExtractionResponse); // Req extraction

      const result = await runStage1Comprehension(sampleEpicContent);

      expect(result.projectEssence).toContain('authentication');
      expect(result.timestamp).toBeDefined();
    });

    it('should identify key entities and relationships', async () => {
      mockCallAI.mockResolvedValueOnce(mockComprehensionResponse);
      mockCallAI.mockResolvedValueOnce(mockRequirementExtractionResponse);

      const result = await runStage1Comprehension(sampleEpicContent);

      expect(result.keyEntities.length).toBeGreaterThan(0);
      expect(result.keyEntities[0]).toHaveProperty('entity');
      expect(result.keyEntities[0]).toHaveProperty('type');
      expect(result.keyEntities[0]).toHaveProperty('relationships');
    });

    it('should detect gaps in content', async () => {
      mockCallAI.mockResolvedValueOnce(mockComprehensionResponse);
      mockCallAI.mockResolvedValueOnce(mockRequirementExtractionResponse);

      const result = await runStage1Comprehension(sampleEpicContent);

      expect(result.detectedGaps).toBeInstanceOf(Array);
    });

    it('should surface implicit risks', async () => {
      mockCallAI.mockResolvedValueOnce(mockComprehensionResponse);
      mockCallAI.mockResolvedValueOnce(mockRequirementExtractionResponse);

      const result = await runStage1Comprehension(sampleEpicContent);

      expect(result.implicitRisks).toBeInstanceOf(Array);
    });

    it('should extract requirements and perform gap analysis', async () => {
      mockCallAI.mockResolvedValueOnce(mockComprehensionResponse);
      mockCallAI.mockResolvedValueOnce(mockRequirementExtractionResponse);

      const result = await runStage1Comprehension(sampleEpicContent);

      expect(result.extractedRequirements).toBeDefined();
      expect(result.extractedRequirements!.length).toBe(3);
      expect(result.extractedRequirements![0]).toHaveProperty('reqNum');
      expect(result.extractedRequirements![0]).toHaveProperty('description');
      expect(result.extractedRequirements![0]).toHaveProperty('sourceSection');
      expect(result.extractedRequirements![0]).toHaveProperty('category');
      expect(result.requirementCount).toBe(3);
      expect(result.gapAnalysis).toBeDefined();
      expect(result.gapAnalysis!.length).toBe(3);
      expect(result.validOpenQuestions).toBeDefined();
      expect(result.validOpenQuestions!.length).toBe(2);
    });

    it('should gracefully handle requirement extraction failure', async () => {
      mockCallAI.mockResolvedValueOnce(mockComprehensionResponse);
      mockCallAI.mockRejectedValueOnce(new Error('Extraction failed'));

      const result = await runStage1Comprehension(sampleEpicContent);

      // Should still have base comprehension, just no requirements
      expect(result.projectEssence).toContain('authentication');
      expect(result.extractedRequirements).toBeUndefined();
    });

    it('should throw when AI not configured', async () => {
      // Reset config to null to simulate unconfigured state
      setConfig(null as unknown as AppConfig);

      await expect(runStage1Comprehension(sampleEpicContent))
        .rejects.toThrow('AI is not configured');

      // Restore config for other tests
      setConfig({
        ...DEFAULT_CONFIG,
        aiProvider: 'openai',
        openAI: { ...DEFAULT_CONFIG.openAI, enabled: true, apiKey: 'test-key' }
      });
    });
  });

  // ===========================================
  // STAGE 2: CATEGORY CLASSIFICATION TESTS
  // ===========================================

  describe('Stage 2: Category Classification', () => {
    const mockComprehension: ComprehensionOutput = {
      projectEssence: 'A technical authentication service',
      keyEntities: [{ entity: 'AuthService', type: 'service', relationships: [], description: 'Auth' }],
      detectedGaps: [],
      implicitRisks: [],
      semanticSections: [],
      timestamp: Date.now()
    };

    it('should classify technical documents correctly', async () => {
      mockCallAI.mockResolvedValueOnce(mockClassificationResponse);

      const result = await runStage2Classification(sampleEpicContent, mockComprehension);

      expect(result.primaryCategory).toBe('technical_design');
      expect(result.confidence).toBeGreaterThanOrEqual(0);
      expect(result.confidence).toBeLessThanOrEqual(1);
    });

    it('should return confidence score', async () => {
      mockCallAI.mockResolvedValueOnce(mockClassificationResponse);

      const result = await runStage2Classification(sampleEpicContent, mockComprehension);

      expect(result.confidence).toBe(0.92);
    });

    it('should provide category config', async () => {
      mockCallAI.mockResolvedValueOnce(mockClassificationResponse);

      const result = await runStage2Classification(sampleEpicContent, mockComprehension);

      expect(result.categoryConfig).toBeDefined();
      expect(result.categoryConfig.requiredSections).toBeInstanceOf(Array);
      expect(result.categoryConfig.tone).toBeDefined();
    });

    it('should include reasoning for classification', async () => {
      mockCallAI.mockResolvedValueOnce(mockClassificationResponse);

      const result = await runStage2Classification(sampleEpicContent, mockComprehension);

      expect(result.reasoning).toBeDefined();
      expect(result.reasoning.length).toBeGreaterThan(0);
    });
  });

  // ===========================================
  // STAGE 3: STRUCTURAL ASSESSMENT TESTS
  // ===========================================

  describe('Stage 3: Structural Assessment', () => {
    const mockComprehension: ComprehensionOutput = {
      projectEssence: 'A technical authentication service',
      keyEntities: [],
      detectedGaps: ['Missing NFRs'],
      implicitRisks: [],
      semanticSections: [],
      timestamp: Date.now()
    };

    const mockClassification: ClassificationOutput = {
      primaryCategory: 'technical_design',
      confidence: 0.9,
      categoryConfig: CATEGORY_CONFIGS.technical_design,
      reasoning: 'Technical content'
    };

    it('should score all sections on 3 dimensions', async () => {
      mockCallAI.mockResolvedValueOnce(mockStructuralResponse);

      const result = await runStage3Structural(sampleEpicContent, mockComprehension, mockClassification);

      result.sectionScores.forEach(score => {
        expect(score.completeness).toBeGreaterThanOrEqual(1);
        expect(score.completeness).toBeLessThanOrEqual(10);
        expect(score.relevance).toBeGreaterThanOrEqual(1);
        expect(score.relevance).toBeLessThanOrEqual(10);
        expect(score.placement).toBeGreaterThanOrEqual(1);
        expect(score.placement).toBeLessThanOrEqual(10);
      });
    });

    it('should identify sections needing transformation', async () => {
      mockCallAI.mockResolvedValueOnce(mockStructuralResponse);

      const result = await runStage3Structural(sampleEpicContent, mockComprehension, mockClassification);

      expect(result.transformationPlan).toBeInstanceOf(Array);
      result.transformationPlan.forEach(action => {
        expect(['keep', 'restructure', 'merge', 'split', 'add']).toContain(action.action);
        expect(action.rationale).toBeDefined();
      });
    });

    it('should detect missing required sections', async () => {
      mockCallAI.mockResolvedValueOnce(mockStructuralResponse);

      const result = await runStage3Structural(sampleEpicContent, mockComprehension, mockClassification);

      expect(result.missingSections).toBeInstanceOf(Array);
    });

    it('should propose optimal outline', async () => {
      mockCallAI.mockResolvedValueOnce(mockStructuralResponse);

      const result = await runStage3Structural(sampleEpicContent, mockComprehension, mockClassification);

      expect(result.proposedOutline).toBeInstanceOf(Array);
    });
  });

  // ===========================================
  // STAGE 4: CONTENT REFINEMENT TESTS
  // ===========================================

  describe('Stage 4: Content Refinement', () => {
    const mockComprehension: ComprehensionOutput = {
      projectEssence: 'A technical authentication service',
      keyEntities: [],
      detectedGaps: [],
      implicitRisks: [],
      semanticSections: [],
      timestamp: Date.now()
    };

    const mockClassification: ClassificationOutput = {
      primaryCategory: 'technical_design',
      confidence: 0.9,
      categoryConfig: CATEGORY_CONFIGS.technical_design,
      reasoning: 'Technical content'
    };

    const mockStructural: StructuralOutput = {
      sectionScores: [
        { sectionTitle: 'Objective', completeness: 8, relevance: 9, placement: 10, overallScore: 9 }
      ],
      transformationPlan: [
        { sectionTitle: 'Objective', action: 'keep', rationale: 'Good' }
      ],
      missingSections: [],
      proposedOutline: ['Objective']
    };

    it('should refine sections with progress callback', async () => {
      mockCallAI.mockResolvedValue(mockRefinementResponse);

      const progressUpdates: Array<{ current: number; total: number; section: string }> = [];

      const result = await runStage4Refinement(
        sampleEpicContent,
        mockComprehension,
        mockClassification,
        mockStructural,
        undefined, // originalProjectTitle
        (current, total, section) => {
          progressUpdates.push({ current, total, section });
        }
      );

      expect(result.refinedSections).toBeInstanceOf(Array);
      expect(progressUpdates.length).toBeGreaterThan(0);
    });

    it('should build terminology map', async () => {
      mockCallAI.mockResolvedValue(mockRefinementResponse);

      const result = await runStage4Refinement(
        sampleEpicContent,
        mockComprehension,
        mockClassification,
        mockStructural
      );

      expect(result.sectionsKept).toBeDefined();
      expect(result.sectionsRefined).toBeDefined();
      expect(result.sectionsAdded).toBeDefined();
    });

    it('should track section counts', async () => {
      mockCallAI.mockResolvedValue(mockRefinementResponse);

      const result = await runStage4Refinement(
        sampleEpicContent,
        mockComprehension,
        mockClassification,
        mockStructural
      );

      expect(result.totalSections).toBeGreaterThanOrEqual(0);
    });
  });

  // ===========================================
  // STAGE 5: MANDATORY SECTIONS TESTS
  // ===========================================

  describe('Stage 5: Mandatory Sections', () => {
    const mockRefinement: RefinementOutput = {
      refinedSections: [
        {
          sectionTitle: 'Objective',
          originalContent: 'Build auth',
          refinedContent: '## Objective\n\nBuild a scalable authentication service',
          action: 'restructure',
          changes: ['Added detail'],
          wasKept: false
        }
      ],
      sectionsKept: 0,
      sectionsRefined: 1,
      sectionsAdded: 0,
      totalSections: 1
    };

    const mockComprehension: ComprehensionOutput = {
      projectEssence: 'A technical authentication service for modern SSO',
      keyEntities: [],
      detectedGaps: [],
      implicitRisks: [],
      semanticSections: [],
      timestamp: Date.now()
    };

    const mockClassification: ClassificationOutput = {
      primaryCategory: 'technical_design',
      confidence: 0.9,
      categoryConfig: CATEGORY_CONFIGS.technical_design,
      reasoning: 'Technical content'
    };

    it('should generate user stories based on category', async () => {
      // Mock for blueprint generation (uses generateIntelligentBlueprint internally)
      mockCallAI.mockResolvedValueOnce('flowchart LR\n  A[Auth] --> B[User]');
      // Mock for user stories
      mockCallAI.mockResolvedValueOnce(mockUserStoriesResponse);

      const result = await runStage5Mandatory(mockRefinement, mockComprehension, mockClassification);

      expect(result.userStories).toBeInstanceOf(Array);
    });

    it('should track embedding status in assembledEpic', async () => {
      mockCallAI.mockResolvedValueOnce('flowchart LR\n  A[Auth] --> B[User]');
      mockCallAI.mockResolvedValueOnce(mockUserStoriesResponse);

      const result = await runStage5Mandatory(mockRefinement, mockComprehension, mockClassification);

      expect(result.assembledEpic).toBeDefined();
      expect(typeof result.assembledEpic.embeddedDiagram).toBe('boolean');
      expect(typeof result.assembledEpic.embeddedStories).toBe('boolean');
    });

    it('should assemble full refined epic', async () => {
      mockCallAI.mockResolvedValueOnce('flowchart LR\n  A[Auth] --> B[User]');
      mockCallAI.mockResolvedValueOnce(mockUserStoriesResponse);

      const result = await runStage5Mandatory(mockRefinement, mockComprehension, mockClassification);

      expect(result.assembledEpic).toBeDefined();
      expect(result.assembledEpic.markdown.length).toBeGreaterThan(0);
    });
  });

  // ===========================================
  // PIPELINE ORCHESTRATOR TESTS
  // ===========================================

  describe('Pipeline Orchestrator', () => {
    // Disable throttling for this test suite
    beforeAll(() => {
      disableThrottlingForTests();
    });

    afterAll(() => {
      enableThrottling();
    });

    // Helper: mock all pipeline stages with a passing validation on the N-th fallback call
    function mockFullPipeline() {
      // Since we can't predict exact call count (Stage 4 varies by sections found),
      // use mockImplementation to return appropriate responses based on call order + content.
      let callCount = 0;
      mockCallAI.mockImplementation(async (_config: unknown, systemPrompt: string, userPrompt: string) => {
        callCount++;
        // First 4 specific calls are for stages 1-3
        if (callCount === 1) return mockComprehensionResponse;
        if (callCount === 2) return mockRequirementExtractionResponse;
        if (callCount === 3) return mockClassificationResponse;
        if (callCount === 4) return mockStructuralResponse;

        // For Stage 6 validation calls (detect by user prompt content)
        if (typeof userPrompt === 'string' && userPrompt.includes('Validate traceability')) {
          return mockValidationResponse;
        }

        // For Stage 5A blueprint generation (detect by system prompt content)
        if (typeof systemPrompt === 'string' && systemPrompt.includes('mermaid')) {
          return 'flowchart LR\n  A[Auth Service] --> B[User DB]\n  A --> C[Redis Cache]';
        }

        // For Stage 5B user stories (detect by system prompt content)
        if (typeof systemPrompt === 'string' && systemPrompt.includes('user stories')) {
          return mockUserStoriesResponse;
        }

        // All other calls (Stage 4 refinement, etc.)
        return mockRefinementResponse;
      });
    }

    it('should run all 6 stages in sequence', async () => {
      mockFullPipeline();

      const result = await runPremiumPipeline(sampleEpicContent);

      expect(result.stagesCompleted).toContain(1);
      expect(result.stagesCompleted).toContain(2);
      expect(result.stagesCompleted).toContain(3);
      expect(result.stagesCompleted).toContain(4);
      expect(result.stagesCompleted).toContain(5);
      expect(result.stagesCompleted).toContain(6);
      expect(result.comprehension).toBeDefined();
      expect(result.classification).toBeDefined();
      expect(result.structural).toBeDefined();
      expect(result.refinement).toBeDefined();
      expect(result.mandatory).toBeDefined();
      expect(result.iterationsRun).toBeGreaterThanOrEqual(1);
    }, 60000);

    it('should report progress through callback including stage 6', async () => {
      mockFullPipeline();

      const progressUpdates: Array<{ stage: number; status: string; detail: string }> = [];

      await runPremiumPipeline(sampleEpicContent, (stage, status, detail) => {
        progressUpdates.push({ stage, status, detail });
      });

      // Should have progress for all 6 stages
      const stages = new Set(progressUpdates.map(p => p.stage));
      expect(stages.size).toBe(6);
    }, 60000);

    it('should return complete PipelineResult with validation', async () => {
      mockFullPipeline();

      const result = await runPremiumPipeline(sampleEpicContent);

      expect(result.totalDuration).toBeGreaterThan(0);
      expect(result.mandatory.assembledEpic).toBeDefined();
      expect(result.mandatory.assembledEpic.markdown).toBeDefined();
      expect(result.iterationsRun).toBeDefined();
      expect(result.validation).toBeDefined();
    }, 60000);

    it('should handle stage failure gracefully', async () => {
      mockCallAI.mockRejectedValueOnce(new Error('AI service unavailable'));

      await expect(runPremiumPipeline(sampleEpicContent))
        .rejects.toThrow('Pipeline failed at stage 1');
    });
  });

  // ===========================================
  // STAGE 6: VALIDATION GATE TESTS
  // ===========================================

  describe('Stage 6: Validation Gate', () => {
    const sampleRequirements: ExtractedRequirement[] = [
      { reqNum: 1, description: 'Build scalable authentication service', sourceSection: 'Objective', sourceText: 'Build a scalable user authentication service', category: 'functional' },
      { reqNum: 2, description: 'Support OAuth 2.0 integration', sourceSection: 'Scope', sourceText: 'OAuth 2.0 integration', category: 'functional' },
      { reqNum: 3, description: 'JWT token management', sourceSection: 'Scope', sourceText: 'JWT token management', category: 'functional' }
    ];

    const sampleStories: PipelineUserStory[] = [
      {
        id: 'US-001',
        persona: 'end user',
        goal: 'login with email',
        benefit: 'access my account securely',
        acceptanceCriteria: ['User can enter email', 'System validates credentials'],
        priority: 'high',
        sourceSection: 11,
        reqTags: [1, 2]
      },
      {
        id: 'US-002',
        persona: 'developer',
        goal: 'manage JWT tokens',
        benefit: 'secure API access',
        acceptanceCriteria: ['Tokens expire after TTL', 'Refresh tokens work'],
        priority: 'medium',
        sourceSection: 11,
        reqTags: [3]
      }
    ];

    const sampleEpic = `# Project Alpha\n\n## Objective\nBuild a scalable authentication service with OAuth 2.0 and JWT token management.\n\n## Scope\nOAuth 2.0 integration and JWT token management.`;
    const sampleDiagram = 'flowchart LR\n  A[Auth Service] --> B[OAuth Provider]\n  A --> C[JWT Manager]';

    it('should build traceability table via AI', async () => {
      mockCallAI.mockResolvedValueOnce(mockValidationResponse);

      const result = await runStage6Validation(
        sampleEpic,
        sampleRequirements,
        sampleStories,
        sampleDiagram,
        1
      );

      expect(result.traceabilityTable).toBeDefined();
      expect(result.traceabilityTable.length).toBeGreaterThan(0);
      expect(result.iterationNumber).toBe(1);
    });

    it('should detect failure patterns deterministically', async () => {
      // Use a validation response with low score to trigger deterministic checks
      mockCallAI.mockResolvedValueOnce(mockValidationResponse);

      const storiesWithoutTags: PipelineUserStory[] = [
        {
          id: 'US-001',
          persona: 'user',
          goal: 'do something',
          benefit: 'benefit',
          acceptanceCriteria: ['works'],
          priority: 'high',
          sourceSection: 1
          // No reqTags!
        }
      ];

      const result = await runStage6Validation(
        sampleEpic,
        sampleRequirements,
        storiesWithoutTags,
        sampleDiagram,
        1
      );

      // Should detect "Partial Story Coverage" since stories have no reqTags
      const partialCoverageFailure = result.detectedFailures.find(
        f => f.pattern === 'partial_story_coverage'
      );
      expect(partialCoverageFailure).toBeDefined();
    });

    it('should detect template artifacts', async () => {
      mockCallAI.mockResolvedValueOnce(mockValidationResponse);

      const epicWithPlaceholders = sampleEpic + '\n\n## TODO Section\n[TODO] Fill in details\n[TBD] To be determined\nlorem ipsum dolor sit amet';

      const result = await runStage6Validation(
        epicWithPlaceholders,
        sampleRequirements,
        sampleStories,
        sampleDiagram,
        1
      );

      const artifactFailure = result.detectedFailures.find(
        f => f.pattern === 'template_artifacts'
      );
      expect(artifactFailure).toBeDefined();
    });

    it('should skip AI validation when no requirements extracted', async () => {
      const result = await runStage6Validation(
        sampleEpic,
        [], // No requirements
        sampleStories,
        sampleDiagram,
        1
      );

      // Should still return a result but with empty traceability
      expect(result.traceabilityTable).toEqual([]);
      expect(mockCallAI).not.toHaveBeenCalled();
    });

    it('should accept previous failures for context', async () => {
      mockCallAI.mockResolvedValueOnce(mockValidationResponse);

      const result = await runStage6Validation(
        sampleEpic,
        sampleRequirements,
        sampleStories,
        sampleDiagram,
        2,
        ['Requirement #3 not traced']
      );

      expect(result.iterationNumber).toBe(2);
    });
  });

  // ===========================================
  // BACKWARD COMPATIBILITY TESTS
  // ===========================================

  describe('Backward Compatibility', () => {
    it('should return EpicQualityReport from runPipelineAsCritique', async () => {
      mockCallAI
        .mockResolvedValueOnce(mockComprehensionResponse)
        .mockResolvedValueOnce(mockRequirementExtractionResponse) // Stage 1 now has 2 AI calls
        .mockResolvedValueOnce(mockClassificationResponse)
        .mockResolvedValueOnce(mockStructuralResponse);

      const report = await runPipelineAsCritique(sampleEpicContent);

      expect(report.overallScore).toBeGreaterThanOrEqual(0);
      expect(report.overallScore).toBeLessThanOrEqual(10);
      expect(report.summary).toBeDefined();
      expect(report.sections).toBeInstanceOf(Array);
      expect(report.criticalIssues).toBeInstanceOf(Array);
      expect(report.strengthAreas).toBeInstanceOf(Array);
      expect(report.missingRequired).toBeInstanceOf(Array);
    });

    it('should have sections with correct structure', async () => {
      mockCallAI
        .mockResolvedValueOnce(mockComprehensionResponse)
        .mockResolvedValueOnce(mockRequirementExtractionResponse) // Stage 1 now has 2 AI calls
        .mockResolvedValueOnce(mockClassificationResponse)
        .mockResolvedValueOnce(mockStructuralResponse);

      const report = await runPipelineAsCritique(sampleEpicContent);

      report.sections.forEach(section => {
        expect(section.sectionNum).toBeDefined();
        expect(section.sectionTitle).toBeDefined();
        expect(section.score).toBeGreaterThanOrEqual(0);
        expect(['strong', 'adequate', 'weak', 'missing']).toContain(section.status);
        expect(section.issues).toBeInstanceOf(Array);
        expect(section.suggestions).toBeInstanceOf(Array);
      });
    });
  });
});
