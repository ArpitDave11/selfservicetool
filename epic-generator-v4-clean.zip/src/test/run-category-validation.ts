#!/usr/bin/env npx tsx
/**
 * Category Validation Script — Multi-Category Quality Assessment
 *
 * Run with:
 *   OPENAI_API_KEY=sk-... npx tsx src/test/run-category-validation.ts
 *
 * This runs the full 6-stage pipeline (with real AI) against all 7 category fixtures
 * and outputs a quality report.
 */

import { readFileSync } from 'fs';
import { resolve, dirname } from 'path';
import { fileURLToPath } from 'url';

// Must set config BEFORE importing skills (which reads config at import time)
const API_KEY = process.env.OPENAI_API_KEY || '';
if (!API_KEY) {
  console.error('ERROR: OPENAI_API_KEY environment variable is required');
  console.error('Usage: OPENAI_API_KEY=sk-... npx tsx src/test/run-category-validation.ts');
  process.exit(1);
}

import {
  runPremiumPipeline,
  setConfig,
  disableThrottlingForTests,
  enableThrottling
} from '../skills';
import { type PipelineResult } from '../types';
import { DEFAULT_CONFIG } from '../config';

// ===== FIXTURES =====
const FIXTURES_DIR = resolve(dirname(fileURLToPath(import.meta.url)), 'fixtures');

interface CategoryFixture {
  category: string;
  filename: string;
  expectedMinRequirements: number;
}

const CATEGORY_FIXTURES: CategoryFixture[] = [
  { category: 'integration_spec', filename: 'broadridge-reference-epic.md', expectedMinRequirements: 5 },
  { category: 'technical_design', filename: 'tech-design-auth-service.md', expectedMinRequirements: 4 },
  { category: 'feature_specification', filename: 'feature-spec-mobile-checkout.md', expectedMinRequirements: 4 },
  { category: 'api_specification', filename: 'api-spec-payment-gateway.md', expectedMinRequirements: 4 },
  { category: 'infrastructure_design', filename: 'infra-design-k8s-migration.md', expectedMinRequirements: 4 },
  { category: 'migration_plan', filename: 'migration-plan-postgres-upgrade.md', expectedMinRequirements: 4 },
  { category: 'business_requirement', filename: 'business-req-digital-transformation.md', expectedMinRequirements: 4 }
];

// ===== QUALITY CHECKS =====
interface QualityResult {
  category: string;
  filename: string;
  passed: boolean;
  iterationsRun: number;
  auditScore: number;
  requirementsExtracted: number;
  storiesGenerated: number;
  storiesWithReqTags: number;
  traceabilityCoverage: number;
  hardFails: number;
  failureReasons: string[];
  duration: number;
  checks: Record<string, { passed: boolean; detail: string }>;
  error?: string;
}

function runQualityChecks(result: PipelineResult, sourceContent?: string): Record<string, { passed: boolean; detail: string }> {
  const checks: Record<string, { passed: boolean; detail: string }> = {};
  const reqs = result.comprehension.extractedRequirements || [];
  const stories = result.mandatory.userStories;
  const validation = result.validation;
  const epic = result.mandatory.assembledEpic.markdown;

  // Q1: Requirements extracted
  checks['Q1_requirements_extracted'] = {
    passed: reqs.length >= 3,
    detail: `${reqs.length} requirements extracted`
  };

  // Q2: No generic template components in diagram
  const diagram = result.mandatory.architectureDiagram;
  const genericNodes = ['Component A', 'Service B', 'Database C', 'Module X'];
  const hasGeneric = genericNodes.some(n => diagram.includes(n));
  checks['Q2_no_generic_diagram_nodes'] = {
    passed: !hasGeneric,
    detail: hasGeneric ? 'Found generic placeholder nodes' : 'All nodes are source-specific'
  };

  // Q3: Stories generated
  checks['Q3_stories_generated'] = {
    passed: stories.length >= 3,
    detail: `${stories.length} user stories generated`
  };

  // Q4: Story format
  const storiesWithBadFormat = stories.filter(s => {
    const hasGoal = s.goal && s.goal.length > 3;
    const hasBenefit = s.benefit && s.benefit.length > 3;
    return !hasGoal || !hasBenefit;
  });
  checks['Q4_story_format'] = {
    passed: storiesWithBadFormat.length === 0,
    detail: storiesWithBadFormat.length > 0
      ? `${storiesWithBadFormat.length} stories with bad format`
      : 'All stories have proper format'
  };

  // Q5: No "Decision/Tradeoff" pattern
  const hasDecisionTradeoff = /\*\*Decision\*\*:.*\*\*Tradeoff?\*\*:/s.test(epic);
  checks['Q5_no_decision_tradeoff'] = {
    passed: !hasDecisionTradeoff,
    detail: hasDecisionTradeoff ? 'Found banned Decision/Tradeoff pattern' : 'Clean'
  };

  // Q6: Diagram type is not sankey
  const diagramType = result.mandatory.diagramType;
  checks['Q6_diagram_type'] = {
    passed: diagramType !== 'sankey',
    detail: `Diagram type: ${diagramType}`
  };

  // Q7: No placeholder text (excluding Open Questions section and source-inherited placeholders)
  const epicWithoutOQ = epic.replace(/##\s*(?:\d+\.\s*)?Open Questions[\s\S]*?(?=\n##\s|\n---|\n\*Generated on|$)/gi, '');
  const outputPlaceholders = (epicWithoutOQ.match(/\[TODO\]|\[TBD\]|\[PLACEHOLDER\]|lorem ipsum/gi) || []).length;
  const sourcePlaceholders = sourceContent
    ? (sourceContent.match(/\[TODO\]|\[TBD\]|\[PLACEHOLDER\]|lorem ipsum/gi) || []).length
    : 0;
  // Pass if output has no NEW placeholders beyond what the source already had
  const hasNewPlaceholders = outputPlaceholders > 0 && outputPlaceholders > sourcePlaceholders;
  checks['Q7_no_placeholders'] = {
    passed: !hasNewPlaceholders,
    detail: outputPlaceholders > 0
      ? `${outputPlaceholders} placeholder(s)${sourcePlaceholders > 0 ? ` (${sourcePlaceholders} from source)` : ''}`
      : 'No placeholders'
  };

  // Q8: Audit score >= 85
  checks['Q8_audit_score'] = {
    passed: (validation?.auditScore ?? 0) >= 85,
    detail: `Score: ${validation?.auditScore ?? 'N/A'}`
  };

  // Q9: All stories have [Req #N] tags
  const storiesWithTags = stories.filter(s => s.reqTags && s.reqTags.length > 0);
  checks['Q9_stories_req_tags'] = {
    passed: storiesWithTags.length === stories.length,
    detail: `${storiesWithTags.length}/${stories.length} stories tagged`
  };

  // Q10: Traceability coverage >= 60% (AI traceability is noisy — 60% is a reasonable floor)
  checks['Q10_traceability'] = {
    passed: (validation?.traceabilityCoverage ?? 0) >= 60,
    detail: `${validation?.traceabilityCoverage ?? 0}% coverage`
  };

  // Q11: No hard fails
  checks['Q11_no_hard_fails'] = {
    passed: (validation?.hardFailCount ?? 0) === 0,
    detail: `${validation?.hardFailCount ?? 0} hard fails`
  };

  // Q12: Word count reasonable
  const wordCount = result.mandatory.assembledEpic.wordCount;
  checks['Q12_word_count'] = {
    passed: wordCount >= 500 && wordCount <= 8000,
    detail: `${wordCount} words`
  };

  return checks;
}

// ===== MAIN =====
async function main() {
  console.log('========================================');
  console.log('  CATEGORY VALIDATION — Full Pipeline');
  console.log('========================================\n');

  // Configure AI
  setConfig({
    ...DEFAULT_CONFIG,
    aiProvider: 'openai',
    openAI: {
      ...DEFAULT_CONFIG.openAI,
      enabled: true,
      apiKey: API_KEY
    }
  });
  disableThrottlingForTests();

  const allResults: QualityResult[] = [];

  // Allow filtering by category via CLI args
  const requestedCategories = process.argv.slice(2).filter(a => !a.startsWith('-'));
  const fixtures = requestedCategories.length > 0
    ? CATEGORY_FIXTURES.filter(f => requestedCategories.includes(f.category))
    : CATEGORY_FIXTURES;

  if (requestedCategories.length > 0) {
    console.log(`Running ${fixtures.length} categories: ${fixtures.map(f => f.category).join(', ')}\n`);
  } else {
    console.log(`Running all ${fixtures.length} categories\n`);
  }

  for (const fixture of fixtures) {
    console.log(`\n--- Processing: ${fixture.category} (${fixture.filename}) ---`);
    const epicContent = readFileSync(resolve(FIXTURES_DIR, fixture.filename), 'utf-8');

    try {
      const startTime = Date.now();
      const result = await runPremiumPipeline(epicContent, (stage, status, detail) => {
        if (status === 'running') {
          process.stdout.write(`  Stage ${stage}: ${detail}\r`);
        } else if (status === 'complete') {
          console.log(`  Stage ${stage}: ${detail}`);
        } else if (status === 'error') {
          console.log(`  Stage ${stage}: ERROR - ${detail}`);
        }
      });
      const duration = Date.now() - startTime;

      const reqs = result.comprehension.extractedRequirements || [];
      const stories = result.mandatory.userStories;
      const validation = result.validation;
      const checks = runQualityChecks(result, epicContent);
      const allChecksPassed = Object.values(checks).every(c => c.passed);

      const qualityResult: QualityResult = {
        category: fixture.category,
        filename: fixture.filename,
        passed: allChecksPassed,
        iterationsRun: result.iterationsRun || 1,
        auditScore: validation?.auditScore ?? 0,
        requirementsExtracted: reqs.length,
        storiesGenerated: stories.length,
        storiesWithReqTags: stories.filter(s => s.reqTags && s.reqTags.length > 0).length,
        traceabilityCoverage: validation?.traceabilityCoverage ?? 0,
        hardFails: validation?.hardFailCount ?? 0,
        failureReasons: validation?.failureReasons ?? [],
        duration,
        checks
      };

      allResults.push(qualityResult);

      console.log(`  Duration: ${(duration / 1000).toFixed(1)}s | Iterations: ${qualityResult.iterationsRun}`);
      console.log(`  Requirements: ${qualityResult.requirementsExtracted} | Stories: ${qualityResult.storiesGenerated} (${qualityResult.storiesWithReqTags} tagged)`);
      console.log(`  Audit: ${qualityResult.auditScore}/100 | Traceability: ${qualityResult.traceabilityCoverage}% | Hard fails: ${qualityResult.hardFails}`);
      console.log('  Checks:');
      for (const [name, check] of Object.entries(checks)) {
        console.log(`    ${check.passed ? 'PASS' : 'FAIL'} ${name}: ${check.detail}`);
      }
      if (qualityResult.failureReasons.length > 0) {
        console.log('  Failure reasons:', qualityResult.failureReasons.slice(0, 5).join('; '));
      }
      console.log(`  Result: ${qualityResult.passed ? 'PASS' : 'FAIL'}`);

    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error);
      console.error(`  ERROR: ${errorMsg}`);
      allResults.push({
        category: fixture.category,
        filename: fixture.filename,
        passed: false,
        iterationsRun: 0,
        auditScore: 0,
        requirementsExtracted: 0,
        storiesGenerated: 0,
        storiesWithReqTags: 0,
        traceabilityCoverage: 0,
        hardFails: 0,
        failureReasons: [errorMsg],
        duration: 0,
        checks: {},
        error: errorMsg
      });
    }
  }

  enableThrottling();

  // ===== FINAL REPORT =====
  console.log('\n\n========================================');
  console.log('      FINAL QUALITY REPORT');
  console.log('========================================\n');

  console.log('| Category | Pass | Score | Reqs | Stories | Tagged | Coverage | Iters | Time |');
  console.log('|----------|------|-------|------|---------|--------|----------|-------|------|');

  for (const r of allResults) {
    if (r.error) {
      console.log(`| ${r.category} | ERROR | - | - | - | - | - | - | - |`);
    } else {
      console.log(
        `| ${r.category} | ${r.passed ? 'PASS' : 'FAIL'} | ${r.auditScore} | ${r.requirementsExtracted} | ${r.storiesGenerated} | ${r.storiesWithReqTags} | ${r.traceabilityCoverage}% | ${r.iterationsRun} | ${(r.duration / 1000).toFixed(0)}s |`
      );
    }
  }

  const totalPassed = allResults.filter(r => r.passed).length;
  const totalErrors = allResults.filter(r => r.error).length;
  console.log(`\nTotal: ${totalPassed}/${allResults.length} passed, ${totalErrors} errors`);

  // Per-check summary
  const nonErrorResults = allResults.filter(r => !r.error);
  if (nonErrorResults.length > 0) {
    console.log('\nPer-check summary:');
    const checkNames = Object.keys(nonErrorResults[0].checks);
    for (const name of checkNames) {
      const passed = nonErrorResults.filter(r => r.checks[name]?.passed).length;
      console.log(`  ${name}: ${passed}/${nonErrorResults.length} passed`);
    }
  }

  // Exit with error code if any failed
  if (totalPassed < allResults.length) {
    process.exit(1);
  }
}

main().catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
