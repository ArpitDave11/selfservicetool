/**
 * Epic Update Unit Tests
 *
 * These tests validate the epic update flow to identify the root cause of
 * "update not happening" issue.
 *
 * Run: npm run test:run -- epicUpdate
 */

import { describe, test, expect, vi, beforeEach } from 'vitest';
import {
  mockUpdateGitLabEpic,
  mockFetchEpicDetails,
  mockEpics,
  MOCK_GITLAB_ENABLED,
} from '../mockGitLabData';
import type { GitLabConfig, GitLabUpdateEpicParams } from '../config';

// Test configuration
const testConfig: GitLabConfig = {
  enabled: true,
  url: 'https://mock-gitlab.test',
  accessToken: 'mock-token',
  rootGroupId: '557797',
  projectId: '',
  branch: '',
  epicFilePath: '',
  crewLabelPrefix: 'crew::',
  podLabelPrefix: 'pod::',
};

describe('Epic Update Flow Tests', () => {
  beforeEach(() => {
    // Reset console spies
    vi.restoreAllMocks();
  });

  // ===========================================
  // TEST 1: Verify MOCK_GITLAB_ENABLED status
  // ===========================================
  test('MOCK_GITLAB_ENABLED should be true for mock mode', () => {
    console.log('\n=== TEST 1: Mock Mode Status ===');
    console.log('MOCK_GITLAB_ENABLED:', MOCK_GITLAB_ENABLED);

    expect(MOCK_GITLAB_ENABLED).toBe(true);
    console.log('✓ Mock mode is enabled - updates will be in-memory only');
  });

  // ===========================================
  // TEST 2: Test mock epic exists in array
  // ===========================================
  test('should find test epic in mockEpics array', () => {
    console.log('\n=== TEST 2: Mock Epic Exists ===');

    // Test epic IID 101 (first mock epic)
    const testEpicIid = 101;
    const epic = mockEpics.find((e) => e.iid === testEpicIid);

    console.log('Looking for epic with iid:', testEpicIid);
    console.log('Found:', epic ? `${epic.iid} - ${epic.title}` : 'NOT FOUND');
    console.log('Epic group_id:', epic?.group_id);

    expect(epic).toBeDefined();
    expect(epic?.iid).toBe(testEpicIid);
    expect(epic?.group_id).toBeDefined();
    console.log('✓ Test epic found in mock data');
  });

  // ===========================================
  // TEST 3: Test mockUpdateGitLabEpic function
  // ===========================================
  test('mockUpdateGitLabEpic should update epic in memory', async () => {
    console.log('\n=== TEST 3: Mock Update Function ===');

    const testEpicIid = 101;
    const originalEpic = mockEpics.find((e) => e.iid === testEpicIid)!;
    const originalTitle = originalEpic.title;
    const originalDescription = originalEpic.description;

    console.log('Original title:', originalTitle);
    console.log('Original description length:', originalDescription.length);

    // Prepare update params
    const updateParams: GitLabUpdateEpicParams = {
      title: 'Updated Test Title',
      description: '# Updated Epic Content\n\nThis is the updated description.',
    };

    const epicGroupId = String(originalEpic.group_id);
    console.log('Calling mockUpdateGitLabEpic with:');
    console.log('  - epicIid:', testEpicIid);
    console.log('  - groupId:', epicGroupId);
    console.log('  - new title:', updateParams.title);

    // Call the update function
    const result = await mockUpdateGitLabEpic(testConfig, testEpicIid, updateParams, epicGroupId);

    console.log('Result:', {
      success: result.success,
      hasData: !!result.data,
      error: result.error,
    });

    // Verify result
    expect(result.success).toBe(true);
    expect(result.data).toBeDefined();
    expect(result.data?.title).toBe(updateParams.title);
    expect(result.data?.description).toBe(updateParams.description);

    // Verify in-memory array was updated
    const updatedEpic = mockEpics.find((e) => e.iid === testEpicIid);
    console.log('After update - title in mockEpics:', updatedEpic?.title);

    expect(updatedEpic?.title).toBe(updateParams.title);
    expect(updatedEpic?.description).toBe(updateParams.description);

    console.log('✓ Mock update function works correctly');

    // IMPORTANT: Restore original values for other tests
    if (updatedEpic) {
      updatedEpic.title = originalTitle;
      updatedEpic.description = originalDescription;
    }
  });

  // ===========================================
  // TEST 4: Test mockFetchEpicDetails returns group_id
  // ===========================================
  test('mockFetchEpicDetails should return epic with group_id', async () => {
    console.log('\n=== TEST 4: Fetch Epic Details ===');

    const testEpicIid = 101;
    const result = await mockFetchEpicDetails(testConfig, testEpicIid);

    console.log('Fetched epic:', {
      success: result.success,
      iid: result.data?.iid,
      title: result.data?.title?.substring(0, 50),
      group_id: result.data?.group_id,
    });

    expect(result.success).toBe(true);
    expect(result.data).toBeDefined();
    expect(result.data?.group_id).toBeDefined();
    expect(typeof result.data?.group_id).toBe('number');

    console.log('✓ Epic details include group_id');
  });

  // ===========================================
  // TEST 5: Test update with wrong epic IID
  // ===========================================
  test('mockUpdateGitLabEpic should return error for non-existent epic', async () => {
    console.log('\n=== TEST 5: Update Non-Existent Epic ===');

    const nonExistentIid = 99999;
    const updateParams: GitLabUpdateEpicParams = {
      title: 'This should fail',
    };

    console.log('Attempting to update non-existent epic:', nonExistentIid);

    const result = await mockUpdateGitLabEpic(testConfig, nonExistentIid, updateParams);

    console.log('Result:', {
      success: result.success,
      error: result.error,
    });

    expect(result.success).toBe(false);
    expect(result.error).toBe('Epic not found');

    console.log('✓ Non-existent epic returns error');
  });

  // ===========================================
  // TEST 6: Verify update flow with groupId
  // ===========================================
  test('should pass correct groupId through update flow', async () => {
    console.log('\n=== TEST 6: GroupId Flow ===');

    // Simulate the App.tsx flow:
    // 1. Load epic details (sets selectedGitLabEpic)
    // 2. Extract group_id from selectedGitLabEpic
    // 3. Call update with group_id

    // Step 1: Load epic
    const testEpicIid = 102; // OAuth epic with different group
    const loadResult = await mockFetchEpicDetails(testConfig, testEpicIid);

    console.log('Step 1 - Loaded epic:');
    console.log('  - iid:', loadResult.data?.iid);
    console.log('  - group_id:', loadResult.data?.group_id);

    expect(loadResult.success).toBe(true);
    const selectedGitLabEpic = loadResult.data;

    // Step 2: Extract group_id (as done in handleUpdateGitLabEpic)
    const epicGroupId = selectedGitLabEpic?.group_id ? String(selectedGitLabEpic.group_id) : undefined;

    console.log('Step 2 - Extracted epicGroupId:', epicGroupId);

    expect(epicGroupId).toBeDefined();

    // Step 3: Call update
    const updateParams: GitLabUpdateEpicParams = {
      title: 'Test Update via GroupId',
      description: '# Test\n\nContent',
    };

    console.log('Step 3 - Calling update with groupId:', epicGroupId);

    const updateResult = await mockUpdateGitLabEpic(
      testConfig,
      testEpicIid,
      updateParams,
      epicGroupId
    );

    console.log('Update result:', {
      success: updateResult.success,
      updatedTitle: updateResult.data?.title,
    });

    expect(updateResult.success).toBe(true);
    expect(updateResult.data?.title).toBe(updateParams.title);

    console.log('✓ GroupId flows correctly through update');

    // Restore original
    const epic = mockEpics.find((e) => e.iid === testEpicIid);
    if (epic) {
      epic.title = 'OAuth 2.0 Authentication System';
      epic.description = loadResult.data?.description || '';
    }
  });

  // ===========================================
  // TEST 7: Simulate selectedGitLabEpic null issue
  // ===========================================
  test('should identify when selectedGitLabEpic would be null', () => {
    console.log('\n=== TEST 7: Null selectedGitLabEpic Detection ===');

    // Simulate the guard clause in handleUpdateGitLabEpic
    const selectedGitLabEpic = null;

    console.log('Simulating handleUpdateGitLabEpic with null epic...');

    if (!selectedGitLabEpic) {
      console.log('⚠️  EARLY RETURN - selectedGitLabEpic is null!');
      console.log('   This would cause "nothing changes" with NO feedback to user');
    }

    // This test documents the issue
    expect(selectedGitLabEpic).toBeNull();
    console.log('✓ Test demonstrates the silent failure case');
  });

  // ===========================================
  // TEST 8: Verify mock persistence behavior
  // ===========================================
  test('should demonstrate mock data is not persisted', async () => {
    console.log('\n=== TEST 8: Mock Persistence Behavior ===');

    const testEpicIid = 101;

    // Get original state
    const original = { ...mockEpics.find((e) => e.iid === testEpicIid)! };
    console.log('Original title:', original.title);

    // Update epic
    await mockUpdateGitLabEpic(testConfig, testEpicIid, {
      title: 'TEMPORARY UPDATE',
    });

    // Check it was updated in memory
    const updated = mockEpics.find((e) => e.iid === testEpicIid)!;
    console.log('After update:', updated.title);
    expect(updated.title).toBe('TEMPORARY UPDATE');

    // Restore to simulate "page refresh" behavior
    updated.title = original.title;
    updated.description = original.description;

    console.log('After "refresh" (restore):', mockEpics.find((e) => e.iid === testEpicIid)?.title);

    console.log('\n⚠️  KEY INSIGHT:');
    console.log('   Mock mode updates are IN-MEMORY ONLY');
    console.log('   When page refreshes, mock data resets to initial state');
    console.log('   This is why "nothing changes" after update in mock mode');
    console.log('✓ Mock persistence behavior documented');
  });
});

// ===========================================
// SUMMARY
// ===========================================
describe('Summary', () => {
  test('prints investigation summary', () => {
    console.log('\n' + '='.repeat(60));
    console.log('EPIC UPDATE INVESTIGATION SUMMARY');
    console.log('='.repeat(60));

    console.log('\n🔍 ROOT CAUSES IDENTIFIED:\n');

    console.log('1. MOCK_GITLAB_ENABLED = true');
    console.log('   - All updates go to in-memory array');
    console.log('   - Changes are lost on page refresh');
    console.log('   - FIX: Set MOCK_GITLAB_ENABLED = false for real API\n');

    console.log('2. selectedGitLabEpic could be null');
    console.log('   - handleUpdateGitLabEpic returns early with NO feedback');
    console.log('   - User sees "nothing changes" without explanation');
    console.log('   - FIX: Add toast/error when epic not selected\n');

    console.log('3. GroupId fix already applied');
    console.log('   - updateGitLabEpic now accepts groupId parameter');
    console.log('   - handleUpdateGitLabEpic passes selectedGitLabEpic.group_id\n');

    console.log('📋 TO VERIFY IN BROWSER:');
    console.log('   1. Open DevTools Console');
    console.log('   2. Load an epic from Load Modal');
    console.log('   3. Run Premium Pipeline');
    console.log('   4. Click Publish → Update Epic');
    console.log('   5. Look for these console logs:');
    console.log('      - [DEBUG handleUpdateGitLabEpic] Called');
    console.log('      - [Mock GitLab] UPDATE EPIC CALLED');
    console.log('      - OR [GitLab Epic API] Update target group:');
    console.log('='.repeat(60));

    expect(true).toBe(true);
  });
});
