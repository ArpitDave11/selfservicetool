/**
 * Complete End-to-End Authentication Test
 *
 * Tests the FULL auth flow from login to app usage:
 * 1. Login page appears
 * 2. Click login button
 * 3. Loading state shows
 * 4. App loads after auth
 * 5. User can interact with app
 * 6. Session persists on refresh
 * 7. Logout works
 */

import puppeteer, { Browser, Page } from 'puppeteer';

const APP_URL = 'http://localhost:3002';
const TIMEOUT = 60000;

describe('Complete Auth E2E Flow', () => {
  let browser: Browser;
  let page: Page;
  const consoleLogs: string[] = [];

  beforeAll(async () => {
    browser = await puppeteer.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox'],
    });
  });

  afterAll(async () => {
    if (browser) {
      await browser.close();
    }
  });

  beforeEach(async () => {
    page = await browser.newPage();
    consoleLogs.length = 0;

    // Capture console messages
    page.on('console', (msg) => {
      consoleLogs.push(`[${msg.type()}] ${msg.text()}`);
    });
  });

  afterEach(async () => {
    console.log('\n=== Console Logs ===');
    consoleLogs.forEach(log => console.log(log));

    if (page) {
      await page.close();
    }
  });

  test('COMPLETE FLOW: Login -> App Load -> Verify User -> Refresh -> Stay Logged In', async () => {
    console.log('\n========================================');
    console.log('STEP 1: Navigate to app (clear session first)');
    console.log('========================================');

    await page.goto(APP_URL, { waitUntil: 'networkidle0', timeout: TIMEOUT });

    // Clear session storage ONCE at the start to ensure fresh state
    await page.evaluate(() => {
      sessionStorage.clear();
      console.log('[Test] Cleared sessionStorage');
    });

    // Reload to get fresh unauthenticated state
    await page.reload({ waitUntil: 'networkidle0' });
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Take screenshot of login page
    await page.screenshot({
      path: '/Users/arpit/Desktop/Project_BKP/epic-generator-v4/e2e-step1-login-page.png',
      fullPage: true
    });

    // Verify login page
    const hasLoginButton = await page.evaluate(() => {
      return document.body.innerText.includes('Sign in with Microsoft');
    });
    console.log('Login page visible:', hasLoginButton);
    expect(hasLoginButton).toBe(true);

    const hasEpicGeneratorTitle = await page.evaluate(() => {
      return document.body.innerText.includes('Epic Generator');
    });
    console.log('Epic Generator title visible:', hasEpicGeneratorTitle);
    expect(hasEpicGeneratorTitle).toBe(true);

    console.log('\n========================================');
    console.log('STEP 2: Click Login Button');
    console.log('========================================');

    // Find and click the login button
    const loginButton = await page.$('button');
    expect(loginButton).not.toBeNull();

    const buttonText = await page.evaluate(el => el?.innerText, loginButton);
    console.log('Button text:', buttonText);
    expect(buttonText).toContain('Sign in with Microsoft');

    // Click login
    console.log('Clicking login button...');
    await loginButton!.click();

    // Wait a moment for loading state
    await new Promise(resolve => setTimeout(resolve, 500));

    // Take screenshot during loading (if we can catch it)
    await page.screenshot({
      path: '/Users/arpit/Desktop/Project_BKP/epic-generator-v4/e2e-step2-loading.png',
      fullPage: true
    });

    console.log('\n========================================');
    console.log('STEP 3: Wait for Auth to Complete');
    console.log('========================================');

    // Wait for mock auth to complete (1.5s delay + rendering)
    await new Promise(resolve => setTimeout(resolve, 3000));

    // Take screenshot after login
    await page.screenshot({
      path: '/Users/arpit/Desktop/Project_BKP/epic-generator-v4/e2e-step3-after-login.png',
      fullPage: true
    });

    // Verify app loaded
    const appLoaded = await page.evaluate(() => {
      const text = document.body.innerText;
      return text.includes('FRAME') || text.includes('Epic Planner') || text.includes('Wizard');
    });
    console.log('App loaded after login:', appLoaded);
    expect(appLoaded).toBe(true);

    // Verify login button is gone
    const loginButtonGone = await page.evaluate(() => {
      return !document.body.innerText.includes('Sign in with your Microsoft account');
    });
    console.log('Login prompt gone:', loginButtonGone);
    expect(loginButtonGone).toBe(true);

    // Verify mock badge still shows
    const mockBadgeVisible = await page.evaluate(() => {
      return document.body.innerText.includes('MOCK AUTH MODE');
    });
    console.log('Mock badge visible:', mockBadgeVisible);
    expect(mockBadgeVisible).toBe(true);

    console.log('\n========================================');
    console.log('STEP 4: Verify App is Functional');
    console.log('========================================');

    // Check for main app elements
    const hasWizard = await page.evaluate(() => document.body.innerText.includes('Wizard'));
    const hasEpicEditor = await page.evaluate(() => document.body.innerText.includes('Epic Editor'));
    const hasSettings = await page.evaluate(() => document.body.innerText.includes('Settings'));

    console.log('Has Wizard tab:', hasWizard);
    console.log('Has Epic Editor tab:', hasEpicEditor);
    console.log('Has Settings:', hasSettings);

    expect(hasWizard).toBe(true);
    expect(hasEpicEditor).toBe(true);
    expect(hasSettings).toBe(true);

    // Check that session was saved
    const sessionSaved = await page.evaluate(() => {
      const session = sessionStorage.getItem('mock_auth_session');
      console.log('[Test] Session in storage:', session);
      return session !== null;
    });
    console.log('Session saved to storage:', sessionSaved);
    expect(sessionSaved).toBe(true);

    console.log('\n========================================');
    console.log('STEP 5: Test Session Persistence (Refresh)');
    console.log('========================================');

    // Get session before refresh
    const sessionBeforeRefresh = await page.evaluate(() => {
      return sessionStorage.getItem('mock_auth_session');
    });
    console.log('Session before refresh:', sessionBeforeRefresh ? 'EXISTS' : 'MISSING');

    // Refresh the page (DO NOT clear session)
    console.log('Refreshing page...');
    await page.reload({ waitUntil: 'networkidle0' });
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Check session after refresh
    const sessionAfterRefresh = await page.evaluate(() => {
      return sessionStorage.getItem('mock_auth_session');
    });
    console.log('Session after refresh:', sessionAfterRefresh ? 'EXISTS' : 'MISSING');

    // Take screenshot after refresh
    await page.screenshot({
      path: '/Users/arpit/Desktop/Project_BKP/epic-generator-v4/e2e-step5-after-refresh.png',
      fullPage: true
    });

    // Get page text for debugging
    const pageTextAfterRefresh = await page.evaluate(() => document.body.innerText);
    console.log('Page text after refresh (first 500 chars):', pageTextAfterRefresh.substring(0, 500));

    // Verify still logged in (app shows, not login page)
    const stillLoggedIn = await page.evaluate(() => {
      const text = document.body.innerText;
      // Should have app content, not login prompt
      const hasAppContent = text.includes('FRAME') || text.includes('Epic Planner') || text.includes('Wizard');
      const hasLoginPrompt = text.includes('Sign in with your Microsoft account');
      console.log('[Test] Has app content:', hasAppContent, 'Has login prompt:', hasLoginPrompt);
      return hasAppContent && !hasLoginPrompt;
    });
    console.log('Still logged in after refresh:', stillLoggedIn);
    expect(stillLoggedIn).toBe(true);

    console.log('\n========================================');
    console.log('STEP 6: Verify Console Logs');
    console.log('========================================');

    // Check for expected log messages
    const hasAuthInitLog = consoleLogs.some(log => log.includes('[Auth] Using MOCK authentication mode'));
    const hasLoginLog = consoleLogs.some(log => log.includes('[MockAuth] Mock login successful'));
    const hasRestoredSessionLog = consoleLogs.some(log => log.includes('[MockAuth] Restored session'));

    console.log('Auth init log present:', hasAuthInitLog);
    console.log('Login success log present:', hasLoginLog);
    console.log('Session restored log present:', hasRestoredSessionLog);

    expect(hasAuthInitLog).toBe(true);
    expect(hasLoginLog).toBe(true);

    // Check for NO infinite loop indicators
    const authInitCount = consoleLogs.filter(log =>
      log.includes('[MockAuth] Starting mock login')
    ).length;
    console.log('Login attempts:', authInitCount);
    expect(authInitCount).toBeLessThanOrEqual(1); // Should only login once

    console.log('\n========================================');
    console.log('ALL TESTS PASSED!');
    console.log('========================================');

  }, TIMEOUT);

  test('FLOW: Fresh visit shows login page', async () => {
    // Navigate first
    await page.goto(APP_URL, { waitUntil: 'networkidle0' });

    // Clear session storage
    await page.evaluate(() => {
      sessionStorage.clear();
    });

    // Reload to get fresh state
    await page.reload({ waitUntil: 'networkidle0' });
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Should show login page
    const showsLoginPage = await page.evaluate(() => {
      return document.body.innerText.includes('Sign in with Microsoft');
    });

    console.log('Fresh visit shows login:', showsLoginPage);
    expect(showsLoginPage).toBe(true);

  }, TIMEOUT);
});
