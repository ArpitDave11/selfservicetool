/**
 * Bug Reproduction Tests
 *
 * Tests for the 3 user-reported bugs:
 * Bug #2: "Generated on" date is duplicated instead of overwritten
 * Bug #3: User story numbering/naming is inconsistent (US-01 vs US-001)
 * Bug #4: Diagram rendering - linkStyle index mismatch
 *
 * These tests validate the root causes and verify fixes.
 */
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import {
  runSkill,
  setConfig,
  parseUserStoriesFromEpic,
  parseEpicToStageData,
  disableThrottlingForTests,
  enableThrottling,
  generateIntelligentBlueprint,
  fixMermaidDiagram,
  loadCategoryTemplate,
} from '../skills';
import { type AppConfig, DEFAULT_CONFIG, callAI } from '../config';
import type { RefinedData, PipelineUserStory, RefinementOutput } from '../types';

// Mock callAI
vi.mock('../config', async () => {
  const actual = await vi.importActual('../config');
  return {
    ...actual,
    callAI: vi.fn()
  };
});

const mockCallAI = vi.mocked(callAI);

// ============================================================================
// BUG #2: "Generated on" date is duplicated instead of overwritten
// ============================================================================
describe('Bug #2: "Generated on" date duplication', () => {
  beforeEach(() => {
    setConfig({ ...DEFAULT_CONFIG, aiProvider: 'mock' });
    disableThrottlingForTests();
  });

  afterEach(() => {
    enableThrottling();
    vi.restoreAllMocks();
  });

  describe('Root cause: generateEpic() unconditionally adds new date', () => {
    it('should produce exactly ONE "Generated on" line when generating a fresh epic', async () => {
      const minimalData: RefinedData = {
        objective: { original: 'Test objective', refined: 'A test objective for validation' },
      };

      const result = await runSkill('generate', {
        data: minimalData,
        projectName: 'Test Project',
      });

      const generatedEpic = (result as { epic: string }).epic;
      const generatedOnMatches = generatedEpic.match(/\*Generated on .+?\*/g);

      expect(generatedOnMatches).not.toBeNull();
      expect(generatedOnMatches!.length).toBe(1);
    });

    it('should contain today\'s date in the "Generated on" line', async () => {
      const minimalData: RefinedData = {
        objective: { original: 'Test', refined: 'Test objective' },
      };

      const result = await runSkill('generate', {
        data: minimalData,
        projectName: 'Date Test',
      });

      const generatedEpic = (result as { epic: string }).epic;
      const today = new Date().toLocaleDateString();
      expect(generatedEpic).toContain(`*Generated on ${today}*`);
    });
  });

  describe('Scenario: Regenerating an epic that already has a date', () => {
    it('should NOT have multiple "Generated on" dates after regeneration', async () => {
      // Step 1: First generation
      const data: RefinedData = {
        objective: { original: 'Build auth', refined: 'Build authentication service' },
        features: { original: 'Login', refined: 'User login and registration' },
      };

      const firstResult = await runSkill('generate', {
        data,
        projectName: 'Auth Service',
      });

      const firstEpic = (firstResult as { epic: string }).epic;

      // Verify first generation has exactly one date
      const firstDates = firstEpic.match(/\*Generated on .+?\*/g);
      expect(firstDates!.length).toBe(1);

      // Step 2: Second generation (simulating regeneration)
      const secondResult = await runSkill('generate', {
        data,
        projectName: 'Auth Service',
      });

      const secondEpic = (secondResult as { epic: string }).epic;
      const secondDates = secondEpic.match(/\*Generated on .+?\*/g);

      // Should still have exactly one date
      expect(secondDates!.length).toBe(1);
    });

    it('should detect when epic markdown already contains a "Generated on" line', () => {
      const epicWithExistingDate = `# My Project

*Generated on 2/2/2026*

---

## 1. Objective
Build something great.`;

      const datePattern = /\*Generated on .+?\*/g;
      const matches = epicWithExistingDate.match(datePattern);

      expect(matches).not.toBeNull();
      expect(matches!.length).toBe(1);
      expect(matches![0]).toContain('2/2/2026');
    });

    it('should properly strip and replace existing "Generated on" dates', () => {
      // This test validates the FIX behavior:
      // Given an epic with an old date, stripping and re-adding should yield exactly one date
      const epicWithOldDate = `# My Project

*Generated on 2/2/2026*

---

## 1. Objective
Content here.`;

      // Simulate what the fix should do: strip old date, add new one
      const stripped = epicWithOldDate.replace(/\*Generated on .+?\*\n?\n?---\n?\n?/g, '');
      const today = new Date().toLocaleDateString();
      const withNewDate = stripped.replace(
        /^(# .+\n\n)/,
        `$1*Generated on ${today}*\n\n---\n\n`
      );

      const dates = withNewDate.match(/\*Generated on .+?\*/g);
      expect(dates!.length).toBe(1);
      expect(withNewDate).toContain(`*Generated on ${today}*`);
      expect(withNewDate).not.toContain('2/2/2026');
    });
  });

  describe('Edge cases for date handling', () => {
    it('should handle epics with multiple existing "Generated on" lines (already broken state)', () => {
      const brokenEpic = `# My Project

*Generated on 2/2/2026*

*Generated on 2/11/2026*

---

## 1. Objective
Content.`;

      // A proper fix should strip ALL existing dates
      const cleanedEpic = brokenEpic.replace(/\*Generated on .+?\*\n?\n?/g, '');
      expect(cleanedEpic).not.toContain('Generated on');
    });

    it('should not break if "Generated on" appears inside a section body', () => {
      const epicWithInlineDate = `# My Project

*Generated on 2/2/2026*

---

## 1. Objective
This was generated on a different day using a tool.`;

      // Only the italic/asterisk format should be matched, not plain text
      const pattern = /\*Generated on .+?\*/g;
      const matches = epicWithInlineDate.match(pattern);
      expect(matches!.length).toBe(1); // Only the actual date line, not the prose
    });
  });
});

// ============================================================================
// BUG #3: User story numbering/naming is inconsistent (US-01 vs US-001)
// ============================================================================
describe('Bug #3: User story numbering inconsistency', () => {
  beforeEach(() => {
    setConfig({ ...DEFAULT_CONFIG, aiProvider: 'mock' });
    disableThrottlingForTests();
  });

  afterEach(() => {
    enableThrottling();
    vi.restoreAllMocks();
  });

  describe('Root cause: Template says US-01, AI prompt says US-001', () => {
    it('should verify categoryTemplates uses US-001 format consistent with AI prompts', () => {
      // feature_specification is the category that has User Stories
      const template = loadCategoryTemplate('feature_specification');
      const userStoriesConfig =
        template.requiredSections?.['User Stories'] ||
        template.optionalSections?.['User Stories'];

      expect(userStoriesConfig).toBeDefined();
      expect(userStoriesConfig!.hint).toBeDefined();
      // After fix: template hint must use 3-digit US-001 format
      expect(userStoriesConfig!.hint).toContain('US-001');
      expect(userStoriesConfig!.hint).not.toMatch(/US-\d{2}[:\s]/); // No 2-digit format
    });

    it('should parse US-001 format (3-digit) stories correctly', () => {
      const epicWith3Digit = `# Test Project

## 11. Key Features & User Stories

### User Stories

**US-001: Implement MFA Authentication** 🔴
> As a user, I want to enable multi-factor authentication, so that my account is more secure.

**US-002: Add Transaction History Export** 🟡
> As a finance manager, I want to export transaction history, so that I can perform audits.

**US-003: Configure Role-Based Access** 🟢
> As an admin, I want to configure role-based access, so that users only see relevant data.
`;

      const stories = parseUserStoriesFromEpic(epicWith3Digit);

      expect(stories.length).toBe(3);
      expect(stories[0].id).toBe('US-001');
      expect(stories[1].id).toBe('US-002');
      expect(stories[2].id).toBe('US-003');
    });

    it('should parse US-01 format (2-digit) stories correctly', () => {
      const epicWith2Digit = `# Test Project

## 11. Key Features & User Stories

### User Stories

**US-01: One-Click Reorder** 🔴
> As a customer, I want to reorder items with one click, so that I can save time.

**US-02: View Order History** 🟡
> As a user, I want to view my order history, so that I can track purchases.
`;

      const stories = parseUserStoriesFromEpic(epicWith2Digit);

      expect(stories.length).toBe(2);
      // Parser should accept both formats
      expect(stories[0].id).toBe('US-01');
      expect(stories[1].id).toBe('US-02');
    });

    it('should NOT mix US-01 and US-001 formats in the same epic', () => {
      const epicWithMixedFormats = `# Test Project

## 11. Key Features & User Stories

### User Stories

**US-01: First Story** 🔴
> As a user, I want feature A, so that I get benefit A.

**US-002: Second Story** 🟡
> As a user, I want feature B, so that I get benefit B.

**US-03: Third Story** 🟢
> As a user, I want feature C, so that I get benefit C.
`;

      const stories = parseUserStoriesFromEpic(epicWithMixedFormats);

      // Extract unique digit lengths from story IDs
      const digitLengths = new Set(
        stories.map(s => {
          const match = s.id.match(/US-(\d+)/);
          return match ? match[1].length : 0;
        })
      );

      // BUG: If this has more than 1 unique digit length, formats are mixed
      if (digitLengths.size > 1) {
        console.warn('BUG CONFIRMED: Mixed US- numbering formats detected:',
          stories.map(s => s.id));
      }

      // After fix: all stories should use consistent format
      expect(stories.length).toBe(3);
    });
  });

  describe('Legacy format fallback creates non-standard IDs', () => {
    it('should assign US-prefixed IDs for legacy "As a..." format stories', () => {
      const legacyEpic = `# Test Project

## 11. Key Features & User Stories

- As a user, I want to login with my email so that I can access my account
- As a developer, I want API documentation so that I can integrate authentication
`;

      const stories = parseUserStoriesFromEpic(legacyEpic);

      expect(stories.length).toBe(2);
      // After fix: legacy stories should get US- prefix with 3-digit padding
      expect(stories[0].id).toBe('US-001');
      expect(stories[1].id).toBe('US-002');
    });

    it('should produce sequential numbering with zero-padding', () => {
      const epicWith3Digit = `# Test Project

## 11. Key Features & User Stories

### User Stories

**US-001: First Feature** 🔴
> As a user, I want feature A, so that benefit A.

**US-002: Second Feature** 🟡
> As a user, I want feature B, so that benefit B.

**US-003: Third Feature** 🟢
> As a user, I want feature C, so that benefit C.
`;

      const stories = parseUserStoriesFromEpic(epicWith3Digit);

      // Verify sequential numbering
      stories.forEach((story, idx) => {
        const expectedId = `US-${String(idx + 1).padStart(3, '0')}`;
        expect(story.id).toBe(expectedId);
      });
    });
  });
});

// ============================================================================
// BUG #4: Diagram rendering - linkStyle index mismatch
// ============================================================================
describe('Bug #4: Diagram linkStyle rendering issues', () => {
  beforeEach(() => {
    setConfig({ ...DEFAULT_CONFIG, aiProvider: 'mock' });
    disableThrottlingForTests();
  });

  afterEach(() => {
    enableThrottling();
    vi.restoreAllMocks();
  });

  describe('Root cause: linkStyle indices don\'t match connection count', () => {
    it('should detect linkStyle index exceeding connection count', () => {
      // Diagram has 3 connections (indices 0, 1, 2) but linkStyle references index 5
      const badDiagram = `flowchart LR
    A[Web App] --> B[API Gateway]
    B --> C[Auth Service]
    C --> D[Database]
    linkStyle 0 stroke:#0072B2,stroke-width:2.5px
    linkStyle 1 stroke:#64748B,stroke-width:2px
    linkStyle 2 stroke:#D55E00,stroke-width:2px
    linkStyle 5 stroke:#6366F1,stroke-width:2px`;

      // Count connections (arrows)
      const arrowPattern = /-->/g;
      const connectionCount = (badDiagram.match(arrowPattern) || []).length;

      // Count linkStyle declarations
      const linkStylePattern = /linkStyle\s+(\d+)/g;
      let match;
      const indices: number[] = [];
      while ((match = linkStylePattern.exec(badDiagram)) !== null) {
        indices.push(parseInt(match[1]));
      }

      const maxIndex = Math.max(...indices);

      // BUG: linkStyle index 5 exceeds connection count (3, max valid index is 2)
      expect(maxIndex).toBeGreaterThanOrEqual(connectionCount);
      console.warn(`BUG CONFIRMED: linkStyle max index ${maxIndex} >= connection count ${connectionCount}`);
    });

    it('should detect when linkStyle count exceeds arrow count', () => {
      const diagramWithExcessLinkStyles = `flowchart TD
    WEB[Web App] --> LB[Load Balancer]
    LB --> AUTH[Auth Service]
    AUTH --> API[API Gateway]

    linkStyle 0 stroke:#0072B2,stroke-width:2.5px
    linkStyle 1 stroke:#64748B,stroke-width:2px
    linkStyle 2 stroke:#D55E00,stroke-width:2px
    linkStyle 3 stroke:#6366F1,stroke-width:2px
    linkStyle 4 stroke:#CC79A7,stroke-width:2px`;

      // Count all arrow types
      const arrows = diagramWithExcessLinkStyles.match(/(-->|-.->|==>|--x|--o)/g) || [];
      const linkStyles = diagramWithExcessLinkStyles.match(/linkStyle\s+\d+/g) || [];

      // 3 connections but 5 linkStyle declarations
      expect(arrows.length).toBe(3);
      expect(linkStyles.length).toBe(5);
      expect(linkStyles.length).toBeGreaterThan(arrows.length);
    });
  });

  describe('validateMermaidDiagram() gaps', () => {
    it('should validate that validateMermaidDiagram does NOT currently check linkStyle indices', () => {
      // This test documents the current behavior gap
      // The validateMermaidDiagram function only checks for:
      // 1. Valid diagram type start
      // 2. Lowercase "end" keyword fix
      // 3. Trailing content removal
      // It does NOT validate linkStyle indices

      const diagramWithBadLinkStyle = `flowchart LR
    A --> B
    linkStyle 99 stroke:#red,stroke-width:5px`;

      // Currently this passes validation because validateMermaidDiagram doesn't check linkStyle
      // The fix should add linkStyle validation
      expect(diagramWithBadLinkStyle.startsWith('flowchart')).toBe(true);
    });
  });

  describe('linkStyle stripping utility (for fix verification)', () => {
    it('should be able to strip all linkStyle lines from a diagram', () => {
      const diagram = `flowchart LR
    A[Web] --> B[API]
    B --> C[DB]
    linkStyle 0 stroke:#0072B2,stroke-width:2.5px
    linkStyle 1 stroke:#64748B,stroke-width:2px
    style A fill:#E60000,color:#fff`;

      // Strip linkStyle lines
      const stripped = diagram.replace(/^\s*linkStyle\s+.+$/gm, '').replace(/\n{2,}/g, '\n');

      expect(stripped).not.toContain('linkStyle');
      expect(stripped).toContain('A[Web] --> B[API]');
      expect(stripped).toContain('B --> C[DB]');
      expect(stripped).toContain('style A fill:#E60000'); // node styles should remain
    });

    it('should handle linkStyle with comma-separated indices', () => {
      const diagram = `flowchart TD
    A --> B
    B --> C
    C --> D
    linkStyle 0,1 stroke:#0072B2,stroke-width:2.5px
    linkStyle 2 stroke:#D55E00,stroke-width:2px`;

      const stripped = diagram.replace(/^\s*linkStyle\s+.+$/gm, '').replace(/\n{2,}/g, '\n');

      expect(stripped).not.toContain('linkStyle');
      expect(stripped).toContain('A --> B');
    });
  });

  describe('Arrow counting accuracy', () => {
    it('should accurately count all arrow types in a flowchart', () => {
      const diagram = `flowchart TD
    A --> B
    B -.-> C
    C ==> D
    D --x E
    E --o F`;

      // All mermaid arrow types
      const allArrows = diagram.match(/(-->|-.->|==>|--x|--o|~~~)/g) || [];
      expect(allArrows.length).toBe(5);
    });

    it('should count arrows inside subgraphs correctly', () => {
      const diagram = `flowchart TD
    subgraph Frontend
        A[React] --> B[Redux]
    end
    subgraph Backend
        C[API] --> D[DB]
    end
    B --> C`;

      const allArrows = diagram.match(/(-->|-.->|==>)/g) || [];
      expect(allArrows.length).toBe(3); // A->B, C->D, B->C
    });
  });

  describe('Mermaid error handling in MarkdownPreview', () => {
    it('should identify that error messages are currently generic', () => {
      // This documents the current gap: MarkdownPreview shows "Diagram preview unavailable"
      // without any details about WHAT went wrong (e.g., linkStyle index out of range)
      const errorMessage = 'Diagram preview unavailable';
      const detailedError = 'linkStyle index 5 exceeds edge count of 3';

      // Current behavior: generic message
      expect(errorMessage).not.toContain('linkStyle');
      // After fix: should include relevant details
      expect(detailedError).toContain('linkStyle');
    });
  });
});

// ============================================================================
// INTEGRATION: Cross-bug validation
// ============================================================================
describe('Cross-bug integration tests', () => {
  beforeEach(() => {
    setConfig({ ...DEFAULT_CONFIG, aiProvider: 'mock' });
    disableThrottlingForTests();
  });

  afterEach(() => {
    enableThrottling();
    vi.restoreAllMocks();
  });

  it('should produce a clean epic with single date and consistent story IDs', async () => {
    const data: RefinedData = {
      objective: { original: 'Build platform', refined: 'Build a scalable e-commerce platform' },
      features: { original: 'Cart, checkout', refined: 'Shopping cart and checkout flow' },
      userStories: { original: 'As a user I want to browse', refined: 'User browsing and purchasing stories' },
    };

    const result = await runSkill('generate', {
      data,
      projectName: 'E-Commerce Platform',
    });

    const epic = (result as { epic: string }).epic;

    // Bug #2: Should have exactly one date
    const dates = epic.match(/\*Generated on .+?\*/g) || [];
    expect(dates.length).toBe(1);

    // Verify the epic has proper structure
    expect(epic).toContain('# E-Commerce Platform');
    expect(epic).toContain('## '); // Has sections
  });

  it('should parse a well-formed epic without any numbering anomalies', () => {
    const wellFormedEpic = `# Test Project

*Generated on 2/18/2026*

---

## 11. Key Features & User Stories

### User Stories

**US-001: Implement User Login** 🔴
> As a user, I want to log in securely, so that my data is protected.

Acceptance Criteria:
- [ ] Support email/password login
- [ ] Support OAuth 2.0

**US-002: Add Product Search** 🟡
> As a customer, I want to search products, so that I can find what I need.

**US-003: Enable Checkout Flow** 🟢
> As a buyer, I want to complete checkout, so that I can purchase items.
`;

    const stories = parseUserStoriesFromEpic(wellFormedEpic);

    // All stories should be found
    expect(stories.length).toBe(3);

    // All IDs should be consistent 3-digit format
    expect(stories[0].id).toBe('US-001');
    expect(stories[1].id).toBe('US-002');
    expect(stories[2].id).toBe('US-003');

    // All should have proper titles
    expect(stories[0].title).toBe('Implement User Login');
    expect(stories[1].title).toBe('Add Product Search');
    expect(stories[2].title).toBe('Enable Checkout Flow');

    // Single date check
    const dates = wellFormedEpic.match(/\*Generated on .+?\*/g) || [];
    expect(dates.length).toBe(1);
  });
});
