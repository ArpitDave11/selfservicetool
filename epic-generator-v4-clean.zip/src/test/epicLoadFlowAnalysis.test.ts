/**
 * Epic Load Flow Analysis Test
 *
 * This test verifies the user's analysis of the bug:
 * - Search from rootGroupId (557797) with include_descendant_groups=true
 * - Returns epics from BOTH parent and subgroups
 * - User expects to edit subgroup epic but app loads parent epic
 *
 * Run: npm run test:run -- epicLoadFlowAnalysis
 */

import { describe, test, expect } from 'vitest';

// ===========================================
// SCENARIO: Two epics with same iid in different groups
// ===========================================
interface MockEpic {
  id: number;
  iid: number;
  group_id: number;
  title: string;
  description: string | null;
  state: 'opened' | 'closed';
  web_url: string;
}

// Simulated GitLab API response when searching from rootGroupId with include_descendant_groups=true
const API_SEARCH_RESULTS: MockEpic[] = [
  // Parent group epic (returned FIRST by API because it's in the root group)
  {
    id: 520625,
    iid: 229,
    group_id: 557797,  // Parent group (rootGroupId)
    title: 'Build AI-Enabled EpicPlanner UI',
    description: '# Full Epic Content\n\nThis epic has all the content...',
    state: 'closed',
    web_url: 'https://gitlab.com/groups/parent/-/epics/229',
  },
  // Subgroup epic (what the user THINKS they're editing)
  {
    id: 841693,
    iid: 229,
    group_id: 478446,  // Subgroup
    title: 'Build AI-Enabled EpicPlanner UI',  // Same title!
    description: null,  // Empty
    state: 'opened',
    web_url: 'https://gitlab.com/groups/parent/subgroup/-/epics/229',
  },
];

describe('Epic Load Flow Analysis', () => {
  // ===========================================
  // TEST 1: Verify the API returns duplicates
  // ===========================================
  test('API search returns multiple epics with same iid from different groups', () => {
    console.log('\n' + '='.repeat(60));
    console.log('TEST 1: API Search Results Analysis');
    console.log('='.repeat(60));

    console.log('\nSimulated API Response (include_descendant_groups=true):');
    API_SEARCH_RESULTS.forEach((epic, i) => {
      console.log(`\n[${i}] Epic:`);
      console.log(`     id: ${epic.id}`);
      console.log(`     iid: ${epic.iid}`);
      console.log(`     group_id: ${epic.group_id}`);
      console.log(`     title: "${epic.title}"`);
      console.log(`     description: ${epic.description ? 'HAS CONTENT' : 'null (empty)'}`);
      console.log(`     state: ${epic.state}`);
    });

    // Both epics have the same iid and title
    expect(API_SEARCH_RESULTS[0].iid).toBe(229);
    expect(API_SEARCH_RESULTS[1].iid).toBe(229);
    expect(API_SEARCH_RESULTS[0].title).toBe(API_SEARCH_RESULTS[1].title);

    // But different group_ids and ids
    expect(API_SEARCH_RESULTS[0].group_id).not.toBe(API_SEARCH_RESULTS[1].group_id);
    expect(API_SEARCH_RESULTS[0].id).not.toBe(API_SEARCH_RESULTS[1].id);

    console.log('\n✓ Confirmed: Two different epics with same iid=229 and same title');
  });

  // ===========================================
  // TEST 2: Simulate the user's scenario
  // ===========================================
  test('User scenario: Expects subgroup epic but gets parent epic', () => {
    console.log('\n' + '='.repeat(60));
    console.log('TEST 2: User Scenario Simulation');
    console.log('='.repeat(60));

    // Config
    const rootGroupId = '557797';

    console.log('\n📋 SETUP:');
    console.log(`   rootGroupId (config): ${rootGroupId}`);
    console.log('   User is on subgroup page in GitLab browser');
    console.log('   User sees: epic 841693 (group_id=478446, description=null)');
    console.log('   User wants to edit THIS epic');

    // Step 1: User opens app and searches
    console.log('\n📋 STEP 1: User searches for epic in app');
    console.log('   Search query: "Build AI-Enabled EpicPlanner UI"');
    console.log(`   API call: GET /api/v4/groups/${rootGroupId}/epics?search=...&include_descendant_groups=true`);

    // Simulate loadEpicResults = API response
    const loadEpicResults = [...API_SEARCH_RESULTS];
    console.log(`   Results: ${loadEpicResults.length} epics found`);

    // Step 2: User clicks on the epic (by iid)
    console.log('\n📋 STEP 2: User clicks on epic with iid=229');
    const targetIid = 229;

    // This is the ACTUAL code from App.tsx line 3430
    const epicFromList = loadEpicResults.find(e => e.iid === targetIid);
    const epicGroupId = epicFromList?.group_id ? String(epicFromList.group_id) : rootGroupId;

    console.log('   find(e => e.iid === 229) returns:');
    console.log(`     → id: ${epicFromList?.id}`);
    console.log(`     → group_id: ${epicFromList?.group_id}`);
    console.log(`     → description: ${epicFromList?.description ? 'HAS CONTENT' : 'null'}`);

    // Step 3: App loads epic details
    console.log('\n📋 STEP 3: App fetches epic details');
    console.log(`   API call: GET /api/v4/groups/${epicGroupId}/epics/${targetIid}`);
    console.log(`   → Loads epic from group ${epicGroupId}`);

    // Step 4: User edits and publishes
    console.log('\n📋 STEP 4: User edits and clicks "Update Epic"');
    console.log(`   API call: PUT /api/v4/groups/${epicGroupId}/epics/${targetIid}`);
    console.log(`   → Updates epic in group ${epicGroupId}`);

    // Step 5: User checks in browser
    console.log('\n📋 STEP 5: User checks epic in browser');
    console.log('   User is still on subgroup page (group_id=478446)');
    console.log('   User expects to see updated content');
    console.log('   BUT: Epic 841693 (subgroup) was NEVER updated!');
    console.log('   Epic 520625 (parent group) was updated instead.');

    // Verify the bug
    expect(epicFromList?.id).toBe(520625);  // Parent epic loaded
    expect(epicFromList?.group_id).toBe(557797);  // Parent group
    expect(epicGroupId).toBe('557797');  // Update goes to parent group

    console.log('\n❌ BUG CONFIRMED:');
    console.log('   User wanted to edit: epic 841693 (group 478446)');
    console.log('   App actually edited: epic 520625 (group 557797)');
    console.log('   This is why "nothing changed" in the browser!');
  });

  // ===========================================
  // TEST 3: Verify the analysis is correct
  // ===========================================
  test('Analysis verification: Issue is at LOAD time, not UPDATE time', () => {
    console.log('\n' + '='.repeat(60));
    console.log('TEST 3: Verify Analysis');
    console.log('='.repeat(60));

    console.log('\n📋 USER\'S ANALYSIS:');
    console.log(`
┌─────────────────────────────────────────────────────────────────┐
│ "Your app loads epic 520625 (parent group) from search results" │
│ "You edit + publish"                                             │
│ "API updates 520625 successfully"                                │
│ "You then check epic 841693 (subgroup) → still empty"           │
│ "Because you never updated your real target epic (841693)"      │
└─────────────────────────────────────────────────────────────────┘
    `);

    console.log('📋 VERIFICATION:');
    console.log('   ✓ The update logic IS correct - it uses the loaded epic\'s group_id');
    console.log('   ✓ The API call IS correct for the epic that was loaded');
    console.log('   ✗ The LOAD logic returns the wrong epic');
    console.log('   ✗ Search by title with include_descendant_groups returns parent first');

    console.log('\n📋 ROOT CAUSE:');
    console.log('   1. Search from rootGroupId returns epics from all descendant groups');
    console.log('   2. Two epics with same iid=229 and same title exist');
    console.log('   3. Parent group epic (557797) is returned first in results');
    console.log('   4. find(e => e.iid === 229) returns the parent epic');
    console.log('   5. App loads and updates the parent epic correctly');
    console.log('   6. User checks subgroup epic (never updated) → "nothing changed"');

    console.log('\n📋 THE FIX NEEDED:');
    console.log('   1. When user clicks on an epic in search results,');
    console.log('      use THAT SPECIFIC epic\'s group_id (not find by iid)');
    console.log('   2. Or, uniquely identify epics by (group_id + iid) pair');
    console.log('   3. Or, show group information in search results so user');
    console.log('      can distinguish between duplicate iid epics');

    expect(true).toBe(true);
  });

  // ===========================================
  // TEST 4: The correct approach
  // ===========================================
  test('CORRECT approach: Use the clicked epic directly, not find by iid', () => {
    console.log('\n' + '='.repeat(60));
    console.log('TEST 4: Correct Approach');
    console.log('='.repeat(60));

    // Simulate user clicking on the SUBGROUP epic specifically
    const clickedEpic = API_SEARCH_RESULTS[1];  // User clicks on index 1 (subgroup)

    console.log('\nUser clicks on:');
    console.log(`  Index: 1 (the subgroup epic)`);
    console.log(`  Epic: id=${clickedEpic.id}, group_id=${clickedEpic.group_id}`);

    // CORRECT: Use the clicked epic's group_id directly
    const epicGroupId = String(clickedEpic.group_id);

    console.log('\nCORRECT approach:');
    console.log(`  epicGroupId = String(clickedEpic.group_id) = "${epicGroupId}"`);
    console.log(`  API call: PUT /api/v4/groups/${epicGroupId}/epics/${clickedEpic.iid}`);

    expect(epicGroupId).toBe('478446');  // Correct subgroup!

    console.log('\n✓ This would update the correct epic (841693 in group 478446)');

    console.log('\n📋 CODE FIX NEEDED (App.tsx):');
    console.log(`
    // BEFORE (buggy):
    // In handleLoadEpicIntoEditor, the function receives only epicIid
    const handleLoadEpicIntoEditor = async (epicIid: number) => {
      const epicFromList = loadEpicResults.find(e => e.iid === epicIid);
      // ^ This may return the WRONG epic if duplicates exist!
    };

    // AFTER (fixed):
    // Pass the full epic object or (groupId, iid) pair
    const handleLoadEpicIntoEditor = async (epic: GitLabEpic) => {
      const epicGroupId = String(epic.group_id);
      // ^ Always use the clicked epic's group_id directly
    };
    `);
  });
});

describe('Summary', () => {
  test('prints final summary', () => {
    console.log('\n' + '='.repeat(70));
    console.log('EPIC LOAD FLOW ANALYSIS - SUMMARY');
    console.log('='.repeat(70));

    console.log(`
┌─────────────────────────────────────────────────────────────────────┐
│                    IS THE USER'S ANALYSIS CORRECT?                   │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  ✅ YES - The analysis is correct!                                   │
│                                                                      │
│  The bug is at LOAD TIME, not UPDATE TIME:                           │
│                                                                      │
│  1. Search from rootGroupId (557797) returns both parent & subgroup  │
│  2. Two epics with iid=229 exist in different groups                 │
│  3. Parent epic (520625) comes first in API response                 │
│  4. App loads and updates 520625 correctly                           │
│  5. User checks 841693 (subgroup) which was never touched            │
│                                                                      │
│  The UPDATE logic is fine. The LOAD logic needs fixing.              │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                           THE FIX                                    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  Option A: Pass full epic object to handleLoadEpicIntoEditor()       │
│            instead of just epicIid                                   │
│                                                                      │
│  Option B: Pass (groupId, iid) pair to uniquely identify the epic    │
│                                                                      │
│  Option C: Show group info in UI so user can see which epic          │
│            they're selecting (in case of duplicates)                 │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘
`);

    expect(true).toBe(true);
  });
});
