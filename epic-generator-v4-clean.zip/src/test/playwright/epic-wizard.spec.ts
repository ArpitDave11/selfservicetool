import { test, expect } from '@playwright/test';

// Map field names to their placeholder text (from STAGES in types.ts)
const FIELD_PLACEHOLDERS: Record<string, string> = {
  projectName: 'Enter project name',
  background: 'Why does this project exist? What problem does it solve?',
  objective: 'What is the main goal of this project?',
  inScope: 'What is included in this project?',
  outOfScope: 'What is explicitly excluded?',
  assumptions: 'What assumptions are we making?',
  architectureOverview: 'Describe the high-level system architecture',
  dataStores: 'What databases, APIs, and services will be used?',
  features: 'List the main features',
  userStories: 'As a [user], I want [feature] so that [benefit]',
  nfrs: 'Performance, scalability, security requirements',
  deliverables: 'What will be delivered?',
  teams: 'Who is involved and what are their roles?',
  environments: 'Dev, Staging, Prod environments and deployment strategy',
  security: 'Security requirements and access controls',
  dependencies: 'What does this project depend on?',
  risks: 'What are the potential risks?',
  nextSteps: 'Immediate actions to take',
  dod: 'When is this project considered complete?',
  approvers: 'Who needs to sign off?',
};

// Sample data for each field
const WIZARD_DATA: Record<string, string> = {
  projectName: 'E-Commerce Platform Modernization',
  background: 'Legacy monolithic platform needs migration to microservices for scalability.',
  objective: 'Migrate the monolithic e-commerce platform to a microservices architecture.',
  inScope: 'Product catalog, shopping cart, checkout, payment processing, order management.',
  outOfScope: 'Mobile app redesign, warehouse management system.',
  assumptions: 'Kubernetes cluster available, team has container experience.',
  architectureOverview: 'Microservices on Kubernetes with API gateway, event-driven communication.',
  dataStores: 'PostgreSQL for orders, Redis for sessions, Elasticsearch for product search.',
  features: 'Product search with filters, real-time inventory, one-click checkout.',
  userStories: 'As a shopper, I want to search products so that I can find what I need quickly.',
  nfrs: 'Page load under 2 seconds, 99.9% uptime, support 10k concurrent users.',
  deliverables: 'API gateway, product service, cart service, checkout service, admin dashboard.',
  teams: 'Tech Lead, 4 Backend Engineers, 2 Frontend Engineers, 1 DevOps, 1 QA.',
  environments: 'Dev (local K8s), Staging (AWS EKS), Production (AWS EKS multi-AZ).',
  security: 'OAuth 2.0, PCI-DSS for payments, encrypted PII at rest.',
  dependencies: 'Payment gateway API access, design system v2 from UI team.',
  risks: 'Data migration complexity, vendor lock-in with AWS services.',
  nextSteps: 'Set up K8s cluster, define API contracts, begin product service.',
  dod: 'All services deployed, load tested, zero critical bugs, documentation complete.',
  approvers: 'CTO, VP Engineering, Product Director.',
};

// Fields per stage (from STAGES in types.ts)
const STAGE_FIELDS: string[][] = [
  ['projectName', 'background'],
  ['objective', 'inScope', 'outOfScope'],
  ['assumptions', 'architectureOverview', 'dataStores'],
  ['features', 'userStories', 'nfrs', 'deliverables'],
  ['teams', 'environments', 'security'],
  ['dependencies', 'risks', 'nextSteps', 'dod', 'approvers'],
];

test.describe('Epic Generator Wizard', () => {
  test('app loads with sidebar showing FRAME logo', async ({ page }) => {
    await page.goto('/');
    await expect(page.getByText('FRAME')).toBeVisible({ timeout: 15_000 });
  });

  test('can navigate to Wizard tab and see Stage 1', async ({ page }) => {
    await page.goto('/');
    await page.waitForLoadState('networkidle');

    // Click Wizard tab button
    await page.getByRole('button', { name: /Wizard/ }).click();

    // Should show Stage 1
    await expect(page.getByText('Stage 1')).toBeVisible({ timeout: 5_000 });
    // Verify input fields are present by placeholder
    await expect(page.getByPlaceholder('Enter project name')).toBeVisible();
  });

  test('complete wizard flow generates epic with all 17 sections', async ({ page }) => {
    test.setTimeout(120_000);

    await page.goto('/');
    await page.waitForLoadState('networkidle');

    // Navigate to Wizard tab
    await page.getByRole('button', { name: /Wizard/ }).click();
    await expect(page.getByText('Stage 1')).toBeVisible({ timeout: 5_000 });

    // Fill all 6 stages
    for (let stageIdx = 0; stageIdx < STAGE_FIELDS.length; stageIdx++) {
      const fields = STAGE_FIELDS[stageIdx];

      for (const fieldName of fields) {
        const value = WIZARD_DATA[fieldName];
        const placeholder = FIELD_PLACEHOLDERS[fieldName];

        // Use placeholder to find the exact input/textarea
        const field = page.getByPlaceholder(placeholder);
        await expect(field).toBeVisible({ timeout: 3_000 });
        await field.fill(value);
      }

      // Click Next (or Generate Epic on last stage)
      const isLastStage = stageIdx === STAGE_FIELDS.length - 1;
      if (isLastStage) {
        await page.getByRole('button', { name: /Generate Epic/ }).click();
      } else {
        await page.getByRole('button', { name: 'Next' }).click();
        await expect(page.getByText(`Stage ${stageIdx + 2}`)).toBeVisible({ timeout: 5_000 });
      }
    }

    // Wait for epic generation to complete
    // The app shows progress then switches to Epic Editor
    await page.waitForTimeout(5_000);

    // Check that key section headers appear in the generated epic
    const content = await page.content();
    expect(content).toContain('Objective');
    expect(content).toContain('Background');
    expect(content).toContain('Scope');
    expect(content).toContain('Architecture');
    expect(content).toContain('Team');
    expect(content).toContain('Deliverables');
    expect(content).toContain('Definition of Done');
  });
});
