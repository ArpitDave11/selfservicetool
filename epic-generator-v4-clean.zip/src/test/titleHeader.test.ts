/**
 * Title/Header Bug Reproduction & Fix Validation Tests
 *
 * Issues reported:
 * 1. H1 is not a proper title - it's a sentence/objective, often truncated
 * 2. Project name repeated AND inconsistent across sections (same long string everywhere)
 * 3. No document identity - missing owner, version, status, etc. in Epic Status
 *
 * Root causes:
 * - The projectName field accepts ANY text (no length guidance) and users paste their objective
 * - AI refinement prompts say "Use the exact project name" causing verbatim sentence injection
 * - assembleEpicWithEmbedding() uses raw projectName as H1 without sanitization
 * - The Epic Status section doesn't include document identity fields like Version/Doc ID
 */
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import {
  runSkill,
  setConfig,
  parseUserStoriesFromEpic,
  parseEpicToStageData,
  disableThrottlingForTests,
  enableThrottling,
  loadCategoryTemplate,
  sanitizeProjectName,
} from '../skills';
import { type AppConfig, DEFAULT_CONFIG } from '../config';
import type { RefinedData } from '../types';

// Mock callAI
vi.mock('../config', async () => {
  const actual = await vi.importActual('../config');
  return {
    ...actual,
    callAI: vi.fn()
  };
});

// ============================================================================
// ISSUE 1: H1 is not a proper title
// ============================================================================
describe('Issue 1: H1 title should be a proper project name, not a sentence', () => {
  beforeEach(() => {
    setConfig({ ...DEFAULT_CONFIG, aiProvider: 'mock' });
    disableThrottlingForTests();
  });

  afterEach(() => {
    enableThrottling();
    vi.restoreAllMocks();
  });

  describe('Root cause: projectName field accepts long sentences as input', () => {
    it('should detect when projectName is a long sentence instead of a title', () => {
      const badProjectName = 'Help GitLab teams turn scattered project context into consistent, high-quality e';

      // A proper project name should be short (2-8 words, under 60 chars)
      const wordCount = badProjectName.split(/\s+/).length;
      const charCount = badProjectName.length;

      expect(wordCount).toBeGreaterThan(8); // This is too long for a title
      expect(charCount).toBeGreaterThan(60);
    });

    it('should detect truncated project names (ending with incomplete words)', () => {
      const truncatedName = 'Help GitLab teams turn scattered project context into consistent, high-quality e';

      // Check for signs of truncation: ends with a single letter, or doesn't end with a real word
      const lastWord = truncatedName.trim().split(/\s+/).pop() || '';
      const isTruncated = lastWord.length <= 2 && !['AI', 'ML', 'UI', 'QA', 'DB', 'CI', 'CD'].includes(lastWord.toUpperCase());

      expect(isTruncated).toBe(true);
    });

    it('should sanitize long projectName in H1 title', async () => {
      const longSentence = 'Help GitLab teams turn scattered project context into consistent, high-quality epics';

      const data: RefinedData = {
        objective: { original: 'Build something', refined: 'Build a tool' },
      };

      const result = await runSkill('generate', {
        data,
        projectName: longSentence,
      });

      const epic = (result as { epic: string }).epic;

      // After fix: H1 should be sanitized, not the raw long sentence
      const h1Match = epic.match(/^# (.+)\n/);
      expect(h1Match).not.toBeNull();
      const h1Title = h1Match![1];
      expect(h1Title.length).toBeLessThanOrEqual(60);
      expect(h1Title.split(/\s+/).length).toBeLessThanOrEqual(8);
    });
  });

  describe('Fix validation: projectName sanitization', () => {
    it('should sanitize a long sentence into a proper title', () => {
      const longName = 'Help GitLab teams turn scattered project context into consistent, high-quality epics by guiding users';

      // The sanitization logic should:
      // 1. Detect it's too long (>60 chars or >8 words)
      // 2. Extract a meaningful short title
      const sanitized = sanitizeProjectName(longName);

      expect(sanitized.length).toBeLessThanOrEqual(60);
      expect(sanitized.split(/\s+/).length).toBeLessThanOrEqual(8);
      expect(sanitized).not.toMatch(/\s[a-z]$/); // Should not end with truncated word
    });

    it('should leave short proper titles unchanged', () => {
      const goodName = 'FRAME Epic Generator';
      const sanitized = sanitizeProjectName(goodName);

      expect(sanitized).toBe(goodName);
    });

    it('should handle single-letter truncation at end', () => {
      const truncated = 'Help GitLab teams turn scattered project context into consistent, high-quality e';
      const sanitized = sanitizeProjectName(truncated);

      expect(sanitized.endsWith(' e')).toBe(false);
    });
  });
});

// ============================================================================
// ISSUE 2: Project name repeated AND inconsistent across sections
// ============================================================================
describe('Issue 2: Project name is repeated verbatim in section content', () => {
  beforeEach(() => {
    setConfig({ ...DEFAULT_CONFIG, aiProvider: 'mock' });
    disableThrottlingForTests();
  });

  afterEach(() => {
    enableThrottling();
    vi.restoreAllMocks();
  });

  describe('Root cause: AI prompts inject raw projectName into every section', () => {
    it('should detect excessive repetition of project name in generated epic', () => {
      // This is the epic content from the user report
      const epicContent = `# Help GitLab teams turn scattered project context into consistent, high-quality e

## Objective
Help GitLab teams turn scattered project context into consistent, high-quality epics by guiding users through a 6-stage wizard.

## Scope
| In V1 (build) | Out of V1 (cut) |
|---|---|
| FRAME browser web app for **Help GitLab teams turn scattered project context into consistent, high-quality e**: create/manage | Mobile apps |

## Non-Functional Requirements
| ID | Requirement | Priority |
|---|---|---|
| 1 | Performance: wizard navigation for **Help GitLab teams turn scattered project context into consistent, high-quality e**. | P0 |

## Launch Plan
Feature flags for Help GitLab teams turn scattered project context into consistent, high-quality e.`;

      const projectName = 'Help GitLab teams turn scattered project context into consistent, high-quality e';

      // Count how many times the full project name appears
      const occurrences = epicContent.split(projectName).length - 1;

      // The title counts as one, but the rest are excessive repetition in section content
      expect(occurrences).toBeGreaterThan(3);
      // After fix: should appear at most in the title and maybe 1 reference
    });

    it('should detect that AI prompt instructs verbatim project name usage', () => {
      // These are the actual AI prompt snippets that cause the problem
      const refinementPrompt = 'Use the exact project name "Help GitLab teams turn scattered project context into consistent, high-quality e" when referencing the project';
      const generatePrompt = 'Use the exact project name "Help GitLab teams turn scattered project context into consistent, high-quality e" when referencing the project';

      // Both prompts instruct AI to use the FULL sentence as a name
      expect(refinementPrompt).toContain('Use the exact project name');
      expect(generatePrompt).toContain('Use the exact project name');

      // After fix: should say something like "Reference the project as 'FRAME Epic Generator'"
    });
  });

  describe('Fix validation: reduced repetition', () => {
    it('should not inject long project name more than twice in full epic', async () => {
      const data: RefinedData = {
        objective: { original: 'Build auth', refined: 'Build authentication service' },
        features: { original: 'Login', refined: 'User login features' },
      };

      const result = await runSkill('generate', {
        data,
        projectName: 'Authentication Service',
      });

      const epic = (result as { epic: string }).epic;

      // Count occurrences of the project name
      const count = epic.split('Authentication Service').length - 1;

      // Should appear in H1 title, and possibly in one diagram/summary reference
      // Should NOT be injected into every section body
      expect(count).toBeLessThanOrEqual(3);
    });
  });
});

// ============================================================================
// ISSUE 3: No document identity in Epic Status
// ============================================================================
describe('Issue 3: Missing document identity metadata', () => {
  describe('Root cause: Epic Status only has "Generated on" date', () => {
    it('should detect that generated epic lacks document identity fields', async () => {
      setConfig({ ...DEFAULT_CONFIG, aiProvider: 'mock' });
      disableThrottlingForTests();

      const data: RefinedData = {
        objective: { original: 'Test', refined: 'Test project' },
      };

      const result = await runSkill('generate', {
        data,
        projectName: 'Test Project',
      });

      const epic = (result as { epic: string }).epic;

      // Currently only has "Generated on" - missing identity fields
      expect(epic).toContain('Generated on');

      // After fix: should include document identity
      // expect(epic).toMatch(/\| Document ID \|/);
      // expect(epic).toMatch(/\| Version \|/);
      // expect(epic).toMatch(/\| Status \|/);

      enableThrottling();
    });

    it('should verify Epic Status template has document identity fields', () => {
      const template = loadCategoryTemplate('feature_specification');
      const epicStatusConfig = template.requiredSections?.['Epic Status'];

      expect(epicStatusConfig).toBeDefined();
      expect(epicStatusConfig!.format).toBe('table');
      expect(epicStatusConfig!.fields).toBeDefined();

      // Template defines fields - check what's there
      const fields = epicStatusConfig!.fields || [];
      const hasStatus = fields.some((f: string) => f.toLowerCase().includes('status'));
      const hasOwner = fields.some((f: string) => f.toLowerCase().includes('owner'));

      expect(hasStatus).toBe(true);
      expect(hasOwner).toBe(true);
    });
  });

  describe('Fix validation: document identity block placed after context sections', () => {
    it('should generate epic with document identity AFTER Assumptions (section 4)', async () => {
      setConfig({ ...DEFAULT_CONFIG, aiProvider: 'mock' });
      disableThrottlingForTests();

      const data: RefinedData = {
        objective: { original: 'Build platform', refined: 'Build a platform' },
      };

      const result = await runSkill('generate', {
        data,
        projectName: 'FRAME Epic Generator',
      });

      const epic = (result as { epic: string }).epic;

      // H1 should be the project name
      expect(epic).toContain('# FRAME Epic Generator');

      // Should have a document identity block (Epic Status section)
      expect(epic).toMatch(/\*\*Status\*\*/i);
      expect(epic).toMatch(/\*\*Owner\*\*/i);
      expect(epic).toMatch(/Draft/i);

      // Epic Status should come AFTER section 4 (Assumptions), not before Objective
      const objectiveIdx = epic.indexOf('## 1. Objective');
      const assumptionsIdx = epic.indexOf('## 4. Assumptions');
      const epicStatusIdx = epic.indexOf('## Epic Status');

      expect(objectiveIdx).toBeGreaterThan(-1);
      expect(assumptionsIdx).toBeGreaterThan(-1);
      expect(epicStatusIdx).toBeGreaterThan(-1);

      // Epic Status must come AFTER both Objective and Assumptions
      expect(epicStatusIdx).toBeGreaterThan(objectiveIdx);
      expect(epicStatusIdx).toBeGreaterThan(assumptionsIdx);

      enableThrottling();
    });

    it('should NOT place Epic Status before Objective', async () => {
      setConfig({ ...DEFAULT_CONFIG, aiProvider: 'mock' });
      disableThrottlingForTests();

      const data: RefinedData = {
        objective: { original: 'Build app', refined: 'Build the app' },
      };

      const result = await runSkill('generate', {
        data,
        projectName: 'Test Project',
      });

      const epic = (result as { epic: string }).epic;

      // The "Generated on" line should be right after title (before sections)
      const h1Idx = epic.indexOf('# Test Project');
      const generatedOnIdx = epic.indexOf('*Generated on');
      const objectiveIdx = epic.indexOf('## 1. Objective');
      const epicStatusIdx = epic.indexOf('## Epic Status');

      // Order should be: Title → Generated On → Objective → ... → Assumptions → Epic Status
      expect(generatedOnIdx).toBeGreaterThan(h1Idx);
      expect(objectiveIdx).toBeGreaterThan(generatedOnIdx);
      expect(epicStatusIdx).toBeGreaterThan(objectiveIdx);

      enableThrottling();
    });
  });
});

// ============================================================================
// CROSS-CUTTING: parseEpicToStageData handles long titles
// ============================================================================
describe('Cross-cutting: parseEpicToStageData handles long H1 titles', () => {
  it('should extract project name from H1 even when it is a long sentence', () => {
    const epicWithLongTitle = `# Help GitLab teams turn scattered project context into consistent, high-quality e

## 1. Objective
Build a tool.`;

    const { projectName } = parseEpicToStageData(epicWithLongTitle);

    // Currently extracts the full long sentence as project name
    expect(projectName).toBe('Help GitLab teams turn scattered project context into consistent, high-quality e');
  });

  it('should extract a normal project name correctly', () => {
    const epicWithGoodTitle = `# FRAME Epic Generator

## 1. Objective
Build a tool.`;

    const { projectName } = parseEpicToStageData(epicWithGoodTitle);
    expect(projectName).toBe('FRAME Epic Generator');
  });
});

// ============================================================================
// ISSUE 4: Epic Status comes too early (before Objective/Scope/Architecture)
// ============================================================================
describe('Issue 4: Epic Status should not come before project context', () => {
  beforeEach(() => {
    setConfig({ ...DEFAULT_CONFIG, aiProvider: 'mock' });
    disableThrottlingForTests();
  });

  afterEach(() => {
    enableThrottling();
    vi.restoreAllMocks();
  });

  it('should place Epic Status after Scope section in generated epic', async () => {
    const data: RefinedData = {
      objective: { original: 'Build auth', refined: 'Build authentication' },
      inScope: { original: 'Login', refined: 'User login flow' },
    };

    const result = await runSkill('generate', { data, projectName: 'Auth Service' });
    const epic = (result as { epic: string }).epic;

    const scopeIdx = epic.indexOf('## 3. Scope');
    const epicStatusIdx = epic.indexOf('## Epic Status');

    expect(scopeIdx).toBeGreaterThan(-1);
    expect(epicStatusIdx).toBeGreaterThan(-1);
    expect(epicStatusIdx).toBeGreaterThan(scopeIdx);
  });

  it('should place Epic Status before Architecture section', async () => {
    const data: RefinedData = {
      objective: { original: 'Build something', refined: 'Build a system' },
    };

    const result = await runSkill('generate', { data, projectName: 'My System' });
    const epic = (result as { epic: string }).epic;

    const epicStatusIdx = epic.indexOf('## Epic Status');
    const archIdx = epic.indexOf('## 5. High-Level Architecture');

    expect(epicStatusIdx).toBeGreaterThan(-1);
    expect(archIdx).toBeGreaterThan(-1);
    expect(archIdx).toBeGreaterThan(epicStatusIdx);
  });
});

// ============================================================================
// ISSUE 5: Duplicated "User Stories" section
// ============================================================================
describe('Issue 5: User Stories section should not be duplicated', () => {
  it('should strip existing user stories subsection before embedding new ones', () => {
    // Simulate Stage 4 content with inline user stories
    const stage4Content = `## 11. Key Features & User Stories

### Key Features
- Feature A: Login system
- Feature B: Dashboard

### User Stories
- **US-001: Implement Login** - As a user, I want to log in
- **US-002: View Dashboard** - As a user, I want to see my dashboard`;

    // The fix should strip existing "### User Stories" subsection
    const existingStoriesIdx = stage4Content.search(/\n*###?\s*User Stories/i);
    expect(existingStoriesIdx).toBeGreaterThan(0);

    const stripped = stage4Content.substring(0, existingStoriesIdx).trim();
    expect(stripped).toContain('Key Features');
    expect(stripped).not.toContain('US-001');
    expect(stripped).not.toContain('US-002');
  });

  it('should strip inline bullet-style US-XXX stories', () => {
    const contentWithInlineStories = `## Key Features & User Stories

Key features:
- Feature A

- **US-001: Login Feature** As a user I want to log in
- **US-002: Dashboard** As a user I want a dashboard`;

    const stripped = contentWithInlineStories
      .replace(/\n[-*]\s*\*\*US-\d+[:\s].*$/gm, '')
      .trim();

    expect(stripped).toContain('Feature A');
    expect(stripped).not.toContain('US-001');
    expect(stripped).not.toContain('US-002');
  });

  it('should count User Stories headers in generated epic — expect exactly one', async () => {
    setConfig({ ...DEFAULT_CONFIG, aiProvider: 'mock' });
    disableThrottlingForTests();

    const data: RefinedData = {
      objective: { original: 'Build app', refined: 'Build an app' },
      features: { original: 'Login', refined: 'User login' },
      userStories: { original: 'Stories', refined: 'As a user, I want to log in' },
    };

    const result = await runSkill('generate', { data, projectName: 'Test App' });
    const epic = (result as { epic: string }).epic;

    // Count occurrences of "User Stories" as a heading (## or ###)
    const userStoriesHeadings = epic.match(/##[#]?\s*.*User Stories/gi) || [];

    // Should have at most 1 occurrence as the section heading
    // The main section "## 11. Key Features & User Stories" counts as one
    // There should NOT be an additional "### User Stories" subsection duplicating content
    expect(userStoriesHeadings.length).toBeLessThanOrEqual(1);

    enableThrottling();
  });
});

// sanitizeProjectName is now imported from '../skills'
