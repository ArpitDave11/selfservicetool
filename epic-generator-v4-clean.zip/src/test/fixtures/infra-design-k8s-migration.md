# Kubernetes Migration - EC2 to EKS

## Context

We're running 47 microservices on EC2 instances managed by Ansible. It works but scaling is manual, deployments take 20+ minutes, and we've had 3 incidents this quarter from configuration drift between environments. Moving to EKS to get proper orchestration, auto-scaling, and deployment automation.

## Target Architecture

### EKS Cluster Setup
- Single EKS cluster per environment (dev, staging, prod)
- Prod cluster: 3 AZs, managed node groups with m5.xlarge (general) and c5.2xlarge (compute-heavy services)
- Kubernetes 1.29, managed control plane
- Cluster autoscaler for node scaling, HPA (Horizontal Pod Autoscaler) for pod scaling based on CPU/memory and custom metrics from Prometheus

### Namespace Strategy
```
├── platform-system    (ingress controllers, cert-manager, external-dns)
├── monitoring         (prometheus, grafana, alertmanager, loki)
├── istio-system       (istiod, ingress/egress gateways)
├── app-frontend       (web apps, BFF services)
├── app-backend        (core microservices)
├── app-data           (database operators, redis, kafka connect)
└── jobs               (cron jobs, batch processing)
```

Network policies between namespaces -- backend can talk to data, frontend can only talk to backend, etc.

### Helm Charts
Every service gets a Helm chart stored in our internal ChartMuseum. Base chart template covers 80% of services (stateless HTTP microservice). Custom charts for stateful workloads (Kafka, Redis). Values files per environment, secrets managed via External Secrets Operator pulling from AWS Secrets Manager.

### Service Mesh (Istio)
Istio for mTLS between services, traffic management, and observability. Sidecar injection enabled by default in app namespaces. We'll use Istio's traffic splitting for canary deployments -- start with 5% traffic to new version, auto-promote if error rate stays below 0.1% over 10 minutes.

### Observability Stack
- **Metrics**: Prometheus with Thanos for long-term storage (S3 backend). Grafana dashboards per team.
- **Logs**: Fluent Bit daemonset -> Loki. Structured JSON logging required from all services.
- **Traces**: OpenTelemetry collector -> Jaeger. Trace sampling at 10% in prod.
- **Alerts**: Alertmanager with PagerDuty and Slack integrations.

### Deployment Strategy
Blue-green deployments for critical services (payment, auth). Implementation: two full deployments exist simultaneously, Istio VirtualService switches traffic. Rollback is instant -- just flip the VirtualService back. For everything else, rolling updates with maxUnavailable=0 and maxSurge=25%.

## Migration Plan (High Level)
1. Set up EKS clusters and platform tooling (2 weeks)
2. Migrate stateless services, lowest traffic first (3 weeks)
3. Migrate stateful services with data sync (2 weeks)
4. Run parallel traffic and compare responses -- shadow mode (1 week)
5. Cut over DNS and decommission EC2 instances (1 week)

## Risks
- Team is new to K8s -- scheduling 2-day workshop with external trainer
- Some services have hardcoded EC2 private IPs (need to find and fix all of these)
- Cost model is different -- need FinOps review to avoid surprise bills
- Persistent volume migration for stateful services is tricky

## Success Metrics
- Deployment time < 5 minutes (currently 20+)
- Zero-downtime deployments for all services
- Auto-scaling response time < 2 minutes
- Infrastructure cost within 10% of current EC2 spend
