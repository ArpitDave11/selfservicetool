# Payment Gateway API v2

## Summary

Version 2 of our Payment Gateway API. The main driver is PCI-DSS 4.0 compliance -- v1 has some patterns that won't pass the next audit (raw card numbers in request logs, no idempotency on charges). We're also adding webhook support which merchants have been asking for since forever.

## Base URL
Production: `https://api.payments.example.com/v2`
Sandbox: `https://sandbox.payments.example.com/v2`

## Authentication
All requests require a merchant API key in the `Authorization: Bearer <key>` header. Keys are scoped: `pk_live_*` for publishable (client-side tokenization only), `sk_live_*` for secret (server-side operations). Rotate keys via the merchant dashboard, old keys valid for 72 hours after rotation.

## Core Endpoints

### POST /v2/charges
Create a new charge. Requires `Idempotency-Key` header (UUID v4) -- replaying the same key within 24 hours returns the original response. Request body: `amount` (integer, cents), `currency` (ISO 4217), `payment_method_token`, `description`, `metadata` (arbitrary key-value, max 20 keys). Returns charge object with status `pending`, `succeeded`, or `failed`.

### POST /v2/charges/{id}/refund
Refund a charge. Supports partial refunds via `amount` field. Full refund if amount omitted. Cannot refund more than original charge amount (obviously). Refunds take 5-10 business days to appear on customer statement. Idempotency-Key also required here.

### POST /v2/webhooks
Register a webhook endpoint. Body: `url` (HTTPS required), `events` (array of event types like `charge.succeeded`, `refund.created`, `dispute.opened`). We sign webhook payloads with HMAC-SHA256 using merchant's webhook secret. Merchants should verify the `X-Signature` header. Failed deliveries retry 3 times with exponential backoff (1min, 5min, 30min).

### GET /v2/charges/{id}
Retrieve charge details. Includes full lifecycle events array showing state transitions with timestamps.

### GET /v2/balance
Current merchant balance. Shows available, pending, and reserved amounts.

## Rate Limits
- Live mode: 100 requests/second per merchant
- Sandbox: 20 requests/second
- Burst allowance: 150% of limit for 10 seconds
- Rate limit info in response headers: `X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-RateLimit-Reset`
- 429 responses include `Retry-After` header

## PCI-DSS Compliance Notes
- Card numbers NEVER transit through merchant servers -- use client-side tokenization via payments.js
- All API traffic TLS 1.2+ only, TLS 1.0/1.1 connections rejected
- Audit logs retained 7 years, immutable storage
- Tokenized PANs stored in isolated vault service with HSM-backed encryption
- Quarterly penetration testing results available to merchants on request

## Error Format
```json
{
  "error": {
    "code": "card_declined",
    "message": "The card was declined by the issuing bank",
    "decline_code": "insufficient_funds",
    "param": "payment_method_token"
  }
}
```

## Migration from v1
v1 endpoints continue to work until Dec 2025. The main breaking changes: charge amounts are now in cents (not dollars), webhook format changed, and the `card` object is replaced by `payment_method_token`. We'll provide a migration guide separately.
