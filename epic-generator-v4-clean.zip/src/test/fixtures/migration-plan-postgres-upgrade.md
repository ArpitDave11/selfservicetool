# PostgreSQL 12 to 16 Upgrade Plan

## Why We Need This

PG 12 hits EOL November 2024 and we're already past that. Security team flagged it in the last audit. Also PG 16 has some features we actually want -- JSONB improvements for our document store tables, better parallel query performance, and the new pg_stat_io view for I/O troubleshooting. Our largest table (events, ~800GB) is slow on complex aggregation queries that should benefit from PG 16 parallelism improvements.

## Current State

- PostgreSQL 12.17 on RDS (db.r5.2xlarge)
- 3 environments: dev (db.t3.medium), staging (db.r5.large), prod (db.r5.2xlarge with read replica)
- Total data: dev ~50GB, staging ~200GB, prod ~1.2TB
- Extensions in use: PostGIS 3.1, pgcrypto, pg_trgm, uuid-ossp, pg_stat_statements, hstore
- 14 application services connecting via PgBouncer (connection pooling)
- Daily pg_dump backups to S3, WAL archiving to S3

## Upgrade Strategy Options

### Option A: pg_dump / pg_restore (Logical)
Pros: Clean, works across major versions, can restructure tablespaces
Cons: Slow for 1.2TB (estimated 4-6 hours), requires extended downtime
Best for: dev and staging

### Option B: pg_upgrade (In-Place)
Pros: Much faster (~20 minutes for our data size with --link mode), less downtime
Cons: Requires same OS/architecture, need to rebuild pg_stat_statements data
Best for: prod

### Option C: Logical Replication (Near-Zero Downtime)
Pros: Minimal downtime (just a switchover), can validate data before cutover
Cons: Complex setup, DDL changes need to be paused during migration, doesn't replicate sequences automatically
Best for: prod if downtime window is rejected

Going with Option A for dev/staging and Option B for prod unless the change board wants near-zero downtime, in which case we'll do Option C for prod.

## Extension Compatibility
Checked compatibility matrix:
- PostGIS 3.1 -> need to upgrade to 3.4 for PG 16 compatibility (separate change request)
- pgcrypto, pg_trgm, uuid-ossp -- bundled with PG 16, no issues
- pg_stat_statements -- need to rebuild after upgrade, stats will be lost
- hstore -- compatible, no changes needed

## Connection String Rotation
All 14 services use connection strings from AWS Secrets Manager. Plan:
1. Create new PG 16 RDS instance with new endpoint
2. Update secret in Secrets Manager with new endpoint
3. Rolling restart services to pick up new connection string
4. PgBouncer config update -- new backend server address

We should test that all services handle the connection string change gracefully. Some older services might cache DNS -- need to verify TTL settings.

## Rollback Plan
- Keep PG 12 instance running (stopped, not terminated) for 2 weeks post-migration
- If critical issues found within 2 hours of cutover: revert DNS/secrets to PG 12 endpoint
- If issues found after 2 hours: assess data drift, may need logical export from PG 16 back to PG 12
- Rollback is NOT possible with pg_upgrade --link mode since it modifies files in place -- so we take a snapshot before starting

## Timeline
| Phase | Environment | Duration | Downtime |
|-------|-------------|----------|----------|
| 1 | Dev | 1 day | 2 hours |
| 2 | Staging + perf testing | 3 days | 4 hours |
| 3 | Prod | 1 day | 30 min (pg_upgrade) or 5 min (logical replication) |
| 4 | Monitoring & validation | 5 days | none |

## Open Items
- Need DBA team to review our custom PG configs (shared_buffers, work_mem, etc.) for PG 16 defaults
- Should we take this opportunity to enable PG 16's new WAL compression? Might save 30% on WAL archive storage
- Coordinate with data team -- their ETL pipelines connect directly and bypass PgBouncer
