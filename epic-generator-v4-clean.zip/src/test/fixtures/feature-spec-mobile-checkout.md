# Mobile Checkout Flow Redesign

## Background

Our mobile checkout conversion rate is 23% below desktop. Analytics shows users drop off mainly at payment entry (41% abandonment) and the order review step (18% abandonment). We need to rebuild the mobile checkout as a streamlined 3-step flow optimized for thumb-friendly interaction.

## User Flow

### Step 1: Cart Review
Display cart items with thumbnail images, quantity steppers, and swipe-to-remove. Show running total with tax estimate based on shipping address. "Apply promo code" should be a collapsible section -- currently it takes up too much space and distracts users. Persist cart state to localStorage so users don't lose items if they leave and come back.

### Step 2: Payment Method Selection
Support the following payment methods:
- **Credit/Debit Card** - Stripe Elements embedded form, auto-detect card type from BIN
- **Apple Pay** - for iOS Safari and native app, use PassKit integration
- **Google Pay** - for Android Chrome and native app, use Google Pay API v2
- **PayPal** - redirect flow with express checkout
- Saved payment methods shown at top with last 4 digits and card brand icon

The payment step needs to feel fast. We should lazy-load the Stripe SDK and only initialize it if the user actually taps "credit card." Apple Pay and Google Pay buttons should use the native platform button styles -- don't try to custom style them.

### Step 3: Order Confirmation
Show order summary, estimated delivery date, and tracking info signup. Send confirmation email via SendGrid within 30 seconds of order placement. Email includes itemized receipt, order number, and deep link back to order status page.

## A/B Testing

Product wants to test two variations of the "Place Order" button:
- **Variant A**: Fixed bottom bar with total + button (current pattern)
- **Variant B**: Inline button below order summary with security badges

We'll use LaunchDarkly feature flags for this. Success metric is conversion rate at the payment step, measured over 2 weeks with 50/50 traffic split. Need minimum 10k orders per variant for statistical significance.

## Error Handling
- Payment declined: show inline error with retry, suggest different method
- Network timeout: queue order attempt locally and retry with exponential backoff
- Address validation failure: highlight fields with Google Places autocomplete suggestion

## Accessibility
All interactive elements need minimum 44x44pt touch targets. VoiceOver and TalkBack support for the entire flow. Color contrast ratio 4.5:1 minimum on all text.

## Out of Scope
- Gift cards (separate epic, depends on new GC service)
- Multi-address shipping
- Crypto payments (lol, leadership asked)
