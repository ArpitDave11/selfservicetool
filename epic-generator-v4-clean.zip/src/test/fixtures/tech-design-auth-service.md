# Auth Service Redesign - Microservice Extraction

## Overview

We need to pull the authentication logic out of the monolith and stand it up as its own microservice. Right now auth is tangled into the main API and it's causing deployment bottlenecks -- every time we touch user login we have to redeploy the whole thing. The new service will own user identity, session management, and authorization.

## Technical Approach

### Authentication Flow
The service will issue JWTs (access + refresh token pair) on successful login. Access tokens expire after 15 minutes, refresh tokens after 7 days. We're going with RS256 signing so downstream services can validate tokens without calling back to the auth service. OAuth2 support is needed for Google and GitHub SSO -- the product team wants this for Q3.

### Password Handling
All passwords hashed with bcrypt, cost factor 12. We talked about argon2 but the team is more familiar with bcrypt and the security review signed off on it. Existing password hashes from the monolith DB will be migrated as-is since we're already using bcrypt there.

### Session Management
Redis cluster for session cache. We'll store active session metadata (device info, IP, last activity) so users can see "active sessions" in their profile and revoke them. Redis gives us TTL-based expiry which maps nicely to our token lifetimes. Planning for ~50k concurrent sessions initially.

### Data Store
PostgreSQL 15 for the user store. Tables: users, roles, permissions, user_roles, oauth_providers, login_audit. The RBAC model supports role hierarchy -- admin inherits manager permissions, manager inherits viewer, etc. We need row-level security on the audit table.

### Rate Limiting
Token bucket algorithm on login endpoints. 5 attempts per minute per username, 20 per minute per IP. After lockout, exponential backoff starting at 30 seconds. Rate limit headers (X-RateLimit-Remaining, X-RateLimit-Reset) returned on every response.

## Non-Functional Requirements
- p99 latency under 100ms for token validation
- 99.95% uptime SLA
- Support 500 login requests/sec at peak
- GDPR compliant -- user deletion must cascade through all tables

## Open Questions
- Do we need to support SAML for enterprise SSO? Sales is pushing for it but nobody on the team has done it before
- Where does MFA fit? Probably a follow-up epic but should we design the schema for it now?
- Need to figure out the migration strategy for existing sessions -- do we force everyone to re-login?

## Dependencies
- DevOps to provision Redis cluster (INFRA-234)
- Security team review of JWT signing key rotation plan
- Frontend team to update login/signup forms for new API contract
