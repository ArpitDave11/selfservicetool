/**
 * GitLab OAuth 2.0 + OIDC Module
 *
 * Provides OAuth authentication for GitLab, replacing Personal Access Tokens
 * with a secure "Sign in with GitLab" flow using PKCE.
 */

// ===========================================
// Types
// ===========================================

export type {
  GitLabOAuthConfig,
  GitLabOAuthTokens,
  GitLabUserInfo,
  GitLabAuthState,
  GitLabAuthContextType,
  GitLabAuthMode,
  PKCEChallenge,
  OAuthState,
  GitLabOAuthEndpoints,
} from './gitlabAuthTypes';

// ===========================================
// Provider and Hook
// ===========================================

export {
  GitLabAuthProvider,
  useGitLabAuth,
  GitLabMockAuthBadge,
  GITLAB_OAUTH_ENABLED,
  GITLAB_OAUTH_MOCK,
} from './GitLabAuthProvider';

// ===========================================
// UI Components
// ===========================================

export { GitLabLoginButton } from './GitLabLoginButton';
export { GitLabUserInfo, GitLabUserBadge } from './GitLabUserInfo';

// ===========================================
// Configuration
// ===========================================

export {
  getDefaultOAuthConfig,
  shouldUseGitLabOAuth,
  isOAuthConfigured,
  getOAuthEndpoints,
  getRedirectUri,
  STORAGE_KEYS,
} from './gitlabAuthConfig';

// ===========================================
// Storage Utilities
// ===========================================

export {
  retrieveTokens,
  storeTokens,
  clearTokens,
  retrieveAuthMode,
  storeAuthMode,
  hasStoredTokens,
  clearAllGitLabAuthData,
  retrieveUserInfo,
  storeUserInfo,
} from './gitlabTokenStorage';

// ===========================================
// Service Functions (for advanced usage)
// ===========================================

export {
  isTokenExpired,
  shouldRefreshToken,
  getTimeUntilRefresh,
} from './gitlabAuthService';
