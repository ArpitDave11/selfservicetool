/**
 * GitLab User Info Component
 *
 * Displays the authenticated GitLab user's information.
 * Shows avatar, name, email, and a logout button.
 */

import React from 'react';
import { useGitLabAuth } from './GitLabAuthProvider';

// ===========================================
// UBS Brand Colors
// ===========================================

const UBS_COLORS = {
  red: '#E60000',
  black: '#000000',
  white: '#FFFFFF',
  grayI: '#ADACA5',
  grayIII: '#8E8D83',
  grayV: '#5A5D5C',
  pastelI: '#ECEBE4',
};

// ===========================================
// Props
// ===========================================

interface GitLabUserInfoProps {
  /** Show logout button */
  showLogout?: boolean;
  /** Compact display mode */
  compact?: boolean;
  /** Custom className */
  className?: string;
  /** Custom styles */
  style?: React.CSSProperties;
}

// ===========================================
// Default Avatar
// ===========================================

const DefaultAvatar: React.FC<{ name: string; size: number }> = ({ name, size }) => {
  // Get initials from name
  const initials = name
    .split(' ')
    .map((n) => n[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();

  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: '50%',
        background: `linear-gradient(135deg, ${UBS_COLORS.red} 0%, #BD000C 100%)`,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        color: UBS_COLORS.white,
        fontSize: size * 0.4,
        fontWeight: 600,
        flexShrink: 0,
      }}
    >
      {initials}
    </div>
  );
};

// ===========================================
// Component
// ===========================================

export const GitLabUserInfo: React.FC<GitLabUserInfoProps> = ({
  showLogout = true,
  compact = false,
  className,
  style,
}) => {
  const { user, isAuthenticated, isLoading, logout } = useGitLabAuth();

  // Don't render if not authenticated or loading
  if (!isAuthenticated || isLoading || !user) {
    return null;
  }

  const avatarSize = compact ? 28 : 36;

  return (
    <div
      className={className}
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: compact ? '8px' : '12px',
        padding: compact ? '6px 10px' : '8px 12px',
        background: UBS_COLORS.pastelI,
        borderRadius: '8px',
        fontFamily: 'Frutiger, "Helvetica Neue", Arial, sans-serif',
        ...style,
      }}
    >
      {/* Avatar */}
      {user.picture ? (
        <img
          src={user.picture}
          alt={user.name}
          style={{
            width: avatarSize,
            height: avatarSize,
            borderRadius: '50%',
            border: `2px solid ${UBS_COLORS.white}`,
            flexShrink: 0,
          }}
          onError={(e) => {
            // Hide broken image and show initials
            e.currentTarget.style.display = 'none';
          }}
        />
      ) : (
        <DefaultAvatar name={user.name} size={avatarSize} />
      )}

      {/* User Info */}
      {!compact && (
        <div style={{ flex: 1, minWidth: 0 }}>
          <div
            style={{
              fontSize: '13px',
              fontWeight: 600,
              color: UBS_COLORS.black,
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
            }}
          >
            {user.name}
          </div>
          <div
            style={{
              fontSize: '11px',
              color: UBS_COLORS.grayIII,
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
            }}
          >
            {user.email || `@${user.nickname}`}
          </div>
        </div>
      )}

      {/* Logout Button */}
      {showLogout && (
        <button
          onClick={logout}
          title="Sign out of GitLab"
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: compact ? '24px' : '28px',
            height: compact ? '24px' : '28px',
            padding: 0,
            background: 'transparent',
            border: `1px solid ${UBS_COLORS.grayI}`,
            borderRadius: '6px',
            cursor: 'pointer',
            transition: 'all 0.2s ease',
            flexShrink: 0,
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.background = UBS_COLORS.white;
            e.currentTarget.style.borderColor = UBS_COLORS.red;
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.background = 'transparent';
            e.currentTarget.style.borderColor = UBS_COLORS.grayI;
          }}
        >
          {/* Logout Icon */}
          <svg
            width={compact ? 14 : 16}
            height={compact ? 14 : 16}
            viewBox="0 0 24 24"
            fill="none"
            stroke={UBS_COLORS.grayV}
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
            <polyline points="16,17 21,12 16,7" />
            <line x1="21" y1="12" x2="9" y2="12" />
          </svg>
        </button>
      )}
    </div>
  );
};

// ===========================================
// Compact Badge Variant
// ===========================================

export const GitLabUserBadge: React.FC<{
  onClick?: () => void;
}> = ({ onClick }) => {
  const { user, isAuthenticated } = useGitLabAuth();

  if (!isAuthenticated || !user) {
    return null;
  }

  return (
    <button
      onClick={onClick}
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: '6px',
        padding: '4px 8px',
        background: UBS_COLORS.pastelI,
        border: 'none',
        borderRadius: '16px',
        cursor: onClick ? 'pointer' : 'default',
        fontFamily: 'Frutiger, "Helvetica Neue", Arial, sans-serif',
        fontSize: '12px',
        color: UBS_COLORS.grayV,
        transition: 'all 0.2s ease',
      }}
      onMouseEnter={(e) => {
        if (onClick) {
          e.currentTarget.style.background = UBS_COLORS.grayI;
        }
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.background = UBS_COLORS.pastelI;
      }}
    >
      {/* GitLab icon */}
      <svg width="14" height="14" viewBox="0 0 380 380" fill="none">
        <path d="M190.007 350.963L256.161 147.389H123.854L190.007 350.963Z" fill="#E24329" />
        <path d="M190.007 350.963L123.854 147.389H31.0505L190.007 350.963Z" fill="#FC6D26" />
        <path d="M190.007 350.963L256.161 147.389H348.963L190.007 350.963Z" fill="#FC6D26" />
      </svg>
      <span>@{user.nickname}</span>
    </button>
  );
};
