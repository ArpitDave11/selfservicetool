/**
 * GitLab OAuth 2.0 + OIDC Type Definitions
 *
 * Interfaces for GitLab OAuth authentication with PKCE support.
 */

// ===========================================
// OAuth Configuration
// ===========================================

export interface GitLabOAuthConfig {
  /** OAuth enabled flag */
  enabled: boolean;
  /** GitLab instance base URL (e.g., https://gitlab.com or https://devcloud.ubs.net) */
  baseUrl: string;
  /** OAuth Application ID (Client ID) */
  clientId: string;
  /** Redirect URI for OAuth callback */
  redirectUri: string;
  /** OAuth scopes to request */
  scopes: string[];
  /** Group ID for API operations */
  groupId: string;
}

// ===========================================
// OAuth Endpoints (derived from baseUrl)
// ===========================================

export interface GitLabOAuthEndpoints {
  authorize: string;
  token: string;
  userInfo: string;
  revoke: string;
  discovery: string;
}

// ===========================================
// OAuth Token Response
// ===========================================

export interface GitLabOAuthTokens {
  /** Access token for API requests */
  access_token: string;
  /** Token type (always "Bearer") */
  token_type: 'Bearer' | 'bearer';
  /** Token expiration time in seconds */
  expires_in: number;
  /** Refresh token for obtaining new access tokens */
  refresh_token: string;
  /** Unix timestamp when token was created */
  created_at: number;
  /** Space-separated list of granted scopes */
  scope: string;
  /** OIDC ID token (JWT) - present when openid scope requested */
  id_token?: string;
}

// ===========================================
// OIDC User Info Response
// ===========================================

export interface GitLabUserInfo {
  /** GitLab user ID (subject claim) */
  sub: string;
  /** User's display name */
  name: string;
  /** User's username/handle */
  nickname: string;
  /** User's preferred username */
  preferred_username?: string;
  /** User's email address */
  email: string;
  /** Whether email is verified */
  email_verified: boolean;
  /** URL to user's avatar image */
  picture?: string;
  /** URL to user's GitLab profile */
  profile?: string;
  /** User's website */
  website?: string;
  /** Direct group memberships */
  groups_direct?: string[];
  /** All group memberships (from userinfo endpoint) */
  groups?: string[];
}

// ===========================================
// PKCE Challenge
// ===========================================

export interface PKCEChallenge {
  /** Random string used to verify token exchange (43-128 chars) */
  codeVerifier: string;
  /** SHA-256 hash of codeVerifier, base64url encoded */
  codeChallenge: string;
  /** Challenge method (always S256 for security) */
  codeChallengeMethod: 'S256';
}

// ===========================================
// OAuth State (for CSRF protection)
// ===========================================

export interface OAuthState {
  /** Random state string */
  state: string;
  /** Timestamp when state was created */
  createdAt: number;
  /** Optional: where to redirect after auth */
  returnTo?: string;
}

// ===========================================
// Auth State
// ===========================================

export interface GitLabAuthState {
  /** Whether user is authenticated */
  isAuthenticated: boolean;
  /** Whether auth is in progress (loading) */
  isLoading: boolean;
  /** Authenticated user info (from OIDC) */
  user: GitLabUserInfo | null;
  /** OAuth tokens */
  tokens: GitLabOAuthTokens | null;
  /** Auth error if any */
  error: Error | null;
}

// ===========================================
// Auth Context Type
// ===========================================

export interface GitLabAuthContextType extends GitLabAuthState {
  /** Initiate OAuth login flow */
  login: () => Promise<void>;
  /** Logout and revoke tokens */
  logout: () => Promise<void>;
  /** Get current access token (refreshing if needed) */
  getAccessToken: () => Promise<string | null>;
  /** Manually trigger token refresh */
  refreshTokens: () => Promise<boolean>;
  /** OAuth configuration */
  config: GitLabOAuthConfig;
}

// ===========================================
// Token Exchange Request
// ===========================================

export interface TokenExchangeRequest {
  client_id: string;
  code: string;
  grant_type: 'authorization_code';
  redirect_uri: string;
  code_verifier: string;
}

// ===========================================
// Token Refresh Request
// ===========================================

export interface TokenRefreshRequest {
  client_id: string;
  refresh_token: string;
  grant_type: 'refresh_token';
}

// ===========================================
// OAuth Error Response
// ===========================================

export interface OAuthErrorResponse {
  error: string;
  error_description?: string;
  error_uri?: string;
}

// ===========================================
// Auth Mode for GitLabConfig
// ===========================================

export type GitLabAuthMode = 'pat' | 'oauth';
