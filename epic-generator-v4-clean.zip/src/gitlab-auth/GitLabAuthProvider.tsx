/**
 * GitLab OAuth Authentication Provider
 *
 * React Context provider for GitLab OAuth 2.0 + OIDC authentication.
 * Handles the complete OAuth flow including:
 * - PKCE challenge generation
 * - Authorization redirect
 * - Callback handling
 * - Token exchange
 * - Automatic token refresh
 * - User info fetching
 * - Logout/revocation
 */

import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  useRef,
} from 'react';
import type {
  GitLabAuthContextType,
  GitLabAuthState,
  GitLabOAuthConfig,
  GitLabOAuthTokens,
  GitLabUserInfo,
} from './gitlabAuthTypes';
import {
  GITLAB_OAUTH_ENABLED,
  GITLAB_OAUTH_MOCK,
  getDefaultOAuthConfig,
  isOAuthConfigured,
  logDebug,
  logError,
  logInfo,
} from './gitlabAuthConfig';
import {
  generatePKCEChallenge,
  createOAuthState,
  validateOAuthState,
  buildAuthorizationUrl,
  exchangeCodeForTokens,
  refreshAccessToken,
  fetchUserInfo,
  revokeToken,
  isOAuthCallback,
  parseOAuthCallback,
  cleanOAuthCallbackUrl,
  shouldRefreshToken,
  isTokenExpired,
  getTimeUntilRefresh,
} from './gitlabAuthService';
import {
  storeTokens,
  retrieveTokens,
  clearTokens,
  storePKCEVerifier,
  retrieveAndClearPKCEVerifier,
  storeOAuthState,
  retrieveAndClearOAuthState,
  storeUserInfo,
  retrieveUserInfo,
  clearAllGitLabAuthData,
} from './gitlabTokenStorage';

// ===========================================
// Mock User for Testing
// ===========================================

const MOCK_USER: GitLabUserInfo = {
  sub: '12345',
  name: 'Test Developer',
  nickname: 'testdev',
  email: 'test.dev@company.com',
  email_verified: true,
  picture: 'https://secure.gravatar.com/avatar/test?s=80&d=identicon',
  profile: 'https://gitlab.com/testdev',
};

const MOCK_TOKENS: GitLabOAuthTokens = {
  access_token: 'mock_access_token_for_testing',
  token_type: 'Bearer',
  expires_in: 7200,
  refresh_token: 'mock_refresh_token_for_testing',
  created_at: Math.floor(Date.now() / 1000),
  scope: 'openid profile email api',
};

// ===========================================
// Initial State
// ===========================================

const initialAuthState: GitLabAuthState = {
  isAuthenticated: false,
  isLoading: true,
  user: null,
  tokens: null,
  error: null,
};

// ===========================================
// Context
// ===========================================

const GitLabAuthContext = createContext<GitLabAuthContextType | null>(null);

// ===========================================
// Provider Component
// ===========================================

interface GitLabAuthProviderProps {
  children: React.ReactNode;
  config?: Partial<GitLabOAuthConfig>;
}

export const GitLabAuthProvider: React.FC<GitLabAuthProviderProps> = ({
  children,
  config: configOverrides,
}) => {
  // Merge config with defaults
  const config: GitLabOAuthConfig = {
    ...getDefaultOAuthConfig(),
    ...configOverrides,
  };

  // State
  const [authState, setAuthState] = useState<GitLabAuthState>(initialAuthState);
  const refreshTimeoutRef = useRef<number | null>(null);
  const isInitializing = useRef(false);
  // Mutex for preventing concurrent token refresh attempts
  const refreshInProgressRef = useRef<Promise<boolean> | null>(null);

  // ===========================================
  // Mock Auth Mode
  // ===========================================

  const handleMockLogin = useCallback(async () => {
    logInfo('Mock GitLab login...');
    setAuthState(prev => ({ ...prev, isLoading: true }));

    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    const tokens = { ...MOCK_TOKENS, created_at: Math.floor(Date.now() / 1000) };
    storeTokens(tokens);
    storeUserInfo(MOCK_USER);

    setAuthState({
      isAuthenticated: true,
      isLoading: false,
      user: MOCK_USER,
      tokens: tokens,
      error: null,
    });

    logInfo('Mock GitLab login successful:', MOCK_USER.name);
  }, []);

  const handleMockLogout = useCallback(async () => {
    logInfo('Mock GitLab logout...');
    clearAllGitLabAuthData();
    setAuthState({
      ...initialAuthState,
      isLoading: false,
    });
  }, []);

  // ===========================================
  // Real OAuth Login
  // ===========================================

  const handleLogin = useCallback(async () => {
    if (GITLAB_OAUTH_MOCK) {
      return handleMockLogin();
    }

    if (!isOAuthConfigured(config)) {
      setAuthState(prev => ({
        ...prev,
        error: new Error('GitLab OAuth not configured. Please set Client ID in settings.'),
      }));
      return;
    }

    logInfo('Starting GitLab OAuth login...');

    try {
      // Generate PKCE challenge
      const pkce = await generatePKCEChallenge();
      storePKCEVerifier(pkce.codeVerifier);

      // Generate state for CSRF protection
      const oauthState = createOAuthState(window.location.pathname);
      storeOAuthState(oauthState);

      // Build authorization URL and redirect
      const authUrl = buildAuthorizationUrl(config, pkce, oauthState.state);
      logDebug('Redirecting to GitLab authorization...');

      window.location.href = authUrl;
    } catch (error) {
      logError('Login initiation failed:', error);
      setAuthState(prev => ({
        ...prev,
        error: error instanceof Error ? error : new Error('Failed to initiate login'),
      }));
    }
  }, [config, handleMockLogin]);

  // ===========================================
  // Logout
  // ===========================================

  const handleLogout = useCallback(async () => {
    if (GITLAB_OAUTH_MOCK) {
      return handleMockLogout();
    }

    logInfo('Logging out...');

    // Clear refresh timer
    if (refreshTimeoutRef.current) {
      window.clearTimeout(refreshTimeoutRef.current);
      refreshTimeoutRef.current = null;
    }

    // Clear any pending refresh
    refreshInProgressRef.current = null;

    // Revoke tokens if available - read fresh from storage
    const tokens = retrieveTokens();
    if (tokens) {
      // Revoke both tokens in parallel, continue even if one fails
      await Promise.allSettled([
        revokeToken(config, tokens.access_token, 'access_token'),
        tokens.refresh_token
          ? revokeToken(config, tokens.refresh_token, 'refresh_token')
          : Promise.resolve(true),
      ]);
    }

    // Clear all stored data
    clearAllGitLabAuthData();

    // Reset state
    setAuthState({
      ...initialAuthState,
      isLoading: false,
    });

    logInfo('Logout complete');
  }, [config, handleMockLogout]);

  // ===========================================
  // Token Refresh (with mutex to prevent concurrent refreshes)
  // ===========================================

  const handleTokenRefresh = useCallback(async (): Promise<boolean> => {
    if (GITLAB_OAUTH_MOCK) {
      logDebug('Mock mode: skipping token refresh');
      return true;
    }

    // Return existing promise if refresh is already in progress (mutex)
    if (refreshInProgressRef.current) {
      logDebug('Token refresh already in progress, waiting...');
      return refreshInProgressRef.current;
    }

    // Create refresh promise and store in ref
    refreshInProgressRef.current = (async (): Promise<boolean> => {
      try {
        // Always read fresh from storage to avoid stale closure issues
        const currentTokens = retrieveTokens();
        if (!currentTokens?.refresh_token) {
          logError('No refresh token available');
          return false;
        }

        logInfo('Refreshing tokens...');

        const newTokens = await refreshAccessToken(config, currentTokens.refresh_token);
        storeTokens(newTokens);

        setAuthState(prev => ({
          ...prev,
          tokens: newTokens,
          error: null,
        }));

        // Schedule next refresh
        scheduleTokenRefresh(newTokens);

        return true;
      } catch (error) {
        logError('Token refresh failed:', error);
        // Don't clear auth immediately - let user continue until token fully expires
        setAuthState(prev => ({
          ...prev,
          error: error instanceof Error ? error : new Error('Token refresh failed'),
        }));
        return false;
      } finally {
        // Clear the mutex after completion
        refreshInProgressRef.current = null;
      }
    })();

    return refreshInProgressRef.current;
  }, [config]); // Removed authState.tokens - always read fresh from storage

  // ===========================================
  // Get Access Token (with auto-refresh)
  // ===========================================

  const getAccessToken = useCallback(async (): Promise<string | null> => {
    // Always read fresh from storage to get latest tokens
    const tokens = retrieveTokens();
    if (!tokens) {
      return null;
    }

    // Check if token needs refresh
    if (shouldRefreshToken(tokens)) {
      logDebug('Token near expiration, refreshing...');
      const refreshed = await handleTokenRefresh();
      if (!refreshed) {
        // If refresh failed but token not fully expired, return current token
        const currentTokens = retrieveTokens();
        if (currentTokens && !isTokenExpired(currentTokens)) {
          return currentTokens.access_token;
        }
        return null;
      }
      // Get updated tokens after refresh
      const newTokens = retrieveTokens();
      return newTokens?.access_token || null;
    }

    return tokens.access_token;
  }, [handleTokenRefresh]); // Removed authState.tokens dependency

  // ===========================================
  // Schedule Token Refresh
  // ===========================================

  const scheduleTokenRefresh = useCallback((tokens: GitLabOAuthTokens) => {
    // Clear existing timer
    if (refreshTimeoutRef.current) {
      window.clearTimeout(refreshTimeoutRef.current);
    }

    const timeUntilRefresh = getTimeUntilRefresh(tokens);

    if (timeUntilRefresh > 0) {
      logDebug(`Scheduling token refresh in ${Math.round(timeUntilRefresh / 1000)} seconds`);
      refreshTimeoutRef.current = window.setTimeout(() => {
        handleTokenRefresh();
      }, timeUntilRefresh);
    }
  }, [handleTokenRefresh]);

  // ===========================================
  // Handle OAuth Callback
  // ===========================================

  const handleOAuthCallback = useCallback(async () => {
    if (!isOAuthCallback()) {
      return false;
    }

    logInfo('Processing OAuth callback...');
    setAuthState(prev => ({ ...prev, isLoading: true }));

    try {
      const { code, state, error, errorDescription } = parseOAuthCallback(window.location.href);

      // Check for OAuth error
      if (error) {
        const errorMessage = errorDescription
          ? `${error}: ${errorDescription}`
          : error;
        throw new Error(`OAuth error: ${errorMessage}`);
      }

      if (!code || !state) {
        throw new Error('Missing code or state in callback');
      }

      // Validate state (CSRF protection)
      const storedState = retrieveAndClearOAuthState();
      if (!validateOAuthState(state, storedState)) {
        throw new Error('Invalid OAuth state - possible CSRF attack');
      }

      // Get PKCE verifier
      const codeVerifier = retrieveAndClearPKCEVerifier();
      if (!codeVerifier) {
        throw new Error('Missing PKCE verifier');
      }

      // Exchange code for tokens
      const tokens = await exchangeCodeForTokens(config, code, codeVerifier);
      storeTokens(tokens);

      // Fetch user info
      const userInfo = await fetchUserInfo(config, tokens.access_token);
      storeUserInfo(userInfo);

      // Clean URL
      cleanOAuthCallbackUrl();

      // Update state
      setAuthState({
        isAuthenticated: true,
        isLoading: false,
        user: userInfo,
        tokens: tokens,
        error: null,
      });

      // Schedule token refresh
      scheduleTokenRefresh(tokens);

      logInfo('OAuth callback processed successfully:', userInfo.name);
      return true;
    } catch (error) {
      logError('OAuth callback failed:', error);
      cleanOAuthCallbackUrl();
      setAuthState({
        ...initialAuthState,
        isLoading: false,
        error: error instanceof Error ? error : new Error('OAuth callback failed'),
      });
      return false;
    }
  }, [config, scheduleTokenRefresh]);

  // ===========================================
  // Initialize Auth State
  // ===========================================

  const initializeAuth = useCallback(async () => {
    logDebug('Initializing GitLab auth...');

    // Check for OAuth callback first
    if (isOAuthCallback()) {
      await handleOAuthCallback();
      return;
    }

    // Check for mock mode with existing session
    if (GITLAB_OAUTH_MOCK) {
      const tokens = retrieveTokens();
      const user = retrieveUserInfo();
      if (tokens && user) {
        logInfo('Restored mock session for:', user.name);
        setAuthState({
          isAuthenticated: true,
          isLoading: false,
          user: user,
          tokens: tokens,
          error: null,
        });
        return;
      }
      // Mock mode but no session - show login
      setAuthState({ ...initialAuthState, isLoading: false });
      return;
    }

    // Check for existing tokens
    const tokens = retrieveTokens();
    const user = retrieveUserInfo();

    if (tokens) {
      // Check if tokens are expired
      if (isTokenExpired(tokens)) {
        logDebug('Stored tokens are expired, attempting refresh...');
        if (tokens.refresh_token) {
          try {
            const newTokens = await refreshAccessToken(config, tokens.refresh_token);
            storeTokens(newTokens);
            const userInfo = user || await fetchUserInfo(config, newTokens.access_token);
            storeUserInfo(userInfo);

            setAuthState({
              isAuthenticated: true,
              isLoading: false,
              user: userInfo,
              tokens: newTokens,
              error: null,
            });
            scheduleTokenRefresh(newTokens);
            logInfo('Restored session with refreshed tokens:', userInfo.name);
            return;
          } catch (error) {
            logError('Failed to refresh expired tokens:', error);
            clearAllGitLabAuthData();
          }
        } else {
          logDebug('No refresh token, clearing expired session');
          clearAllGitLabAuthData();
        }
      } else {
        // Tokens are still valid
        logInfo('Restored valid session for:', user?.name || 'user');
        setAuthState({
          isAuthenticated: true,
          isLoading: false,
          user: user,
          tokens: tokens,
          error: null,
        });
        scheduleTokenRefresh(tokens);
        return;
      }
    }

    // No valid session
    setAuthState({ ...initialAuthState, isLoading: false });
  }, [config, handleOAuthCallback, scheduleTokenRefresh]);

  // ===========================================
  // Effect: Initialize on Mount
  // ===========================================

  useEffect(() => {
    if (isInitializing.current) return;
    isInitializing.current = true;

    let isMounted = true;

    initializeAuth().finally(() => {
      if (!isMounted) return;
      isInitializing.current = false;
    });

    return () => {
      isMounted = false;
      // Clear refresh timer on unmount
      if (refreshTimeoutRef.current) {
        window.clearTimeout(refreshTimeoutRef.current);
      }
    };
  }, [initializeAuth]);

  // ===========================================
  // Context Value
  // ===========================================

  const contextValue: GitLabAuthContextType = {
    ...authState,
    login: handleLogin,
    logout: handleLogout,
    getAccessToken,
    refreshTokens: handleTokenRefresh,
    config,
  };

  return (
    <GitLabAuthContext.Provider value={contextValue}>
      {children}
    </GitLabAuthContext.Provider>
  );
};

// ===========================================
// Hook
// ===========================================

export function useGitLabAuth(): GitLabAuthContextType {
  const context = useContext(GitLabAuthContext);
  if (!context) {
    throw new Error('useGitLabAuth must be used within a GitLabAuthProvider');
  }
  return context;
}

// ===========================================
// Mock Badge Component
// ===========================================

export const GitLabMockAuthBadge: React.FC = () => {
  if (!GITLAB_OAUTH_MOCK) {
    return null;
  }

  return (
    <div
      style={{
        position: 'fixed',
        bottom: '16px',
        left: '16px',
        background: '#FFA500',
        color: '#000',
        padding: '6px 12px',
        borderRadius: '4px',
        fontSize: '11px',
        fontWeight: 'bold',
        zIndex: 9999,
        boxShadow: '0 2px 4px rgba(0,0,0,0.2)',
      }}
    >
      MOCK GITLAB AUTH
    </div>
  );
};

// ===========================================
// Export Feature Flags
// ===========================================

export { GITLAB_OAUTH_ENABLED, GITLAB_OAUTH_MOCK };
