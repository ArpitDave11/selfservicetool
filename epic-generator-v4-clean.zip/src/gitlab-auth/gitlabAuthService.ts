/**
 * GitLab OAuth 2.0 Service
 *
 * Core OAuth logic including PKCE, token exchange, refresh, and revocation.
 */

import type {
  GitLabOAuthConfig,
  GitLabOAuthTokens,
  GitLabUserInfo,
  PKCEChallenge,
  OAuthState,
  OAuthErrorResponse,
} from './gitlabAuthTypes';
import {
  getOAuthEndpoints,
  TOKEN_REFRESH_BUFFER_MS,
  OAUTH_STATE_TIMEOUT_MS,
  logDebug,
  logError,
  logInfo,
} from './gitlabAuthConfig';

// ===========================================
// Error Type Validation
// ===========================================

/**
 * Type guard to check if response is an OAuth error
 */
function isOAuthErrorResponse(data: unknown): data is OAuthErrorResponse {
  return (
    typeof data === 'object' &&
    data !== null &&
    'error' in data &&
    typeof (data as OAuthErrorResponse).error === 'string'
  );
}

/**
 * Safely parse error response
 */
async function parseErrorResponse(response: Response): Promise<string> {
  try {
    const data = await response.json();
    if (isOAuthErrorResponse(data)) {
      return data.error_description || data.error;
    }
    return `HTTP ${response.status}: ${response.statusText}`;
  } catch {
    return `HTTP ${response.status}: ${response.statusText}`;
  }
}

/**
 * Validate token response structure
 * Ensures required fields are present before using tokens
 */
function validateTokenResponse(data: unknown): GitLabOAuthTokens {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid token response: not an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.access_token !== 'string' || !obj.access_token) {
    throw new Error('Invalid token response: missing access_token');
  }

  if (typeof obj.expires_in !== 'number') {
    throw new Error('Invalid token response: missing expires_in');
  }

  // refresh_token is optional in some flows but we require it
  if (typeof obj.refresh_token !== 'string') {
    logDebug('Warning: Token response missing refresh_token');
  }

  // token_type should be Bearer (case insensitive)
  const tokenType = typeof obj.token_type === 'string' ? obj.token_type.toLowerCase() : 'bearer';
  if (tokenType !== 'bearer') {
    logDebug('Warning: Unexpected token_type:', obj.token_type);
  }

  // Return normalized token object
  return {
    access_token: obj.access_token as string,
    token_type: 'Bearer', // Normalize to capitalized
    expires_in: obj.expires_in as number,
    refresh_token: (obj.refresh_token as string) || '',
    created_at: typeof obj.created_at === 'number' ? obj.created_at : Math.floor(Date.now() / 1000),
    scope: typeof obj.scope === 'string' ? obj.scope : '',
    id_token: typeof obj.id_token === 'string' ? obj.id_token : undefined,
  };
}

// ===========================================
// Retry Logic
// ===========================================

/**
 * Fetch with exponential backoff retry for transient failures
 */
async function fetchWithRetry(
  url: string,
  options: RequestInit,
  maxRetries: number = 3
): Promise<Response> {
  let lastError: Error | null = null;

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      const response = await fetch(url, options);

      // Don't retry on client errors (4xx) or success
      if (response.ok || (response.status >= 400 && response.status < 500)) {
        return response;
      }

      // Server error (5xx) - retry
      lastError = new Error(`Server error: ${response.status}`);
    } catch (error) {
      // Network error - retry
      lastError = error instanceof Error ? error : new Error('Network error');
    }

    // Wait before retry (exponential backoff: 1s, 2s, 4s)
    if (attempt < maxRetries - 1) {
      const delay = Math.pow(2, attempt) * 1000;
      logDebug(`Retry attempt ${attempt + 1} in ${delay}ms...`);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }

  throw lastError || new Error('Request failed after retries');
}

// ===========================================
// PKCE Utilities
// ===========================================

/**
 * Generate a cryptographically random string for code_verifier
 * Length: 64 characters (within 43-128 range)
 * Characters: [A-Z][a-z][0-9]-._~
 */
export function generateCodeVerifier(): string {
  const array = new Uint8Array(48);
  crypto.getRandomValues(array);
  return base64urlEncode(array);
}

/**
 * Generate code_challenge from code_verifier using SHA-256
 */
export async function generateCodeChallenge(verifier: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(verifier);
  const digest = await crypto.subtle.digest('SHA-256', data);
  return base64urlEncode(new Uint8Array(digest));
}

/**
 * Base64url encoding (RFC 4648 Section 5)
 * Standard base64 with URL-safe characters and no padding
 */
function base64urlEncode(buffer: Uint8Array): string {
  const base64 = btoa(String.fromCharCode(...buffer));
  return base64
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
}

/**
 * Generate complete PKCE challenge
 */
export async function generatePKCEChallenge(): Promise<PKCEChallenge> {
  const codeVerifier = generateCodeVerifier();
  const codeChallenge = await generateCodeChallenge(codeVerifier);

  logDebug('Generated PKCE challenge');

  return {
    codeVerifier,
    codeChallenge,
    codeChallengeMethod: 'S256',
  };
}

// ===========================================
// State Parameter (CSRF Protection)
// ===========================================

/**
 * Generate random state string for CSRF protection
 */
export function generateState(): string {
  const array = new Uint8Array(32);
  crypto.getRandomValues(array);
  return base64urlEncode(array);
}

/**
 * Create OAuth state object with timestamp
 */
export function createOAuthState(returnTo?: string): OAuthState {
  return {
    state: generateState(),
    createdAt: Date.now(),
    returnTo,
  };
}

/**
 * Validate OAuth state (check not expired and matches)
 */
export function validateOAuthState(
  receivedState: string,
  storedState: OAuthState | null
): boolean {
  if (!storedState) {
    logError('No stored OAuth state found');
    return false;
  }

  // Check state matches
  if (receivedState !== storedState.state) {
    logError('OAuth state mismatch (possible CSRF attack)');
    return false;
  }

  // Check not expired
  const elapsed = Date.now() - storedState.createdAt;
  if (elapsed > OAUTH_STATE_TIMEOUT_MS) {
    logError('OAuth state expired');
    return false;
  }

  return true;
}

// ===========================================
// Authorization URL
// ===========================================

/**
 * Build complete OAuth authorization URL with PKCE
 */
export function buildAuthorizationUrl(
  config: GitLabOAuthConfig,
  pkce: PKCEChallenge,
  state: string
): string {
  const endpoints = getOAuthEndpoints(config.baseUrl);

  const params = new URLSearchParams({
    client_id: config.clientId,
    redirect_uri: config.redirectUri,
    response_type: 'code',
    scope: config.scopes.join(' '),
    state: state,
    code_challenge: pkce.codeChallenge,
    code_challenge_method: pkce.codeChallengeMethod,
  });

  const url = `${endpoints.authorize}?${params.toString()}`;
  logDebug('Built authorization URL:', url);

  return url;
}

// ===========================================
// Token Exchange
// ===========================================

/**
 * Exchange authorization code for tokens
 * This is the critical step after user authorizes the app
 * Uses retry logic for transient failures
 */
export async function exchangeCodeForTokens(
  config: GitLabOAuthConfig,
  code: string,
  codeVerifier: string
): Promise<GitLabOAuthTokens> {
  const endpoints = getOAuthEndpoints(config.baseUrl);

  logInfo('Exchanging authorization code for tokens...');

  const response = await fetchWithRetry(endpoints.token, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Accept': 'application/json',
    },
    body: new URLSearchParams({
      client_id: config.clientId,
      code: code,
      grant_type: 'authorization_code',
      redirect_uri: config.redirectUri,
      code_verifier: codeVerifier,
    }),
  });

  if (!response.ok) {
    const errorMessage = await parseErrorResponse(response);
    logError('Token exchange failed:', errorMessage);
    throw new Error(errorMessage);
  }

  const responseData = await response.json();

  // Validate and normalize the token response
  const tokens = validateTokenResponse(responseData);

  logInfo('Token exchange successful');
  logDebug('Token expires in:', tokens.expires_in, 'seconds');

  return tokens;
}

// ===========================================
// Token Refresh
// ===========================================

/**
 * Refresh access token using refresh_token
 * Should be called before current token expires
 * Uses retry logic for transient failures
 */
export async function refreshAccessToken(
  config: GitLabOAuthConfig,
  refreshToken: string
): Promise<GitLabOAuthTokens> {
  const endpoints = getOAuthEndpoints(config.baseUrl);

  logInfo('Refreshing access token...');

  const response = await fetchWithRetry(endpoints.token, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Accept': 'application/json',
    },
    body: new URLSearchParams({
      client_id: config.clientId,
      refresh_token: refreshToken,
      grant_type: 'refresh_token',
    }),
  });

  if (!response.ok) {
    const errorMessage = await parseErrorResponse(response);
    logError('Token refresh failed:', errorMessage);
    throw new Error(`Token refresh failed: ${errorMessage}`);
  }

  const responseData = await response.json();

  // Validate and normalize the token response
  const tokens = validateTokenResponse(responseData);

  logInfo('Token refresh successful');

  return tokens;
}

/**
 * Check if token needs refresh (within buffer time of expiration)
 */
export function shouldRefreshToken(tokens: GitLabOAuthTokens): boolean {
  const expiresAt = (tokens.created_at + tokens.expires_in) * 1000; // Convert to ms
  const bufferTime = Date.now() + TOKEN_REFRESH_BUFFER_MS;
  return bufferTime >= expiresAt;
}

/**
 * Check if token is completely expired
 */
export function isTokenExpired(tokens: GitLabOAuthTokens): boolean {
  const expiresAt = (tokens.created_at + tokens.expires_in) * 1000;
  return Date.now() >= expiresAt;
}

/**
 * Get time until token refresh is needed (in ms)
 */
export function getTimeUntilRefresh(tokens: GitLabOAuthTokens): number {
  const expiresAt = (tokens.created_at + tokens.expires_in) * 1000;
  const refreshAt = expiresAt - TOKEN_REFRESH_BUFFER_MS;
  return Math.max(0, refreshAt - Date.now());
}

// ===========================================
// User Info
// ===========================================

/**
 * Fetch user info from OIDC userinfo endpoint
 */
export async function fetchUserInfo(
  config: GitLabOAuthConfig,
  accessToken: string
): Promise<GitLabUserInfo> {
  const endpoints = getOAuthEndpoints(config.baseUrl);

  logDebug('Fetching user info...');

  const response = await fetch(endpoints.userInfo, {
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Accept': 'application/json',
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    logError('User info fetch failed:', errorText);
    throw new Error('Failed to fetch user info');
  }

  const userInfo = await response.json() as GitLabUserInfo;
  logInfo('User info fetched:', userInfo.name);

  return userInfo;
}

// ===========================================
// Token Revocation
// ===========================================

/**
 * Revoke OAuth token (for logout)
 */
export async function revokeToken(
  config: GitLabOAuthConfig,
  token: string,
  tokenTypeHint: 'access_token' | 'refresh_token' = 'access_token'
): Promise<boolean> {
  const endpoints = getOAuthEndpoints(config.baseUrl);

  logInfo('Revoking token...');

  try {
    const response = await fetch(endpoints.revoke, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        client_id: config.clientId,
        token: token,
        token_type_hint: tokenTypeHint,
      }),
    });

    // Revocation endpoint returns 200 even if token was already invalid
    if (response.ok) {
      logInfo('Token revoked successfully');
      return true;
    }

    logError('Token revocation returned non-OK status:', response.status);
    return false;
  } catch (error) {
    logError('Token revocation failed:', error);
    return false;
  }
}

// ===========================================
// OAuth Callback Parsing
// ===========================================

/**
 * Parse OAuth callback URL for code, state, and error details
 */
export function parseOAuthCallback(url: string): {
  code: string | null;
  state: string | null;
  error: string | null;
  errorDescription: string | null;
} {
  const urlObj = new URL(url);
  const params = urlObj.searchParams;

  return {
    code: params.get('code'),
    state: params.get('state'),
    error: params.get('error'),
    errorDescription: params.get('error_description'),
  };
}

/**
 * Check if current URL is an OAuth callback
 */
export function isOAuthCallback(): boolean {
  if (typeof window === 'undefined') return false;

  const params = new URLSearchParams(window.location.search);
  return params.has('code') && params.has('state');
}

/**
 * Clean OAuth callback params from URL (after processing)
 */
export function cleanOAuthCallbackUrl(): void {
  if (typeof window === 'undefined') return;

  const url = new URL(window.location.href);
  url.searchParams.delete('code');
  url.searchParams.delete('state');
  url.searchParams.delete('error');
  url.searchParams.delete('error_description');

  // Replace URL without reload
  window.history.replaceState({}, document.title, url.pathname + url.search);

  logDebug('Cleaned OAuth callback params from URL');
}
