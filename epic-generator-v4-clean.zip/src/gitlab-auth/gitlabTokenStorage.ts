/**
 * GitLab OAuth Token Storage
 *
 * Secure storage utilities for OAuth tokens using sessionStorage.
 * sessionStorage is preferred over localStorage for security:
 * - Cleared when browser/tab is closed
 * - Not shared across tabs (isolation)
 * - Not sent to server with requests
 */

import type {
  GitLabOAuthTokens,
  GitLabUserInfo,
  OAuthState,
} from './gitlabAuthTypes';
import { STORAGE_KEYS, logDebug, logError } from './gitlabAuthConfig';

// ===========================================
// Token Storage
// ===========================================

/**
 * Store OAuth tokens in sessionStorage
 */
export function storeTokens(tokens: GitLabOAuthTokens): void {
  try {
    sessionStorage.setItem(STORAGE_KEYS.TOKENS, JSON.stringify(tokens));
    logDebug('Tokens stored successfully');
  } catch (error) {
    logError('Failed to store tokens:', error);
    throw new Error('Failed to store OAuth tokens');
  }
}

/**
 * Retrieve OAuth tokens from sessionStorage
 */
export function retrieveTokens(): GitLabOAuthTokens | null {
  try {
    const stored = sessionStorage.getItem(STORAGE_KEYS.TOKENS);
    if (!stored) {
      return null;
    }
    return JSON.parse(stored) as GitLabOAuthTokens;
  } catch (error) {
    logError('Failed to retrieve tokens:', error);
    return null;
  }
}

/**
 * Clear OAuth tokens from sessionStorage
 */
export function clearTokens(): void {
  try {
    sessionStorage.removeItem(STORAGE_KEYS.TOKENS);
    logDebug('Tokens cleared');
  } catch (error) {
    logError('Failed to clear tokens:', error);
  }
}

// ===========================================
// PKCE Verifier Storage (Temporary)
// ===========================================

/**
 * Store PKCE code_verifier temporarily during auth flow
 * This is needed between redirect to GitLab and callback
 */
export function storePKCEVerifier(verifier: string): void {
  try {
    sessionStorage.setItem(STORAGE_KEYS.PKCE_VERIFIER, verifier);
    logDebug('PKCE verifier stored');
  } catch (error) {
    logError('Failed to store PKCE verifier:', error);
    throw new Error('Failed to store PKCE verifier');
  }
}

/**
 * Retrieve and clear PKCE code_verifier
 * Clears after retrieval for security (one-time use)
 */
export function retrieveAndClearPKCEVerifier(): string | null {
  try {
    const verifier = sessionStorage.getItem(STORAGE_KEYS.PKCE_VERIFIER);
    if (verifier) {
      sessionStorage.removeItem(STORAGE_KEYS.PKCE_VERIFIER);
      logDebug('PKCE verifier retrieved and cleared');
    }
    return verifier;
  } catch (error) {
    logError('Failed to retrieve PKCE verifier:', error);
    return null;
  }
}

// ===========================================
// OAuth State Storage (CSRF Protection)
// ===========================================

/**
 * Store OAuth state for CSRF validation
 */
export function storeOAuthState(state: OAuthState): void {
  try {
    sessionStorage.setItem(STORAGE_KEYS.OAUTH_STATE, JSON.stringify(state));
    logDebug('OAuth state stored');
  } catch (error) {
    logError('Failed to store OAuth state:', error);
    throw new Error('Failed to store OAuth state');
  }
}

/**
 * Retrieve and clear OAuth state
 * Clears after retrieval for security (one-time use)
 */
export function retrieveAndClearOAuthState(): OAuthState | null {
  try {
    const stored = sessionStorage.getItem(STORAGE_KEYS.OAUTH_STATE);
    if (stored) {
      sessionStorage.removeItem(STORAGE_KEYS.OAUTH_STATE);
      logDebug('OAuth state retrieved and cleared');
      return JSON.parse(stored) as OAuthState;
    }
    return null;
  } catch (error) {
    logError('Failed to retrieve OAuth state:', error);
    return null;
  }
}

// ===========================================
// User Info Storage (Cache)
// ===========================================

/**
 * Store user info (for quick access without API call)
 */
export function storeUserInfo(user: GitLabUserInfo): void {
  try {
    sessionStorage.setItem(STORAGE_KEYS.USER_INFO, JSON.stringify(user));
    logDebug('User info stored');
  } catch (error) {
    logError('Failed to store user info:', error);
  }
}

/**
 * Retrieve cached user info
 */
export function retrieveUserInfo(): GitLabUserInfo | null {
  try {
    const stored = sessionStorage.getItem(STORAGE_KEYS.USER_INFO);
    if (!stored) {
      return null;
    }
    return JSON.parse(stored) as GitLabUserInfo;
  } catch (error) {
    logError('Failed to retrieve user info:', error);
    return null;
  }
}

/**
 * Clear user info
 */
export function clearUserInfo(): void {
  try {
    sessionStorage.removeItem(STORAGE_KEYS.USER_INFO);
    logDebug('User info cleared');
  } catch (error) {
    logError('Failed to clear user info:', error);
  }
}

// ===========================================
// Auth Mode Preference (localStorage for persistence)
// ===========================================

/**
 * Store auth mode preference (pat or oauth)
 * Uses localStorage so preference persists across sessions
 */
export function storeAuthMode(mode: 'pat' | 'oauth'): void {
  try {
    localStorage.setItem(STORAGE_KEYS.AUTH_MODE, mode);
    logDebug('Auth mode stored:', mode);
  } catch (error) {
    logError('Failed to store auth mode:', error);
  }
}

/**
 * Retrieve auth mode preference
 * Defaults to 'pat' for backwards compatibility
 */
export function retrieveAuthMode(): 'pat' | 'oauth' {
  try {
    const stored = localStorage.getItem(STORAGE_KEYS.AUTH_MODE);
    if (stored === 'oauth') {
      return 'oauth';
    }
    return 'pat'; // Default
  } catch (error) {
    logError('Failed to retrieve auth mode:', error);
    return 'pat';
  }
}

// ===========================================
// Clear All GitLab Auth Data
// ===========================================

/**
 * Clear all GitLab OAuth data (for logout or reset)
 */
export function clearAllGitLabAuthData(): void {
  try {
    clearTokens();
    clearUserInfo();
    sessionStorage.removeItem(STORAGE_KEYS.PKCE_VERIFIER);
    sessionStorage.removeItem(STORAGE_KEYS.OAUTH_STATE);
    logDebug('All GitLab auth data cleared');
  } catch (error) {
    logError('Failed to clear all auth data:', error);
  }
}

// ===========================================
// Utility: Check if authenticated
// ===========================================

/**
 * Quick check if user has stored tokens (may be expired)
 */
export function hasStoredTokens(): boolean {
  return sessionStorage.getItem(STORAGE_KEYS.TOKENS) !== null;
}
