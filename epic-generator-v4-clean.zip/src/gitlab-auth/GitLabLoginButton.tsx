/**
 * GitLab Login Button Component
 *
 * Renders a "Sign in with GitLab" button that initiates the OAuth flow.
 * Styled to match the application's UBS brand colors.
 */

import React from 'react';
import { useGitLabAuth } from './GitLabAuthProvider';

// ===========================================
// UBS Brand Colors
// ===========================================

const UBS_COLORS = {
  red: '#E60000',
  black: '#000000',
  white: '#FFFFFF',
  grayV: '#5A5D5C',
};

// ===========================================
// GitLab Logo SVG
// ===========================================

const GitLabLogo: React.FC<{ size?: number }> = ({ size = 20 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 380 380"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M190.007 350.963L256.161 147.389H123.854L190.007 350.963Z"
      fill="#E24329"
    />
    <path
      d="M190.007 350.963L123.854 147.389H31.0505L190.007 350.963Z"
      fill="#FC6D26"
    />
    <path
      d="M31.0505 147.389L14.0649 199.619C12.4995 204.403 14.1766 209.664 18.2607 212.628L190.007 350.963L31.0505 147.389Z"
      fill="#FCA326"
    />
    <path
      d="M31.0505 147.389H123.854L84.9141 27.8762C83.1592 22.5133 75.6192 22.5133 73.8643 27.8762L31.0505 147.389Z"
      fill="#E24329"
    />
    <path
      d="M190.007 350.963L256.161 147.389H348.963L190.007 350.963Z"
      fill="#FC6D26"
    />
    <path
      d="M348.963 147.389L365.949 199.619C367.514 204.403 365.837 209.664 361.753 212.628L190.007 350.963L348.963 147.389Z"
      fill="#FCA326"
    />
    <path
      d="M348.963 147.389H256.161L295.1 27.8762C296.855 22.5133 304.395 22.5133 306.15 27.8762L348.963 147.389Z"
      fill="#E24329"
    />
  </svg>
);

// ===========================================
// Props
// ===========================================

interface GitLabLoginButtonProps {
  /** Button label override */
  label?: string;
  /** Full width button */
  fullWidth?: boolean;
  /** Size variant */
  size?: 'small' | 'medium' | 'large';
  /** Custom className */
  className?: string;
  /** Custom styles */
  style?: React.CSSProperties;
}

// ===========================================
// Component
// ===========================================

export const GitLabLoginButton: React.FC<GitLabLoginButtonProps> = ({
  label = 'Sign in with GitLab',
  fullWidth = false,
  size = 'medium',
  className,
  style,
}) => {
  const { login, isLoading, isAuthenticated, error } = useGitLabAuth();

  // Don't render if already authenticated
  if (isAuthenticated) {
    return null;
  }

  // Size configurations
  const sizeConfig = {
    small: { padding: '8px 16px', fontSize: '13px', iconSize: 16 },
    medium: { padding: '12px 24px', fontSize: '14px', iconSize: 20 },
    large: { padding: '14px 28px', fontSize: '15px', iconSize: 24 },
  };

  const { padding, fontSize, iconSize } = sizeConfig[size];

  const handleClick = async () => {
    if (isLoading) return;
    await login();
  };

  return (
    <div style={{ width: fullWidth ? '100%' : 'auto' }}>
      <button
        onClick={handleClick}
        disabled={isLoading}
        className={className}
        style={{
          display: 'inline-flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '10px',
          padding,
          fontSize,
          fontWeight: 500,
          fontFamily: 'Frutiger, "Helvetica Neue", Arial, sans-serif',
          background: UBS_COLORS.red,
          color: UBS_COLORS.white,
          border: 'none',
          borderRadius: '8px',
          cursor: isLoading ? 'wait' : 'pointer',
          transition: 'all 0.2s ease',
          opacity: isLoading ? 0.7 : 1,
          width: fullWidth ? '100%' : 'auto',
          ...style,
        }}
        onMouseEnter={(e) => {
          if (!isLoading) {
            e.currentTarget.style.background = '#BD000C';
            e.currentTarget.style.transform = 'translateY(-1px)';
          }
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.background = UBS_COLORS.red;
          e.currentTarget.style.transform = 'translateY(0)';
        }}
      >
        {isLoading ? (
          <>
            <div
              style={{
                width: iconSize,
                height: iconSize,
                border: `2px solid ${UBS_COLORS.white}`,
                borderTop: '2px solid transparent',
                borderRadius: '50%',
                animation: 'gitlab-spin 1s linear infinite',
              }}
            />
            <span>Signing in...</span>
          </>
        ) : (
          <>
            <GitLabLogo size={iconSize} />
            <span>{label}</span>
          </>
        )}
      </button>

      {error && (
        <div
          style={{
            marginTop: '8px',
            padding: '8px 12px',
            background: '#FEF2F2',
            border: '1px solid #FECACA',
            borderRadius: '6px',
            fontSize: '12px',
            color: '#991B1B',
          }}
        >
          {error.message}
        </div>
      )}

      <style>{`
        @keyframes gitlab-spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
};
