/**
 * GitLab OAuth 2.0 Configuration
 *
 * Handles feature flags, environment variables, and OAuth endpoints.
 */

import type { GitLabOAuthConfig, GitLabOAuthEndpoints } from './gitlabAuthTypes';

// ===========================================
// Feature Flags
// ===========================================

/**
 * Whether GitLab OAuth is enabled (vs PAT)
 * Set via VITE_GITLAB_OAUTH_ENABLED environment variable
 */
export const GITLAB_OAUTH_ENABLED: boolean =
  import.meta.env.VITE_GITLAB_OAUTH_ENABLED === 'true';

/**
 * Whether to use mock GitLab OAuth (for local testing)
 * Set via VITE_GITLAB_OAUTH_MOCK environment variable
 */
export const GITLAB_OAUTH_MOCK: boolean =
  import.meta.env.VITE_GITLAB_OAUTH_MOCK === 'true';

// ===========================================
// Default Configuration
// ===========================================

/**
 * Default GitLab instance URL
 * Can be overridden in Settings
 */
const DEFAULT_GITLAB_URL = import.meta.env.VITE_GITLAB_URL || 'https://devcloud.ubs.net';

/**
 * Default OAuth Client ID
 * Must be set via environment variable or Settings
 */
const DEFAULT_CLIENT_ID = import.meta.env.VITE_GITLAB_OAUTH_CLIENT_ID || '';

/**
 * Default OAuth scopes
 * - openid: Enable OIDC (user identity)
 * - profile: User's name, username, avatar
 * - email: User's email address
 * - api: Full API access (required for epic/issue operations)
 */
const DEFAULT_SCOPES = ['openid', 'profile', 'email', 'api'];

/**
 * Default Group ID for API operations
 */
const DEFAULT_GROUP_ID = import.meta.env.VITE_GITLAB_GROUP_ID || '';

// ===========================================
// Configuration Builder
// ===========================================

/**
 * Build OAuth redirect URI based on current origin
 */
export function getRedirectUri(): string {
  if (typeof window === 'undefined') {
    return 'http://localhost:3002/';
  }
  // Use origin without trailing path to handle callback at root
  return `${window.location.origin}/`;
}

/**
 * Get the base URL for OAuth API calls
 * In development, uses Vite proxy to avoid CORS issues
 * In production, uses the configured GitLab URL directly
 */
export function getOAuthApiBaseUrl(baseUrl: string): string {
  const cleanUrl = baseUrl.replace(/\/$/, '');

  // In development, use Vite proxy for token/userinfo/revoke endpoints
  // (authorize endpoint must go directly to GitLab for redirect)
  if (import.meta.env.DEV) {
    return '/gitlab-api';  // Proxied by Vite to GitLab instance
  }

  // In production, use the configured base URL directly
  return cleanUrl;
}

/**
 * Build OAuth endpoints from GitLab base URL
 * Note: authorize endpoint always goes directly to GitLab (for user redirect)
 * Token, userinfo, revoke endpoints use proxy in development
 */
export function getOAuthEndpoints(baseUrl: string): GitLabOAuthEndpoints {
  const cleanUrl = baseUrl.replace(/\/$/, ''); // Remove trailing slash
  const apiBaseUrl = getOAuthApiBaseUrl(baseUrl);

  return {
    // Authorization URL - always direct to GitLab (user redirect)
    authorize: `${cleanUrl}/oauth/authorize`,
    // These endpoints use proxy in dev for CORS
    token: `${apiBaseUrl}/oauth/token`,
    userInfo: `${apiBaseUrl}/oauth/userinfo`,
    revoke: `${apiBaseUrl}/oauth/revoke`,
    discovery: `${apiBaseUrl}/.well-known/openid-configuration`,
  };
}

/**
 * Get default OAuth configuration
 */
export function getDefaultOAuthConfig(): GitLabOAuthConfig {
  return {
    enabled: GITLAB_OAUTH_ENABLED,
    baseUrl: DEFAULT_GITLAB_URL,
    clientId: DEFAULT_CLIENT_ID,
    redirectUri: getRedirectUri(),
    scopes: DEFAULT_SCOPES,
    groupId: DEFAULT_GROUP_ID,
  };
}

/**
 * Check if OAuth is properly configured
 */
export function isOAuthConfigured(config: GitLabOAuthConfig): boolean {
  return !!(
    config.enabled &&
    config.clientId &&
    config.baseUrl &&
    config.redirectUri
  );
}

/**
 * Check if we should use OAuth (enabled and configured)
 */
export function shouldUseGitLabOAuth(): boolean {
  if (GITLAB_OAUTH_MOCK) {
    return true;
  }
  const config = getDefaultOAuthConfig();
  return isOAuthConfigured(config);
}

// ===========================================
// Storage Keys
// ===========================================

export const STORAGE_KEYS = {
  /** OAuth tokens storage key */
  TOKENS: 'gitlab_oauth_tokens',
  /** PKCE code verifier (temporary) */
  PKCE_VERIFIER: 'gitlab_oauth_pkce_verifier',
  /** OAuth state (for CSRF) */
  OAUTH_STATE: 'gitlab_oauth_state',
  /** User info cache */
  USER_INFO: 'gitlab_oauth_user',
  /** Auth mode preference */
  AUTH_MODE: 'gitlab_auth_mode',
} as const;

// ===========================================
// Token Timing
// ===========================================

/**
 * Buffer time before token expiration to trigger refresh (5 minutes)
 */
export const TOKEN_REFRESH_BUFFER_MS = 5 * 60 * 1000;

/**
 * OAuth state validity period (10 minutes)
 */
export const OAUTH_STATE_TIMEOUT_MS = 10 * 60 * 1000;

// ===========================================
// Logging
// ===========================================

const LOG_PREFIX = '[GitLabOAuth]';

export function logDebug(message: string, ...args: unknown[]): void {
  if (import.meta.env.DEV) {
    console.log(`${LOG_PREFIX} ${message}`, ...args);
  }
}

export function logError(message: string, ...args: unknown[]): void {
  console.error(`${LOG_PREFIX} ${message}`, ...args);
}

export function logInfo(message: string, ...args: unknown[]): void {
  console.log(`${LOG_PREFIX} ${message}`, ...args);
}
