import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig(({ mode }) => {
  // Load env variables based on mode
  const env = loadEnv(mode, process.cwd(), '')

  // GitLab URL - configurable via environment variable
  // Default: https://devcloud.ubs.net (for local development)
  const GITLAB_URL = env.VITE_GITLAB_URL || process.env.GITLAB_URL || 'https://devcloud.ubs.net'

  console.log('[Vite Config] GitLab proxy target:', GITLAB_URL)

  return {
    plugins: [react()],
    server: {
      port: 3002,
      host: true, // Allow external connections (needed for Docker)
      proxy: {
        // Proxy GitLab OAuth requests (for token, userinfo, revoke endpoints)
        // These go to /oauth/* without rewriting
        '/gitlab-api/oauth': {
          target: GITLAB_URL,
          changeOrigin: true,
          rewrite: (path) => path.replace(/^\/gitlab-api/, ''),
          secure: false,  // Allow self-signed certificates
          configure: (proxy, options) => {
            proxy.on('error', (err, req, res) => {
              console.log('[OAuth Proxy Error]', err.message);
            });
            proxy.on('proxyReq', (proxyReq, req, res) => {
              console.log('[OAuth Proxy Request]', req.method, req.url, '→', options.target + req.url.replace('/gitlab-api', ''));
            });
            proxy.on('proxyRes', (proxyRes, req, res) => {
              console.log('[OAuth Proxy Response]', proxyRes.statusCode, req.url);
            });
          }
        },
        // Proxy GitLab OIDC discovery endpoint
        '/gitlab-api/.well-known': {
          target: GITLAB_URL,
          changeOrigin: true,
          rewrite: (path) => path.replace(/^\/gitlab-api/, ''),
          secure: false,
        },
        // Proxy GitLab API requests to bypass CORS
        // All requests to /gitlab-api/* are forwarded to GitLab's /api/v4/*
        '/gitlab-api': {
          target: GITLAB_URL,
          changeOrigin: true,
          rewrite: (path) => path.replace(/^\/gitlab-api/, '/api/v4'),
          secure: false,  // Allow self-signed certificates
          // Logging for debugging proxy issues
          configure: (proxy, options) => {
            proxy.on('error', (err, req, res) => {
              console.log('[Proxy Error]', err.message);
            });
            proxy.on('proxyReq', (proxyReq, req, res) => {
              console.log('[Proxy Request]', req.method, req.url, '→', options.target + req.url.replace('/gitlab-api', '/api/v4'));
            });
            proxy.on('proxyRes', (proxyRes, req, res) => {
              console.log('[Proxy Response]', proxyRes.statusCode, req.url);
            });
          }
        }
      }
    }
  }
})
