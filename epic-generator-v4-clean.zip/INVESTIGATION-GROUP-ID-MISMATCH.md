# Epic Group ID Mismatch - Root Cause Analysis

**Date:** 2026-02-11
**Issue:** Epic update not working - updates go to wrong epic because of duplicate `iid` in different groups

---

## Executive Summary

The root cause has been **confirmed and reproduced**: When two epics exist with the **same `iid` in different groups**, the app's `find()` logic returns the **first match**, which may be from the wrong group. This causes updates to be sent to the wrong epic.

---

## The Exact Scenario

Two epics share the same `iid` (229):

| Property | Group 478446 (Subgroup) | Group 557797 (Parent) |
|----------|-------------------------|----------------------|
| **Epic ID** | 841693 | 520625 |
| **iid** | 229 | 229 |
| **Description** | `null` (empty) | Full content |
| **State** | `opened` | `closed` |
| **_links.self** | `/groups/478446/epics/229` | `/groups/557797/epics/229` |

---

## Root Cause Analysis

### Bug Location: `src/App.tsx`, Line 2171

```typescript
// BUGGY CODE:
const epicFromList = gitlabEpics.find(e => e.iid === epicIid) ||
                     loadEpicResults.find(e => e.iid === epicIid);
const epicGroupId = epicFromList?.group_id ? String(epicFromList.group_id) : config.gitlab.rootGroupId;
```

### Why This Fails:

1. **`iid` is NOT globally unique** - it's only unique within a group
2. When epics are loaded from multiple groups (including descendant groups), the list may contain **duplicate iids**
3. `Array.find()` returns the **first match**, which may be from the wrong group
4. The wrong `group_id` is used for all subsequent API calls

### The Failing Flow:

```
1. User searches/loads epics (includes descendant groups)
   → loadEpicResults = [
       { iid: 229, group_id: 478446, ... },  // index 0 (wrong - empty)
       { iid: 229, group_id: 557797, ... },  // index 1 (correct - has content)
     ]

2. User clicks on epic with iid 229
   → find(e => e.iid === 229) returns index 0 (WRONG!)
   → epicGroupId = "478446" (WRONG!)

3. fetchEpicDetails called with wrong group
   → GET /api/v4/groups/478446/epics/229
   → Returns the EMPTY epic (id: 841693)

4. User refines and clicks Update
   → PUT /api/v4/groups/478446/epics/229
   → Updates the EMPTY epic, NOT the one with content!

5. User reloads expecting to see changes
   → Sees original content (from group 557797)
   → "Nothing changed!"
```

---

## Evidence from Tests

```
TEST 1: Demonstrating the Bug
============================================================
Epics in loadEpicResults:
  [0] iid=229, group_id=478446, id=841693, title="Empty Epic..."
  [1] iid=229, group_id=557797, id=520625, title="Epic with Full Content..."

Result of find(e => e.iid === 229):
  Found: id=841693, group_id=478446

❌ BUG CONFIRMED: find() returned the WRONG epic!
   Expected: group_id=557797 (epic with content)
   Got:      group_id=478446 (empty epic)
```

---

## Additional Issue: Closed Epic State

The epic with actual content (id: 520625) is **closed**:

```
State: closed
```

GitLab may reject or silently ignore updates to closed epics. Even if we fix the group_id issue, we may need to **reopen the epic first** before updating.

---

## Proposed Fix

### Fix 1: Add `_links` to GitLabEpic Interface

**File:** `src/config.ts`

```typescript
export interface GitLabEpic {
  id: number;
  iid: number;
  group_id: number;
  title: string;
  description: string;
  state: 'opened' | 'closed';
  // ... existing fields ...

  // ADD: Links from GitLab API response
  _links?: {
    self: string;      // e.g., "https://gitlab.com/api/v4/groups/557797/epics/229"
    group: string;     // e.g., "https://gitlab.com/api/v4/groups/557797"
    epic_issues: string;
  };
}
```

### Fix 2: Add Helper Function to Extract Canonical Group ID

**File:** `src/config.ts`

```typescript
/**
 * Extract the canonical group_id from an epic's _links.self URL.
 * This is the AUTHORITATIVE source for which group the epic belongs to.
 *
 * @param epic - The GitLab epic object
 * @returns The canonical group_id as a string
 */
export function getCanonicalGroupId(epic: GitLabEpic): string {
  if (epic._links?.self) {
    // URL format: https://gitlab.com/api/v4/groups/{group_id}/epics/{iid}
    const match = epic._links.self.match(/\/groups\/(\d+)\/epics\//);
    if (match) {
      return match[1];
    }
  }
  // Fallback to group_id field
  return String(epic.group_id);
}
```

### Fix 3: Use Canonical Group ID in handleUpdateGitLabEpic

**File:** `src/App.tsx`

```typescript
const handleUpdateGitLabEpic = async () => {
  if (!selectedGitLabEpic) {
    showToast('error', 'No Epic Selected', 'Load an epic first');
    return;
  }

  // Use canonical group_id from _links.self (not from find())
  const epicGroupId = getCanonicalGroupId(selectedGitLabEpic);

  console.log('[DEBUG] Using canonical group_id:', epicGroupId);
  console.log('[DEBUG] Epic _links.self:', selectedGitLabEpic._links?.self);

  // ... rest of update logic
};
```

### Fix 4: Handle Closed Epic State (Optional)

```typescript
// Before updating, check if epic is closed
if (selectedGitLabEpic.state === 'closed') {
  // Option A: Warn user
  showToast('warning', 'Epic is Closed', 'Reopening epic before update...');

  // Option B: Reopen automatically
  await updateGitLabEpic(config.gitlab, selectedGitLabEpic.iid,
    { state_event: 'reopen' }, epicGroupId);
}

// Then proceed with content update
const result = await updateGitLabEpic(config.gitlab, selectedGitLabEpic.iid,
  params, epicGroupId);
```

---

## Files to Modify

| File | Changes |
|------|---------|
| `src/config.ts` | Add `_links` to `GitLabEpic` interface; Add `getCanonicalGroupId()` helper |
| `src/App.tsx` | Use `getCanonicalGroupId()` in `handleUpdateGitLabEpic()` and `handleViewEpicDetails()` |
| `src/mockGitLabData.ts` | Add `_links` to mock epic data for testing |

---

## Verification Steps

After the fix:

1. Load an epic that has duplicates in different groups
2. Check browser console for:
   ```
   [DEBUG] Using canonical group_id: 557797
   [DEBUG] Epic _links.self: https://gitlab.com/api/v4/groups/557797/epics/229
   ```
3. Verify the PUT request goes to correct group:
   ```
   PUT /api/v4/groups/557797/epics/229 ✅
   ```
   NOT:
   ```
   PUT /api/v4/groups/478446/epics/229 ❌
   ```
4. Reload the epic and verify content was updated

---

## Test Files Created

| File | Purpose |
|------|---------|
| `src/test/epicGroupIdMismatch.test.ts` | Reproduces and verifies the bug |

Run: `npm run test:run -- epicGroupIdMismatch`

---

## Summary

| Issue | Status | Root Cause |
|-------|--------|------------|
| Wrong group_id used | **CONFIRMED** | `find(e => e.iid)` returns first match |
| Updates go to empty epic | **CONFIRMED** | Same iid in multiple groups |
| Closed epic may block updates | **IDENTIFIED** | Epic state is `closed` |

**The fix is clear:** Use `_links.self` as the authoritative source for `group_id` instead of relying on `find()` results.

---

## Sources

- [GitLab Epics API Documentation](https://docs.gitlab.com/ee/api/epics.html)
- [GitLab Linked Epics API](https://docs.gitlab.com/api/linked_epics/)
