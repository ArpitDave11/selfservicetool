# Implementation Plan: Apply Feedback to Entire Epic

## Overview
Add a new option in the chat interface where users can apply feedback globally to the entire epic, tuning all 17 sections according to the feedback while preserving the structure.

---

## Current Flow (Unchanged)
```
User sends feedback → AI detects section → Confirm → Update THAT section only
```

## New Flow (Extension)
```
User sends feedback → AI asks: "Update specific section OR entire epic?"
  ├── Specific Section → Current flow (select section → update)
  └── Entire Epic → New flow (apply to all 17 sections → progress shown)
```

---

## User Experience

### Step 1: User Sends Feedback
```
User: "Make everything more focused on security and compliance"
```

### Step 2: AI Asks for Scope
```
AI: "Would you like me to:
     1. Update a specific section with this feedback
     2. Apply this feedback to the entire epic (all sections)"
```

### Step 3a: User Chooses "Entire Epic"
```
AI: "Applying feedback to entire epic..."
    [Progress: Updating Section 1: Objective...]
    [Progress: Updating Section 2: Background...]
    ...
    [Progress: Complete! 17/17 sections updated]

AI: "Done! I've updated all sections to focus more on security and compliance.
     Key changes:
     - Added security considerations to Objective
     - Enhanced Background with compliance context
     - Strengthened NFRs with security requirements
     - Added compliance risks to Dependencies & Risks
     ..."
```

### Step 3b: User Chooses "Specific Section"
```
→ Continues with current flow (select section dropdown)
```

---

## Technical Implementation

### Phase 1: Update Types

**File: `src/types.ts`**

Update `ChatMessage` to support the new question type:
```typescript
export interface ChatMessage {
  // ... existing fields
  questionType?: 'section-select' | 'text-input' | 'confirm' | 'scope-select'; // NEW
  options?: string[];
  selectedValue?: string;
  isAnswered?: boolean;
}
```

### Phase 2: Add AI Function for Entire Epic

**File: `src/skills.ts`**

```typescript
/**
 * Apply feedback globally to entire epic
 * Processes all 17 sections while preserving structure
 */
export async function applyFeedbackToEntireEpic(
  feedback: string,
  currentEpic: string,
  onProgress?: (current: number, total: number, sectionTitle: string) => void
): Promise<{ updatedEpic: string; summary: string; changedSections: string[] }> {
  if (!currentConfig) {
    throw new Error('AI is not configured. Please check Settings.');
  }

  const changedSections: string[] = [];
  let updatedEpic = currentEpic;

  // Process each section
  for (let i = 0; i < EPIC_SECTIONS.length; i++) {
    const section = EPIC_SECTIONS[i];
    onProgress?.(i + 1, EPIC_SECTIONS.length, section.title);

    // Skip reference-only sections (like Architecture Diagrams)
    if (section.isReference) continue;

    try {
      const result = await applySectionFeedback(
        feedback,
        updatedEpic,
        section.num,
        section.title
      );

      if (result.wasChanged) {
        updatedEpic = replaceSectionContent(updatedEpic, section.num, result.updatedContent);
        changedSections.push(section.title);
      }
    } catch (error) {
      console.error(`Failed to update section ${section.num}:`, error);
      // Continue with other sections
    }
  }

  // Generate summary of changes
  const summary = await generateChangeSummary(feedback, changedSections);

  return { updatedEpic, summary, changedSections };
}

/**
 * Apply feedback to a single section, determining if changes are needed
 */
async function applySectionFeedback(
  feedback: string,
  currentEpic: string,
  sectionNum: number,
  sectionTitle: string
): Promise<{ updatedContent: string; wasChanged: boolean }> {
  const systemPrompt = `You are an expert technical writer modifying an epic document.
Apply this feedback to section ${sectionNum} "${sectionTitle}":

FEEDBACK: "${feedback}"

RULES:
1. If this feedback is relevant to this section, update it accordingly
2. If this feedback is NOT relevant to this section, return the original unchanged
3. Preserve the section header: "## ${sectionNum}. ${sectionTitle}"
4. Keep the same format and style
5. Make meaningful improvements, not superficial word changes

Return JSON:
{
  "wasChanged": boolean,
  "updatedContent": "## ${sectionNum}. ${sectionTitle}\\n\\n[content]",
  "changeReason": "Brief reason for change" or null
}`;

  const currentSection = extractSection(currentEpic, sectionNum);

  const userPrompt = `CURRENT SECTION:
${currentSection}

Apply the feedback and return JSON:`;

  const response = await callAI(currentConfig, systemPrompt, userPrompt);
  const parsed = JSON.parse(response);

  return {
    updatedContent: parsed.updatedContent,
    wasChanged: parsed.wasChanged
  };
}

/**
 * Generate a summary of changes made
 */
async function generateChangeSummary(
  feedback: string,
  changedSections: string[]
): Promise<string> {
  if (changedSections.length === 0) {
    return "No sections required changes based on this feedback.";
  }

  const systemPrompt = `Summarize the changes made to an epic document in 2-3 sentences.`;
  const userPrompt = `Feedback applied: "${feedback}"
Sections updated: ${changedSections.join(', ')}

Write a brief summary:`;

  return await callAI(currentConfig, systemPrompt, userPrompt);
}
```

### Phase 3: Update Chat Flow in App.tsx

**File: `src/App.tsx`**

#### 3a. Add State for Global Feedback

```typescript
const [globalFeedbackProgress, setGlobalFeedbackProgress] = useState<{
  isApplying: boolean;
  current: number;
  total: number;
  currentSection: string;
} | null>(null);
```

#### 3b. Modify `handleSendChatMessage` to Ask About Scope

```typescript
const handleSendChatMessage = useCallback(async () => {
  if (!chatInput.trim() || chatState.isProcessing) return;

  const feedback = chatInput.trim();
  setChatInput('');

  // Add user message
  addChatMessage({ role: 'user', content: feedback });

  // Store the feedback for later use
  setChatState(prev => ({
    ...prev,
    isProcessing: true,
    pendingFeedback: feedback,
  }));

  try {
    // First, ask user about scope
    addChatMessage({
      role: 'assistant',
      content: 'How would you like me to apply this feedback?',
      questionType: 'scope-select',
      options: [
        'Apply to entire epic (all sections)',
        'Update a specific section only'
      ],
    });
    setChatState(prev => ({ ...prev, isProcessing: false }));

  } catch (err) {
    console.error('Failed to process feedback:', err);
    addChatMessage({
      role: 'assistant',
      content: 'Sorry, I encountered an error processing your request.',
    });
    setChatState(prev => ({ ...prev, isProcessing: false }));
  }
}, [chatInput, chatState.isProcessing, addChatMessage]);
```

#### 3c. Add Handler for Scope Selection

```typescript
const handleScopeSelect = useCallback(async (scope: 'entire' | 'specific', messageId: string) => {
  // Mark as answered
  setChatState(prev => ({
    ...prev,
    messages: prev.messages.map(m =>
      m.id === messageId ? { ...m, isAnswered: true, selectedValue: scope } : m
    ),
  }));

  if (scope === 'entire') {
    // Apply to entire epic
    await handleApplyGlobalFeedback();
  } else {
    // Continue with section-specific flow
    await handleDetectSection();
  }
}, []);

const handleApplyGlobalFeedback = useCallback(async () => {
  if (!chatState.pendingFeedback) return;

  setChatState(prev => ({ ...prev, isProcessing: true }));
  setGlobalFeedbackProgress({ isApplying: true, current: 0, total: 17, currentSection: '' });

  addChatMessage({
    role: 'assistant',
    content: 'Applying feedback to entire epic...',
  });

  try {
    const result = await applyFeedbackToEntireEpic(
      chatState.pendingFeedback,
      editableEpic,
      (current, total, sectionTitle) => {
        setGlobalFeedbackProgress({ isApplying: true, current, total, currentSection: sectionTitle });
      }
    );

    // Update epic
    setEditableEpic(result.updatedEpic);

    // Show completion message
    addChatMessage({
      role: 'assistant',
      content: `Done! Updated ${result.changedSections.length} sections.\n\n${result.summary}\n\n**Sections updated:**\n${result.changedSections.map(s => `- ${s}`).join('\n')}`,
    });

    showToast('success', 'Epic Updated', `${result.changedSections.length} sections modified`);

  } catch (error) {
    addChatMessage({
      role: 'assistant',
      content: 'Sorry, I encountered an error while updating the epic. Please try again.',
    });
    showToast('error', 'Update Failed', error instanceof Error ? error.message : 'Unknown error');
  } finally {
    setChatState(prev => ({
      ...prev,
      isProcessing: false,
      pendingFeedback: undefined,
    }));
    setGlobalFeedbackProgress(null);
  }
}, [chatState.pendingFeedback, editableEpic, addChatMessage, showToast]);

const handleDetectSection = useCallback(async () => {
  // Existing logic to detect section and ask for confirmation
  // ... (current analyzeUserFeedback flow)
}, []);
```

#### 3d. Update Chat UI to Show Progress

In the chat panel, show progress during global update:

```tsx
{globalFeedbackProgress?.isApplying && (
  <div style={{
    padding: '12px 16px',
    backgroundColor: UBS_COLORS.pastelI,
    borderRadius: '8px',
    margin: '8px 0'
  }}>
    <div style={{ fontSize: '13px', color: UBS_COLORS.grayV, marginBottom: '8px' }}>
      Updating: {globalFeedbackProgress.currentSection}
    </div>
    <div style={{
      height: '4px',
      backgroundColor: UBS_COLORS.neutral200,
      borderRadius: '2px',
      overflow: 'hidden'
    }}>
      <div style={{
        height: '100%',
        width: `${(globalFeedbackProgress.current / globalFeedbackProgress.total) * 100}%`,
        backgroundColor: UBS_COLORS.red,
        transition: 'width 0.3s ease'
      }} />
    </div>
    <div style={{ fontSize: '11px', color: UBS_COLORS.grayIII, marginTop: '4px' }}>
      {globalFeedbackProgress.current} / {globalFeedbackProgress.total} sections
    </div>
  </div>
)}
```

#### 3e. Add Scope Selection UI Component

```tsx
{message.questionType === 'scope-select' && !message.isAnswered && (
  <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginTop: '12px' }}>
    <button
      onClick={() => handleScopeSelect('entire', message.id)}
      style={{
        padding: '10px 16px',
        borderRadius: '6px',
        border: `1px solid ${UBS_COLORS.red}`,
        backgroundColor: '#fff',
        color: UBS_COLORS.red,
        cursor: 'pointer',
        fontWeight: 500,
        textAlign: 'left',
        display: 'flex',
        alignItems: 'center',
        gap: '8px'
      }}
    >
      <span>🌐</span> Apply to entire epic (all sections)
    </button>
    <button
      onClick={() => handleScopeSelect('specific', message.id)}
      style={{
        padding: '10px 16px',
        borderRadius: '6px',
        border: `1px solid ${UBS_COLORS.grayV}`,
        backgroundColor: '#fff',
        color: UBS_COLORS.grayV,
        cursor: 'pointer',
        fontWeight: 500,
        textAlign: 'left',
        display: 'flex',
        alignItems: 'center',
        gap: '8px'
      }}
    >
      <span>📄</span> Update a specific section only
    </button>
  </div>
)}
```

---

## File Changes Summary

| File | Changes |
|------|---------|
| `src/types.ts` | Add `'scope-select'` to `questionType` |
| `src/skills.ts` | Add `applyFeedbackToEntireEpic()`, `applySectionFeedback()`, `generateChangeSummary()` |
| `src/App.tsx` | Add `globalFeedbackProgress` state, `handleScopeSelect()`, `handleApplyGlobalFeedback()`, update chat UI |

---

## Performance Considerations

| Aspect | Approach |
|--------|----------|
| **17 API calls** | Sequential to avoid rate limits, ~3s each = ~51s total |
| **Progress feedback** | Show real-time progress to user |
| **Skip unchanged** | AI determines if feedback is relevant per section |
| **Cancellation** | Add cancel button during progress |

### Optimization: Parallel with Concurrency (Optional)

Could reduce time from ~51s to ~17s with concurrency of 3:
```typescript
// Process in batches of 3
for (let i = 0; i < EPIC_SECTIONS.length; i += 3) {
  const batch = EPIC_SECTIONS.slice(i, i + 3);
  await Promise.all(batch.map(section => applySectionFeedback(...)));
}
```

---

## Example Feedback Scenarios

| Feedback | Sections Likely to Change |
|----------|---------------------------|
| "Add more security focus" | 9 (Security), 12 (NFRs), 13 (Risks), 4 (Assumptions) |
| "Make it more technical" | 5 (Architecture), 6 (Diagrams), 10 (Data Stores), 11 (Features) |
| "Simplify for executives" | 1 (Objective), 2 (Background), 14 (Deliverables), 15 (Next Steps) |
| "Add compliance requirements" | 9 (Security), 12 (NFRs), 13 (Risks), 16 (DoD) |
| "Focus on mobile-first" | 5 (Architecture), 11 (Features), 12 (NFRs), 8 (Environments) |

---

## Testing Checklist

- [ ] User can choose "entire epic" or "specific section"
- [ ] Progress bar shows during global update
- [ ] All relevant sections are updated
- [ ] Irrelevant sections are left unchanged
- [ ] Summary shows what was changed
- [ ] Cancel button works during progress
- [ ] Error handling for failed sections
- [ ] Existing section-specific flow still works
