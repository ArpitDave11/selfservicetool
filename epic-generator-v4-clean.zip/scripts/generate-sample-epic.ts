/**
 * Generate a sample epic using the app's own runSkill('generate').
 * Run: npx tsx scripts/generate-sample-epic.ts
 */
import { writeFileSync } from 'fs';
import { resolve } from 'path';
import { runSkill } from '../src/skills.js';
import type { RefinedData } from '../src/types.js';

// Helper to create a RefinedData entry
const field = (text: string) => ({ original: text, refined: text, diagramNode: '' });

// Realistic MFA project data across all 20 fields
const data: RefinedData = {
  // Stage 1: Project
  projectName: field('Enterprise Multi-Factor Authentication System'),
  background: field(
`The organization currently relies on single-factor (password-only) authentication for all internal applications.
Recent security audits identified this as a critical vulnerability, with 73% of breached accounts traced to compromised passwords.

Industry regulations (SOC 2, ISO 27001) now mandate MFA for all enterprise systems. Competitors have already adopted MFA,
and our customers have raised concerns about data protection. This project will implement a robust, user-friendly MFA system
that supports multiple authentication methods and integrates seamlessly with our existing identity provider (Azure AD).`
  ),

  // Stage 2: Objective & Scope
  objective: field(
`Implement a comprehensive Multi-Factor Authentication (MFA) system that:
- Supports TOTP (Time-based One-Time Password), SMS, email, and push notification as second factors
- Integrates with Azure Active Directory as the identity provider
- Provides a self-service enrollment portal for end users
- Enforces MFA policies based on user role, application sensitivity, and risk score
- Achieves 99.9% authentication service availability
- Reduces account compromise incidents by at least 95%`
  ),
  inScope: field(
`- TOTP authenticator app support (Google Authenticator, Microsoft Authenticator, Authy)
- SMS-based one-time codes via Twilio
- Email-based one-time codes
- Push notification approval via mobile app
- Self-service MFA enrollment and recovery portal
- Admin dashboard for policy management and audit logs
- Azure AD integration via OIDC/SAML
- Risk-based authentication (adaptive MFA)
- Backup/recovery codes generation
- Rate limiting and brute-force protection`
  ),
  outOfScope: field(
`- Hardware security keys (YubiKey) — planned for Phase 2
- Biometric authentication (fingerprint, face) — planned for Phase 2
- Legacy application integration (pre-2015 systems)
- Mobile app development (will use existing authenticator apps)
- Password policy changes (handled by separate initiative)`
  ),

  // Stage 3: Architecture
  assumptions: field(
`- Azure AD is the authoritative identity provider and will remain so
- All target applications support OIDC or SAML 2.0 protocols
- Users have access to at least one of: smartphone, email, or SMS-capable phone
- Twilio account is available for SMS delivery
- Existing API gateway (Kong) will route MFA verification requests
- Maximum 50,000 concurrent users during peak hours
- 99.9% uptime SLA is achievable with multi-region deployment`
  ),
  architectureOverview: field(
`The MFA system follows a microservices architecture deployed on Kubernetes (AKS):

**Core Services:**
- **MFA Gateway Service** — Central orchestrator handling authentication flows, factor selection, and verification
- **TOTP Service** — Generates and validates time-based codes, manages secret key lifecycle
- **Notification Service** — Dispatches SMS (Twilio), email (SendGrid), and push notifications
- **Policy Engine** — Evaluates risk scores and determines required authentication factors
- **Enrollment Service** — Manages user MFA enrollment, recovery codes, and device registration

**Integration Layer:**
- Azure AD via OIDC/SAML for identity federation
- Kong API Gateway for request routing and rate limiting
- Redis for session management and OTP caching (5-minute TTL)
- PostgreSQL for persistent storage (enrollment data, audit logs)

**Security:**
- All inter-service communication over mTLS
- TOTP secrets encrypted at rest (AES-256)
- API rate limiting: 5 attempts per factor per 15-minute window`
  ),
  dataStores: field(
`**PostgreSQL 15** (Primary Database)
- User enrollment records, device registrations
- Audit logs (authentication attempts, policy changes)
- Recovery code hashes (bcrypt)
- Policy configurations

**Redis 7** (Cache & Session Store)
- Active OTP codes (TTL: 5 minutes)
- Authentication session state
- Rate limiting counters
- Risk score cache

**Azure Blob Storage**
- Encrypted TOTP secret key vault
- QR code generation cache
- Compliance report archives`
  ),

  // Stage 4: Features
  features: field(
`1. **TOTP Authenticator Support** — Users scan QR codes to enroll authenticator apps; system validates 6-digit TOTP codes with 30-second window and ±1 step tolerance
2. **SMS & Email OTP** — 6-digit codes sent via Twilio (SMS) or SendGrid (email) with 5-minute expiry and automatic retry
3. **Push Notification Approval** — One-tap approve/deny via mobile push notification with 60-second timeout
4. **Self-Service Enrollment Portal** — Web UI for users to add/remove factors, generate backup codes, and manage trusted devices
5. **Risk-Based Adaptive MFA** — Policy engine evaluates IP reputation, device fingerprint, login time, and geo-location to dynamically require step-up authentication
6. **Admin Policy Dashboard** — Configure MFA policies per application, role, or user group; view real-time authentication metrics and audit logs
7. **Backup & Recovery Codes** — Generate 10 single-use recovery codes during enrollment; codes are bcrypt-hashed and stored securely
8. **Brute-Force Protection** — Account lockout after 5 failed attempts; progressive delays; CAPTCHA challenge on suspicious activity`
  ),
  userStories: field(
`- As a developer, I want to enable MFA for my account so that my code repositories are protected from unauthorized access
- As an IT administrator, I want to enforce MFA policies by department so that sensitive teams have stricter authentication requirements
- As a remote employee, I want to use my authenticator app for MFA so that I can log in securely without cellular service
- As a security analyst, I want to view real-time MFA audit logs so that I can detect and respond to suspicious authentication patterns
- As a new hire, I want a guided MFA enrollment process so that I can set up my second factor on my first day without IT support
- As a user who lost their phone, I want to use backup recovery codes so that I can regain access to my account without contacting help desk
- As a compliance officer, I want MFA adoption reports so that I can demonstrate regulatory compliance during audits`
  ),
  nfrs: field(
`**Performance:**
- Authentication verification < 200ms (P95)
- SMS/email delivery < 10 seconds (P95)
- Push notification delivery < 5 seconds (P95)
- Support 50,000 concurrent authentications

**Availability:**
- 99.9% uptime SLA for MFA verification service
- Graceful degradation: fallback to email OTP if SMS service is down
- Multi-region active-active deployment

**Security:**
- TOTP secrets encrypted at rest (AES-256-GCM)
- All API endpoints require mTLS
- OWASP Top 10 compliance
- SOC 2 Type II audit-ready logging

**Scalability:**
- Horizontal auto-scaling (2-10 pods per service)
- Database connection pooling (PgBouncer)
- Redis cluster with 3 replicas`
  ),
  deliverables: field(
`- MFA Gateway Service (REST API + OpenAPI spec)
- TOTP enrollment and verification module
- SMS/Email notification service integration
- Push notification service
- Self-service enrollment web portal
- Admin policy management dashboard
- Risk-based authentication engine
- Database migration scripts
- Kubernetes Helm charts
- CI/CD pipeline configuration
- Load test suite (k6)
- Security penetration test report
- User documentation and admin guide
- API documentation (Swagger/OpenAPI 3.0)`
  ),

  // Stage 5: Team & Environment
  teams: field(
`Lead Architect — System design, architecture decisions, code reviews
Backend Team (3 engineers) — MFA services, API development, database design
Frontend Team (2 engineers) — Enrollment portal, admin dashboard, UX
DevOps Engineer — Kubernetes deployment, CI/CD, monitoring
Security Engineer — Threat modeling, pen testing, encryption implementation
QA Lead — Test strategy, automation, load testing
Product Owner — Requirements, stakeholder communication, prioritization
Scrum Master — Sprint ceremonies, blocker resolution, velocity tracking`
  ),
  environments: field(
`**Development** — AKS dev cluster, shared PostgreSQL, local Redis
- CI: GitHub Actions → build, lint, unit tests on every PR
- Auto-deploy to dev on merge to main

**Staging** — AKS staging cluster, dedicated PostgreSQL, Redis cluster
- Integration tests, E2E tests, security scans (SAST/DAST)
- Load testing with k6 (target: 10,000 concurrent users)
- Manual QA sign-off required

**Production** — AKS production (multi-region: East US, West Europe)
- Blue-green deployment with automated rollback
- Canary releases (5% → 25% → 100%)
- Monitoring: Datadog APM, PagerDuty alerts
- Database: Azure PostgreSQL Flexible Server with geo-replication`
  ),
  security: field(
`**Data Classification:** Confidential (TOTP secrets, recovery codes, session tokens)

**Encryption:**
- At rest: AES-256-GCM for TOTP secrets, bcrypt (cost 12) for recovery codes
- In transit: TLS 1.3 for external, mTLS for inter-service

**Access Control:**
- RBAC via Azure AD groups
- Service-to-service: OAuth 2.0 client credentials
- Admin dashboard: MFA-protected + IP allowlist

**Audit & Compliance:**
- All authentication events logged with correlation IDs
- 90-day log retention (hot), 7-year archive (cold)
- SOC 2 Type II controls mapped
- GDPR: User can export/delete their MFA enrollment data`
  ),

  // Stage 6: Delivery
  dependencies: field(
`- Azure AD tenant configuration and app registration (IT Operations team)
- Twilio account provisioning and phone number allocation (Procurement)
- SendGrid API key and sender domain verification (Email team)
- Kong API Gateway route configuration (Platform team)
- AKS cluster provisioning for staging and production (Cloud Infrastructure)
- PostgreSQL Flexible Server provisioned with geo-replication (DBA team)
- Security team approval of encryption key management approach`
  ),
  risks: field(
`| Risk | Impact | Likelihood | Mitigation |
|------|--------|------------|------------|
| Twilio SMS delivery delays in certain regions | Medium | Medium | Implement email OTP as automatic fallback |
| User resistance to MFA enrollment | High | Medium | Gradual rollout with department champions and training |
| Azure AD outage blocks all authentication | Critical | Low | Cache authentication tokens, implement 15-min grace period |
| TOTP secret key compromise | Critical | Low | HSM-backed key encryption, regular key rotation |
| Load exceeds projections during company-wide rollout | Medium | Medium | Auto-scaling policies, staged department-by-department rollout |`
  ),
  nextSteps: field(
`1. **Week 1-2:** Complete architecture design review and threat model
2. **Week 2-3:** Set up development environment, CI/CD pipeline, database schemas
3. **Week 3-6:** Implement core MFA services (TOTP, OTP delivery, verification)
4. **Week 6-8:** Build enrollment portal and admin dashboard
5. **Week 8-9:** Integration testing, security review, load testing
6. **Week 9-10:** Staged rollout to pilot group (IT department, 200 users)
7. **Week 10-12:** Company-wide rollout with department-by-department onboarding`
  ),
  dod: field(
`- [ ] All MFA methods (TOTP, SMS, email, push) functional and tested
- [ ] Self-service enrollment portal deployed and accessible
- [ ] Admin dashboard with policy management operational
- [ ] Risk-based authentication engine scoring correctly
- [ ] 99.9% uptime verified over 2-week monitoring period
- [ ] Load test passed: 50,000 concurrent authentications < 200ms P95
- [ ] Security penetration test completed with no critical/high findings
- [ ] SOC 2 audit controls documented and validated
- [ ] User documentation and admin guide published
- [ ] Pilot rollout completed with < 2% support ticket rate
- [ ] All teams trained on incident response procedures`
  ),
  approvers: field(
`Chief Information Security Officer (CISO)
VP of Engineering
Director of IT Operations
Head of Compliance
Product Owner`
  ),
};

async function main() {
  console.log('Generating sample epic...');
  const result = await runSkill('generate', {
    data,
    projectName: 'Enterprise Multi-Factor Authentication System',
  });

  const epic = (result as { epic: string }).epic;
  const outPath = resolve(import.meta.dirname, '..', 'sample-epic.md');
  writeFileSync(outPath, epic, 'utf-8');
  console.log(`Done! Epic written to: ${outPath}`);
  console.log(`Length: ${epic.length} chars, ${epic.split('\n').length} lines`);
}

main().catch(console.error);
