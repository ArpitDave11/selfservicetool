# Verbose Content & Mind Map Fix - Changelog

**Date:** 2026-02-11
**Issue:** Epic content was extremely verbose and unprofessional. Mind maps were messy and added no value.

---

## Problems Identified

### 1. Verbose Content in Wizard Phase
The `aiRefineField()` function was instructing AI to "ENHANCE and EXPAND" content, leading to:
- Overly wordy paragraphs
- Generic filler phrases like "in order to", "the ability to"
- Unprofessional, rambling content

### 2. No Word Limits
Field-specific prompts had no word count constraints, allowing unlimited expansion.

### 3. Mind Map Diagrams
Mind maps were:
- Messy and hard to read
- Generic with no specific value
- Selected too aggressively based on generic keywords

---

## Changes Made

### 1. Updated `aiRefineField()` System Prompt

**File:** `src/skills.ts`, Lines 248-258

**BEFORE:**
```typescript
const systemPrompt = `You are an expert technical writer enhancing content for a software project epic.

CRITICAL RULES:
1. READ the existing content carefully - DO NOT duplicate or repeat what's already there
2. ENHANCE and EXPAND the content with specific, relevant details
3. If content already has headers like "**Context:**", do NOT add another one
4. Add NEW information that complements existing content
5. Keep the same writing style and tone as the input
6. Be specific to THIS project based on the context provided
7. Output ONLY the enhanced content - no explanations or preamble`;
```

**AFTER:**
```typescript
const systemPrompt = `You are an expert technical writer creating concise, professional content for a software project epic.

CRITICAL RULES:
1. READ the existing content carefully - DO NOT duplicate or repeat what's already there
2. Be CONCISE and DIRECT - avoid verbose phrases like "in order to", "the ability to", "functionality for"
3. If content already has headers like "**Context:**", do NOT add another one
4. Add only ESSENTIAL information that adds clear value
5. Use professional, active voice - no filler or fluff
6. Be specific to THIS project based on the context provided
7. Output ONLY the enhanced content - no explanations or preamble
8. TARGET: Keep content scannable - use bullet points, short sentences (15-20 words max)`;
```

---

### 2. Added Word Limits to Field Prompts

**File:** `src/skills.ts`, Lines 259-278

Each field now has specific word/item limits:

| Field | Word/Item Limit |
|-------|-----------------|
| background | 80-120 words |
| objective | 60-100 words |
| inScope | 5-10 bullets, 15 words each |
| outOfScope | 3-7 bullets, 12 words each |
| assumptions | 5-8 bullets, 15 words each |
| architectureOverview | 100-150 words |
| dataStores | 80-120 words |
| features | 5-10 items, 1-2 sentences each |
| nfrs | 5-8 items, 20 words each |
| deliverables | 5-10 items, 15 words each |
| teams | 80-120 words |
| environments | 60-100 words |
| security | 5-8 bullets, 20 words each |
| dependencies | 5-10 bullets, 15 words each |
| risks | 3-6 items with likelihood |
| nextSteps | 5-8 numbered items, 15 words each |
| dod | 5-10 checklist items, 15 words each |
| approvers | 3-5 items |

---

### 3. Removed Mind Map from Diagram Options

**File:** `src/skills.ts`, Multiple locations

**Changes:**
1. **Table mapping** (Line 1611): Changed from `mindmap` to `block-beta`
2. **Decision heuristics** (Line 1630): Changed from `mindmap` to `block-beta`
3. **TYPE output format** (Line 2307): Removed `mindmap` from list
4. **diagramPatterns array** (Line 2344): Commented out mindmap pattern
5. **validStarts array** (Line 2394): Commented out mindmap validator
6. **Example section** (Line 1924-1938): Replaced Mind Map example with Block Diagram example

**Block Diagram now used for hierarchical concepts instead:**
```mermaid
block-beta
    columns 3
    block:backend["Backend"]
        api["API Gateway"]
        svc["Services"]
        db[("Database")]
    end
    block:frontend["Frontend"]
        web["Web App"]
        mobile["Mobile App"]
    end
    block:infra["Infrastructure"]
        aws["AWS"]
        k8s["Kubernetes"]
    end
```

---

## Summary

| Change | Impact |
|--------|--------|
| Concise prompt | Shorter, professional content |
| Word limits | Consistent section lengths |
| No filler phrases | Direct, actionable content |
| No mind maps | Cleaner, more professional diagrams |
| Block diagrams | Better visualization for hierarchies |

---

## Expected Results

After this fix:
1. Generated epics will be 40-60% shorter
2. Content will be scannable with bullet points
3. No verbose filler phrases
4. No messy mind map diagrams
5. Professional, active voice throughout

---

## Verification

1. Run `npm run dev`
2. Create a new epic through the wizard
3. Use AI suggestions on any field
4. Verify content is concise and professional
5. Generate blueprint - verify no mind map diagrams
6. Run Premium Pipeline - verify all sections have appropriate length
