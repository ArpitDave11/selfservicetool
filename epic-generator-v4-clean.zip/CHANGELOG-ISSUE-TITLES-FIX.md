# Professional Issue Titles Fix - Changelog

**Date:** 2026-02-11
**Issue:** Issue titles were verbose sentences from user story goals, not professional action-oriented titles

---

## Root Cause

The pipeline and parser were using the `goal` field (e.g., "enable multi-factor authentication for all user accounts") directly as the issue title, just capitalizing the first letter.

**Before:**
| Goal (from AI) | Issue Title Created |
|----------------|---------------------|
| `enable multi-factor authentication for all user accounts` | `Enable multi-factor authentication for all user accounts` |
| `view my transaction history for the past 12 months` | `View my transaction history for the past 12 months` |

**After:**
| Goal | Professional Title |
|------|-------------------|
| `enable multi-factor authentication for all user accounts` | `Implement MFA Authentication` |
| `view my transaction history for the past 12 months` | `Add Transaction History View` |

---

## Changes Made

### 1. Updated PipelineUserStory Interface (types.ts)

**File:** `src/types.ts`, Lines 300-309

**BEFORE:**
```typescript
export interface PipelineUserStory {
  id: string;
  persona: string;
  goal: string;
  benefit: string;
  // ...
}
```

**AFTER:**
```typescript
export interface PipelineUserStory {
  id: string;
  title: string;               // Professional, action-oriented title (5-8 words)
  persona: string;
  goal: string;
  benefit: string;
  // ...
}
```

---

### 2. Updated Stage 5B Prompt (skills.ts)

**File:** `src/skills.ts`, Lines 4986-5025

Added title field with clear guidelines:

```typescript
const systemPrompt = `You are an expert Agile coach extracting user stories...

TITLE GUIDELINES:
- Start with action verb: Implement, Add, Create, Enable, Configure, Integrate
- Be crisp and scannable (5-8 words maximum)
- Use technical terms appropriately (MFA, API, OAuth, SSO)
- Avoid verbose phrases like "the ability to" or "functionality for"
- Examples: "Implement MFA Authentication", "Add Transaction History Export"

OUTPUT FORMAT:
{
  "stories": [
    {
      "id": "US-001",
      "title": "<professional action-oriented title, 5-8 words>",  // NEW FIELD
      "persona": "<specific role>",
      "goal": "<what they want>",
      ...
    }
  ]
}`;
```

---

### 3. Updated Story Display in Epic (skills.ts)

**File:** `src/skills.ts`, Lines 5133-5147 (assembleEpicWithEmbedding)

**BEFORE:**
```markdown
**US-001** 🔴 HIGH
As a user, I want enable MFA, so that my account is secure.
```

**AFTER:**
```markdown
**US-001: Implement MFA Authentication** 🔴
> As a user, I want enable MFA, so that my account is secure.
```

---

### 4. Updated Story Parser (skills.ts)

**File:** `src/skills.ts`, Lines 3428-3530 (parseUserStoriesFromEpic)

Added new format pattern to extract professional titles:

```typescript
// NEW FORMAT: **US-XXX: Professional Title** with blockquote story
const newFormatPattern = /\*\*([A-Z]{2,3}-\d+):\s*([^*]+)\*\*[^\n]*\n>\s*As an?\s+([^,]+),?\s*I\s+want\s+([^,]+?)(?:,?\s*so\s+that\s+([^.\n]+))?/gi;
```

The parser now:
1. First tries to match the new format with professional titles
2. Falls back to legacy format (capitalized goal) for backward compatibility
3. Falls back to bullet points as last resort

---

## Flow After Fix

```
Stage 5B AI Prompt
    ↓
AI generates: { "id": "US-001", "title": "Implement MFA Authentication", "goal": "enable MFA..." }
    ↓
assembleEpicWithEmbedding() → Embeds as: **US-001: Implement MFA Authentication**
    ↓
User opens Issue Modal → parseUserStoriesFromEpic() extracts title
    ↓
createGitLabIssue({ title: "Implement MFA Authentication" })
    ↓
GitLab Issue: "Implement MFA Authentication" ✅
```

---

## Example Output

### In Epic Markdown:
```markdown
### User Stories

**US-001: Implement MFA Authentication** 🔴
> As a user, I want to enable multi-factor authentication, so that my account is more secure.

Acceptance Criteria:
- [ ] Support TOTP authenticator apps
- [ ] Provide backup codes

**US-002: Add Transaction History Export** 🟡
> As a finance manager, I want to export transaction history, so that I can perform audits.

Acceptance Criteria:
- [ ] Export to PDF and CSV formats
- [ ] Filter by date range
```

### GitLab Issues Created:
1. `Implement MFA Authentication`
2. `Add Transaction History Export`

---

## Summary

| File | Lines | Change |
|------|-------|--------|
| `types.ts` | 300-309 | Added `title` field to `PipelineUserStory` |
| `skills.ts` | 4986-5025 | Updated Stage 5B prompt with title guidelines |
| `skills.ts` | 5133-5147 | Updated story display format in assembled epic |
| `skills.ts` | 3428-3530 | Updated parser to extract professional titles |

---

## Backward Compatibility

The parser maintains backward compatibility:
1. Tries new format first (with professional titles)
2. Falls back to legacy format (capitalized goal)
3. Falls back to bullet points

Existing epics without the new format will continue to work, though titles will be less professional.
