import { defineConfig, devices } from '@playwright/test';

const PORT = 3099; // Dedicated port for Playwright (avoids conflicts with dev server on 3002)

export default defineConfig({
  testDir: './src/test/playwright',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: 'html',
  timeout: 60_000,
  use: {
    baseURL: `http://localhost:${PORT}`,
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
  },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
  ],
  webServer: {
    // Disable all auth (MSAL + mock) so tests can access the app directly
    command: `VITE_MSAL_AUTH_ENABLED=false VITE_MSAL_AUTH_MOCK=false npx vite --port ${PORT}`,
    url: `http://localhost:${PORT}`,
    reuseExistingServer: false,
    timeout: 30_000,
  },
});
