# Epic Load Flow Fix - Complete Changelog

**Date:** 2026-02-12
**Issue:** When two epics with the same `iid` exist in different groups, the app loads and updates the wrong epic.

---

## Summary

Fixed a critical bug in **BOTH** the application code AND the mock functions. The bug caused updates to go to the wrong epic when duplicate `iid`s existed across different groups.

---

## Root Cause Analysis

### Problem 1: App Code (Previously Fixed)
`handleLoadEpicIntoEditor()` used `Array.find()` to locate an epic by `iid`, which returned the **first match** instead of the **clicked epic**.

### Problem 2: Mock Functions (NEW - Fixed Now)
Even after the App.tsx fix, the mock functions in `mockGitLabData.ts` were **ignoring the `groupId` parameter** completely:

```typescript
// BUGGY CODE in mockFetchEpicDetails:
const epic = mockEpics.find(e => e.iid === epicIid);  // Ignores _groupId!

// BUGGY CODE in mockUpdateGitLabEpic:
const epicIndex = mockEpics.findIndex(e => e.iid === epicIid);  // Ignores groupId!
```

Since `MOCK_GITLAB_ENABLED = true`, the mock functions were always used, causing the bug to persist.

---

## Files Modified

### 1. `src/App.tsx` (Previously Fixed)

#### Change: Function Signature
**Location:** Line ~3427

```typescript
// Before:
const handleLoadEpicIntoEditor = async (epicIid: number) => {
  const epicFromList = loadEpicResults.find(e => e.iid === epicIid);
  const epicGroupId = epicFromList?.group_id ? String(epicFromList.group_id) : config.gitlab.rootGroupId;

// After:
const handleLoadEpicIntoEditor = async (epic: import('./config').GitLabEpic) => {
  const epicGroupId = epic.group_id ? String(epic.group_id) : config.gitlab.rootGroupId;
  const epicIid = epic.iid;
```

#### Change: Function Call Site
**Location:** Line ~7278

```typescript
// Before:
onClick={() => handleLoadEpicIntoEditor(epic.iid)}

// After:
onClick={() => handleLoadEpicIntoEditor(epic)}  // Pass full epic object
```

---

### 2. `src/mockGitLabData.ts` (NEW - Fixed Now)

#### Fix 1: `mockFetchEpicDetails` (Lines 1867-1894)

**Before:**
```typescript
export async function mockFetchEpicDetails(
  config: GitLabConfig,
  epicIid: number,
  _groupId?: string  // ← Underscore = intentionally ignored!
): Promise<GitLabEpicResult> {
  const epic = mockEpics.find(e => e.iid === epicIid);  // ← BUG: ignores groupId
```

**After:**
```typescript
export async function mockFetchEpicDetails(
  config: GitLabConfig,
  epicIid: number,
  groupId?: string  // ← Now used!
): Promise<GitLabEpicResult> {
  let epic;
  if (groupId) {
    // Find by BOTH iid AND group_id
    epic = mockEpics.find(e => e.iid === epicIid && String(e.group_id) === groupId);
    console.log('[Mock GitLab] Finding epic with iid:', epicIid, 'AND group_id:', groupId);
  }
  if (!epic) {
    // Fallback to iid-only search
    epic = mockEpics.find(e => e.iid === epicIid);
  }
```

#### Fix 2: `mockUpdateGitLabEpic` (Lines 1991-2037)

**Before:**
```typescript
export async function mockUpdateGitLabEpic(
  config: GitLabConfig,
  epicIid: number,
  params: GitLabUpdateEpicParams,
  groupId?: string  // ← Comment said "mock ignores this"!
): Promise<GitLabEpicResult> {
  const epicIndex = mockEpics.findIndex(e => e.iid === epicIid);  // ← BUG: ignores groupId
```

**After:**
```typescript
export async function mockUpdateGitLabEpic(
  config: GitLabConfig,
  epicIid: number,
  params: GitLabUpdateEpicParams,
  groupId?: string  // ← IMPORTANT: Now used to find epic in correct group
): Promise<GitLabEpicResult> {
  let epicIndex = -1;
  if (groupId) {
    // Find by BOTH iid AND group_id
    epicIndex = mockEpics.findIndex(e => e.iid === epicIid && String(e.group_id) === groupId);
    console.log('[Mock GitLab] Finding epic with iid:', epicIid, 'AND group_id:', groupId);
  }
  if (epicIndex === -1) {
    // Fallback to iid-only search
    epicIndex = mockEpics.findIndex(e => e.iid === epicIid);
  }
```

#### Fix 3: `mockFetchEpicChildren` (Lines 1911-1923)

**Before:**
```typescript
export async function mockFetchEpicChildren(
  _config: GitLabConfig,
  epicIid: number,
  _groupId?: string  // ← Ignored
): Promise<GitLabEpicChildrenResult> {
```

**After:**
```typescript
export async function mockFetchEpicChildren(
  _config: GitLabConfig,
  epicIid: number,
  groupId?: string  // ← Now logged (data structure still keyed by iid only)
): Promise<GitLabEpicChildrenResult> {
  console.log('[Mock GitLab] Fetching children for epic iid:', epicIid, 'groupId:', groupId);
```

---

### 3. `src/config.ts` (Previously Fixed)

Added `groupId` parameter to `updateGitLabEpic()`:

```typescript
export async function updateGitLabEpic(
  config: GitLabConfig,
  epicIid: number,
  params: GitLabUpdateEpicParams,
  groupId?: string  // ← Added parameter
): Promise<GitLabEpicResult> {
  const targetGroupId = groupId || config.rootGroupId;
  const url = `${apiUrl}/groups/${targetGroupId}/epics/${epicIid}`;
```

---

## Complete Data Flow (After Fix)

```
1. User searches for epics in Load Epic modal
   → API returns epics with correct group_id on each

2. User clicks on an epic (e.g., subgroup epic with group_id=478446)
   → handleLoadEpicIntoEditor(epic) called with FULL epic object

3. Function extracts group_id from the clicked epic
   → epicGroupId = epic.group_id = "478446"

4. Mock/Real fetchEpicDetails called with groupId
   → mockFetchEpicDetails(config, 229, "478446")
   → Finds epic with BOTH iid=229 AND group_id=478446

5. selectedGitLabEpic set with correct epic (group_id=478446)

6. User edits and clicks "Update Epic"
   → handleUpdateGitLabEpic() uses selectedGitLabEpic.group_id

7. Mock/Real updateGitLabEpic called with groupId
   → mockUpdateGitLabEpic(config, 229, params, "478446")
   → Finds and updates epic with BOTH iid=229 AND group_id=478446

8. Correct epic updated!
```

---

## Verification

### Console Logs to Expect

When loading an epic:
```
[Load Epic] Using clicked epic directly:
  - epic.id: 841693
  - epic.iid: 229
  - epic.group_id: 478446
  - epicGroupId (for API): 478446
[Mock GitLab] Finding epic with iid: 229 AND group_id: 478446
[Mock GitLab] Found epic: 841693 in group: 478446
```

When updating:
```
[Mock GitLab] ============ UPDATE EPIC CALLED ============
[Mock GitLab] Input Parameters:
  - epicIid: 229
  - groupId (passed): 478446
[Mock GitLab] Finding epic with iid: 229 AND group_id: 478446 -> index: X
[Mock GitLab] Found epic at index: X
[Mock GitLab] Epic id: 841693
[Mock GitLab] Epic group_id: 478446
```

---

## Test Files

| File | Purpose |
|------|---------|
| `src/test/epicGroupIdMismatch.test.ts` | Demonstrates the duplicate iid bug |
| `src/test/epicLoadFlowAnalysis.test.ts` | Verifies bug is at LOAD time |

Run: `npm run test:run -- epicGroupIdMismatch`

---

## Summary of All Bugs Fixed

| Location | Bug | Fix |
|----------|-----|-----|
| `App.tsx` handleLoadEpicIntoEditor | `find(e => e.iid)` returns first match | Accept full epic object, use `epic.group_id` directly |
| `App.tsx` onClick handler | Passed only `epic.iid` | Pass full `epic` object |
| `mockGitLabData.ts` mockFetchEpicDetails | Ignored `groupId` parameter | Find by BOTH `iid` AND `group_id` |
| `mockGitLabData.ts` mockUpdateGitLabEpic | Ignored `groupId` parameter | Find by BOTH `iid` AND `group_id` |
| `config.ts` updateGitLabEpic | Used `config.rootGroupId` only | Accept and use `groupId` parameter |

---

## Why Previous Fix Didn't Work

The App.tsx fix was correct - it properly extracted `group_id` from the clicked epic and passed it to the mock functions.

**BUT** the mock functions (`mockFetchEpicDetails`, `mockUpdateGitLabEpic`) were **ignoring the `groupId` parameter** entirely! The comment on line 1996 even said:

```typescript
groupId?: string  // Optional: For API consistency (mock ignores this, finds by iid)
```

This meant:
1. App.tsx correctly passed `groupId=478446`
2. Mock function received it but **ignored it**
3. Mock used only `iid` to search
4. First matching epic (potentially wrong group) was returned/updated

---

## GitLab API URL Format

The real GitLab API uses this URL format:
```
GET  /api/v4/groups/{group_id}/epics/{epic_iid}    # Fetch epic details
PUT  /api/v4/groups/{group_id}/epics/{epic_iid}    # Update epic
```

In development, this is proxied through Vite:
```
/gitlab-api/groups/{group_id}/epics/{epic_iid}
```

The `group_id` in the URL determines which epic is fetched/updated. This is why passing the correct `group_id` is critical when duplicate `iid`s exist.
