import { defineConfig } from 'vitest/config'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  test: {
    globals: true,
    environment: 'jsdom',
    setupFiles: ['./src/test/setup.ts'],
    include: ['src/test/**/*.{test,spec}.{js,ts,jsx,tsx}'],
    // Exclude Puppeteer tests - they run with test:e2e
    exclude: ['src/test/puppeteer/**/*', 'src/test/playwright/**/*', 'node_modules/**/*'],
    coverage: {
      reporter: ['text', 'json', 'html'],
    },
  },
})
