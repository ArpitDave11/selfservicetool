import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    // E2E tests don't need jsdom - they use real browser via Puppeteer
    environment: 'node',
    // Only run Puppeteer tests
    include: ['src/test/puppeteer/**/*.test.ts'],
    // Longer timeout for browser tests (AI operations can take time)
    testTimeout: 180000,
    hookTimeout: 120000,
    // Run tests sequentially (browser tests shouldn't run in parallel)
    fileParallelism: false,
    // Don't use the jsdom setup
    setupFiles: [],
  },
});
