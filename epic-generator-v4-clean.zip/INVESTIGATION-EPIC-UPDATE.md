# Epic Update Investigation Report

**Date:** 2026-02-11
**Issue:** "I refined the Epic and then clicked the Update Epic button. It should have updated the same Epic that I originally loaded, but for some reason nothing changes."

---

## Executive Summary

After thorough investigation including unit tests, E2E tests, and code tracing, I identified **THREE root causes** that could cause "nothing changes" behavior.

---

## Root Causes Identified

### 🔴 Root Cause 1: MOCK_GITLAB_ENABLED = true (MOST LIKELY)

**File:** `src/mockGitLabData.ts`, Line 27

```typescript
export const MOCK_GITLAB_ENABLED = true;
```

**Impact:**
- ALL GitLab API calls use mock functions instead of real API
- `mockUpdateGitLabEpic()` updates an **IN-MEMORY array**
- Changes are **NOT PERSISTED** to GitLab
- When page refreshes, mock data resets to initial state
- User sees "nothing changes" because it's the same mock data

**Evidence:**
- Unit test confirms mock mode is enabled
- Screenshot shows "MOCK MODE" badge in UI
- Console logs show `[Mock GitLab]` prefix instead of `[GitLab Epic API]`

**Fix:**
```typescript
// In src/mockGitLabData.ts, line 27
export const MOCK_GITLAB_ENABLED = false;  // Enable real API
```

---

### 🟡 Root Cause 2: Silent Early Return (selectedGitLabEpic = null)

**File:** `src/App.tsx`, Lines 2253-2255

```typescript
if (!selectedGitLabEpic) {
  console.log('[DEBUG handleUpdateGitLabEpic] EARLY RETURN - selectedGitLabEpic is null!');
  return;  // ← SILENT RETURN - NO TOAST OR ERROR
}
```

**Impact:**
- If `selectedGitLabEpic` is null when "Update Epic" is clicked
- Function exits silently with ZERO feedback
- User sees "nothing changes" with no explanation

**How this could happen:**
- Epic wasn't properly loaded from Load Modal
- User clicked Reset Wizard (clears selectedGitLabEpic)
- Some state race condition

**Fix:**
```typescript
if (!selectedGitLabEpic) {
  console.log('[DEBUG handleUpdateGitLabEpic] EARLY RETURN - selectedGitLabEpic is null!');
  showToast('error', 'No Epic Selected', 'Load an epic first before updating');
  return;
}
```

---

### 🟢 Root Cause 3: Wrong GroupId (Already Fixed)

**File:** `src/config.ts`, Line 2045

Previously, `updateGitLabEpic()` used `config.rootGroupId` instead of the epic's actual `group_id`.

**Status:** ✅ FIXED in this session

```typescript
// Now correctly uses epic's group_id
const targetGroupId = groupId || config.rootGroupId;
const url = `${apiUrl}/groups/${targetGroupId}/epics/${epicIid}`;
```

---

## Investigation Evidence

### Unit Test Results

```
✓ MOCK_GITLAB_ENABLED should be true for mock mode
✓ mockUpdateGitLabEpic should update epic in memory
✓ mockUpdateGitLabEpic should return error for non-existent epic
✓ should pass correct groupId through update flow
✓ should identify when selectedGitLabEpic would be null
✓ should demonstrate mock data is not persisted
```

**Key Finding:** Mock update function works correctly, but changes only persist in memory until page refresh.

### Console Debug Logs

When update runs correctly, you should see:
```
[DEBUG handleUpdateGitLabEpic] Called
[DEBUG handleUpdateGitLabEpic] selectedGitLabEpic: {iid: 101, group_id: 557797, ...}
[DEBUG handleUpdateGitLabEpic] Calling update with:
  - iid: 101
  - group_id from epic: 557797
  - epicGroupId (passed to API): 557797
  - shouldUseMockGitLab: true
[Mock GitLab] ============ UPDATE EPIC CALLED ============
[Mock GitLab] Input Parameters:
  - epicIid: 101
  - groupId (passed): 557797
[Mock GitLab] Updated epic: 101 Updated Title
```

If you see:
```
[DEBUG handleUpdateGitLabEpic] EARLY RETURN - selectedGitLabEpic is null!
```

That means `selectedGitLabEpic` is null - the epic wasn't properly loaded.

---

## How to Verify the Issue

### Step 1: Check if Mock Mode is Active
1. Open browser DevTools → Console
2. Look for logs starting with `[Mock GitLab]`
3. Check if "MOCK MODE" badge appears in UI header

### Step 2: Check selectedGitLabEpic State
1. Load an epic from Load Modal
2. Check console for: `[Mock GitLab] Fetched epic details: 101 ...`
3. Click Publish → Update Epic
4. Check console for: `[DEBUG handleUpdateGitLabEpic] selectedGitLabEpic: {iid: ...}`

### Step 3: Verify API Call
1. Open DevTools → Network tab
2. Click Update Epic
3. Look for PUT request to `/groups/{id}/epics/{iid}`
4. If no network request and only `[Mock GitLab]` logs, you're in mock mode

---

## Recommended Fixes

### Fix 1: Disable Mock Mode (if real API needed)

```typescript
// src/mockGitLabData.ts, line 27
export const MOCK_GITLAB_ENABLED = false;
```

### Fix 2: Add Error Toast for Null Epic

```typescript
// src/App.tsx, in handleUpdateGitLabEpic
if (!selectedGitLabEpic) {
  showToast('error', 'No Epic Selected', 'Load an epic from GitLab first');
  return;
}
```

### Fix 3: Verify Epic Loaded Before Enabling Update Button

```typescript
// Only enable Update button if epic is actually loaded
<button
  disabled={!selectedGitLabEpic}
  onClick={handleUpdateGitLabEpic}
>
  {selectedGitLabEpic ? 'Update Epic' : 'Load Epic First'}
</button>
```

---

## Files Created/Modified

| File | Purpose |
|------|---------|
| `src/test/epicUpdate.test.ts` | Unit tests for update flow |
| `src/test/puppeteer/epic-update.puppeteer.test.ts` | E2E tests |
| `src/App.tsx` | Added debug logging to handleUpdateGitLabEpic |
| `src/mockGitLabData.ts` | Added debug logging to mockUpdateGitLabEpic |
| `src/config.ts` | Fixed groupId parameter in updateGitLabEpic |
| `CHANGELOG-EPIC-UPDATE-FIX.md` | Documents the groupId fix |
| `INVESTIGATION-EPIC-UPDATE.md` | This report |

---

## Summary

| Root Cause | Status | Impact |
|------------|--------|--------|
| Mock mode enabled | IDENTIFIED | Updates don't persist |
| selectedGitLabEpic null | IDENTIFIED | Silent failure |
| Wrong groupId | FIXED | API 404 error |

**Most Likely Cause:** If `MOCK_GITLAB_ENABLED = true`, all updates are in-memory only. This is why "nothing changes" - the mock data resets on page refresh.

---

## Next Steps

1. **If using real GitLab:** Set `MOCK_GITLAB_ENABLED = false` in `src/mockGitLabData.ts`
2. **Add user feedback:** Show error toast when selectedGitLabEpic is null
3. **Test with real API:** Verify update works against actual GitLab instance
