# GitLab OAuth 2.0 + OIDC Implementation Plan

## Executive Summary

This plan details the implementation of GitLab OAuth 2.0 Authorization Code Flow with PKCE for the Epic Generator v4 application, replacing the current Personal Access Token (PAT) authentication while maintaining backwards compatibility.

## Current State vs Target State

| Aspect | Current (PAT) | Target (OAuth) |
|--------|---------------|----------------|
| Auth Method | Personal Access Token | OAuth 2.0 + PKCE |
| Header | `PRIVATE-TOKEN: <token>` | `Authorization: Bearer <token>` |
| Storage | localStorage (insecure) | sessionStorage (secure) |
| User Experience | Manual token copy/paste | "Sign in with GitLab" button |
| Token Expiry | Never (until revoked) | 2 hours (auto-refresh) |
| User Info | None | OIDC profile (name, email, avatar) |

---

## 1. File Structure

```
src/
├── auth/                           # Existing MSAL auth
│   ├── index.ts                    # Add GitLab auth exports
│   └── ... (existing files)
│
├── gitlab-auth/                    # NEW: GitLab OAuth module
│   ├── index.ts                    # Module exports
│   ├── gitlabAuthConfig.ts         # OAuth configuration & feature flags
│   ├── gitlabAuthTypes.ts          # TypeScript interfaces
│   ├── gitlabAuthService.ts        # Core OAuth logic (PKCE, tokens)
│   ├── GitLabAuthProvider.tsx      # React context provider
│   ├── GitLabLoginButton.tsx       # "Sign in with GitLab" button
│   ├── GitLabUserInfo.tsx          # Displays authenticated user
│   └── gitlabTokenStorage.ts       # Secure token storage utilities
│
├── config.ts                       # MODIFY: Add Bearer token support
├── types.ts                        # MODIFY: Add OAuth-related types
└── App.tsx                         # MODIFY: Settings UI updates
```

---

## 2. GitLab OAuth Endpoints

Based on GitLab documentation:

| Endpoint | URL | Purpose |
|----------|-----|---------|
| Authorization | `/oauth/authorize` | Start OAuth flow |
| Token | `/oauth/token` | Exchange code for tokens |
| User Info | `/oauth/userinfo` | Get OIDC user profile |
| Revoke | `/oauth/revoke` | Logout/revoke tokens |
| Discovery | `/.well-known/openid-configuration` | OIDC metadata |

---

## 3. Required Scopes

```
openid profile email api
```

- `openid` - Enable OIDC (required for user info)
- `profile` - Get user's name, username, avatar
- `email` - Get user's email address
- `api` - Full API access (same as current PAT)

---

## 4. PKCE Flow (for SPA Security)

```
┌─────────────────────────────────────────────────────────────────────┐
│                     PKCE Authorization Flow                          │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  1. Generate PKCE Challenge                                          │
│     ┌──────────────────────────────────────────────────────────┐    │
│     │ code_verifier = random(43-128 chars)                      │    │
│     │ code_challenge = base64url(sha256(code_verifier))         │    │
│     └──────────────────────────────────────────────────────────┘    │
│                              │                                       │
│                              ▼                                       │
│  2. Redirect to GitLab /oauth/authorize                              │
│     ┌──────────────────────────────────────────────────────────┐    │
│     │ ?client_id=APP_ID                                         │    │
│     │ &redirect_uri=http://localhost:3002/                      │    │
│     │ &response_type=code                                       │    │
│     │ &scope=openid profile email api                           │    │
│     │ &state=RANDOM_STATE                                       │    │
│     │ &code_challenge=CHALLENGE                                 │    │
│     │ &code_challenge_method=S256                               │    │
│     └──────────────────────────────────────────────────────────┘    │
│                              │                                       │
│                              ▼                                       │
│  3. User Authorizes App in GitLab                                    │
│                              │                                       │
│                              ▼                                       │
│  4. GitLab Redirects Back with Code                                  │
│     http://localhost:3002/?code=AUTH_CODE&state=STATE                │
│                              │                                       │
│                              ▼                                       │
│  5. Exchange Code for Tokens (POST /oauth/token)                     │
│     ┌──────────────────────────────────────────────────────────┐    │
│     │ client_id=APP_ID                                          │    │
│     │ code=AUTH_CODE                                            │    │
│     │ grant_type=authorization_code                             │    │
│     │ redirect_uri=http://localhost:3002/                       │    │
│     │ code_verifier=ORIGINAL_VERIFIER  ← PKCE proof             │    │
│     └──────────────────────────────────────────────────────────┘    │
│                              │                                       │
│                              ▼                                       │
│  6. Receive Tokens                                                   │
│     ┌──────────────────────────────────────────────────────────┐    │
│     │ { access_token, refresh_token, expires_in, id_token }     │    │
│     └──────────────────────────────────────────────────────────┘    │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 5. Implementation Phases

### Phase 1: Foundation (Types & Config)
- [ ] Create `src/gitlab-auth/` directory
- [ ] Implement `gitlabAuthTypes.ts` - TypeScript interfaces
- [ ] Implement `gitlabAuthConfig.ts` - feature flags, env vars
- [ ] Update `.env.example` and `vite-env.d.ts`

### Phase 2: Core OAuth Service
- [ ] Implement PKCE utilities (generateCodeVerifier, generateCodeChallenge)
- [ ] Implement token exchange (`exchangeCodeForTokens`)
- [ ] Implement token refresh (`refreshAccessToken`)
- [ ] Implement user info fetch (`fetchUserInfo`)
- [ ] Implement token revocation (`revokeToken`)

### Phase 3: Token Storage
- [ ] Implement `gitlabTokenStorage.ts`
- [ ] Secure sessionStorage utilities
- [ ] PKCE verifier temporary storage
- [ ] Token expiration checking

### Phase 4: React Integration
- [ ] Implement `GitLabAuthProvider.tsx`
- [ ] Implement `GitLabLoginButton.tsx`
- [ ] Implement `GitLabUserInfo.tsx`
- [ ] Create `index.ts` exports

### Phase 5: API Integration
- [ ] Add `getGitLabAuthHeaders()` function to config.ts
- [ ] Update all 26 API calls to use new header function
- [ ] Add `authMode` to GitLabConfig interface

### Phase 6: Settings UI
- [ ] Add auth mode toggle in Settings
- [ ] Add "Sign in with GitLab" button
- [ ] Display authenticated user info
- [ ] Add logout option

### Phase 7: Testing
- [ ] Unit tests for OAuth service
- [ ] Component tests for provider
- [ ] E2E tests with Puppeteer
- [ ] Mock OAuth mode for local dev

---

## 6. Environment Variables

```bash
# .env.example additions

# GitLab OAuth Configuration
VITE_GITLAB_OAUTH_ENABLED=false        # Enable OAuth (vs PAT)
VITE_GITLAB_OAUTH_CLIENT_ID=           # GitLab Application ID
VITE_GITLAB_OAUTH_MOCK=false           # Mock mode for local testing
```

---

## 7. GitLab Application Registration

Users/admins need to register an OAuth application in GitLab:

1. **Navigate to**: GitLab → User Settings → Applications (or Group/Admin for shared app)
2. **Create Application**:
   - **Name**: `Epic Generator`
   - **Redirect URI**:
     - Dev: `http://localhost:3002/`
     - Prod: `https://your-app-domain.com/`
   - **Confidential**: `No` (public client for SPA)
   - **Scopes**: `openid`, `profile`, `email`, `api`
3. **Copy Application ID** → Use as `VITE_GITLAB_OAUTH_CLIENT_ID`

---

## 8. Security Considerations

| Concern | Mitigation |
|---------|------------|
| Token theft | sessionStorage (cleared on tab close) |
| CSRF attacks | Random `state` parameter validated |
| Code interception | PKCE with S256 challenge |
| Token exposure | No client secret (public client) |
| Long-lived tokens | 2-hour expiry + auto-refresh |
| Logout security | Token revocation on sign out |

---

## 9. Migration Strategy

### Backwards Compatibility
```typescript
// GitLabConfig interface
interface GitLabConfig {
  // ... existing fields ...
  authMode: 'pat' | 'oauth';  // NEW - defaults to 'pat'
}

// Header selection
function getGitLabAuthHeaders(config: GitLabConfig): Headers {
  if (config.authMode === 'oauth') {
    return { 'Authorization': `Bearer ${getOAuthAccessToken()}` };
  }
  return { 'PRIVATE-TOKEN': config.accessToken };
}
```

### Rollout Plan
1. **v1**: Feature flag disabled by default, PAT unchanged
2. **v2**: OAuth available as opt-in in Settings
3. **v3**: OAuth as default for new users
4. **v4**: PAT deprecated with warning
5. **v5**: PAT removed (far future)

---

## 10. Token Refresh Strategy

```typescript
// Automatic refresh scheduling
const REFRESH_BUFFER_MS = 5 * 60 * 1000; // 5 minutes before expiry

function scheduleTokenRefresh(tokens: GitLabOAuthTokens) {
  const expiresAt = (tokens.created_at + tokens.expires_in) * 1000;
  const refreshAt = expiresAt - REFRESH_BUFFER_MS;
  const delay = refreshAt - Date.now();

  if (delay > 0) {
    setTimeout(() => refreshAccessToken(tokens.refresh_token), delay);
  }
}
```

---

## Sources

- [GitLab OAuth 2.0 Provider Documentation](https://docs.gitlab.com/integration/oauth_provider/)
- [GitLab OAuth 2.0 API](https://docs.gitlab.com/api/oauth2/)
- [GitLab as OIDC Provider](https://docs.gitlab.com/integration/openid_connect_provider/)
