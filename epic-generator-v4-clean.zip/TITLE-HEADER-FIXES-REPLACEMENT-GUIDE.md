# Title/Header Fixes Replacement Guide

Apply these changes to 2 files on your remote desktop. Each section shows the **OLD** code to find and the **NEW** code to replace it with.

---

## FILE 1: `src/skills.ts`

### Change 1 of 4 -- Add `sanitizeProjectName()` utility function

**FIND THIS (OLD):**
```typescript
// Small delay for UI feedback
const mockDelay = () => new Promise(resolve => setTimeout(resolve, 300));
```

**REPLACE WITH (NEW):**
```typescript
// Small delay for UI feedback
const mockDelay = () => new Promise(resolve => setTimeout(resolve, 300));

/**
 * Sanitize projectName for use as document title.
 * Ensures the H1 heading is a proper short title, not a long sentence or truncated text.
 * - If <=60 chars and <=8 words, keep as-is
 * - Otherwise truncate to 8 words / 60 chars, removing trailing incomplete words
 */
export function sanitizeProjectName(name: string): string {
  const trimmed = name.trim();
  const words = trimmed.split(/\s+/);

  // Already a reasonable title
  if (trimmed.length <= 60 && words.length <= 8) {
    // Still check for single-char trailing word (truncation artifact)
    if (words.length > 1 && words[words.length - 1].length <= 1) {
      return words.slice(0, -1).join(' ');
    }
    return trimmed;
  }

  // Truncate to first 8 words
  let sanitized = words.slice(0, 8).join(' ');
  if (sanitized.length > 60) {
    sanitized = sanitized.substring(0, 60);
    // Remove trailing partial word
    const lastSpace = sanitized.lastIndexOf(' ');
    if (lastSpace > 10) {
      sanitized = sanitized.substring(0, lastSpace);
    }
  }

  // Remove trailing single-char word (truncation artifact like "e" or "a")
  sanitized = sanitized.replace(/\s+\S{1,2}$/, '').trim();

  return sanitized || 'Untitled Project';
}
```

---

### Change 2 of 4 -- Update `generateEpic()` to use sanitized title + document identity

**FIND THIS (OLD):**
```typescript
// Generate Epic Skill - Creates full 17-section epic
async function generateEpic(data: RefinedData, projectName: string, blueprintCode?: string): Promise<GenerateResult> {
  await mockDelay();

  // Build the epic document - use project name as title
  let epic = `# ${projectName}\n\n`;
  epic += `*Generated on ${new Date().toLocaleDateString()}*\n\n---\n\n`;
```

**REPLACE WITH (NEW):**
```typescript
// Generate Epic Skill - Creates full 17-section epic
async function generateEpic(data: RefinedData, projectName: string, blueprintCode?: string): Promise<GenerateResult> {
  await mockDelay();

  // Sanitize project name for H1 title — prevent sentence-as-title and truncation
  const title = sanitizeProjectName(projectName);

  // Build the epic document with proper document identity
  let epic = `# ${title}\n\n`;

  // Document identity block
  epic += `| | |\n|---|---|\n`;
  epic += `| **Status** | Draft |\n`;
  epic += `| **Owner** | _TBD_ |\n`;
  epic += `| **Last Updated** | ${new Date().toLocaleDateString()} |\n\n`;

  epic += `*Generated on ${new Date().toLocaleDateString()}*\n\n---\n\n`;
```

---

### Change 3 of 4 -- Update `assembleEpicWithEmbedding()` to use sanitized title

**FIND THIS (OLD):**
```typescript
  // Start with title and GitLab TOC
  let epic = `# ${projectName}\n\n`;
  epic += `[[_TOC_]]\n\n`; // GitLab Table of Contents
```

**REPLACE WITH (NEW):**
```typescript
  // Sanitize project name for H1 title — prevent sentence-as-title and truncation
  const title = sanitizeProjectName(projectName);

  // Start with title and GitLab TOC
  let epic = `# ${title}\n\n`;
  epic += `[[_TOC_]]\n\n`; // GitLab Table of Contents
```

---

### Change 4 of 4 -- Stop AI prompts from repeating long project name verbatim

There are **2 occurrences** of this string. Replace **BOTH**.

**FIND THIS (OLD)** (appears twice):
```typescript
Use the exact project name "${projectName}" when referencing the project:
```

**REPLACE WITH (NEW)** (both occurrences):
```typescript
When referencing the project, use a short name (do NOT repeat long sentences as the project name):
```

**Locations** (approximate lines, both in the Stage 4 refinement prompts):
- First: around line 4753 (in `refineExistingSection()`)
- Second: around line 4840 (in `generateMissingSection()`)

---

## FILE 2: `src/categoryTemplates.json`

**No changes needed** -- the Epic Status template already includes proper fields (Status, Owner, etc.). The fix is in the code that generates the epic, not the template.

---

## Summary Checklist

| # | File | What Changed |
|---|------|-------------|
| 1 | `src/skills.ts` ~line 652 | Added `sanitizeProjectName()` exported function |
| 2 | `src/skills.ts` ~line 850 | `generateEpic()` uses sanitized title + document identity block |
| 3 | `src/skills.ts` ~line 5179 | `assembleEpicWithEmbedding()` uses sanitized title |
| 4 | `src/skills.ts` ~line 4753, ~4840 | AI prompts no longer inject verbatim long project names |

**Total: 4 replacements in 1 file (`src/skills.ts`)**

---

## What These Fixes Do

### Issue 1: H1 is not a proper title
**Before:** `# Help GitLab teams turn scattered project context into consistent, high-quality e`
**After:** `# Help GitLab teams turn scattered project`
The `sanitizeProjectName()` function truncates to max 8 words / 60 chars and removes trailing truncated words.

### Issue 2: Project name repeated everywhere
**Before:** AI prompts said "Use the exact project name" causing the full sentence to appear in every section
**After:** Prompts say "use a short name (do NOT repeat long sentences as the project name)"

### Issue 3: No document identity
**Before:** Only `*Generated on 2/18/2026*` after title
**After:** A document identity table is added:
```markdown
| | |
|---|---|
| **Status** | Draft |
| **Owner** | _TBD_ |
| **Last Updated** | 2/18/2026 |
```
