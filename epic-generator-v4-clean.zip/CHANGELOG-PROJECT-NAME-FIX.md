# Project Name Fix in 5-Stage Pipeline - Changelog

**Date:** 2026-02-11
**Issue:** Project name in pipeline output was derived from AI comprehension instead of original epic title

---

## Root Cause

**TWO separate issues were found:**

### Issue 1: Stage 5A (Diagram Generation)
Stage 5A (`runStage5AArchitecture`) was **ignoring** the correct project title and **re-deriving** it from `comprehension.projectEssence`.

### Issue 2: Stage 4 (Section Refinement) - THE MAIN ISSUE
All AI prompts in Stage 4 were receiving:
```
PROJECT: A distributed payment platform that enables real-time transactions...
```
Instead of:
```
PROJECT NAME: Mobile Payment System
```

The `projectEssence` is a "2-3 sentence description" of the project, NOT the actual project name. When AI refined sections, it referenced this description instead of the actual title.

This caused:
1. Diagram generation to use wrong project name
2. Section content to reference project description instead of name
3. Updated epics to appear as "new" content instead of updates
4. Inconsistent naming throughout the refined output

---

## The Bug

**File:** `src/skills.ts`

### Stage 5A Function (Line 4924-4932) - BEFORE

```typescript
async function runStage5AArchitecture(
  refinement: RefinementOutput,
  comprehension: ComprehensionOutput  // ← NO projectName parameter
): Promise<{ diagram: string; type: string }> {
  const refinedData = convertRefinementToRefinedData(refinement);

  // WRONG: Derives project name from AI-generated comprehension summary
  const projectName = comprehension.projectEssence.split(/[.!?]/)[0].substring(0, 50).trim() || 'System';
```

### The Call in Stage 5 (Line 5175) - BEFORE

```typescript
const architecture = await runStage5AArchitecture(refinement, comprehension);
// ← projectName NOT passed!
```

---

## Example of the Bug

| Original Epic Title | AI Comprehension Output | Stage 5A Used |
|---------------------|------------------------|---------------|
| `# Mobile Payment System` | `"A distributed payment platform that enables..."` | `"A distributed payment platform"` ❌ |
| `# Customer Portal Redesign` | `"A modern web application for self-service..."` | `"A modern web application for self-service"` ❌ |

The derived name was a **sentence fragment**, not the actual project title.

---

## The Fix

### Change 1: Add `projectName` Parameter to Stage 5A

**File:** `src/skills.ts`, Line 4924-4932

**BEFORE:**
```typescript
async function runStage5AArchitecture(
  refinement: RefinementOutput,
  comprehension: ComprehensionOutput
): Promise<{ diagram: string; type: string }> {
  const refinedData = convertRefinementToRefinedData(refinement);

  // Extract project name from comprehension
  const projectName = comprehension.projectEssence.split(/[.!?]/)[0].substring(0, 50).trim() || 'System';
```

**AFTER:**
```typescript
async function runStage5AArchitecture(
  refinement: RefinementOutput,
  comprehension: ComprehensionOutput,
  projectName: string  // Use the original project title, not derived from comprehension
): Promise<{ diagram: string; type: string }> {
  const refinedData = convertRefinementToRefinedData(refinement);

  // Use the passed projectName (original epic title) - DO NOT derive from comprehension
  console.log('[Stage 5A] Using project name:', projectName);
```

---

### Change 2: Pass `projectName` When Calling Stage 5A

**File:** `src/skills.ts`, Line 5173-5175

**BEFORE:**
```typescript
  // Run 5A and 5B sequentially to avoid rate limiting
  // Blueprint generation is heavy on tokens, so we run it first
  const architecture = await runStage5AArchitecture(refinement, comprehension);
```

**AFTER:**
```typescript
  // Run 5A and 5B sequentially to avoid rate limiting
  // Blueprint generation is heavy on tokens, so we run it first
  // Pass projectName to ensure diagram uses correct title (not derived from comprehension)
  const architecture = await runStage5AArchitecture(refinement, comprehension, projectName);
```

---

## Project Name Flow - AFTER FIX

```
Epic Loaded: "# Mobile Payment System"
                    ↓
extractProjectTitle() → "Mobile Payment System" ✅
                    ↓
runPremiumPipeline(originalProjectTitle) ✅
                    ↓
runStage5Mandatory(originalProjectTitle) → projectName = "Mobile Payment System" ✅
                    ↓
    ├── runStage5AArchitecture(projectName) → Uses "Mobile Payment System" ✅
    │
    └── assembleEpicWithEmbedding(projectName) → "# Mobile Payment System" ✅
```

Now all stages use the **same correct project name** from the original epic.

---

---

## Additional Fixes: Stage 4 Prompts

### Change 3: Add `projectName` Parameter to Stage 4

**File:** `src/skills.ts`, Line 4774-4780

**BEFORE:**
```typescript
export async function runStage4Refinement(
  epicContent: string,
  comprehension: ComprehensionOutput,
  classification: ClassificationOutput,
  structural: StructuralOutput,
  onProgress?: (current: number, total: number, section: string) => void
): Promise<RefinementOutput> {
```

**AFTER:**
```typescript
export async function runStage4Refinement(
  epicContent: string,
  comprehension: ComprehensionOutput,
  classification: ClassificationOutput,
  structural: StructuralOutput,
  projectName: string,  // Original epic title - used in prompts for consistency
  onProgress?: (current: number, total: number, section: string) => void
): Promise<RefinementOutput> {
```

---

### Change 4: Update `refineSingleSectionDynamic()` Signature and Prompt

**File:** `src/skills.ts`, Line 4586-4592

**BEFORE:**
```typescript
async function refineSingleSectionDynamic(
  section: DiscoveredSection,
  score: SectionScore | undefined,
  transformation: TransformationAction | undefined,
  template: LoadedCategoryTemplate,
  projectEssence: string
): Promise<PipelineRefinedSection> {
```

**AFTER:**
```typescript
async function refineSingleSectionDynamic(
  section: DiscoveredSection,
  score: SectionScore | undefined,
  transformation: TransformationAction | undefined,
  template: LoadedCategoryTemplate,
  projectName: string,      // Actual project title
  projectEssence: string    // Project description for context
): Promise<PipelineRefinedSection> {
```

**Prompt Change (Line 4640-4645):**

**BEFORE:**
```typescript
const userPrompt = `PROJECT: ${projectEssence.substring(0, 300)}

CURRENT CONTENT:
${section.content || '(empty)'}

Refine to target ${target} words (max ${max}):`;
```

**AFTER:**
```typescript
const userPrompt = `PROJECT NAME: ${projectName}
PROJECT CONTEXT: ${projectEssence.substring(0, 200)}

CURRENT CONTENT:
${section.content || '(empty)'}

Refine to target ${target} words (max ${max}). Use the exact project name "${projectName}" when referencing the project:`;
```

---

### Change 5: Update `generateMissingSectionDynamic()` Signature and Prompt

**File:** `src/skills.ts`, Line 4691-4695

**BEFORE:**
```typescript
async function generateMissingSectionDynamic(
  sectionTitle: string,
  comprehension: ComprehensionOutput,
  template: LoadedCategoryTemplate
): Promise<PipelineRefinedSection> {
```

**AFTER:**
```typescript
async function generateMissingSectionDynamic(
  sectionTitle: string,
  comprehension: ComprehensionOutput,
  template: LoadedCategoryTemplate,
  projectName: string  // Actual project title for AI prompts
): Promise<PipelineRefinedSection> {
```

**Prompt Change (Line 4727-4732):**

**BEFORE:**
```typescript
const userPrompt = `PROJECT: ${comprehension.projectEssence}

KEY INFO:
${comprehension.keyEntities.slice(0, 5).map(e => `- ${e.entity}: ${e.description}`).join('\n')}

Generate the section (target ${target} words, max ${max}):`;
```

**AFTER:**
```typescript
const userPrompt = `PROJECT NAME: ${projectName}
PROJECT CONTEXT: ${comprehension.projectEssence.substring(0, 200)}

KEY INFO:
${comprehension.keyEntities.slice(0, 5).map(e => `- ${e.entity}: ${e.description}`).join('\n')}

Generate the section (target ${target} words, max ${max}). Use the exact project name "${projectName}" when referencing the project:`;
```

---

### Change 6: Update Pipeline Call to Stage 4

**File:** `src/skills.ts`, Line 5257-5265

**BEFORE:**
```typescript
const refinement = await runStage4Refinement(
  epicContent,
  comprehension,
  classification,
  structural,
  (current, total, section) => {
    onProgress?.(4, 'running', `Refining section ${current}/${total}: ${section}`);
  }
);
```

**AFTER:**
```typescript
const refinement = await runStage4Refinement(
  epicContent,
  comprehension,
  classification,
  structural,
  originalProjectTitle,  // Pass actual project name
  (current, total, section) => {
    onProgress?.(4, 'running', `Refining section ${current}/${total}: ${section}`);
  }
);
```

---

## Summary

| Item | Details |
|------|---------|
| **Files Changed** | `src/skills.ts` |
| **Functions Modified** | 5 functions updated |
| **Change Type** | Bug fix - project name propagation through all stages |
| **Impact** | Epic updates now preserve original project name in ALL content |

### Functions Modified:

| Function | Change |
|----------|--------|
| `runStage4Refinement()` | Added `projectName` parameter |
| `refineSingleSectionDynamic()` | Added `projectName` + updated prompt |
| `generateMissingSectionDynamic()` | Added `projectName` + updated prompt |
| `runStage5AArchitecture()` | Now uses passed `projectName` |
| `runPremiumPipeline()` | Passes `originalProjectTitle` to Stage 4 |

---

## Project Name Flow - AFTER ALL FIXES

```
Epic Loaded: "# Mobile Payment System"
                    ↓
extractProjectTitle() → "Mobile Payment System" ✅
                    ↓
runPremiumPipeline(originalProjectTitle) ✅
                    ↓
runStage4Refinement(projectName) → All prompts use "Mobile Payment System" ✅
    ├── refineSingleSectionDynamic(projectName) → Uses "Mobile Payment System" ✅
    └── generateMissingSectionDynamic(projectName) → Uses "Mobile Payment System" ✅
                    ↓
runStage5Mandatory(originalProjectTitle) ✅
    ├── runStage5AArchitecture(projectName) → Diagram uses "Mobile Payment System" ✅
    └── assembleEpicWithEmbedding(projectName) → Title is "# Mobile Payment System" ✅
```

---

## Verification

After this fix:
1. Load an existing epic (e.g., "Customer Portal Redesign")
2. Run the Premium Pipeline (⊕ Refine button)
3. The refined epic will have the **same title** as the original
4. **All section content** will reference "Customer Portal Redesign" (not a description)
5. Diagram will reference the correct project name
6. Updating the epic will correctly update the existing epic, not create a new one
