import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3002,
    proxy: {
      // Proxy GitLab API requests to bypass CORS
      '/gitlab-api': {
        target: 'http://devcloud.ubs.net',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/gitlab-api/, '/api/v4'),
        secure: false,
      }
    }
  }
})
