// ===========================================
// FRAME TEMPLATE SCHEMA
// Template-Driven Document Generation System
// ===========================================

// ===========================================
// CORE TEMPLATE INTERFACE
// ===========================================

export interface Template {
  // Metadata
  id: string;
  name: string;
  description: string;
  version: string;
  icon: string;
  category: TemplateCategory;
  author: string;
  createdAt: string;
  updatedAt: string;
  isBuiltIn: boolean;
  tags: string[];

  // Structure
  stages: TemplateStage[];
  sections: TemplateSection[];

  // AI Configuration
  aiConfig: TemplateAIConfig;

  // Diagram Configuration
  diagramConfig: TemplateDiagramConfig;

  // Output Configuration
  outputConfig: TemplateOutputConfig;

  // Branding (optional)
  branding?: TemplateBranding;
}

export type TemplateCategory =
  | 'architecture'
  | 'product'
  | 'agile'
  | 'operations'
  | 'documentation'
  | 'custom';

// ===========================================
// STAGE DEFINITIONS (Input Form)
// ===========================================

export interface TemplateStage {
  id: string;
  title: string;
  description: string;
  icon?: string;
  order: number;
  fields: TemplateField[];
  populatesSections: string[];
  showIf?: FieldCondition;
}

export interface TemplateField {
  id: string;
  name: string;
  label: string;
  description?: string;
  placeholder: string;
  type: FieldType;
  required: boolean;
  validation?: FieldValidation;
  defaultValue?: string;
  showIf?: FieldCondition;
  aiAssist: FieldAIConfig;

  // For select/multiselect fields
  options?: FieldOption[];

  // For table fields
  tableConfig?: TableFieldConfig;
}

export type FieldType =
  | 'text'
  | 'textarea'
  | 'richtext'
  | 'select'
  | 'multiselect'
  | 'date'
  | 'number'
  | 'toggle'
  | 'tags'
  | 'table';

export interface FieldOption {
  value: string;
  label: string;
  description?: string;
}

export interface TableFieldConfig {
  columns: TableColumn[];
  minRows?: number;
  maxRows?: number;
  allowAddRows: boolean;
  allowDeleteRows: boolean;
}

export interface TableColumn {
  key: string;
  header: string;
  type: 'text' | 'select' | 'number';
  width?: string;
  options?: FieldOption[]; // For select type
}

export interface FieldValidation {
  minLength?: number;
  maxLength?: number;
  pattern?: string;
  patternMessage?: string;
  min?: number; // For number fields
  max?: number; // For number fields
}

export interface FieldCondition {
  field: string;
  operator: 'equals' | 'notEquals' | 'contains' | 'isEmpty' | 'isNotEmpty' | 'greaterThan' | 'lessThan';
  value?: string | number;
}

export interface FieldAIConfig {
  enabled: boolean;
  systemPrompt: string;
  userPromptTemplate: string;
  refinementTemplate?: string;
  generateDiagramNode?: boolean;
  diagramNodeTemplate?: string;
}

// ===========================================
// SECTION DEFINITIONS (Output Structure)
// ===========================================

export interface TemplateSection {
  id: string;
  number: number;
  title: string;
  dataKeys: string[];
  renderType: SectionRenderType;
  subsections?: SubsectionConfig[];
  showIf?: FieldCondition;
  template?: string; // Custom Mustache/Handlebars template
}

export type SectionRenderType =
  | 'markdown'
  | 'table'
  | 'bulletList'
  | 'numberedList'
  | 'diagram'
  | 'reference'
  | 'custom';

export interface SubsectionConfig {
  title: string;
  dataKey: string;
  renderType?: SectionRenderType;
}

// ===========================================
// AI CONFIGURATION
// ===========================================

export interface TemplateAIConfig {
  defaultSystemPrompt: string;
  contextFields: string[];
  fieldPrompts: Record<string, FieldAIConfig>;
  refinementRules: Record<string, RefinementRule>;
  documentPrompts: DocumentAIPrompts;
}

export interface RefinementRule {
  preProcess?: string;
  format: 'bullets' | 'numbered' | 'paragraphs' | 'table' | 'preserve';
  wrapWith?: string;
  addPrefix?: string;
  addSuffix?: string;
  diagramNode?: DiagramNodeConfig;
}

export interface DiagramNodeConfig {
  enabled: boolean;
  template: string;
  shape?: 'box' | 'rounded' | 'circle' | 'diamond' | 'hexagon' | 'stadium' | 'cylinder';
}

export interface DocumentAIPrompts {
  summarize: string;
  review: string;
  enhance: string;
}

// ===========================================
// DIAGRAM CONFIGURATION
// ===========================================

export interface TemplateDiagramConfig {
  enabled: boolean;
  primaryType: DiagramType;
  availableTypes: DiagramType[];
  generators: Record<string, DiagramGenerator>;
  defaultTheme: MermaidTheme;
  customStyles?: string;
}

export type DiagramType =
  | 'flowchart'
  | 'sequence'
  | 'c4-container'
  | 'c4-component'
  | 'deployment'
  | 'er'
  | 'gantt'
  | 'mindmap'
  | 'timeline'
  | 'state'
  | 'class'
  | 'custom';

export type MermaidTheme = 'default' | 'forest' | 'dark' | 'neutral' | 'base';

export interface DiagramGenerator {
  type: DiagramType;
  template: string;
  fieldMappings: Record<string, string>;
  staticElements?: string[];
  direction?: 'TB' | 'BT' | 'LR' | 'RL';
  title?: string;
}

// ===========================================
// OUTPUT CONFIGURATION
// ===========================================

export interface TemplateOutputConfig {
  primaryFormat: OutputFormat;
  documentTemplate: string;
  headerTemplate?: string;
  footerTemplate?: string;
  exportFormats: ExportConfig[];
  includeMetadata: boolean;
  metadataFields?: string[];
}

export type OutputFormat = 'markdown' | 'html' | 'pdf' | 'docx';

export interface ExportConfig {
  id: string;
  name: string;
  format: OutputFormat;
  extension: string;
  enabled: boolean;
  handler?: string;
}

// ===========================================
// BRANDING CONFIGURATION
// ===========================================

export interface TemplateBranding {
  primaryColor: string;
  secondaryColor: string;
  accentColor?: string;
  logoUrl?: string;
  logoPosition?: 'header' | 'footer' | 'both';
  fontFamily?: string;
  customStyles?: string;
}

// ===========================================
// FORM DATA & STATE
// ===========================================

export interface RefinedFieldData {
  original: string;
  refined: string;
  diagramNode?: string;
  metadata?: Record<string, unknown>;
}

export interface FormData {
  [fieldName: string]: RefinedFieldData;
}

export interface TemplateState {
  templateId: string;
  currentStage: number;
  data: FormData;
  diagramNodes: string[];
  generatedDocument: string | null;
  lastSaved: string | null;
}

// ===========================================
// TEMPLATE STORE TYPES
// ===========================================

export interface TemplateStore {
  templates: Record<string, Template>;
  activeTemplateId: string | null;
  recentTemplates: string[];
}

export interface TemplateMetadata {
  id: string;
  name: string;
  description: string;
  icon: string;
  category: TemplateCategory;
  stageCount: number;
  sectionCount: number;
  isBuiltIn: boolean;
  updatedAt: string;
}

// ===========================================
// VALIDATION TYPES
// ===========================================

export interface ValidationResult {
  valid: boolean;
  errors: ValidationError[];
  warnings: ValidationWarning[];
}

export interface ValidationError {
  path: string;
  message: string;
  code: string;
}

export interface ValidationWarning {
  path: string;
  message: string;
  suggestion?: string;
}

// ===========================================
// HELPER FUNCTIONS
// ===========================================

/**
 * Create a new empty template with default values
 */
export function createEmptyTemplate(name: string, category: TemplateCategory = 'custom'): Template {
  const now = new Date().toISOString();
  return {
    id: generateTemplateId(),
    name,
    description: '',
    version: '1.0.0',
    icon: getDefaultIcon(category),
    category,
    author: 'User',
    createdAt: now,
    updatedAt: now,
    isBuiltIn: false,
    tags: [],
    stages: [],
    sections: [],
    aiConfig: createDefaultAIConfig(),
    diagramConfig: createDefaultDiagramConfig(),
    outputConfig: createDefaultOutputConfig(),
  };
}

/**
 * Generate a unique template ID
 */
export function generateTemplateId(): string {
  return `tpl-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

/**
 * Get default icon for a category
 */
export function getDefaultIcon(category: TemplateCategory): string {
  const icons: Record<TemplateCategory, string> = {
    architecture: '🏗️',
    product: '📋',
    agile: '🏃',
    operations: '🔧',
    documentation: '📝',
    custom: '✨',
  };
  return icons[category] || '📄';
}

/**
 * Create default AI configuration
 */
export function createDefaultAIConfig(): TemplateAIConfig {
  return {
    defaultSystemPrompt: 'You are a helpful assistant for generating professional documentation.',
    contextFields: [],
    fieldPrompts: {},
    refinementRules: {},
    documentPrompts: {
      summarize: 'Summarize the following document in 2-3 paragraphs.',
      review: 'Review the following document and suggest improvements.',
      enhance: 'Enhance the following document with more detail and clarity.',
    },
  };
}

/**
 * Create default diagram configuration
 */
export function createDefaultDiagramConfig(): TemplateDiagramConfig {
  return {
    enabled: true,
    primaryType: 'flowchart',
    availableTypes: ['flowchart', 'sequence', 'c4-container'],
    generators: {},
    defaultTheme: 'default',
  };
}

/**
 * Create default output configuration
 */
export function createDefaultOutputConfig(): TemplateOutputConfig {
  return {
    primaryFormat: 'markdown',
    documentTemplate: '# {{projectName}}\n\n{{#sections}}## {{number}}. {{title}}\n\n{{content}}\n\n{{/sections}}',
    exportFormats: [
      { id: 'md', name: 'Markdown', format: 'markdown', extension: '.md', enabled: true },
      { id: 'html', name: 'HTML', format: 'html', extension: '.html', enabled: true },
    ],
    includeMetadata: true,
    metadataFields: ['projectName', 'author', 'createdAt'],
  };
}

/**
 * Create a new field with default values
 */
export function createDefaultField(name: string, type: FieldType = 'textarea'): TemplateField {
  return {
    id: `field-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
    name,
    label: name.charAt(0).toUpperCase() + name.slice(1).replace(/([A-Z])/g, ' $1'),
    placeholder: `Enter ${name}...`,
    type,
    required: false,
    aiAssist: {
      enabled: true,
      systemPrompt: 'You are a helpful assistant.',
      userPromptTemplate: 'Help me write content for {{fieldName}}.',
    },
  };
}

/**
 * Create a new stage with default values
 */
export function createDefaultStage(title: string, order: number): TemplateStage {
  return {
    id: `stage-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
    title,
    description: '',
    order,
    fields: [],
    populatesSections: [],
  };
}

/**
 * Create a new section with default values
 */
export function createDefaultSection(title: string, number: number): TemplateSection {
  return {
    id: `section-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
    number,
    title,
    dataKeys: [],
    renderType: 'markdown',
  };
}

/**
 * Get template metadata for gallery display
 */
export function getTemplateMetadata(template: Template): TemplateMetadata {
  return {
    id: template.id,
    name: template.name,
    description: template.description,
    icon: template.icon,
    category: template.category,
    stageCount: template.stages.length,
    sectionCount: template.sections.length,
    isBuiltIn: template.isBuiltIn,
    updatedAt: template.updatedAt,
  };
}

/**
 * Clone a template with a new ID
 */
export function cloneTemplate(template: Template, newName?: string): Template {
  const now = new Date().toISOString();
  return {
    ...JSON.parse(JSON.stringify(template)), // Deep clone
    id: generateTemplateId(),
    name: newName || `${template.name} (Copy)`,
    isBuiltIn: false,
    createdAt: now,
    updatedAt: now,
  };
}

/**
 * Validate a template structure
 */
export function validateTemplate(template: Template): ValidationResult {
  const errors: ValidationError[] = [];
  const warnings: ValidationWarning[] = [];

  // Required fields
  if (!template.id) errors.push({ path: 'id', message: 'Template ID is required', code: 'REQUIRED' });
  if (!template.name) errors.push({ path: 'name', message: 'Template name is required', code: 'REQUIRED' });
  if (!template.stages || template.stages.length === 0) {
    errors.push({ path: 'stages', message: 'At least one stage is required', code: 'MIN_LENGTH' });
  }
  if (!template.sections || template.sections.length === 0) {
    errors.push({ path: 'sections', message: 'At least one section is required', code: 'MIN_LENGTH' });
  }

  // Validate stages
  template.stages?.forEach((stage, i) => {
    if (!stage.id) errors.push({ path: `stages[${i}].id`, message: 'Stage ID is required', code: 'REQUIRED' });
    if (!stage.title) errors.push({ path: `stages[${i}].title`, message: 'Stage title is required', code: 'REQUIRED' });
    if (!stage.fields || stage.fields.length === 0) {
      warnings.push({ path: `stages[${i}].fields`, message: 'Stage has no fields', suggestion: 'Add at least one field' });
    }

    // Validate fields
    stage.fields?.forEach((field, j) => {
      if (!field.id) errors.push({ path: `stages[${i}].fields[${j}].id`, message: 'Field ID is required', code: 'REQUIRED' });
      if (!field.name) errors.push({ path: `stages[${i}].fields[${j}].name`, message: 'Field name is required', code: 'REQUIRED' });
    });
  });

  // Validate sections
  template.sections?.forEach((section, i) => {
    if (!section.id) errors.push({ path: `sections[${i}].id`, message: 'Section ID is required', code: 'REQUIRED' });
    if (!section.title) errors.push({ path: `sections[${i}].title`, message: 'Section title is required', code: 'REQUIRED' });
    if (section.dataKeys.length === 0 && section.renderType !== 'reference') {
      warnings.push({ path: `sections[${i}].dataKeys`, message: 'Section has no data keys', suggestion: 'Link to form fields' });
    }
  });

  // Check for orphaned data keys
  const allFieldNames = new Set(template.stages?.flatMap(s => s.fields?.map(f => f.name) || []) || []);
  template.sections?.forEach((section, i) => {
    section.dataKeys.forEach(key => {
      if (!allFieldNames.has(key)) {
        warnings.push({
          path: `sections[${i}].dataKeys`,
          message: `Data key "${key}" does not match any field`,
          suggestion: 'Ensure data keys match field names',
        });
      }
    });
  });

  return {
    valid: errors.length === 0,
    errors,
    warnings,
  };
}
