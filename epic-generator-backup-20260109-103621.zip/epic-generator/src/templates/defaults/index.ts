// ===========================================
// FRAME BUILT-IN TEMPLATES
// Default templates that ship with the application
// ===========================================

import { Template } from '../schema';

// ===========================================
// ARCHITECT EPIC TEMPLATE
// The original 17-section architecture documentation
// ===========================================

export const architectTemplate: Template = {
  id: 'architect-epic',
  name: 'Architect Epic',
  description: 'Comprehensive technical architecture documentation with 17 sections covering objectives, scope, architecture, features, and delivery.',
  version: '1.0.0',
  icon: '🏗️',
  category: 'architecture',
  author: 'FRAME Team',
  createdAt: '2025-01-01T00:00:00.000Z',
  updatedAt: '2025-01-01T00:00:00.000Z',
  isBuiltIn: true,
  tags: ['architecture', 'epic', 'technical', 'documentation', 'enterprise'],

  // ===========================================
  // STAGES (Input Form - 6 Stages)
  // ===========================================
  stages: [
    {
      id: 'project',
      title: 'Project',
      description: 'Project name and background context',
      icon: '📋',
      order: 1,
      populatesSections: ['objective', 'background'],
      fields: [
        {
          id: 'projectName',
          name: 'projectName',
          label: 'Project Name',
          placeholder: 'Enter the project name (2-4 words)',
          type: 'text',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a project naming expert. Generate a professional, concise project name.',
            userPromptTemplate: 'Generate a professional project name for: {{input}}',
            generateDiagramNode: true,
            diagramNodeTemplate: 'Project["{{value}}"]',
          },
        },
        {
          id: 'background',
          name: 'background',
          label: 'Background & Context',
          placeholder: 'Describe the business context, problem statement, and why this initiative exists...',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a technical writer. Generate clear, professional background context.',
            userPromptTemplate: 'Write a comprehensive background section for a project about: {{input}}',
            generateDiagramNode: true,
            diagramNodeTemplate: 'Context["Background & Context"]',
          },
        },
      ],
    },
    {
      id: 'objective_scope',
      title: 'Objective & Scope',
      description: 'Define objectives and what is in/out of scope',
      icon: '🎯',
      order: 2,
      populatesSections: ['objective', 'scope'],
      fields: [
        {
          id: 'objective',
          name: 'objective',
          label: 'Objective',
          placeholder: 'What is the primary goal of this initiative?',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a product strategist. Write clear, measurable objectives.',
            userPromptTemplate: 'Write a clear objective statement for: {{input}}',
            generateDiagramNode: true,
            diagramNodeTemplate: 'Objective["Primary Objective"]',
          },
        },
        {
          id: 'inScope',
          name: 'inScope',
          label: 'In Scope',
          placeholder: 'List items that ARE included in this initiative...',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a project manager. Create clear scope definitions.',
            userPromptTemplate: 'Define what is IN scope for: {{input}}',
          },
        },
        {
          id: 'outOfScope',
          name: 'outOfScope',
          label: 'Out of Scope',
          placeholder: 'List items that are NOT included in this initiative...',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a project manager. Define clear exclusions.',
            userPromptTemplate: 'Define what is OUT of scope for: {{input}}',
          },
        },
      ],
    },
    {
      id: 'architecture',
      title: 'Architecture',
      description: 'Technical architecture and data considerations',
      icon: '🏛️',
      order: 3,
      populatesSections: ['assumptions', 'architectureOverview', 'architectureDiagrams', 'dataStores'],
      fields: [
        {
          id: 'assumptions',
          name: 'assumptions',
          label: 'Assumptions',
          placeholder: 'List key assumptions for this initiative...',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a solutions architect. Identify key technical and business assumptions.',
            userPromptTemplate: 'List key assumptions for: {{input}}',
          },
        },
        {
          id: 'architectureOverview',
          name: 'architectureOverview',
          label: 'High-Level Architecture Overview',
          placeholder: 'Describe the overall system architecture...',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a solutions architect. Describe system architecture clearly.',
            userPromptTemplate: 'Describe the high-level architecture for: {{input}}',
            generateDiagramNode: true,
            diagramNodeTemplate: 'Architecture["System Architecture"]',
          },
        },
        {
          id: 'dataStores',
          name: 'dataStores',
          label: 'Data Stores, Services & Interfaces',
          placeholder: 'List databases, services, APIs, and interfaces...',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a data architect. Define data stores and integrations.',
            userPromptTemplate: 'Define data stores and services for: {{input}}',
            generateDiagramNode: true,
            diagramNodeTemplate: 'DataStores[("Data & Services")]',
          },
        },
      ],
    },
    {
      id: 'features',
      title: 'Features',
      description: 'Key features, user stories, and requirements',
      icon: '✨',
      order: 4,
      populatesSections: ['features', 'nfrs', 'deliverables'],
      fields: [
        {
          id: 'features',
          name: 'features',
          label: 'Key Features & User Stories',
          placeholder: 'List key features and user stories...',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a product owner. Write clear user stories and features.',
            userPromptTemplate: 'Write user stories and features for: {{input}}',
            generateDiagramNode: true,
            diagramNodeTemplate: 'Features["Key Features"]',
          },
        },
        {
          id: 'userStories',
          name: 'userStories',
          label: 'Detailed User Stories',
          placeholder: 'As a [user], I want [action] so that [benefit]...',
          type: 'textarea',
          required: false,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a product owner. Write detailed user stories in standard format.',
            userPromptTemplate: 'Write detailed user stories for: {{input}}',
          },
        },
        {
          id: 'nfrs',
          name: 'nfrs',
          label: 'Non-Functional Requirements (NFRs)',
          placeholder: 'List performance, security, scalability requirements...',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a solutions architect. Define comprehensive NFRs.',
            userPromptTemplate: 'Define NFRs for: {{input}}',
            generateDiagramNode: true,
            diagramNodeTemplate: 'NFRs{{"Non-Functional Requirements"}}',
          },
        },
        {
          id: 'deliverables',
          name: 'deliverables',
          label: 'Deliverables',
          placeholder: 'List expected deliverables...',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a project manager. Define clear deliverables.',
            userPromptTemplate: 'Define deliverables for: {{input}}',
            generateDiagramNode: true,
            diagramNodeTemplate: 'Deliverables["Deliverables"]',
          },
        },
      ],
    },
    {
      id: 'team_env',
      title: 'Team & Environment',
      description: 'Team structure, environments, and security',
      icon: '👥',
      order: 5,
      populatesSections: ['teams', 'environments', 'security'],
      fields: [
        {
          id: 'teams',
          name: 'teams',
          label: 'Team & Roles',
          placeholder: 'List team members, roles, and responsibilities...',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are an engineering manager. Define team structure and roles.',
            userPromptTemplate: 'Define team structure for: {{input}}',
          },
        },
        {
          id: 'environments',
          name: 'environments',
          label: 'Environments & CI/CD Strategy',
          placeholder: 'Describe environments (DEV, STG, PROD) and deployment strategy...',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a DevOps engineer. Define environment and CI/CD strategy.',
            userPromptTemplate: 'Define environments and CI/CD for: {{input}}',
            generateDiagramNode: true,
            diagramNodeTemplate: 'Environments["DEV / STG / PROD"]',
          },
        },
        {
          id: 'security',
          name: 'security',
          label: 'Data Security & Access Controls',
          placeholder: 'Describe security requirements, access controls, and compliance...',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a security architect. Define security and access controls.',
            userPromptTemplate: 'Define security requirements for: {{input}}',
            generateDiagramNode: true,
            diagramNodeTemplate: 'Security{{"Security & Access"}}',
          },
        },
      ],
    },
    {
      id: 'delivery',
      title: 'Delivery',
      description: 'Dependencies, risks, and next steps',
      icon: '🚀',
      order: 6,
      populatesSections: ['dependencies', 'nextSteps', 'dod', 'approvers'],
      fields: [
        {
          id: 'dependencies',
          name: 'dependencies',
          label: 'Dependencies',
          placeholder: 'List external dependencies...',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a project manager. Identify dependencies.',
            userPromptTemplate: 'Identify dependencies for: {{input}}',
          },
        },
        {
          id: 'risks',
          name: 'risks',
          label: 'Risks',
          placeholder: 'List potential risks and mitigations...',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a risk analyst. Identify risks and mitigations.',
            userPromptTemplate: 'Identify risks for: {{input}}',
          },
        },
        {
          id: 'nextSteps',
          name: 'nextSteps',
          label: 'Next Steps',
          placeholder: 'List immediate next steps...',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a project manager. Define clear next steps.',
            userPromptTemplate: 'Define next steps for: {{input}}',
          },
        },
        {
          id: 'dod',
          name: 'dod',
          label: 'Definition of Done (DoD)',
          placeholder: 'Define when this initiative is considered complete...',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are an agile coach. Define clear definition of done.',
            userPromptTemplate: 'Define Definition of Done for: {{input}}',
          },
        },
        {
          id: 'approvers',
          name: 'approvers',
          label: 'Approvals & Sign-Offs',
          placeholder: 'List stakeholders who need to approve this initiative...',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a project manager. Identify approvers and stakeholders.',
            userPromptTemplate: 'Identify approvers for: {{input}}',
          },
        },
      ],
    },
  ],

  // ===========================================
  // SECTIONS (Output Structure - 17 Sections)
  // ===========================================
  sections: [
    { id: 'objective', number: 1, title: 'Objective', dataKeys: ['objective'], renderType: 'markdown' },
    { id: 'background', number: 2, title: 'Background & Context', dataKeys: ['background'], renderType: 'markdown' },
    {
      id: 'scope',
      number: 3,
      title: 'Scope',
      dataKeys: ['inScope', 'outOfScope'],
      renderType: 'markdown',
      subsections: [
        { title: 'In Scope', dataKey: 'inScope' },
        { title: 'Out of Scope', dataKey: 'outOfScope' },
      ],
    },
    { id: 'assumptions', number: 4, title: 'Assumptions', dataKeys: ['assumptions'], renderType: 'bulletList' },
    { id: 'architectureOverview', number: 5, title: 'High-Level Architecture Overview', dataKeys: ['architectureOverview'], renderType: 'diagram' },
    { id: 'architectureDiagrams', number: 6, title: 'Architecture Diagrams', dataKeys: [], renderType: 'reference' },
    { id: 'teams', number: 7, title: 'Team & Roles', dataKeys: ['teams'], renderType: 'table' },
    { id: 'environments', number: 8, title: 'Environments & CI/CD Strategy', dataKeys: ['environments'], renderType: 'markdown' },
    { id: 'security', number: 9, title: 'Data Security & Access Controls', dataKeys: ['security'], renderType: 'markdown' },
    { id: 'dataStores', number: 10, title: 'Data Stores, Services & Interfaces', dataKeys: ['dataStores'], renderType: 'markdown' },
    { id: 'features', number: 11, title: 'Key Features & User Stories', dataKeys: ['features', 'userStories'], renderType: 'markdown' },
    { id: 'nfrs', number: 12, title: 'Non-Functional Requirements (NFRs)', dataKeys: ['nfrs'], renderType: 'bulletList' },
    {
      id: 'dependencies',
      number: 13,
      title: 'Dependencies & Risks',
      dataKeys: ['dependencies', 'risks'],
      renderType: 'markdown',
      subsections: [
        { title: 'Dependencies', dataKey: 'dependencies' },
        { title: 'Risks', dataKey: 'risks' },
      ],
    },
    { id: 'deliverables', number: 14, title: 'Deliverables', dataKeys: ['deliverables'], renderType: 'bulletList' },
    { id: 'nextSteps', number: 15, title: 'Next Steps', dataKeys: ['nextSteps'], renderType: 'numberedList' },
    { id: 'dod', number: 16, title: 'Definition of Done (DoD)', dataKeys: ['dod'], renderType: 'bulletList' },
    { id: 'approvers', number: 17, title: 'Approvals & Sign-Offs', dataKeys: ['approvers'], renderType: 'table' },
  ],

  // ===========================================
  // AI CONFIGURATION
  // ===========================================
  aiConfig: {
    defaultSystemPrompt: `You are an expert technical writer and solutions architect helping to create comprehensive project documentation.
Your responses should be professional, clear, and suitable for enterprise documentation.
Focus on clarity, completeness, and actionable content.`,
    contextFields: ['projectName', 'objective', 'background'],
    fieldPrompts: {},
    refinementRules: {
      default: {
        format: 'bullets',
        diagramNode: { enabled: false, template: '', shape: 'box' },
      },
    },
    documentPrompts: {
      summarize: 'Create an executive summary of this architecture document in 2-3 paragraphs.',
      review: 'Review this architecture document and suggest improvements for clarity and completeness.',
      enhance: 'Enhance this architecture document with additional technical details and best practices.',
    },
  },

  // ===========================================
  // DIAGRAM CONFIGURATION
  // ===========================================
  diagramConfig: {
    enabled: true,
    primaryType: 'c4-container',
    availableTypes: ['c4-container', 'c4-component', 'flowchart', 'sequence', 'deployment'],
    generators: {
      'c4-container': {
        type: 'c4-container',
        template: `C4Container
  title System Architecture - {{projectName}}

  Person(user, "User", "End user of the system")

  System_Boundary(system, "{{projectName}}") {
    Container(frontend, "Web Application", "React", "User interface")
    Container(api, "API Service", "Node.js", "Backend API")
    Container(db, "Database", "PostgreSQL", "Data storage")
  }

  System_Ext(external, "External Services", "Third-party integrations")

  Rel(user, frontend, "Uses")
  Rel(frontend, api, "API calls")
  Rel(api, db, "Reads/Writes")
  Rel(api, external, "Integrates")`,
        fieldMappings: {
          projectName: 'title',
          architectureOverview: 'containers',
          dataStores: 'databases',
        },
        direction: 'TB',
      },
      flowchart: {
        type: 'flowchart',
        template: `flowchart TB
  subgraph "{{projectName}}"
    A[User] --> B[Frontend]
    B --> C[API Layer]
    C --> D[(Database)]
  end`,
        fieldMappings: {},
        direction: 'TB',
      },
    },
    defaultTheme: 'default',
  },

  // ===========================================
  // OUTPUT CONFIGURATION
  // ===========================================
  outputConfig: {
    primaryFormat: 'markdown',
    documentTemplate: `# {{projectName}} - Architecture Epic

{{#sections}}
## {{number}}. {{title}}

{{content}}

{{/sections}}

---
*Generated by FRAME - Flexible Rules & Architecture Modeling Engine*
`,
    headerTemplate: `# {{projectName}}
**Version:** 1.0 | **Date:** {{date}} | **Author:** {{author}}

---`,
    exportFormats: [
      { id: 'md', name: 'Markdown', format: 'markdown', extension: '.md', enabled: true },
      { id: 'html', name: 'HTML', format: 'html', extension: '.html', enabled: true },
    ],
    includeMetadata: true,
    metadataFields: ['projectName', 'version', 'createdAt'],
  },

  // ===========================================
  // BRANDING
  // ===========================================
  branding: {
    primaryColor: '#E60000',      // UBS Red
    secondaryColor: '#1C1C1C',    // Cod Gray
    accentColor: '#CC0000',
  },
};

// ===========================================
// PRODUCT BRIEF TEMPLATE (Placeholder)
// ===========================================

export const productBriefTemplate: Template = {
  id: 'product-brief',
  name: 'Product Brief',
  description: 'Product requirements document for feature planning with user stories and success metrics.',
  version: '1.0.0',
  icon: '📋',
  category: 'product',
  author: 'FRAME Team',
  createdAt: '2025-01-01T00:00:00.000Z',
  updatedAt: '2025-01-01T00:00:00.000Z',
  isBuiltIn: true,
  tags: ['product', 'requirements', 'prd', 'features'],

  stages: [
    {
      id: 'problem',
      title: 'Problem',
      description: 'Define the problem and target users',
      icon: '🎯',
      order: 1,
      populatesSections: ['problem', 'users'],
      fields: [
        {
          id: 'problemStatement',
          name: 'problemStatement',
          label: 'Problem Statement',
          placeholder: 'What problem are we solving?',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a product manager. Write clear problem statements.',
            userPromptTemplate: 'Write a problem statement for: {{input}}',
          },
        },
        {
          id: 'targetUsers',
          name: 'targetUsers',
          label: 'Target Users',
          placeholder: 'Who are the target users?',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a UX researcher. Define target user personas.',
            userPromptTemplate: 'Define target users for: {{input}}',
          },
        },
      ],
    },
    {
      id: 'solution',
      title: 'Solution',
      description: 'Proposed solution and features',
      icon: '💡',
      order: 2,
      populatesSections: ['solution', 'features'],
      fields: [
        {
          id: 'proposedSolution',
          name: 'proposedSolution',
          label: 'Proposed Solution',
          placeholder: 'How will we solve this problem?',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a product manager. Describe the proposed solution.',
            userPromptTemplate: 'Describe solution for: {{input}}',
          },
        },
        {
          id: 'keyFeatures',
          name: 'keyFeatures',
          label: 'Key Features',
          placeholder: 'List the key features...',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a product owner. List key features.',
            userPromptTemplate: 'List features for: {{input}}',
          },
        },
      ],
    },
    {
      id: 'success',
      title: 'Success',
      description: 'Success metrics and acceptance criteria',
      icon: '📊',
      order: 3,
      populatesSections: ['metrics', 'acceptance'],
      fields: [
        {
          id: 'successMetrics',
          name: 'successMetrics',
          label: 'Success Metrics',
          placeholder: 'How will we measure success?',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a product analyst. Define measurable success metrics.',
            userPromptTemplate: 'Define success metrics for: {{input}}',
          },
        },
        {
          id: 'acceptanceCriteria',
          name: 'acceptanceCriteria',
          label: 'Acceptance Criteria',
          placeholder: 'What are the acceptance criteria?',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a QA engineer. Write acceptance criteria.',
            userPromptTemplate: 'Write acceptance criteria for: {{input}}',
          },
        },
      ],
    },
    {
      id: 'delivery',
      title: 'Delivery',
      description: 'Dependencies and timeline',
      icon: '🚀',
      order: 4,
      populatesSections: ['dependencies', 'timeline'],
      fields: [
        {
          id: 'dependencies',
          name: 'dependencies',
          label: 'Dependencies',
          placeholder: 'List dependencies...',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a project manager. Identify dependencies.',
            userPromptTemplate: 'Identify dependencies for: {{input}}',
          },
        },
        {
          id: 'timeline',
          name: 'timeline',
          label: 'Timeline',
          placeholder: 'Describe the timeline...',
          type: 'textarea',
          required: false,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a project manager. Outline a realistic timeline.',
            userPromptTemplate: 'Outline timeline for: {{input}}',
          },
        },
      ],
    },
  ],

  sections: [
    { id: 'problem', number: 1, title: 'Problem Statement', dataKeys: ['problemStatement'], renderType: 'markdown' },
    { id: 'users', number: 2, title: 'Target Users', dataKeys: ['targetUsers'], renderType: 'markdown' },
    { id: 'solution', number: 3, title: 'Proposed Solution', dataKeys: ['proposedSolution'], renderType: 'markdown' },
    { id: 'features', number: 4, title: 'Key Features', dataKeys: ['keyFeatures'], renderType: 'bulletList' },
    { id: 'metrics', number: 5, title: 'Success Metrics', dataKeys: ['successMetrics'], renderType: 'bulletList' },
    { id: 'acceptance', number: 6, title: 'Acceptance Criteria', dataKeys: ['acceptanceCriteria'], renderType: 'numberedList' },
    { id: 'dependencies', number: 7, title: 'Dependencies', dataKeys: ['dependencies'], renderType: 'bulletList' },
    { id: 'timeline', number: 8, title: 'Timeline', dataKeys: ['timeline'], renderType: 'markdown' },
  ],

  aiConfig: {
    defaultSystemPrompt: 'You are a product manager helping to create product briefs.',
    contextFields: ['problemStatement', 'proposedSolution'],
    fieldPrompts: {},
    refinementRules: {},
    documentPrompts: {
      summarize: 'Summarize this product brief.',
      review: 'Review this product brief and suggest improvements.',
      enhance: 'Enhance this product brief with more detail.',
    },
  },

  diagramConfig: {
    enabled: false,
    primaryType: 'flowchart',
    availableTypes: ['flowchart'],
    generators: {},
    defaultTheme: 'default',
  },

  outputConfig: {
    primaryFormat: 'markdown',
    documentTemplate: '# Product Brief\n\n{{#sections}}## {{number}}. {{title}}\n\n{{content}}\n\n{{/sections}}',
    exportFormats: [
      { id: 'md', name: 'Markdown', format: 'markdown', extension: '.md', enabled: true },
    ],
    includeMetadata: true,
  },

  branding: {
    primaryColor: '#2563eb',
    secondaryColor: '#1e40af',
  },
};

// ===========================================
// SPRINT PLAN TEMPLATE (Placeholder)
// ===========================================

export const sprintPlanTemplate: Template = {
  id: 'sprint-plan',
  name: 'Sprint Plan',
  description: 'Agile sprint planning document with goals, backlog, and definition of done.',
  version: '1.0.0',
  icon: '🏃',
  category: 'agile',
  author: 'FRAME Team',
  createdAt: '2025-01-01T00:00:00.000Z',
  updatedAt: '2025-01-01T00:00:00.000Z',
  isBuiltIn: true,
  tags: ['agile', 'sprint', 'scrum', 'planning'],

  stages: [
    {
      id: 'goal',
      title: 'Sprint Goal',
      description: 'Define the sprint goal and capacity',
      icon: '🎯',
      order: 1,
      populatesSections: ['goal', 'capacity'],
      fields: [
        {
          id: 'sprintGoal',
          name: 'sprintGoal',
          label: 'Sprint Goal',
          placeholder: 'What is the primary goal of this sprint?',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a scrum master. Write clear sprint goals.',
            userPromptTemplate: 'Write a sprint goal for: {{input}}',
          },
        },
        {
          id: 'capacity',
          name: 'capacity',
          label: 'Capacity & Velocity',
          placeholder: 'Team capacity and expected velocity...',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a scrum master. Define team capacity.',
            userPromptTemplate: 'Define capacity for: {{input}}',
          },
        },
      ],
    },
    {
      id: 'backlog',
      title: 'Backlog',
      description: 'Sprint backlog items',
      icon: '📝',
      order: 2,
      populatesSections: ['backlog'],
      fields: [
        {
          id: 'sprintBacklog',
          name: 'sprintBacklog',
          label: 'Sprint Backlog',
          placeholder: 'List sprint backlog items...',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a product owner. Define sprint backlog.',
            userPromptTemplate: 'Define backlog for: {{input}}',
          },
        },
      ],
    },
    {
      id: 'risks',
      title: 'Risks & DoD',
      description: 'Risks and definition of done',
      icon: '⚠️',
      order: 3,
      populatesSections: ['risks', 'dod'],
      fields: [
        {
          id: 'risks',
          name: 'risks',
          label: 'Risks & Dependencies',
          placeholder: 'Identify risks and dependencies...',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are a scrum master. Identify sprint risks.',
            userPromptTemplate: 'Identify risks for: {{input}}',
          },
        },
        {
          id: 'dod',
          name: 'dod',
          label: 'Definition of Done',
          placeholder: 'What is the definition of done?',
          type: 'textarea',
          required: true,
          aiAssist: {
            enabled: true,
            systemPrompt: 'You are an agile coach. Define DoD.',
            userPromptTemplate: 'Define DoD for: {{input}}',
          },
        },
      ],
    },
  ],

  sections: [
    { id: 'goal', number: 1, title: 'Sprint Goal', dataKeys: ['sprintGoal'], renderType: 'markdown' },
    { id: 'capacity', number: 2, title: 'Capacity & Velocity', dataKeys: ['capacity'], renderType: 'markdown' },
    { id: 'backlog', number: 3, title: 'Sprint Backlog', dataKeys: ['sprintBacklog'], renderType: 'table' },
    { id: 'risks', number: 4, title: 'Risks & Dependencies', dataKeys: ['risks'], renderType: 'bulletList' },
    { id: 'dod', number: 5, title: 'Definition of Done', dataKeys: ['dod'], renderType: 'bulletList' },
  ],

  aiConfig: {
    defaultSystemPrompt: 'You are a scrum master helping to plan sprints.',
    contextFields: ['sprintGoal'],
    fieldPrompts: {},
    refinementRules: {},
    documentPrompts: {
      summarize: 'Summarize this sprint plan.',
      review: 'Review this sprint plan.',
      enhance: 'Enhance this sprint plan.',
    },
  },

  diagramConfig: {
    enabled: false,
    primaryType: 'flowchart',
    availableTypes: [],
    generators: {},
    defaultTheme: 'default',
  },

  outputConfig: {
    primaryFormat: 'markdown',
    documentTemplate: '# Sprint Plan\n\n{{#sections}}## {{title}}\n\n{{content}}\n\n{{/sections}}',
    exportFormats: [
      { id: 'md', name: 'Markdown', format: 'markdown', extension: '.md', enabled: true },
    ],
    includeMetadata: true,
  },

  branding: {
    primaryColor: '#16a34a',
    secondaryColor: '#15803d',
  },
};

// ===========================================
// EXPORT ALL BUILT-IN TEMPLATES
// ===========================================

export function getBuiltInTemplates(): Template[] {
  return [
    architectTemplate,
    productBriefTemplate,
    sprintPlanTemplate,
  ];
}

export function getBuiltInTemplateById(id: string): Template | null {
  return getBuiltInTemplates().find(t => t.id === id) || null;
}
