// ===========================================
// FRAME TEMPLATE STORE
// CRUD Operations for Template Management
// ===========================================

import {
  Template,
  TemplateMetadata,
  TemplateStore,
  ValidationResult,
  validateTemplate,
  getTemplateMetadata,
  cloneTemplate as cloneTemplateUtil,
} from './schema';

// Import built-in templates
import { getBuiltInTemplates } from './defaults';

// ===========================================
// STORAGE KEYS
// ===========================================

const STORAGE_KEYS = {
  TEMPLATES: 'frame-templates',
  ACTIVE_TEMPLATE: 'frame-active-template',
  RECENT_TEMPLATES: 'frame-recent-templates',
  FORM_DATA_PREFIX: 'frame-form-data-',
};

const MAX_RECENT_TEMPLATES = 5;

// ===========================================
// TEMPLATE CRUD OPERATIONS
// ===========================================

/**
 * Get all templates (built-in + user-created)
 */
export function getAllTemplates(): Template[] {
  const builtIn = getBuiltInTemplates();
  const userTemplates = getUserTemplates();
  return [...builtIn, ...userTemplates];
}

/**
 * Get all template metadata for gallery display
 */
export function getAllTemplateMetadata(): TemplateMetadata[] {
  return getAllTemplates().map(getTemplateMetadata);
}

/**
 * Get user-created templates only
 */
export function getUserTemplates(): Template[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEYS.TEMPLATES);
    if (!stored) return [];
    const templates = JSON.parse(stored) as Record<string, Template>;
    return Object.values(templates);
  } catch (error) {
    console.error('[TemplateStore] Error loading user templates:', error);
    return [];
  }
}

/**
 * Get a single template by ID
 */
export function getTemplate(id: string): Template | null {
  // Check built-in templates first
  const builtIn = getBuiltInTemplates();
  const builtInTemplate = builtIn.find(t => t.id === id);
  if (builtInTemplate) return builtInTemplate;

  // Check user templates
  try {
    const stored = localStorage.getItem(STORAGE_KEYS.TEMPLATES);
    if (!stored) return null;
    const templates = JSON.parse(stored) as Record<string, Template>;
    return templates[id] || null;
  } catch (error) {
    console.error('[TemplateStore] Error loading template:', error);
    return null;
  }
}

/**
 * Save a user template (create or update)
 */
export function saveTemplate(template: Template): { success: boolean; error?: string } {
  // Validate template
  const validation = validateTemplate(template);
  if (!validation.valid) {
    return {
      success: false,
      error: validation.errors.map(e => e.message).join(', '),
    };
  }

  // Cannot save over built-in templates
  const builtIn = getBuiltInTemplates();
  if (builtIn.some(t => t.id === template.id && t.isBuiltIn)) {
    return {
      success: false,
      error: 'Cannot modify built-in templates. Clone it first.',
    };
  }

  try {
    const stored = localStorage.getItem(STORAGE_KEYS.TEMPLATES);
    const templates: Record<string, Template> = stored ? JSON.parse(stored) : {};

    // Update timestamp
    template.updatedAt = new Date().toISOString();
    template.isBuiltIn = false;

    templates[template.id] = template;
    localStorage.setItem(STORAGE_KEYS.TEMPLATES, JSON.stringify(templates));

    console.log('[TemplateStore] Template saved:', template.id);
    return { success: true };
  } catch (error) {
    console.error('[TemplateStore] Error saving template:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Failed to save template',
    };
  }
}

/**
 * Delete a user template
 */
export function deleteTemplate(id: string): { success: boolean; error?: string } {
  // Cannot delete built-in templates
  const builtIn = getBuiltInTemplates();
  if (builtIn.some(t => t.id === id)) {
    return {
      success: false,
      error: 'Cannot delete built-in templates',
    };
  }

  try {
    const stored = localStorage.getItem(STORAGE_KEYS.TEMPLATES);
    if (!stored) return { success: true }; // Nothing to delete

    const templates: Record<string, Template> = JSON.parse(stored);
    delete templates[id];
    localStorage.setItem(STORAGE_KEYS.TEMPLATES, JSON.stringify(templates));

    // Also delete associated form data
    localStorage.removeItem(STORAGE_KEYS.FORM_DATA_PREFIX + id);

    // Remove from recent templates
    removeFromRecentTemplates(id);

    console.log('[TemplateStore] Template deleted:', id);
    return { success: true };
  } catch (error) {
    console.error('[TemplateStore] Error deleting template:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Failed to delete template',
    };
  }
}

/**
 * Clone a template (built-in or user)
 */
export function cloneTemplate(id: string, newName?: string): { success: boolean; template?: Template; error?: string } {
  const original = getTemplate(id);
  if (!original) {
    return {
      success: false,
      error: 'Template not found',
    };
  }

  const cloned = cloneTemplateUtil(original, newName);
  const saveResult = saveTemplate(cloned);

  if (saveResult.success) {
    return { success: true, template: cloned };
  } else {
    return { success: false, error: saveResult.error };
  }
}

/**
 * Validate a template
 */
export function validateTemplateById(id: string): ValidationResult | null {
  const template = getTemplate(id);
  if (!template) return null;
  return validateTemplate(template);
}

// ===========================================
// ACTIVE TEMPLATE MANAGEMENT
// ===========================================

/**
 * Get the currently active template ID
 */
export function getActiveTemplateId(): string | null {
  return localStorage.getItem(STORAGE_KEYS.ACTIVE_TEMPLATE);
}

/**
 * Set the active template
 */
export function setActiveTemplate(id: string): void {
  localStorage.setItem(STORAGE_KEYS.ACTIVE_TEMPLATE, id);
  addToRecentTemplates(id);
}

/**
 * Get the active template
 */
export function getActiveTemplate(): Template | null {
  const id = getActiveTemplateId();
  if (!id) return null;
  return getTemplate(id);
}

// ===========================================
// RECENT TEMPLATES
// ===========================================

/**
 * Get recent template IDs
 */
export function getRecentTemplateIds(): string[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEYS.RECENT_TEMPLATES);
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
}

/**
 * Get recent templates
 */
export function getRecentTemplates(): Template[] {
  const ids = getRecentTemplateIds();
  return ids
    .map(id => getTemplate(id))
    .filter((t): t is Template => t !== null);
}

/**
 * Add template to recent list
 */
export function addToRecentTemplates(id: string): void {
  try {
    let recent = getRecentTemplateIds();

    // Remove if already exists (will add to front)
    recent = recent.filter(r => r !== id);

    // Add to front
    recent.unshift(id);

    // Limit size
    recent = recent.slice(0, MAX_RECENT_TEMPLATES);

    localStorage.setItem(STORAGE_KEYS.RECENT_TEMPLATES, JSON.stringify(recent));
  } catch (error) {
    console.error('[TemplateStore] Error updating recent templates:', error);
  }
}

/**
 * Remove template from recent list
 */
export function removeFromRecentTemplates(id: string): void {
  try {
    let recent = getRecentTemplateIds();
    recent = recent.filter(r => r !== id);
    localStorage.setItem(STORAGE_KEYS.RECENT_TEMPLATES, JSON.stringify(recent));
  } catch (error) {
    console.error('[TemplateStore] Error removing from recent templates:', error);
  }
}

// ===========================================
// FORM DATA PERSISTENCE
// ===========================================

/**
 * Save form data for a template
 */
export function saveFormData(templateId: string, data: Record<string, unknown>): void {
  try {
    const key = STORAGE_KEYS.FORM_DATA_PREFIX + templateId;
    localStorage.setItem(key, JSON.stringify({
      data,
      savedAt: new Date().toISOString(),
    }));
  } catch (error) {
    console.error('[TemplateStore] Error saving form data:', error);
  }
}

/**
 * Load form data for a template
 */
export function loadFormData(templateId: string): Record<string, unknown> | null {
  try {
    const key = STORAGE_KEYS.FORM_DATA_PREFIX + templateId;
    const stored = localStorage.getItem(key);
    if (!stored) return null;
    const parsed = JSON.parse(stored);
    return parsed.data;
  } catch (error) {
    console.error('[TemplateStore] Error loading form data:', error);
    return null;
  }
}

/**
 * Clear form data for a template
 */
export function clearFormData(templateId: string): void {
  localStorage.removeItem(STORAGE_KEYS.FORM_DATA_PREFIX + templateId);
}

// ===========================================
// IMPORT / EXPORT
// ===========================================

/**
 * Export a template as JSON string
 */
export function exportTemplateAsJson(id: string): string | null {
  const template = getTemplate(id);
  if (!template) return null;

  // Remove isBuiltIn flag for export
  const exportTemplate = { ...template, isBuiltIn: false };
  return JSON.stringify(exportTemplate, null, 2);
}

/**
 * Export a template as a downloadable file
 */
export function downloadTemplate(id: string): void {
  const json = exportTemplateAsJson(id);
  if (!json) {
    console.error('[TemplateStore] Template not found for export:', id);
    return;
  }

  const template = getTemplate(id);
  const fileName = `${template?.name.toLowerCase().replace(/\s+/g, '-') || id}.json`;

  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Import a template from JSON string
 */
export function importTemplateFromJson(json: string): { success: boolean; template?: Template; error?: string } {
  try {
    const template = JSON.parse(json) as Template;

    // Validate structure
    const validation = validateTemplate(template);
    if (!validation.valid) {
      return {
        success: false,
        error: `Invalid template: ${validation.errors.map(e => e.message).join(', ')}`,
      };
    }

    // Generate new ID to avoid conflicts
    template.id = `tpl-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    template.isBuiltIn = false;
    template.createdAt = new Date().toISOString();
    template.updatedAt = new Date().toISOString();

    // Check for name conflicts
    const existing = getAllTemplates();
    if (existing.some(t => t.name === template.name)) {
      template.name = `${template.name} (Imported)`;
    }

    // Save
    const saveResult = saveTemplate(template);
    if (saveResult.success) {
      return { success: true, template };
    } else {
      return { success: false, error: saveResult.error };
    }
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Invalid JSON format',
    };
  }
}

/**
 * Import a template from a File object
 */
export async function importTemplateFromFile(file: File): Promise<{ success: boolean; template?: Template; error?: string }> {
  try {
    const text = await file.text();
    return importTemplateFromJson(text);
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Failed to read file',
    };
  }
}

// ===========================================
// SEARCH & FILTER
// ===========================================

/**
 * Search templates by name, description, or tags
 */
export function searchTemplates(query: string): Template[] {
  const lowerQuery = query.toLowerCase();
  return getAllTemplates().filter(t =>
    t.name.toLowerCase().includes(lowerQuery) ||
    t.description.toLowerCase().includes(lowerQuery) ||
    t.tags.some(tag => tag.toLowerCase().includes(lowerQuery))
  );
}

/**
 * Filter templates by category
 */
export function filterTemplatesByCategory(category: string): Template[] {
  if (category === 'all') return getAllTemplates();
  return getAllTemplates().filter(t => t.category === category);
}

/**
 * Get templates grouped by category
 */
export function getTemplatesByCategory(): Record<string, Template[]> {
  const templates = getAllTemplates();
  const grouped: Record<string, Template[]> = {};

  templates.forEach(t => {
    if (!grouped[t.category]) {
      grouped[t.category] = [];
    }
    grouped[t.category].push(t);
  });

  return grouped;
}

// ===========================================
// UTILITIES
// ===========================================

/**
 * Check if a template exists
 */
export function templateExists(id: string): boolean {
  return getTemplate(id) !== null;
}

/**
 * Get template count
 */
export function getTemplateCount(): { total: number; builtIn: number; user: number } {
  const builtIn = getBuiltInTemplates().length;
  const user = getUserTemplates().length;
  return {
    total: builtIn + user,
    builtIn,
    user,
  };
}

/**
 * Clear all user templates (dangerous!)
 */
export function clearAllUserTemplates(): void {
  localStorage.removeItem(STORAGE_KEYS.TEMPLATES);
  localStorage.removeItem(STORAGE_KEYS.RECENT_TEMPLATES);

  // Clear all form data
  const keys = Object.keys(localStorage).filter(k => k.startsWith(STORAGE_KEYS.FORM_DATA_PREFIX));
  keys.forEach(k => localStorage.removeItem(k));

  console.log('[TemplateStore] All user templates cleared');
}
