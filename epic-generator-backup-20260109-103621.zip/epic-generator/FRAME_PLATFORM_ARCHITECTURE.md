# FRAME Platform Architecture
## Template-Driven Document Generation System

---

## Executive Summary

Transform FRAME from a single-purpose "Architect Epic Generator" into a flexible, template-driven platform where users can:
1. Use built-in templates (Architect, Product Brief, Sprint Plan, etc.)
2. Create custom templates with their own stages, fields, and output formats
3. Save, share, and reuse templates
4. Generate AI-powered documents from any template

---

## Current State vs Target State

### Current (Hardcoded)
```
┌─────────────────────────────────────────┐
│           FRAME (Current)               │
├─────────────────────────────────────────┤
│  STAGES[] ────────► Fixed 6 stages      │
│  EPIC_SECTIONS[] ─► Fixed 17 sections   │
│  fieldPrompts ────► Hardcoded AI prompts│
│  refinements ─────► Hardcoded logic     │
│  generateMermaid ─► Single diagram type │
└─────────────────────────────────────────┘
```

### Target (Template-Driven)
```
┌─────────────────────────────────────────────────────────────┐
│                    FRAME Platform                            │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────┐   ┌─────────────┐   ┌─────────────┐       │
│  │  Template   │   │  Template   │   │  Template   │       │
│  │   Store     │◄──│   Editor    │   │  Gallery    │       │
│  └──────┬──────┘   └─────────────┘   └──────┬──────┘       │
│         │                                    │               │
│         ▼                                    ▼               │
│  ┌──────────────────────────────────────────────────┐       │
│  │              Template Engine                      │       │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐       │       │
│  │  │ Dynamic  │  │ Dynamic  │  │ Dynamic  │       │       │
│  │  │  Form    │  │  Output  │  │ Diagram  │       │       │
│  │  │ Renderer │  │Generator │  │Generator │       │       │
│  │  └──────────┘  └──────────┘  └──────────┘       │       │
│  └──────────────────────────────────────────────────┘       │
└─────────────────────────────────────────────────────────────┘
```

---

## Template Schema Design

### 1. Master Template Interface

```typescript
// src/templates/schema.ts

export interface Template {
  // Metadata
  id: string;                          // UUID
  name: string;                        // "Architect Epic", "Product Brief"
  description: string;                 // Template purpose
  version: string;                     // Semantic version
  icon: string;                        // Emoji or icon name
  category: TemplateCategory;          // 'architecture' | 'product' | 'agile' | 'custom'
  author: string;                      // Creator name
  createdAt: string;                   // ISO date
  updatedAt: string;                   // ISO date
  isBuiltIn: boolean;                  // System vs user template
  tags: string[];                      // Searchable tags

  // Structure
  stages: TemplateStage[];             // Input form stages
  sections: TemplateSection[];         // Output document sections

  // AI Configuration
  aiConfig: TemplateAIConfig;          // Prompts and refinement rules

  // Diagram Configuration
  diagramConfig: TemplateDiagramConfig;// Mermaid generation rules

  // Output Configuration
  outputConfig: TemplateOutputConfig;  // Export formats and templates

  // Branding (optional)
  branding?: TemplateBranding;         // Custom colors, logos
}

export type TemplateCategory =
  | 'architecture'    // Technical architecture docs
  | 'product'         // Product requirements, PRDs
  | 'agile'           // Sprint plans, retrospectives
  | 'operations'      // Runbooks, incident reports
  | 'documentation'   // General docs, meeting notes
  | 'custom';         // User-created

```

### 2. Stage Definition (Input Form)

```typescript
export interface TemplateStage {
  id: string;                          // Unique stage identifier
  title: string;                       // "Project Details"
  description: string;                 // Help text for the stage
  icon?: string;                       // Stage icon
  order: number;                       // Display order (1-based)

  fields: TemplateField[];             // Form fields in this stage

  // Mapping to output sections
  populatesSections: string[];         // Section IDs this stage feeds into

  // Conditional logic (optional)
  showIf?: FieldCondition;             // Show stage conditionally
}

export interface TemplateField {
  id: string;                          // Unique field identifier
  name: string;                        // Data key (e.g., 'projectName')
  label: string;                       // UI label
  description?: string;                // Help text below field
  placeholder: string;                 // Input placeholder

  // Input type
  type: FieldType;

  // Validation
  required: boolean;
  validation?: FieldValidation;

  // Default value
  defaultValue?: string;

  // Conditional display
  showIf?: FieldCondition;

  // AI assistance
  aiAssist: FieldAIConfig;
}

export type FieldType =
  | 'text'            // Single line input
  | 'textarea'        // Multi-line input
  | 'richtext'        // WYSIWYG editor
  | 'select'          // Dropdown
  | 'multiselect'     // Multiple selection
  | 'date'            // Date picker
  | 'number'          // Numeric input
  | 'toggle'          // Boolean switch
  | 'tags'            // Tag input
  | 'table';          // Editable table

export interface FieldValidation {
  minLength?: number;
  maxLength?: number;
  pattern?: string;                    // Regex pattern
  patternMessage?: string;             // Custom validation message
  custom?: string;                     // Custom validation function name
}

export interface FieldCondition {
  field: string;                       // Field name to check
  operator: 'equals' | 'notEquals' | 'contains' | 'isEmpty' | 'isNotEmpty';
  value?: string;                      // Value to compare against
}

export interface FieldAIConfig {
  enabled: boolean;                    // Show Refine/Auto buttons
  systemPrompt: string;                // AI system prompt for this field
  userPromptTemplate: string;          // Template with {{placeholders}}
  refinementTemplate?: string;         // How to format the output
  generateDiagramNode?: boolean;       // Should this field contribute to diagram
  diagramNodeTemplate?: string;        // e.g., '{{fieldName}}["{{value}}"]'
}
```

### 3. Section Definition (Output Structure)

```typescript
export interface TemplateSection {
  id: string;                          // Unique section identifier
  number: number;                      // Section number (1, 2, 3...)
  title: string;                       // "Objective", "Background & Context"

  // Data mapping
  dataKeys: string[];                  // Field names that populate this section

  // Rendering options
  renderType: SectionRenderType;
  subsections?: SubsectionConfig[];    // For sections with multiple parts

  // Conditional display
  showIf?: FieldCondition;

  // Custom template (Mustache/Handlebars syntax)
  template?: string;                   // Optional custom rendering template
}

export type SectionRenderType =
  | 'markdown'        // Standard markdown content
  | 'table'           // Render as markdown table
  | 'bulletList'      // Render as bullet points
  | 'numberedList'    // Render as numbered list
  | 'diagram'         // Embed a Mermaid diagram
  | 'reference'       // Reference to external content
  | 'custom';         // Use custom template

export interface SubsectionConfig {
  title: string;                       // Subsection title
  dataKey: string;                     // Which field populates this
}
```

### 4. AI Configuration

```typescript
export interface TemplateAIConfig {
  // Global settings
  defaultSystemPrompt: string;         // Base prompt for all fields
  contextFields: string[];             // Fields to include as context in all prompts

  // Per-field prompts (keyed by field.id)
  fieldPrompts: Record<string, FieldAIConfig>;

  // Refinement rules
  refinementRules: Record<string, RefinementRule>;

  // Document-level AI features
  documentPrompts: {
    summarize: string;                 // Prompt for generating summary
    review: string;                    // Prompt for reviewing document
    enhance: string;                   // Prompt for enhancing content
  };
}

export interface RefinementRule {
  // Input transformation
  preProcess?: string;                 // Function name for preprocessing

  // Output formatting
  format: 'bullets' | 'numbered' | 'paragraphs' | 'table' | 'preserve';
  wrapWith?: string;                   // e.g., '**Context:** {{content}}'

  // Enrichment
  addPrefix?: string;
  addSuffix?: string;

  // Diagram node generation
  diagramNode?: {
    enabled: boolean;
    template: string;                  // e.g., 'Node["{{value}}"]'
    shape?: 'box' | 'rounded' | 'circle' | 'diamond' | 'hexagon';
  };
}
```

### 5. Diagram Configuration

```typescript
export interface TemplateDiagramConfig {
  enabled: boolean;

  // Primary diagram type
  primaryType: DiagramType;

  // Available diagram types for this template
  availableTypes: DiagramType[];

  // Diagram generation rules
  generators: Record<DiagramType, DiagramGenerator>;

  // Default styling
  defaultTheme: 'default' | 'forest' | 'dark' | 'neutral';
  customStyles?: string;               // Custom Mermaid CSS
}

export type DiagramType =
  | 'flowchart'       // General flowchart
  | 'sequence'        // Sequence diagram
  | 'c4-container'    // C4 Container diagram
  | 'c4-component'    // C4 Component diagram
  | 'deployment'      // Deployment diagram
  | 'er'              // Entity-relationship
  | 'gantt'           // Gantt chart
  | 'mindmap'         // Mind map
  | 'timeline'        // Timeline
  | 'custom';         // Custom Mermaid

export interface DiagramGenerator {
  // Template for generating the diagram
  template: string;                    // Mermaid template with {{placeholders}}

  // Field mappings
  fieldMappings: Record<string, string>; // fieldId -> diagram element

  // Static elements
  staticElements?: string[];           // Always-included diagram elements

  // Layout
  direction?: 'TB' | 'BT' | 'LR' | 'RL';
}
```

### 6. Output Configuration

```typescript
export interface TemplateOutputConfig {
  // Primary output format
  primaryFormat: 'markdown' | 'html' | 'pdf';

  // Document template (Mustache syntax)
  documentTemplate: string;

  // Header/footer
  headerTemplate?: string;
  footerTemplate?: string;

  // Export options
  exportFormats: ExportFormat[];

  // Metadata to include
  includeMetadata: boolean;
  metadataFields?: string[];           // Which fields to include as metadata
}

export interface ExportFormat {
  id: string;
  name: string;                        // "Markdown", "PDF", "Confluence"
  extension: string;                   // ".md", ".pdf"
  handler: string;                     // Export handler function name
  enabled: boolean;
}
```

### 7. Branding Configuration

```typescript
export interface TemplateBranding {
  // Colors
  primaryColor: string;                // e.g., '#E60000' (UBS Red)
  secondaryColor: string;              // e.g., '#1C1C1C'
  accentColor?: string;

  // Logo
  logoUrl?: string;
  logoPosition?: 'header' | 'footer' | 'both';

  // Typography
  fontFamily?: string;

  // Custom CSS
  customStyles?: string;
}
```

---

## File Structure

```
src/
├── templates/
│   ├── schema.ts                      # TypeScript interfaces (above)
│   ├── store.ts                       # Template CRUD operations
│   ├── validator.ts                   # Template validation
│   ├── migrator.ts                    # Version migration logic
│   │
│   ├── defaults/                      # Built-in templates
│   │   ├── index.ts                   # Export all defaults
│   │   ├── architect.json             # Current 17-stage epic template
│   │   ├── product-brief.json         # Product requirements
│   │   ├── sprint-plan.json           # Sprint planning
│   │   ├── api-design.json            # API specification
│   │   └── incident-report.json       # Post-mortem template
│   │
│   └── engine/                        # Template processing
│       ├── index.ts                   # Engine exports
│       ├── formRenderer.ts            # Dynamic form generation
│       ├── documentGenerator.ts       # Output generation
│       ├── diagramGenerator.ts        # Mermaid generation
│       ├── aiProcessor.ts             # AI refinement handling
│       └── exportHandler.ts           # Export format handlers
│
├── components/
│   ├── TemplateGallery/               # Template browser
│   │   ├── index.tsx
│   │   ├── TemplateCard.tsx
│   │   ├── CategoryFilter.tsx
│   │   └── SearchBar.tsx
│   │
│   ├── TemplateEditor/                # Template creation/editing
│   │   ├── index.tsx
│   │   ├── StageEditor.tsx
│   │   ├── FieldEditor.tsx
│   │   ├── SectionEditor.tsx
│   │   ├── AIConfigEditor.tsx
│   │   ├── DiagramConfigEditor.tsx
│   │   └── PreviewPanel.tsx
│   │
│   ├── DynamicForm/                   # Template-driven form
│   │   ├── index.tsx
│   │   ├── StageRenderer.tsx
│   │   ├── FieldRenderer.tsx
│   │   ├── fields/                    # Field type components
│   │   │   ├── TextField.tsx
│   │   │   ├── TextareaField.tsx
│   │   │   ├── SelectField.tsx
│   │   │   ├── TableField.tsx
│   │   │   └── ...
│   │   └── AIAssistButton.tsx
│   │
│   ├── DocumentPreview/               # Template-driven preview
│   │   ├── index.tsx
│   │   ├── SectionRenderer.tsx
│   │   └── DiagramRenderer.tsx
│   │
│   └── common/                        # Shared components
│       ├── Modal.tsx
│       ├── Tabs.tsx
│       └── ...
│
├── hooks/
│   ├── useTemplate.ts                 # Current template state
│   ├── useTemplateStore.ts            # Template CRUD
│   └── useFormData.ts                 # Form state management
│
├── context/
│   ├── TemplateContext.tsx            # Template provider
│   └── FormDataContext.tsx            # Form data provider
│
├── utils/
│   ├── templateUtils.ts               # Helper functions
│   ├── mustache.ts                    # Template rendering
│   └── validation.ts                  # Form validation
│
├── App.tsx                            # Main app (refactored)
├── types.ts                           # Shared types
├── config.ts                          # Azure/GitLab config
└── main.tsx                           # Entry point
```

---

## Built-in Templates

### 1. Architect Epic (Current - 17 Sections)
```json
{
  "id": "architect-epic",
  "name": "Architect Epic",
  "description": "Comprehensive technical architecture documentation with 17 sections",
  "category": "architecture",
  "icon": "🏗️",
  "stages": 6,
  "sections": 17
}
```

### 2. Product Brief (8 Sections)
```json
{
  "id": "product-brief",
  "name": "Product Brief",
  "description": "Product requirements document for feature planning",
  "category": "product",
  "icon": "📋",
  "stages": 4,
  "sections": [
    "Problem Statement",
    "Target Users",
    "Proposed Solution",
    "Success Metrics",
    "User Stories",
    "Acceptance Criteria",
    "Dependencies",
    "Timeline"
  ]
}
```

### 3. Sprint Plan (5 Sections)
```json
{
  "id": "sprint-plan",
  "name": "Sprint Plan",
  "description": "Agile sprint planning document",
  "category": "agile",
  "icon": "🏃",
  "stages": 3,
  "sections": [
    "Sprint Goal",
    "Capacity & Velocity",
    "Sprint Backlog",
    "Risks & Dependencies",
    "Definition of Done"
  ]
}
```

### 4. API Design (10 Sections)
```json
{
  "id": "api-design",
  "name": "API Design Document",
  "description": "RESTful API specification and design",
  "category": "architecture",
  "icon": "🔌",
  "stages": 5,
  "sections": [
    "Overview",
    "Authentication",
    "Endpoints",
    "Request/Response Schemas",
    "Error Handling",
    "Rate Limiting",
    "Versioning Strategy",
    "Security Considerations",
    "Testing Strategy",
    "Changelog"
  ]
}
```

### 5. Incident Report (6 Sections)
```json
{
  "id": "incident-report",
  "name": "Incident Report",
  "description": "Post-mortem and root cause analysis",
  "category": "operations",
  "icon": "🚨",
  "stages": 4,
  "sections": [
    "Incident Summary",
    "Timeline",
    "Impact Assessment",
    "Root Cause Analysis",
    "Remediation Steps",
    "Lessons Learned"
  ]
}
```

---

## Storage Strategy

### Option 1: localStorage (Simple)
```typescript
// src/templates/store.ts

const TEMPLATE_STORAGE_KEY = 'frame-templates';

export function saveTemplate(template: Template): void {
  const templates = loadAllTemplates();
  templates[template.id] = template;
  localStorage.setItem(TEMPLATE_STORAGE_KEY, JSON.stringify(templates));
}

export function loadTemplate(id: string): Template | null {
  const templates = loadAllTemplates();
  return templates[id] || null;
}

export function loadAllTemplates(): Record<string, Template> {
  const stored = localStorage.getItem(TEMPLATE_STORAGE_KEY);
  return stored ? JSON.parse(stored) : {};
}

export function deleteTemplate(id: string): void {
  const templates = loadAllTemplates();
  delete templates[id];
  localStorage.setItem(TEMPLATE_STORAGE_KEY, JSON.stringify(templates));
}
```

### Option 2: IndexedDB (Better for Large Templates)
```typescript
// For templates with large content or many templates
import { openDB, DBSchema } from 'idb';

interface FrameDB extends DBSchema {
  templates: {
    key: string;
    value: Template;
    indexes: { 'by-category': string; 'by-updated': string };
  };
}

const db = await openDB<FrameDB>('frame-db', 1, {
  upgrade(db) {
    const store = db.createObjectStore('templates', { keyPath: 'id' });
    store.createIndex('by-category', 'category');
    store.createIndex('by-updated', 'updatedAt');
  },
});
```

### Option 3: File-based JSON (For Export/Import)
```typescript
// Export template as JSON file
export function exportTemplate(template: Template): void {
  const blob = new Blob([JSON.stringify(template, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${template.id}.json`;
  a.click();
}

// Import template from JSON file
export async function importTemplate(file: File): Promise<Template> {
  const text = await file.text();
  const template = JSON.parse(text) as Template;
  // Validate template structure
  validateTemplate(template);
  return template;
}
```

---

## Migration Strategy

### Phase 1: Extract Current Logic to JSON
1. Convert hardcoded `STAGES` to `architect.json`
2. Convert hardcoded `EPIC_SECTIONS` to template sections
3. Convert `fieldPrompts` to AI config
4. Convert `refinements` to refinement rules
5. Convert Mermaid generators to diagram config

### Phase 2: Create Template Engine
1. Build `formRenderer.ts` - reads template, renders dynamic form
2. Build `documentGenerator.ts` - reads template, generates output
3. Build `diagramGenerator.ts` - reads template, generates Mermaid
4. Build `aiProcessor.ts` - handles AI refinement per template config

### Phase 3: Refactor App.tsx
1. Replace hardcoded logic with template engine calls
2. Add template selection UI (dropdown or gallery)
3. Maintain backward compatibility with existing saved data

### Phase 4: Add Template Management
1. Build Template Gallery component
2. Build Template Editor component
3. Add import/export functionality
4. Add template versioning

### Phase 5: Add Built-in Templates
1. Create Product Brief template
2. Create Sprint Plan template
3. Create API Design template
4. Create Incident Report template

---

## UI Mockups

### Template Gallery
```
┌─────────────────────────────────────────────────────────────┐
│  FRAME - Template Gallery                          [+ New]  │
├─────────────────────────────────────────────────────────────┤
│  [All] [Architecture] [Product] [Agile] [Operations]       │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐         │
│  │ 🏗️          │  │ 📋          │  │ 🏃          │         │
│  │ Architect   │  │ Product     │  │ Sprint      │         │
│  │ Epic        │  │ Brief       │  │ Plan        │         │
│  │             │  │             │  │             │         │
│  │ 17 sections │  │ 8 sections  │  │ 5 sections  │         │
│  │ [Use]       │  │ [Use]       │  │ [Use]       │         │
│  └─────────────┘  └─────────────┘  └─────────────┘         │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐         │
│  │ 🔌          │  │ 🚨          │  │ ➕          │         │
│  │ API         │  │ Incident    │  │             │         │
│  │ Design      │  │ Report      │  │ Create New  │         │
│  │             │  │             │  │ Template    │         │
│  │ 10 sections │  │ 6 sections  │  │             │         │
│  │ [Use]       │  │ [Use]       │  │ [Create]    │         │
│  └─────────────┘  └─────────────┘  └─────────────┘         │
└─────────────────────────────────────────────────────────────┘
```

### Template Editor
```
┌─────────────────────────────────────────────────────────────┐
│  Edit Template: My Custom Template              [Save] [X]  │
├─────────────────────────────────────────────────────────────┤
│  [Metadata] [Stages] [Sections] [AI Config] [Diagram]       │
├─────────────────────────────────────────────────────────────┤
│  STAGES                              │  PREVIEW             │
│  ┌───────────────────────────────┐   │  ┌─────────────────┐ │
│  │ Stage 1: Project Details      │   │  │ # My Document   │ │
│  │ ├─ projectName (text)         │   │  │                 │ │
│  │ ├─ description (textarea)     │   │  │ ## 1. Objective │ │
│  │ └─ [+ Add Field]              │   │  │ ...             │ │
│  ├───────────────────────────────┤   │  │                 │ │
│  │ Stage 2: Requirements         │   │  │ ## 2. Scope     │ │
│  │ ├─ features (textarea)        │   │  │ ...             │ │
│  │ └─ [+ Add Field]              │   │  │                 │ │
│  ├───────────────────────────────┤   │  └─────────────────┘ │
│  │ [+ Add Stage]                 │   │                      │
│  └───────────────────────────────┘   │                      │
└─────────────────────────────────────────────────────────────┘
```

---

## API Reference

### Template Store API

```typescript
// Load all templates (built-in + user)
function getAllTemplates(): Template[];

// Get single template by ID
function getTemplate(id: string): Template | null;

// Save user template
function saveTemplate(template: Template): void;

// Delete user template (cannot delete built-in)
function deleteTemplate(id: string): boolean;

// Clone template
function cloneTemplate(id: string, newName: string): Template;

// Export template as JSON
function exportTemplate(id: string): string;

// Import template from JSON
function importTemplate(json: string): Template;
```

### Template Engine API

```typescript
// Render form for a template
function renderForm(template: Template, data: FormData): ReactNode;

// Generate document from template + data
function generateDocument(template: Template, data: FormData): string;

// Generate diagram from template + data
function generateDiagram(template: Template, data: FormData, type: DiagramType): string;

// Process field with AI
function processFieldWithAI(template: Template, fieldId: string, input: string): Promise<RefinedData>;
```

---

## Implementation Checklist

### Phase 1: Foundation (Week 1)
- [ ] Create `src/templates/schema.ts` with all interfaces
- [ ] Create `src/templates/store.ts` with localStorage CRUD
- [ ] Create `src/templates/validator.ts` for template validation
- [ ] Convert current `STAGES` to `architect.json`
- [ ] Convert current `EPIC_SECTIONS` to template format
- [ ] Convert `fieldPrompts` to AI config format

### Phase 2: Engine (Week 2)
- [ ] Create `src/templates/engine/formRenderer.ts`
- [ ] Create `src/templates/engine/documentGenerator.ts`
- [ ] Create `src/templates/engine/diagramGenerator.ts`
- [ ] Create `src/templates/engine/aiProcessor.ts`
- [ ] Create field type components in `src/components/DynamicForm/fields/`

### Phase 3: Refactor App (Week 3)
- [ ] Create `TemplateContext` for current template state
- [ ] Create `FormDataContext` for form state
- [ ] Refactor `App.tsx` to use template engine
- [ ] Add template selector dropdown in header
- [ ] Test with architect template

### Phase 4: Template Management (Week 4)
- [ ] Create `TemplateGallery` component
- [ ] Create `TemplateEditor` component
- [ ] Add import/export functionality
- [ ] Add template duplication
- [ ] Add template deletion (user templates only)

### Phase 5: Additional Templates (Week 5)
- [ ] Create `product-brief.json`
- [ ] Create `sprint-plan.json`
- [ ] Create `api-design.json`
- [ ] Create `incident-report.json`
- [ ] Test all templates

### Phase 6: Polish (Week 6)
- [ ] Add template search in gallery
- [ ] Add category filtering
- [ ] Add template preview in gallery
- [ ] Add keyboard shortcuts
- [ ] Performance optimization
- [ ] Documentation

---

## Benefits

1. **Flexibility** - Users create templates for any document type
2. **Reusability** - Save and share templates across teams
3. **Maintainability** - Template changes don't require code changes
4. **Scalability** - Add new templates without new releases
5. **Customization** - Each organization can have branded templates
6. **AI-Powered** - Every field can have AI assistance

---

## Risks & Mitigations

| Risk | Mitigation |
|------|------------|
| Complex template editor UX | Start with JSON import, add visual editor later |
| Template version conflicts | Add version field, migration logic |
| Performance with large templates | Lazy loading, IndexedDB for storage |
| AI prompt quality varies | Provide default prompts, allow overrides |
| Breaking changes in schema | Semantic versioning, backward compatibility |

---

## Next Steps

1. **Approve this architecture** - Review and refine the schema design
2. **Create schema.ts** - Implement TypeScript interfaces
3. **Extract architect template** - Convert current hardcoded logic to JSON
4. **Build template engine** - Core rendering and generation logic
5. **Refactor App.tsx** - Integrate template engine
6. **Add template gallery** - UI for template selection

---

*Document Version: 1.0*
*Created: January 2025*
*Author: FRAME Platform Team*
