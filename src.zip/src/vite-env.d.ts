/// <reference types="vite/client" />

/**
 * Vite Environment Variable Type Definitions
 */
interface ImportMetaEnv {
  // MSAL Authentication
  readonly VITE_MSAL_AUTH_ENABLED: string;
  readonly VITE_MSAL_CLIENT_ID: string;
  readonly VITE_MSAL_TENANT_ID: string;
  readonly VITE_APP_CONTEXT: string;

  // Mock Auth (for local testing)
  readonly VITE_MSAL_AUTH_MOCK: string;

  // GitLab Integration
  readonly VITE_GITLAB_URL: string;
  readonly VITE_GITLAB_GROUP_ID: string;

  // GitLab OAuth (alternative to PAT)
  readonly VITE_GITLAB_OAUTH_ENABLED: string;
  readonly VITE_GITLAB_OAUTH_CLIENT_ID: string;
  readonly VITE_GITLAB_OAUTH_MOCK: string;

  // Vite built-in
  readonly DEV: boolean;
  readonly PROD: boolean;
  readonly MODE: string;
  readonly BASE_URL: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
