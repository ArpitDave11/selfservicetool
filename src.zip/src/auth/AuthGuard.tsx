/**
 * Authentication Guard Component
 *
 * Protects content by requiring authentication.
 * When MSAL_AUTH_ENABLED is false, always renders children.
 *
 * IMPORTANT: This implementation includes:
 * - Redirect loop protection (max 3 attempts)
 * - Error state handling
 * - Proper cleanup on successful auth
 */

import React, { useEffect, useState } from 'react';
import { useAuth } from './AuthProvider';
import { shouldUseMsalAuth } from './authConfig';
import { MOCK_AUTH_ENABLED } from './MockAuthProvider';
import type { AuthGuardProps } from './types';

/**
 * Check if any auth mode is active (real MSAL or mock)
 */
const isAuthEnabled = (): boolean => {
  return shouldUseMsalAuth() || MOCK_AUTH_ENABLED;
};

// ===========================================
// REDIRECT LOOP PROTECTION
// ===========================================

const MAX_REDIRECT_ATTEMPTS = 3;
const REDIRECT_ATTEMPTS_KEY = 'msal_redirect_attempts';
const REDIRECT_TIMESTAMP_KEY = 'msal_redirect_timestamp';
const REDIRECT_TIMEOUT_MS = 60000; // Reset counter after 1 minute

// ===========================================
// UBS BRAND COLORS (matching App.tsx)
// ===========================================

const UBS_COLORS = {
  red: '#E60000',
  black: '#000000',
  white: '#FFFFFF',
  grayI: '#ADACA5',
  grayIII: '#8E8D83',
  grayV: '#5A5D5C',
  pastelI: '#ECEBE4',
  neutral200: '#E5E5E5',
};

// ===========================================
// DEFAULT LOADING SCREEN
// ===========================================

const DefaultLoadingScreen: React.FC = () => (
  <div
    style={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      height: '100vh',
      background: `linear-gradient(135deg, ${UBS_COLORS.pastelI} 0%, ${UBS_COLORS.neutral200} 100%)`,
      fontFamily: 'Frutiger, "Helvetica Neue", Arial, sans-serif',
    }}
  >
    <div style={{ textAlign: 'center' }}>
      <div
        style={{
          width: '48px',
          height: '48px',
          border: `4px solid ${UBS_COLORS.red}`,
          borderTop: '4px solid transparent',
          borderRadius: '50%',
          margin: '0 auto 16px',
          animation: 'auth-spin 1s linear infinite',
        }}
      />
      <p style={{ color: UBS_COLORS.grayV, fontSize: '14px', margin: 0 }}>
        Authenticating...
      </p>
      <style>{`
        @keyframes auth-spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  </div>
);

// ===========================================
// DEFAULT ERROR SCREEN
// ===========================================

interface DefaultErrorScreenProps {
  error: Error;
  onRetry: () => void;
}

const DefaultErrorScreen: React.FC<DefaultErrorScreenProps> = ({ error, onRetry }) => (
  <div
    style={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      height: '100vh',
      background: `linear-gradient(135deg, ${UBS_COLORS.pastelI} 0%, ${UBS_COLORS.neutral200} 100%)`,
      fontFamily: 'Frutiger, "Helvetica Neue", Arial, sans-serif',
    }}
  >
    <div
      style={{
        textAlign: 'center',
        padding: '48px',
        background: UBS_COLORS.white,
        borderRadius: '16px',
        boxShadow: '0 4px 24px rgba(0, 0, 0, 0.1)',
        maxWidth: '450px',
      }}
    >
      {/* Error Icon */}
      <div
        style={{
          width: '64px',
          height: '64px',
          background: '#FEE2E2',
          borderRadius: '50%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          margin: '0 auto 24px',
        }}
      >
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke={UBS_COLORS.red} strokeWidth="2">
          <circle cx="12" cy="12" r="10" />
          <line x1="12" y1="8" x2="12" y2="12" />
          <line x1="12" y1="16" x2="12.01" y2="16" />
        </svg>
      </div>

      <h1 style={{ margin: '0 0 8px', color: UBS_COLORS.black, fontSize: '20px', fontWeight: '600' }}>
        Authentication Failed
      </h1>

      <p style={{ margin: '0 0 16px', color: UBS_COLORS.grayIII, fontSize: '14px', lineHeight: '1.5' }}>
        We couldn't sign you in. This might be a temporary issue.
      </p>

      <div
        style={{
          background: '#FEF2F2',
          border: '1px solid #FECACA',
          borderRadius: '8px',
          padding: '12px',
          marginBottom: '24px',
          textAlign: 'left',
        }}
      >
        <code style={{ fontSize: '12px', color: '#991B1B', wordBreak: 'break-word' }}>
          {error.message}
        </code>
      </div>

      <button
        onClick={onRetry}
        style={{
          padding: '12px 24px',
          fontSize: '14px',
          fontWeight: '500',
          background: UBS_COLORS.red,
          color: UBS_COLORS.white,
          border: 'none',
          borderRadius: '8px',
          cursor: 'pointer',
          transition: 'all 0.2s ease',
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.background = '#BD000C';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.background = UBS_COLORS.red;
        }}
      >
        Try Again
      </button>
    </div>
  </div>
);

// ===========================================
// REDIRECT LOOP ERROR SCREEN
// ===========================================

const RedirectLoopErrorScreen: React.FC = () => (
  <div
    style={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      height: '100vh',
      background: `linear-gradient(135deg, ${UBS_COLORS.pastelI} 0%, ${UBS_COLORS.neutral200} 100%)`,
      fontFamily: 'Frutiger, "Helvetica Neue", Arial, sans-serif',
    }}
  >
    <div
      style={{
        textAlign: 'center',
        padding: '48px',
        background: UBS_COLORS.white,
        borderRadius: '16px',
        boxShadow: '0 4px 24px rgba(0, 0, 0, 0.1)',
        maxWidth: '450px',
      }}
    >
      <div
        style={{
          width: '64px',
          height: '64px',
          background: '#FEF3C7',
          borderRadius: '50%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          margin: '0 auto 24px',
        }}
      >
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#D97706" strokeWidth="2">
          <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
          <line x1="12" y1="9" x2="12" y2="13" />
          <line x1="12" y1="17" x2="12.01" y2="17" />
        </svg>
      </div>

      <h1 style={{ margin: '0 0 8px', color: UBS_COLORS.black, fontSize: '20px', fontWeight: '600' }}>
        Sign In Issue Detected
      </h1>

      <p style={{ margin: '0 0 24px', color: UBS_COLORS.grayIII, fontSize: '14px', lineHeight: '1.5' }}>
        Multiple sign-in attempts have failed. This usually happens due to browser settings or network issues.
      </p>

      <div style={{ textAlign: 'left', marginBottom: '24px' }}>
        <p style={{ margin: '0 0 8px', color: UBS_COLORS.black, fontSize: '13px', fontWeight: '500' }}>
          Try these steps:
        </p>
        <ol style={{ margin: 0, paddingLeft: '20px', color: UBS_COLORS.grayV, fontSize: '13px', lineHeight: '1.8' }}>
          <li>Clear your browser cookies and cache</li>
          <li>Disable browser extensions temporarily</li>
          <li>Try using an incognito/private window</li>
          <li>Check your network connection</li>
        </ol>
      </div>

      <button
        onClick={() => {
          // Clear the redirect counter and reload
          sessionStorage.removeItem(REDIRECT_ATTEMPTS_KEY);
          sessionStorage.removeItem(REDIRECT_TIMESTAMP_KEY);
          window.location.reload();
        }}
        style={{
          padding: '12px 24px',
          fontSize: '14px',
          fontWeight: '500',
          background: UBS_COLORS.red,
          color: UBS_COLORS.white,
          border: 'none',
          borderRadius: '8px',
          cursor: 'pointer',
          transition: 'all 0.2s ease',
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.background = '#BD000C';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.background = UBS_COLORS.red;
        }}
      >
        Reset and Try Again
      </button>
    </div>
  </div>
);

// ===========================================
// DEFAULT LOGIN SCREEN
// ===========================================

interface DefaultLoginScreenProps {
  onLogin: () => void;
  isRedirectLoopDetected: boolean;
}

const DefaultLoginScreen: React.FC<DefaultLoginScreenProps> = ({ onLogin, isRedirectLoopDetected }) => {
  if (isRedirectLoopDetected) {
    return <RedirectLoopErrorScreen />;
  }

  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        height: '100vh',
        background: `linear-gradient(135deg, ${UBS_COLORS.pastelI} 0%, ${UBS_COLORS.neutral200} 100%)`,
        fontFamily: 'Frutiger, "Helvetica Neue", Arial, sans-serif',
      }}
    >
      <div
        style={{
          textAlign: 'center',
          padding: '48px',
          background: UBS_COLORS.white,
          borderRadius: '16px',
          boxShadow: '0 4px 24px rgba(0, 0, 0, 0.1)',
          maxWidth: '400px',
        }}
      >
        {/* Logo/Title */}
        <div
          style={{
            width: '64px',
            height: '64px',
            background: UBS_COLORS.red,
            borderRadius: '16px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 24px',
          }}
        >
          <span style={{ color: UBS_COLORS.white, fontSize: '28px', fontWeight: '700' }}>
            E
          </span>
        </div>

        <h1
          style={{
            margin: '0 0 8px',
            color: UBS_COLORS.black,
            fontSize: '24px',
            fontWeight: '600',
          }}
        >
          Epic Generator
        </h1>

        <p
          style={{
            margin: '0 0 32px',
            color: UBS_COLORS.grayIII,
            fontSize: '14px',
            lineHeight: '1.5',
          }}
        >
          Sign in with your Microsoft account to continue
        </p>

        <button
          onClick={onLogin}
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '10px',
            padding: '14px 28px',
            fontSize: '14px',
            fontWeight: '500',
            background: UBS_COLORS.red,
            color: UBS_COLORS.white,
            border: 'none',
            borderRadius: '8px',
            cursor: 'pointer',
            transition: 'all 0.2s ease',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.background = '#BD000C';
            e.currentTarget.style.transform = 'translateY(-1px)';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.background = UBS_COLORS.red;
            e.currentTarget.style.transform = 'translateY(0)';
          }}
        >
          {/* Microsoft Logo */}
          <svg width="20" height="20" viewBox="0 0 21 21">
            <rect x="1" y="1" width="9" height="9" fill="#f25022" />
            <rect x="11" y="1" width="9" height="9" fill="#7fba00" />
            <rect x="1" y="11" width="9" height="9" fill="#00a4ef" />
            <rect x="11" y="11" width="9" height="9" fill="#ffb900" />
          </svg>
          Sign in with Microsoft
        </button>
      </div>
    </div>
  );
};

// ===========================================
// AUTH GUARD COMPONENT
// ===========================================

/**
 * Protects content by requiring authentication.
 *
 * Features:
 * - Shows loading screen during auth
 * - Shows login screen when not authenticated
 * - Shows error screen on auth failure
 * - Prevents redirect loops (max 3 attempts)
 * - Clears attempt counter on successful auth
 */
export const AuthGuard: React.FC<AuthGuardProps> = ({
  children,
  loadingComponent,
  loginComponent,
  errorComponent,
}) => {
  const { isAuthenticated, isLoading, login, error } = useAuth();
  const [redirectAttempts, setRedirectAttempts] = useState(0);
  const [isRedirectLoopDetected, setIsRedirectLoopDetected] = useState(false);

  // Check and manage redirect attempts
  useEffect(() => {
    if (!isAuthEnabled()) return;

    const storedAttempts = parseInt(sessionStorage.getItem(REDIRECT_ATTEMPTS_KEY) || '0', 10);
    const storedTimestamp = parseInt(sessionStorage.getItem(REDIRECT_TIMESTAMP_KEY) || '0', 10);
    const now = Date.now();

    // Reset counter if timeout has passed
    if (storedTimestamp && (now - storedTimestamp) > REDIRECT_TIMEOUT_MS) {
      sessionStorage.removeItem(REDIRECT_ATTEMPTS_KEY);
      sessionStorage.removeItem(REDIRECT_TIMESTAMP_KEY);
      setRedirectAttempts(0);
      setIsRedirectLoopDetected(false);
    } else {
      setRedirectAttempts(storedAttempts);
      setIsRedirectLoopDetected(storedAttempts >= MAX_REDIRECT_ATTEMPTS);
    }

    // Clear counter on successful authentication
    if (isAuthenticated) {
      sessionStorage.removeItem(REDIRECT_ATTEMPTS_KEY);
      sessionStorage.removeItem(REDIRECT_TIMESTAMP_KEY);
      setRedirectAttempts(0);
      setIsRedirectLoopDetected(false);
    }
  }, [isAuthenticated]);

  // If auth is disabled (neither real nor mock), always show children
  if (!isAuthEnabled()) {
    return <>{children}</>;
  }

  // Show loading state
  if (isLoading) {
    return <>{loadingComponent || <DefaultLoadingScreen />}</>;
  }

  // Show error state
  if (error) {
    const handleRetry = () => {
      // Clear error and try again
      window.location.reload();
    };

    return <>{errorComponent || <DefaultErrorScreen error={error} onRetry={handleRetry} />}</>;
  }

  // Show login prompt if not authenticated
  if (!isAuthenticated) {
    const handleLogin = async () => {
      if (isRedirectLoopDetected) {
        return;
      }

      // Track redirect attempt
      const newAttempts = redirectAttempts + 1;
      sessionStorage.setItem(REDIRECT_ATTEMPTS_KEY, String(newAttempts));
      sessionStorage.setItem(REDIRECT_TIMESTAMP_KEY, String(Date.now()));
      setRedirectAttempts(newAttempts);

      if (newAttempts >= MAX_REDIRECT_ATTEMPTS) {
        setIsRedirectLoopDetected(true);
        return;
      }

      await login();
    };

    return (
      <>
        {loginComponent || (
          <DefaultLoginScreen onLogin={handleLogin} isRedirectLoopDetected={isRedirectLoopDetected} />
        )}
      </>
    );
  }

  // User is authenticated, show protected content
  return <>{children}</>;
};
