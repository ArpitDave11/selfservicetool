/**
 * Mock Authentication Provider for Local Testing
 *
 * This provider simulates MSAL authentication flow WITHOUT connecting to Azure AD.
 * Use this to test the full auth UI flow locally before deploying to production.
 *
 * Enable by setting: VITE_MSAL_AUTH_MOCK=true
 *
 * Features:
 * - Simulates login/logout flow
 * - Shows loading states
 * - Simulates redirect behavior
 * - Persists mock session in sessionStorage
 * - Provides mock user data
 */

import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import type { AuthContextType, AuthenticatedUser, AuthProviderProps } from './types';

// ===========================================
// MOCK AUTH CONFIGURATION
// ===========================================

export const MOCK_AUTH_ENABLED: boolean =
  import.meta.env.VITE_MSAL_AUTH_MOCK === 'true';

const MOCK_SESSION_KEY = 'mock_auth_session';
const MOCK_LOGIN_DELAY = 1500; // Simulate network delay

// Mock user data - customize as needed
const MOCK_USER: AuthenticatedUser = {
  name: 'Test User',
  email: 'test.user@example.com',
  username: 'test.user',
  tenantId: 'mock-tenant-id-12345',
  objectId: 'mock-object-id-67890',
};

// ===========================================
// MOCK AUTH CONTEXT
// ===========================================

const MockAuthContext = createContext<AuthContextType | null>(null);

/**
 * Hook to access mock authentication context
 */
export const useMockAuth = (): AuthContextType => {
  const context = useContext(MockAuthContext);
  if (!context) {
    throw new Error('useMockAuth must be used within a MockAuthProvider');
  }
  return context;
};

// ===========================================
// MOCK AUTH PROVIDER
// ===========================================

/**
 * Mock Authentication Provider
 *
 * Simulates the full MSAL authentication flow for local testing.
 * Does NOT connect to Azure AD - all authentication is simulated.
 */
export const MockAuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<AuthenticatedUser | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  // Check for existing mock session on mount
  useEffect(() => {
    const checkExistingSession = async () => {
      // Simulate initial loading delay
      await new Promise(resolve => setTimeout(resolve, 500));

      const savedSession = sessionStorage.getItem(MOCK_SESSION_KEY);
      if (savedSession) {
        try {
          const sessionData = JSON.parse(savedSession);
          setUser(sessionData.user);
          setIsAuthenticated(true);
          console.log('[MockAuth] Restored session for:', sessionData.user.name);
        } catch (e) {
          console.error('[MockAuth] Failed to parse saved session:', e);
          sessionStorage.removeItem(MOCK_SESSION_KEY);
        }
      }
      setIsLoading(false);
    };

    checkExistingSession();
  }, []);

  // Login handler - simulates redirect flow
  const login = useCallback(async () => {
    console.log('[MockAuth] Starting mock login flow...');
    setIsLoading(true);
    setError(null);

    try {
      // Simulate redirect delay (like going to Azure AD and back)
      await new Promise(resolve => setTimeout(resolve, MOCK_LOGIN_DELAY));

      // "Login successful" - set user and session
      setUser(MOCK_USER);
      setIsAuthenticated(true);
      sessionStorage.setItem(MOCK_SESSION_KEY, JSON.stringify({
        user: MOCK_USER,
        timestamp: Date.now(),
      }));

      console.log('[MockAuth] Mock login successful:', MOCK_USER.name);
    } catch (e) {
      const error = e instanceof Error ? e : new Error('Mock login failed');
      setError(error);
      console.error('[MockAuth] Login error:', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Logout handler
  const logout = useCallback(async () => {
    console.log('[MockAuth] Logging out...');
    setIsLoading(true);

    // Simulate logout delay
    await new Promise(resolve => setTimeout(resolve, 500));

    setUser(null);
    setIsAuthenticated(false);
    sessionStorage.removeItem(MOCK_SESSION_KEY);
    setIsLoading(false);

    console.log('[MockAuth] Logged out successfully');
  }, []);

  // Get access token (returns mock token)
  const getAccessToken = useCallback(async (): Promise<string | null> => {
    if (!isAuthenticated) return null;
    return 'mock-access-token-' + Date.now();
  }, [isAuthenticated]);

  const authContextValue: AuthContextType = {
    user,
    isAuthenticated,
    isLoading,
    error,
    login,
    logout,
    getAccessToken,
  };

  return (
    <MockAuthContext.Provider value={authContextValue}>
      {children}
    </MockAuthContext.Provider>
  );
};

// ===========================================
// MOCK AUTH INDICATOR BADGE
// ===========================================

/**
 * Visual indicator that mock auth mode is active
 * Shows a badge in the corner of the screen
 */
export const MockAuthBadge: React.FC = () => {
  if (!MOCK_AUTH_ENABLED) return null;

  return (
    <div
      style={{
        position: 'fixed',
        bottom: '16px',
        right: '16px',
        background: '#F59E0B',
        color: '#000',
        padding: '8px 16px',
        borderRadius: '8px',
        fontSize: '12px',
        fontWeight: '600',
        fontFamily: 'monospace',
        zIndex: 9999,
        boxShadow: '0 2px 8px rgba(0,0,0,0.2)',
        display: 'flex',
        alignItems: 'center',
        gap: '6px',
      }}
    >
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
      </svg>
      MOCK AUTH MODE
    </div>
  );
};
