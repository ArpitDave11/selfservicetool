/**
 * Auth Module Exports
 *
 * Provides conditional MSAL authentication for Epic Generator.
 *
 * @example Basic usage (production)
 * ```tsx
 * // main.tsx
 * import { AuthProvider, AuthGuard } from './auth';
 *
 * <AuthProvider>
 *   <AuthGuard>
 *     <App />
 *   </AuthGuard>
 * </AuthProvider>
 * ```
 *
 * @example Using auth state in components
 * ```tsx
 * import { useAuth, UserMenu } from './auth';
 *
 * const Header = () => {
 *   const { user, isAuthenticated } = useAuth();
 *   return (
 *     <header>
 *       <h1>App</h1>
 *       <UserMenu />
 *     </header>
 *   );
 * };
 * ```
 *
 * @example Local testing with mock auth
 * Set VITE_MSAL_AUTH_MOCK=true in .env to enable mock auth mode.
 * This simulates the full auth flow without connecting to Azure AD.
 */

// Configuration & Feature Flags
export {
  MSAL_AUTH_ENABLED,
  shouldUseMsalAuth,
  msalConfig,
  loginRequest,
  silentRequest,
} from './authConfig';

// Provider & Hook
export { AuthProvider, useAuth } from './AuthProvider';

// Guard Component
export { AuthGuard } from './AuthGuard';

// UI Components
export { UserMenu } from './UserMenu';

// Mock Auth (for local testing)
export { MockAuthProvider, MockAuthBadge, MOCK_AUTH_ENABLED } from './MockAuthProvider';

// Types
export type {
  AuthenticatedUser,
  AuthContextType,
  AuthProviderProps,
  AuthGuardProps,
} from './types';
