/**
 * Conditional MSAL Authentication Provider
 *
 * Updated for @azure/msal-browser v5.x and @azure/msal-react v5.x
 *
 * React 19 compatible authentication provider that:
 * - When MSAL_AUTH_ENABLED is true: Wraps app with MsalProvider and handles Azure AD auth
 * - When MSAL_AUTH_ENABLED is false: Bypasses all auth, renders children directly
 * - When MSAL_AUTH_MOCK is true: Uses mock auth for local testing
 *
 * IMPORTANT: MSAL v5 requires async initialization with await pca.initialize()
 */

import React, { createContext, useContext, useEffect, useState, useCallback, useRef } from 'react';
import { MSAL_AUTH_ENABLED, msalConfig, loginRequest, shouldUseMsalAuth } from './authConfig';
import { MockAuthProvider, MOCK_AUTH_ENABLED, useMockAuth } from './MockAuthProvider';
import type { AuthContextType, AuthenticatedUser, AuthProviderProps } from './types';

// ===========================================
// CONDITIONAL MSAL IMPORTS
// Only import MSAL when auth is enabled to enable tree-shaking
// ===========================================

let PublicClientApplication: any = null;
let MsalProvider: any = null;
let useMsal: any = null;
let useIsAuthenticated: any = null;
let InteractionStatus: any = null;

// Track module loading state
let msalModulesLoaded = false;
let msalLoadError: Error | null = null;

// Dynamic import MSAL only when needed
if (MSAL_AUTH_ENABLED) {
  try {
    const msalBrowser = require('@azure/msal-browser');
    const msalReact = require('@azure/msal-react');

    PublicClientApplication = msalBrowser.PublicClientApplication;
    InteractionStatus = msalBrowser.InteractionStatus;
    MsalProvider = msalReact.MsalProvider;
    useMsal = msalReact.useMsal;
    useIsAuthenticated = msalReact.useIsAuthenticated;
    msalModulesLoaded = true;
  } catch (e) {
    console.error('[Auth] Failed to load MSAL packages. Make sure @azure/msal-browser and @azure/msal-react are installed.');
    console.error(e);
    msalLoadError = e instanceof Error ? e : new Error(String(e));
  }
}

// ===========================================
// AUTH CONTEXT
// ===========================================

const defaultAuthContext: AuthContextType = {
  user: null,
  isAuthenticated: !MSAL_AUTH_ENABLED, // Always "authenticated" when auth disabled
  isLoading: false,
  error: null,
  login: async () => {},
  logout: async () => {},
};

const AuthContext = createContext<AuthContextType>(defaultAuthContext);

// Internal hook for real MSAL auth context (not exported - use useAuth instead)
const useRealAuthContext = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// ===========================================
// MSAL AUTH CONTENT (Internal component)
// Only used when MSAL is enabled
// ===========================================

const MsalAuthContent: React.FC<AuthProviderProps> = ({ children }) => {
  const { instance, inProgress } = useMsal();
  const isAuthenticated = useIsAuthenticated();
  const [user, setUser] = useState<AuthenticatedUser | null>(null);
  const [isInitialized, setIsInitialized] = useState(false);
  const [authError, setAuthError] = useState<Error | null>(null);

  // Guard against double initialization in StrictMode
  const isInitializing = useRef(false);

  // Single initialization effect - NO accounts in dependencies to prevent infinite loop
  useEffect(() => {
    // Prevent double initialization in StrictMode
    if (isInitializing.current || isInitialized) {
      return;
    }
    isInitializing.current = true;

    let isMounted = true;

    const initializeAuth = async () => {
      try {
        // Handle any redirect response from Azure AD
        const response = await instance.handleRedirectPromise();

        if (!isMounted) return;

        let activeAccount = response?.account;

        // If no redirect response, check for existing accounts
        if (!activeAccount) {
          activeAccount = instance.getActiveAccount();
          if (!activeAccount) {
            const allAccounts = instance.getAllAccounts();
            if (allAccounts.length > 0) {
              activeAccount = allAccounts[0];
            }
          }
        }

        // Set active account and update user state together (prevent race condition)
        if (activeAccount) {
          instance.setActiveAccount(activeAccount);
          setUser({
            name: activeAccount.name || 'Unknown User',
            email: activeAccount.username || '',
            username: activeAccount.username?.split('@')[0] || '',
            tenantId: activeAccount.tenantId,
            objectId: activeAccount.localAccountId,
          });
        } else {
          setUser(null);
        }

        setAuthError(null);
      } catch (error) {
        console.error('[Auth] Redirect handling error:', error);
        if (isMounted) {
          setAuthError(error instanceof Error ? error : new Error(String(error)));
          setUser(null);
        }
      } finally {
        if (isMounted) {
          setIsInitialized(true);
        }
      }
    };

    initializeAuth();

    // Cleanup function to prevent state updates after unmount
    return () => {
      isMounted = false;
    };
  }, [instance, isInitialized]); // NO accounts dependency - prevents infinite loop

  // Login handler
  const login = useCallback(async () => {
    try {
      setAuthError(null);
      await instance.loginRedirect(loginRequest);
    } catch (error) {
      console.error('[Auth] Login failed:', error);
      setAuthError(error instanceof Error ? error : new Error(String(error)));
      throw error;
    }
  }, [instance]);

  // Logout handler
  const logout = useCallback(async () => {
    try {
      setUser(null);
      await instance.logoutRedirect({
        postLogoutRedirectUri: window.location.origin,
      });
    } catch (error) {
      console.error('[Auth] Logout failed:', error);
      throw error;
    }
  }, [instance]);

  // Get access token for API calls
  const getAccessToken = useCallback(async (): Promise<string | null> => {
    try {
      const account = instance.getActiveAccount();
      if (!account) return null;

      const response = await instance.acquireTokenSilent({
        ...loginRequest,
        account,
      });
      return response.accessToken;
    } catch (error) {
      console.error('[Auth] Token acquisition failed:', error);
      return null;
    }
  }, [instance]);

  // IMPORTANT: In v5, InteractionStatus may have been refactored
  // Ensure InteractionStatus.None is still the correct value
  const isLoading = !isInitialized || (InteractionStatus && inProgress !== InteractionStatus.None);

  const authContextValue: AuthContextType = {
    user,
    isAuthenticated,
    isLoading,
    error: authError,
    login,
    logout,
    getAccessToken,
  };

  return (
    <AuthContext.Provider value={authContextValue}>
      {children}
    </AuthContext.Provider>
  );
};

// ===========================================
// AUTH PROVIDER (Main export)
// CRITICAL: MSAL v5 requires async initialization
// ===========================================

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [msalInstance, setMsalInstance] = useState<any>(null);
  const [isInitializing, setIsInitializing] = useState(MSAL_AUTH_ENABLED && msalModulesLoaded);
  const [initError, setInitError] = useState<Error | null>(msalLoadError);
  const initStarted = useRef(false);

  // CRITICAL: Initialize MSAL instance asynchronously (required for v3+/v5)
  useEffect(() => {
    if (!MSAL_AUTH_ENABLED || !msalModulesLoaded || !PublicClientApplication) {
      setIsInitializing(false);
      return;
    }

    if (initStarted.current) {
      return;
    }
    initStarted.current = true;

    let isMounted = true;

    const initializeMsal = async () => {
      try {
        // Create the MSAL instance
        const instance = new PublicClientApplication(msalConfig);

        // CRITICAL: Must await initialize() before using any MSAL APIs (v5 requirement)
        await instance.initialize();

        if (isMounted) {
          setMsalInstance(instance);
          setIsInitializing(false);
        }
      } catch (error) {
        console.error('[Auth] Failed to initialize MSAL:', error);
        if (isMounted) {
          setInitError(error instanceof Error ? error : new Error(String(error)));
          setIsInitializing(false);
        }
      }
    };

    initializeMsal();

    return () => {
      isMounted = false;
    };
  }, []);

  // Priority 1: Mock auth mode for local testing
  if (MOCK_AUTH_ENABLED) {
    console.log('[Auth] Using MOCK authentication mode for local testing');
    return <MockAuthProvider>{children}</MockAuthProvider>;
  }

  // Priority 2: Real MSAL auth disabled - bypass entirely
  if (!shouldUseMsalAuth()) {
    const bypassAuthContext: AuthContextType = {
      user: null,
      isAuthenticated: true, // Always "authenticated" when auth is bypassed
      isLoading: false,
      error: null,
      login: async () => {
        console.log('[Auth] Authentication is disabled - login skipped');
      },
      logout: async () => {
        console.log('[Auth] Authentication is disabled - logout skipped');
      },
    };

    return (
      <AuthContext.Provider value={bypassAuthContext}>
        {children}
      </AuthContext.Provider>
    );
  }

  // Show loading while MSAL is initializing
  if (isInitializing) {
    return (
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          height: '100vh',
          fontFamily: 'sans-serif',
          background: '#0a0a0a',
          color: '#fff',
        }}
      >
        <p>Initializing authentication...</p>
      </div>
    );
  }

  // Show error if initialization failed
  if (initError) {
    return (
      <div style={{ padding: '20px', color: '#ff4444', fontFamily: 'sans-serif', background: '#0a0a0a', minHeight: '100vh' }}>
        <h2>Authentication Initialization Error</h2>
        <p>{initError.message}</p>
        <code style={{ background: '#1a1a1a', padding: '8px', display: 'block', marginTop: '8px', color: '#fff' }}>
          npm install @azure/msal-browser @azure/msal-react
        </code>
      </div>
    );
  }

  // Priority 3: Real MSAL auth - check if packages loaded successfully
  if (!MsalProvider || !msalInstance) {
    console.error('[Auth] MSAL not available or not initialized');
    return (
      <div style={{ padding: '20px', color: '#ff4444', fontFamily: 'sans-serif', background: '#0a0a0a', minHeight: '100vh' }}>
        <h2>Authentication Error</h2>
        <p>MSAL packages not installed or failed to initialize.</p>
        <code style={{ background: '#1a1a1a', padding: '8px', display: 'block', marginTop: '8px', color: '#fff' }}>
          npm install @azure/msal-browser @azure/msal-react
        </code>
      </div>
    );
  }

  return (
    <MsalProvider instance={msalInstance}>
      <MsalAuthContent>{children}</MsalAuthContent>
    </MsalProvider>
  );
};

// ===========================================
// UNIFIED useAuth HOOK
// Works with both Mock and Real auth providers
// ===========================================

/**
 * Hook to access authentication context
 * Works with Mock, Real MSAL, and Bypass modes
 */
export const useAuth = (): AuthContextType => {
  // Try mock auth context first (when MOCK_AUTH_ENABLED)
  if (MOCK_AUTH_ENABLED) {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    return useMockAuth();
  }

  // Use regular auth context
  // eslint-disable-next-line react-hooks/rules-of-hooks
  return useRealAuthContext();
};
