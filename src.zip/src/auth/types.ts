/**
 * Authentication Types
 */

/**
 * Authenticated user information extracted from MSAL account
 */
export interface AuthenticatedUser {
  /** Full display name */
  name: string;
  /** Email address (UPN) */
  email: string;
  /** Username portion of email */
  username: string;
  /** Azure AD tenant ID */
  tenantId?: string;
  /** User's object ID in Azure AD */
  objectId?: string;
}

/**
 * Authentication context provided to the application
 */
export interface AuthContextType {
  /** Current authenticated user, null if not authenticated */
  user: AuthenticatedUser | null;
  /** Whether the user is currently authenticated */
  isAuthenticated: boolean;
  /** Whether authentication is in progress */
  isLoading: boolean;
  /** Authentication error, if any */
  error: Error | null;
  /** Initiate login flow */
  login: () => Promise<void>;
  /** Initiate logout flow */
  logout: () => Promise<void>;
  /** Get access token for API calls (optional) */
  getAccessToken?: () => Promise<string | null>;
}

/**
 * Props for AuthProvider component
 */
export interface AuthProviderProps {
  children: React.ReactNode;
}

/**
 * Props for AuthGuard component
 */
export interface AuthGuardProps {
  children: React.ReactNode;
  /** Custom loading component */
  loadingComponent?: React.ReactNode;
  /** Custom login component */
  loginComponent?: React.ReactNode;
  /** Custom error component */
  errorComponent?: React.ReactNode;
}
