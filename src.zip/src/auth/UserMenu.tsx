/**
 * User Menu Component
 *
 * Displays current user info and logout option.
 * Only renders when MSAL authentication is enabled and user is authenticated.
 */

import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from './AuthProvider';
import { shouldUseMsalAuth } from './authConfig';

// ===========================================
// UBS BRAND COLORS
// ===========================================

const UBS_COLORS = {
  red: '#E60000',
  black: '#000000',
  white: '#FFFFFF',
  grayI: '#ADACA5',
  grayIII: '#8E8D83',
  grayV: '#5A5D5C',
  pastelI: '#ECEBE4',
  neutral200: '#E5E5E5',
};

// ===========================================
// USER MENU COMPONENT
// ===========================================

/**
 * User profile dropdown menu
 *
 * @example
 * ```tsx
 * // In your header component
 * <header>
 *   <h1>Epic Generator</h1>
 *   <UserMenu />
 * </header>
 * ```
 */
export const UserMenu: React.FC = () => {
  const { user, logout, isAuthenticated } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  // Close on escape key
  useEffect(() => {
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('keydown', handleEscape);
    }

    return () => {
      document.removeEventListener('keydown', handleEscape);
    };
  }, [isOpen]);

  // Don't render if auth is disabled or user not authenticated
  if (!shouldUseMsalAuth() || !isAuthenticated || !user) {
    return null;
  }

  // Get user initials for avatar
  const initials = user.name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  const handleLogout = async () => {
    setIsOpen(false);
    await logout();
  };

  return (
    <div ref={menuRef} style={{ position: 'relative' }}>
      {/* User Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        aria-expanded={isOpen}
        aria-haspopup="true"
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          padding: '6px 12px',
          background: 'transparent',
          border: `1px solid ${UBS_COLORS.neutral200}`,
          borderRadius: '8px',
          cursor: 'pointer',
          transition: 'all 0.2s ease',
          outline: 'none',
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.background = UBS_COLORS.pastelI;
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.background = 'transparent';
        }}
        onFocus={(e) => {
          e.currentTarget.style.boxShadow = `0 0 0 2px ${UBS_COLORS.red}40`;
        }}
        onBlur={(e) => {
          e.currentTarget.style.boxShadow = 'none';
        }}
      >
        {/* Avatar */}
        <div
          style={{
            width: '28px',
            height: '28px',
            borderRadius: '50%',
            background: UBS_COLORS.red,
            color: UBS_COLORS.white,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '11px',
            fontWeight: '600',
          }}
        >
          {initials}
        </div>

        {/* Name */}
        <span
          style={{
            fontSize: '13px',
            color: UBS_COLORS.black,
            fontWeight: '500',
            maxWidth: '120px',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
          }}
        >
          {user.name.split(' ')[0]}
        </span>

        {/* Chevron */}
        <svg
          width="12"
          height="12"
          viewBox="0 0 24 24"
          fill="none"
          stroke={UBS_COLORS.grayV}
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          style={{
            transition: 'transform 0.2s ease',
            transform: isOpen ? 'rotate(180deg)' : 'rotate(0deg)',
          }}
        >
          <path d="M6 9l6 6 6-6" />
        </svg>
      </button>

      {/* Dropdown Menu */}
      {isOpen && (
        <div
          role="menu"
          style={{
            position: 'absolute',
            top: '100%',
            right: 0,
            marginTop: '4px',
            background: UBS_COLORS.white,
            borderRadius: '8px',
            boxShadow: '0 4px 16px rgba(0, 0, 0, 0.12)',
            border: `1px solid ${UBS_COLORS.neutral200}`,
            minWidth: '220px',
            zIndex: 1000,
            overflow: 'hidden',
            animation: 'userMenuFadeIn 0.15s ease',
          }}
        >
          {/* User Info Section */}
          <div
            style={{
              padding: '14px 16px',
              borderBottom: `1px solid ${UBS_COLORS.neutral200}`,
            }}
          >
            <div
              style={{
                fontSize: '14px',
                fontWeight: '500',
                color: UBS_COLORS.black,
                marginBottom: '2px',
              }}
            >
              {user.name}
            </div>
            <div
              style={{
                fontSize: '12px',
                color: UBS_COLORS.grayIII,
              }}
            >
              {user.email}
            </div>
          </div>

          {/* Menu Items */}
          <div style={{ padding: '4px 0' }}>
            <button
              role="menuitem"
              onClick={handleLogout}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '10px',
                width: '100%',
                padding: '10px 16px',
                background: 'transparent',
                border: 'none',
                textAlign: 'left',
                fontSize: '13px',
                color: UBS_COLORS.grayV,
                cursor: 'pointer',
                transition: 'background 0.15s ease',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = UBS_COLORS.pastelI;
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'transparent';
              }}
            >
              {/* Logout Icon */}
              <svg
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                <polyline points="16 17 21 12 16 7" />
                <line x1="21" y1="12" x2="9" y2="12" />
              </svg>
              Sign out
            </button>
          </div>
        </div>
      )}

      {/* Animation Styles */}
      <style>{`
        @keyframes userMenuFadeIn {
          from {
            opacity: 0;
            transform: translateY(-8px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
};
