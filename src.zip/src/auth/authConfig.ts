/**
 * MSAL Authentication Configuration
 *
 * Feature flag controlled authentication setup for Epic Generator.
 * When MSAL_AUTH_ENABLED is false, all authentication is bypassed.
 */

// ===========================================
// MSAL FEATURE FLAG
// ===========================================
// Control via environment variable: VITE_MSAL_AUTH_ENABLED=true/false
// When false: App runs without any authentication
// When true: Azure AD login is required

export const MSAL_AUTH_ENABLED: boolean =
  import.meta.env.VITE_MSAL_AUTH_ENABLED === 'true';

/**
 * Helper function to check if MSAL auth should be used
 */
export function shouldUseMsalAuth(): boolean {
  return MSAL_AUTH_ENABLED;
}

// ===========================================
// MSAL CONFIGURATION
// ===========================================

// Default Azure AD values (replace with your own)
const DEFAULT_CLIENT_ID = 'fe1265b4-2d98-4687-9999-1956f428b8ae';
const DEFAULT_TENANT_ID = 'fb6ea403-7cf1-4905-810a-fe5547e98204';

/**
 * Build redirect URI dynamically based on current origin
 */
const getRedirectUri = (): string => {
  const appContext = import.meta.env.VITE_APP_CONTEXT || '/';
  return `${window.location.origin}${appContext}`;
};

/**
 * MSAL Configuration object
 * @see https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-browser/docs/configuration.md
 */
export const msalConfig = {
  auth: {
    clientId: import.meta.env.VITE_MSAL_CLIENT_ID || DEFAULT_CLIENT_ID,
    authority: `https://login.microsoftonline.com/${import.meta.env.VITE_MSAL_TENANT_ID || DEFAULT_TENANT_ID}`,
    redirectUri: getRedirectUri(),
    postLogoutRedirectUri: getRedirectUri(),
    navigateToLoginRequestUrl: true,
  },
  cache: {
    cacheLocation: 'sessionStorage' as const, // More secure than localStorage
    storeAuthStateInCookie: false,
  },
  system: {
    loggerOptions: {
      logLevel: import.meta.env.DEV ? 3 : 0, // Info in dev, Error only in prod
      loggerCallback: (level: number, message: string, containsPii: boolean) => {
        if (containsPii) return;
        switch (level) {
          case 0: console.error('[MSAL]', message); break;
          case 1: console.warn('[MSAL]', message); break;
          case 2: console.info('[MSAL]', message); break;
          case 3: console.debug('[MSAL]', message); break;
        }
      },
    },
  },
};

/**
 * Login request configuration
 */
export const loginRequest = {
  scopes: ['openid', 'profile', 'email'],
};

/**
 * Silent request configuration for token refresh
 */
export const silentRequest = {
  scopes: ['openid', 'profile', 'email'],
  forceRefresh: false,
};
