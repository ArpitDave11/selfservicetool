// Sidebar Component - UBS Brand Theme Compliant
// Per UBS Brand Theme Style Guide: flat colors, official palette, weight 300

import { type FC, type ReactNode, useState, useEffect } from 'react';

interface NavItem {
  id: string;
  label: string;
  icon: ReactNode;
  isExternal?: boolean;
}

interface SidebarProps {
  activeItem: string;
  onNavigate: (itemId: string) => void;
  isCollapsed?: boolean;
  onToggleCollapse?: (collapsed: boolean) => void;
}

// Navigation items configuration
const navItems: NavItem[] = [
  {
    id: 'epic-planner',
    label: 'Epic Planner',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
      </svg>
    ),
  },
  {
    id: 'blueprints',
    label: 'Blueprints',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <rect x="3" y="3" width="18" height="6" rx="1" />
        <rect x="3" y="12" width="8" height="9" rx="1" />
        <rect x="14" y="12" width="7" height="9" rx="1" />
      </svg>
    ),
  },
  {
    id: 'settings',
    label: 'Settings',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <circle cx="12" cy="12" r="3" />
        <path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-2 2 2 2 0 01-2-2v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 01-2-2 2 2 0 012-2h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 010-2.83 2 2 0 012.83 0l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 012-2 2 2 0 012 2v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 0 2 2 0 010 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 012 2 2 2 0 01-2 2h-.09a1.65 1.65 0 00-1.51 1z" />
      </svg>
    ),
  },
];

// Layout constants - Swiss precision with 8px base unit
const COLLAPSED_WIDTH = '56px';
const EXPANDED_WIDTH = 'var(--sidebar-width, 240px)';

// Official UBS Brand Colors - From UBS Brand Theme Style Guide
const UBS_COLORS = {
  // Primary Brand Colors
  red: '#E60000',           // UBS Red - Primary brand color
  bordeauxI: '#BD000C',     // Bordeaux I - Hover state for UBS Red
  black: '#000000',         // Black - Primary text
  white: '#FFFFFF',         // White - Backgrounds

  // Gray Palette (Official UBS Grays)
  grayI: '#CCCABC',         // Gray I - Decorative elements
  grayIII: '#8E8D83',       // Gray III - Secondary text
  grayV: '#5A5D5C',         // Gray V - Icons, tertiary text

  // Pastel Palette (Official UBS Pastels)
  pastelI: '#ECEBE4',       // Pastel I - Subtle backgrounds
  pastelII: '#F5F0E1',      // Pastel II - Hover backgrounds

  // Neutral Palette (Official UBS Neutrals)
  neutral50: '#FAFAFA',     // Neutral-50 - Sidebar background
  neutral200: '#E5E5E5',    // Neutral-200 - Borders

  // Focus/Accessibility
  redGlow: 'rgba(230, 0, 0, 0.12)',  // For focus rings
};

/* UBS Brand Compliant Sidebar Styles
   Design principles per UBS Brand Theme Style Guide:
   - Flat colors (no gradients)
   - Official UBS color palette only
   - Font weight 300 (Frutiger Light equivalent)
   - Clean, professional appearance
*/
const getSidebarStyles = (isCollapsed: boolean) => ({
  sidebarWrapper: {
    position: 'sticky' as const,
    top: '16px',
    height: 'calc(100vh - 32px)',
    margin: '16px 0 16px 16px',
    display: 'flex',
    alignItems: 'flex-start',
  },

  sidebar: {
    width: isCollapsed ? COLLAPSED_WIDTH : EXPANDED_WIDTH,
    minWidth: isCollapsed ? COLLAPSED_WIDTH : EXPANDED_WIDTH,
    height: '100%',
    // UBS Brand: Flat Neutral-50 background
    background: UBS_COLORS.neutral50,
    display: 'flex',
    flexDirection: 'column' as const,
    position: 'relative' as const,
    borderRadius: '12px',
    // Subtle shadow for depth
    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.08)',
    // UBS Brand: Neutral-200 border
    border: `1px solid ${UBS_COLORS.neutral200}`,
    overflow: 'hidden',
    transition: 'width 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
  },

  logoContainer: {
    padding: isCollapsed ? '16px 12px' : '20px 16px',
    // UBS Brand: Neutral-200 border
    borderBottom: `1px solid ${UBS_COLORS.neutral200}`,
    // UBS Brand: Flat white background
    background: UBS_COLORS.white,
    display: isCollapsed ? 'none' : 'flex',
    justifyContent: 'flex-start',
    alignItems: 'center',
    minHeight: '64px',
    gap: '12px',
    position: 'relative' as const,
  },

  // Toggle button container - positioned outside sidebar to the right
  toggleWrapper: {
    marginLeft: '-16px',
    marginTop: '16px',
    zIndex: 100,
  },

  logo: {
    display: isCollapsed ? 'none' : 'flex',
    alignItems: 'center',
    gap: '10px',
    overflow: 'hidden',
  },

  logoImage: {
    height: '32px',
    width: 'auto',
    flexShrink: 0,
    // HD rendering
    imageRendering: 'crisp-edges' as const,
    WebkitFontSmoothing: 'antialiased',
  },

  // UBS Brand: Logo text with Black color
  logoText: {
    fontSize: '17px',
    fontWeight: 600 as const,
    color: UBS_COLORS.black,
    textRendering: 'optimizeLegibility' as const,
    WebkitFontSmoothing: 'antialiased',
    MozOsxFontSmoothing: 'grayscale' as const,
    letterSpacing: '0.08em',
    lineHeight: 1,
    whiteSpace: 'nowrap' as const,
    fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
  },

  // UBS Brand: Toggle button with flat colors
  toggleButton: {
    width: '32px',
    height: '32px',
    borderRadius: '8px',
    // UBS Brand: Flat white background
    background: UBS_COLORS.white,
    border: `1px solid ${UBS_COLORS.neutral200}`,
    boxShadow: '0 1px 3px rgba(0, 0, 0, 0.08)',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
    transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
  },

  toggleButtonHover: {
    // UBS Brand: Pastel II hover background
    background: UBS_COLORS.pastelII,
    borderColor: UBS_COLORS.grayI,
    boxShadow: '0 2px 6px rgba(0, 0, 0, 0.1)',
  },

  toggleIcon: {
    // UBS Brand: Gray V for icons
    color: UBS_COLORS.grayV,
    width: '14px',
    height: '14px',
    transform: isCollapsed ? 'rotate(180deg)' : 'rotate(0deg)',
    transition: 'transform 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
  },

  nav: {
    flex: 1,
    padding: isCollapsed ? '12px 8px' : '16px 12px',
    overflowY: 'auto' as const,
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '4px',
  },

  // UBS Brand: Navigation button with flat colors and weight 300
  navButton: (isActive: boolean, isHovered: boolean) => ({
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    width: '100%',
    padding: isCollapsed ? '10px' : '12px 14px',
    cursor: 'pointer',
    // UBS Brand: Black text, White when active
    color: isActive
      ? UBS_COLORS.white
      : UBS_COLORS.black,
    // UBS Brand: Flat colors - UBS Red active, Pastel II hover
    backgroundColor: isActive
      ? UBS_COLORS.red
      : isHovered
        ? UBS_COLORS.pastelII
        : 'transparent',
    background: isActive
      ? UBS_COLORS.red
      : isHovered
        ? UBS_COLORS.pastelII
        : 'transparent',
    border: 'none',
    borderRadius: '8px',
    fontSize: '14px',
    // UBS Brand: Font weight 300 (Frutiger Light), 400 for active
    fontWeight: isActive ? 400 : 300,
    transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
    textDecoration: 'none',
    textAlign: 'left' as const,
    fontFamily: 'inherit',
    outline: 'none',
    letterSpacing: '-0.01em',
    position: 'relative' as const,
    boxShadow: 'none',
    justifyContent: isCollapsed ? 'center' : 'flex-start',
    overflow: 'hidden',
  }),

  // UBS Brand: Icon colors - Gray V default, White when active
  navIcon: (isActive: boolean) => ({
    color: isActive
      ? UBS_COLORS.white
      : UBS_COLORS.grayV,
    flexShrink: 0,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    transition: 'color 0.15s ease-out',
  }),

  navLabel: {
    opacity: isCollapsed ? 0 : 1,
    display: isCollapsed ? 'none' : 'inline',
    whiteSpace: 'nowrap' as const,
  },

  externalIcon: {
    marginLeft: 'auto',
    opacity: 0.4,
    display: isCollapsed ? 'none' : 'block',
  },

  // UBS Brand: Footer with flat colors
  footer: {
    padding: isCollapsed ? '12px 8px' : '20px 16px',
    // UBS Brand: Neutral-200 border
    borderTop: `1px solid ${UBS_COLORS.neutral200}`,
    // UBS Brand: Flat Pastel I background
    background: UBS_COLORS.pastelI,
    display: 'flex',
    flexDirection: 'column' as const,
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
  },

  footerLogo: {
    height: isCollapsed ? '24px' : '40px',
    width: 'auto',
    opacity: 0.6,
    transition: 'opacity 0.2s ease',
  },

  // UBS Brand: Footer text with Gray III and weight 300
  footerText: {
    fontSize: '11px',
    color: UBS_COLORS.grayIII,
    letterSpacing: '0.02em',
    fontWeight: 300,
    textAlign: 'center' as const,
    display: isCollapsed ? 'none' : 'block',
    fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
  },

  // UBS Brand: Tooltip with flat black background
  tooltip: {
    position: 'absolute' as const,
    left: '100%',
    marginLeft: '12px',
    padding: '8px 12px',
    // UBS Brand: Flat black background
    background: UBS_COLORS.black,
    color: UBS_COLORS.white,
    fontSize: '12px',
    fontWeight: 300,
    letterSpacing: '-0.01em',
    borderRadius: '8px',
    whiteSpace: 'nowrap' as const,
    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
    zIndex: 1000,
    pointerEvents: 'none' as const,
    opacity: 0,
    transform: 'translateX(-8px) scale(0.95)',
    transition: 'opacity 0.2s ease-out, transform 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
    border: 'none',
  },

  tooltipVisible: {
    opacity: 1,
    transform: 'translateX(0) scale(1)',
  },
});

/* UBS Brand: Focus styles with UBS Red accent for accessibility */
const focusStyles = `
  .sidebar-nav-button:focus-visible {
    outline: 2px solid ${UBS_COLORS.red};
    outline-offset: 2px;
    box-shadow: 0 0 0 4px ${UBS_COLORS.redGlow};
  }

  .sidebar-nav-button:active {
    background-color: ${UBS_COLORS.bordeauxI} !important;
    color: ${UBS_COLORS.white} !important;
  }

  .sidebar-toggle-btn:focus-visible {
    outline: 2px solid ${UBS_COLORS.red};
    outline-offset: 2px;
    box-shadow: 0 0 0 4px ${UBS_COLORS.redGlow};
  }

  .sidebar-toggle-btn:active {
    background-color: ${UBS_COLORS.pastelI} !important;
  }

  .sidebar-footer-logo:hover {
    opacity: 0.8 !important;
    transition: opacity 0.2s ease;
  }
`;

const Sidebar: FC<SidebarProps> = ({
  activeItem,
  onNavigate,
  isCollapsed: controlledCollapsed,
  onToggleCollapse
}) => {
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);
  const [toggleHovered, setToggleHovered] = useState(false);
  const [internalCollapsed, setInternalCollapsed] = useState(false);

  // Use controlled or internal state
  const isCollapsed = controlledCollapsed !== undefined ? controlledCollapsed : internalCollapsed;

  const styles = getSidebarStyles(isCollapsed);

  const handleToggle = () => {
    const newCollapsed = !isCollapsed;
    if (onToggleCollapse) {
      onToggleCollapse(newCollapsed);
    } else {
      setInternalCollapsed(newCollapsed);
    }
  };

  // Update CSS variable for main content adjustment
  useEffect(() => {
    document.documentElement.style.setProperty(
      '--sidebar-actual-width',
      isCollapsed ? COLLAPSED_WIDTH : EXPANDED_WIDTH
    );
  }, [isCollapsed]);

  return (
    <div style={styles.sidebarWrapper}>
      {/* Inject focus styles */}
      <style>{focusStyles}</style>

      <aside
        style={styles.sidebar}
        aria-label="Main navigation"
        data-collapsed={isCollapsed}
      >
        {/* Logo */}
        <div style={styles.logoContainer}>
          <div style={styles.logo}>
            <img
              src="/UBS-3821101260.png"
              alt="UBS Logo"
              style={styles.logoImage}
            />
            {/* UBS Brand: Separator line with Gray I */}
            <div style={{
              width: '1px',
              height: '20px',
              backgroundColor: UBS_COLORS.grayI,
              flexShrink: 0,
            }} />
            <span style={styles.logoText}>FRAME</span>
          </div>
        </div>

        {/* Navigation */}
        <nav style={styles.nav} aria-label="Main navigation">
          {navItems.map((item) => {
            const isActive = activeItem === item.id;
            const isHovered = hoveredItem === item.id;
            const showTooltip = isCollapsed && isHovered;

            return (
              <div key={item.id} style={{ position: 'relative' }}>
                <button
                  type="button"
                  className="sidebar-nav-button"
                  style={styles.navButton(isActive, isHovered)}
                  onClick={() => onNavigate(item.id)}
                  onMouseEnter={() => setHoveredItem(item.id)}
                  onMouseLeave={() => setHoveredItem(null)}
                  aria-current={isActive ? 'page' : undefined}
                  title={isCollapsed ? item.label : undefined}
                >
                  <span style={styles.navIcon(isActive)}>
                    {item.icon}
                  </span>
                  <span style={styles.navLabel}>{item.label}</span>
                  {item.isExternal && !isCollapsed && (
                    <svg
                      width="14"
                      height="14"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      style={{
                        ...styles.externalIcon,
                        opacity: isHovered ? 0.6 : 0.4,
                      }}
                      aria-hidden="true"
                    >
                      <path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6M15 3h6v6M10 14L21 3" />
                    </svg>
                  )}
                </button>

                {/* Tooltip for collapsed state */}
                {isCollapsed && (
                  <div
                    style={{
                      ...styles.tooltip,
                      ...(showTooltip ? styles.tooltipVisible : {}),
                    }}
                    role="tooltip"
                    aria-hidden={!showTooltip}
                  >
                    {item.label}
                  </div>
                )}
              </div>
            );
          })}
        </nav>

        {/* Footer with UBS Keys Logo - Premium styling */}
        <div style={styles.footer}>
          <img
            src="/ubs-keys-logo.png"
            alt="UBS Keys"
            style={styles.footerLogo}
            className="sidebar-footer-logo"
          />
          <span style={styles.footerText}>
            &copy; UBS {new Date().getFullYear()}
          </span>
        </div>
      </aside>

      {/* Toggle Button - positioned outside sidebar on the right edge */}
      <div style={styles.toggleWrapper}>
        <button
          type="button"
          className="sidebar-toggle-btn"
          style={{
            ...styles.toggleButton,
            ...(toggleHovered ? styles.toggleButtonHover : {}),
          }}
          onClick={handleToggle}
          onMouseEnter={() => setToggleHovered(true)}
          onMouseLeave={() => setToggleHovered(false)}
          aria-label={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          aria-expanded={!isCollapsed}
        >
          <svg
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            style={styles.toggleIcon}
            aria-hidden="true"
          >
            <polyline points="15 18 9 12 15 6" />
          </svg>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
