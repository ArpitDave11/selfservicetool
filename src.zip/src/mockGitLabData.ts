/**
 * Mock GitLab Data for Local Testing
 *
 * This file contains realistic mock data that mirrors actual GitLab API responses.
 * Used for end-to-end testing without requiring GitLab connectivity.
 *
 * To enable: Set MOCK_GITLAB_ENABLED = true in this file
 */

import type {
  GitLabEpic,
  GitLabLabel,
  GitLabEpicChild,
  GitLabEpicListResult,
  GitLabEpicResult,
  GitLabLabelResult,
  GitLabEpicChildrenResult,
  GitLabEpicSearchParams,
  GitLabCreateEpicParams,
  GitLabUpdateEpicParams,
  GitLabConfig,
  CreateIssueParams,
  GitLabIssueResult,
} from './config';

// ===========================================
// MOCK MODE TOGGLE - Set to true for local testing
// ===========================================
export const MOCK_GITLAB_ENABLED = true;

// ===========================================
// MOCK GROUPS DATA (for hierarchy navigation)
// ===========================================
export interface MockGitLabGroup {
  id: number;
  name: string;
  full_path: string;
  parent_id: number | null;
  description?: string;
  visibility?: string;
}

export const mockGroups: MockGitLabGroup[] = [
  // Root group
  {
    id: 557797,
    name: 'Engineering',
    full_path: 'engineering',
    parent_id: null,
    description: 'Engineering organization root group',
    visibility: 'private'
  },
  // First-level subgroups (Crews)
  {
    id: 557801,
    name: 'Platform Crew',
    full_path: 'engineering/platform-crew',
    parent_id: 557797,
    description: 'Platform engineering team',
    visibility: 'private'
  },
  {
    id: 557802,
    name: 'Mobile Crew',
    full_path: 'engineering/mobile-crew',
    parent_id: 557797,
    description: 'Mobile application team',
    visibility: 'private'
  },
  {
    id: 557803,
    name: 'Data Crew',
    full_path: 'engineering/data-crew',
    parent_id: 557797,
    description: 'Data engineering and analytics',
    visibility: 'private'
  },
  // Second-level subgroups (Pods)
  {
    id: 557810,
    name: 'Auth Pod',
    full_path: 'engineering/platform-crew/auth-pod',
    parent_id: 557801,
    description: 'Authentication and authorization services',
    visibility: 'private'
  },
  {
    id: 557811,
    name: 'API Pod',
    full_path: 'engineering/platform-crew/api-pod',
    parent_id: 557801,
    description: 'API gateway and services',
    visibility: 'private'
  },
  {
    id: 557812,
    name: 'Infrastructure Pod',
    full_path: 'engineering/platform-crew/infra-pod',
    parent_id: 557801,
    description: 'Cloud infrastructure and DevOps',
    visibility: 'private'
  },
  {
    id: 557820,
    name: 'iOS Pod',
    full_path: 'engineering/mobile-crew/ios-pod',
    parent_id: 557802,
    description: 'iOS native development',
    visibility: 'private'
  },
  {
    id: 557821,
    name: 'Android Pod',
    full_path: 'engineering/mobile-crew/android-pod',
    parent_id: 557802,
    description: 'Android native development',
    visibility: 'private'
  },
  {
    id: 557830,
    name: 'Pipelines Pod',
    full_path: 'engineering/data-crew/pipelines-pod',
    parent_id: 557803,
    description: 'Data pipeline engineering',
    visibility: 'private'
  },
];

// Map epics to groups for the hierarchy navigation
export const mockEpicGroupMapping: Record<number, number[]> = {
  // Root group has all epics
  557797: [101, 102, 103, 104, 105, 106],
  // Platform Crew
  557801: [101, 102, 105, 106],
  // Auth Pod (under Platform)
  557810: [102],
  // Infra Pod (under Platform)
  557812: [106],
  // Mobile Crew
  557802: [104],
  // Data Crew
  557803: [103],
  // Pipelines Pod (under Data)
  557830: [103],
};

// ===========================================
// MOCK EPICS DATA (Realistic GitLab API format)
// ===========================================
export const mockEpics: GitLabEpic[] = [
  {
    id: 12345678,
    iid: 101,
    group_id: 557797,
    title: 'Platform Modernization Initiative Q1 2025',
    description: `# Platform Modernization Initiative

## 1. Executive Summary
This epic captures the comprehensive effort to modernize our core platform infrastructure, improving scalability, maintainability, and developer experience.

## 2. Business Context
- **Problem Statement**: Current platform has accumulated technical debt limiting feature velocity
- **Strategic Alignment**: Supports company goal of 2x feature delivery speed by Q3 2025
- **Key Stakeholders**: Engineering, Product, Infrastructure teams

## 3. Technical Scope

### 3.1 Core Infrastructure
- Migrate to containerized microservices architecture
- Implement service mesh for inter-service communication
- Upgrade to PostgreSQL 16 with connection pooling

### 3.2 API Layer
- Implement GraphQL gateway for unified API access
- Add rate limiting and circuit breaker patterns
- Enhance API documentation with OpenAPI 3.1

### 3.3 Observability
- Deploy distributed tracing with Jaeger
- Implement structured logging with correlation IDs
- Create SLO dashboards in Grafana

## 4. Success Metrics
| Metric | Current | Target |
|--------|---------|--------|
| API Latency (p99) | 450ms | <200ms |
| Deployment Frequency | Weekly | Daily |
| Change Failure Rate | 15% | <5% |
| MTTR | 4 hours | <30 min |

## 5. Timeline
- **Phase 1** (Jan-Feb): Infrastructure setup
- **Phase 2** (Mar-Apr): Migration execution
- **Phase 3** (May): Validation and optimization

## 6. Dependencies
- Cloud infrastructure budget approval
- DevOps team capacity allocation
- Security review completion

## 7. Risks & Mitigations
| Risk | Impact | Mitigation |
|------|--------|------------|
| Data migration complexity | High | Incremental migration with rollback capability |
| Team learning curve | Medium | Training sessions and pair programming |
| Service disruption | High | Blue-green deployment strategy |
`,
    state: 'opened',
    confidential: false,
    author: {
      id: 1001,
      username: 'john.smith',
      name: 'John Smith'
    },
    labels: ['crew::platform', 'epic-generator', 'priority::high', 'Q1-2025'],
    start_date: '2025-01-01',
    due_date: '2025-05-31',
    created_at: '2024-12-15T10:30:00Z',
    updated_at: '2025-01-14T15:45:00Z',
    closed_at: null,
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/101',
    epicLevel: 'crew'
  },
  {
    id: 12345679,
    iid: 102,
    group_id: 557797,
    title: 'User Authentication Service Refactor',
    description: `# User Authentication Service Refactor

## Overview
Modernize the authentication service to support OAuth 2.0, SAML, and passwordless authentication methods.

## Objectives
1. Implement OAuth 2.0 / OIDC provider
2. Add SAML 2.0 integration for enterprise SSO
3. Support WebAuthn for passwordless login
4. Enhance session management with refresh tokens

## Technical Requirements

### Authentication Methods
- OAuth 2.0 Authorization Code Flow with PKCE
- SAML 2.0 Service Provider implementation
- WebAuthn/FIDO2 for biometric authentication
- Magic link email authentication

### Security Enhancements
- JWT token rotation with sliding window
- Device fingerprinting for anomaly detection
- Rate limiting per user and IP
- Audit logging for all auth events

### Integration Points
- Identity Provider federation
- User directory synchronization
- Multi-tenant support

## Acceptance Criteria
- [ ] All existing auth flows continue working
- [ ] New OAuth clients can be registered via API
- [ ] SAML metadata can be imported/exported
- [ ] WebAuthn registration flow complete
- [ ] 99.99% auth service availability

## Dependencies
- Platform Modernization Epic (parent)
- Security team approval
- Compliance review for PII handling
`,
    state: 'opened',
    confidential: false,
    author: {
      id: 1002,
      username: 'jane.doe',
      name: 'Jane Doe'
    },
    labels: ['pod::auth', 'epic-generator', 'security', 'priority::high'],
    start_date: '2025-01-15',
    due_date: '2025-03-31',
    created_at: '2025-01-05T09:00:00Z',
    updated_at: '2025-01-13T11:20:00Z',
    closed_at: null,
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/102',
    parent: {
      id: 12345678,
      iid: 101,
      title: 'Platform Modernization Initiative Q1 2025'
    },
    epicLevel: 'pod'
  },
  {
    id: 12345680,
    iid: 103,
    group_id: 557797,
    title: 'Data Pipeline Optimization',
    description: `# Data Pipeline Optimization

## Summary
Optimize existing data pipelines for better performance, reliability, and cost efficiency.

## Current State
- Batch processing taking 6+ hours
- High failure rate on large datasets
- Limited real-time capabilities

## Target State
- Batch processing < 2 hours
- 99.9% pipeline success rate
- Near real-time data availability

## Implementation Plan

### Phase 1: Assessment
- Profile existing pipelines
- Identify bottlenecks
- Document data dependencies

### Phase 2: Optimization
- Implement incremental processing
- Add data partitioning
- Optimize queries and transformations

### Phase 3: Monitoring
- Pipeline health dashboards
- Automated alerting
- Data quality checks

## Success Metrics
- Processing time reduction: 70%
- Cost reduction: 40%
- Data freshness: < 15 minutes
`,
    state: 'opened',
    confidential: false,
    author: {
      id: 1003,
      username: 'bob.wilson',
      name: 'Bob Wilson'
    },
    labels: ['pod::data', 'epic-generator', 'performance'],
    start_date: '2025-02-01',
    due_date: '2025-04-30',
    created_at: '2025-01-10T14:00:00Z',
    updated_at: '2025-01-12T09:30:00Z',
    closed_at: null,
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/103',
    parent: {
      id: 12345678,
      iid: 101,
      title: 'Platform Modernization Initiative Q1 2025'
    },
    epicLevel: 'pod'
  },
  {
    id: 12345681,
    iid: 104,
    group_id: 557797,
    title: 'Mobile App Redesign',
    description: `# Mobile App Redesign

## Vision
Create a modern, intuitive mobile experience that increases user engagement by 50%.

## Key Features
1. New navigation paradigm
2. Offline-first architecture
3. Biometric authentication
4. Push notification enhancements
5. Dark mode support

## Design Principles
- Mobile-first approach
- Accessibility (WCAG 2.1 AA)
- Performance budget: <3s initial load
- Gesture-based interactions

## Technical Stack
- React Native 0.73+
- TypeScript
- Redux Toolkit
- React Query for caching

## Timeline
Q1 2025: Design and prototyping
Q2 2025: Development
Q3 2025: Testing and launch
`,
    state: 'opened',
    confidential: false,
    author: {
      id: 1004,
      username: 'sarah.chen',
      name: 'Sarah Chen'
    },
    labels: ['crew::mobile', 'epic-generator', 'ux', 'priority::medium'],
    start_date: '2025-01-01',
    due_date: '2025-09-30',
    created_at: '2024-12-01T08:00:00Z',
    updated_at: '2025-01-11T16:00:00Z',
    closed_at: null,
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/104',
    epicLevel: 'crew'
  },
  {
    id: 12345682,
    iid: 105,
    group_id: 557797,
    title: 'Legacy API Migration (Completed)',
    description: `# Legacy API Migration

## Summary
Successfully migrated all v1 API endpoints to v2 with improved performance and security.

## Achievements
- Migrated 47 endpoints
- Zero downtime deployment
- 35% latency improvement
- All clients updated

## Lessons Learned
- Gradual rollout was key to success
- Client communication essential
- Monitoring prevented issues
`,
    state: 'closed',
    confidential: false,
    author: {
      id: 1001,
      username: 'john.smith',
      name: 'John Smith'
    },
    labels: ['crew::platform', 'epic-generator', 'migration', 'completed'],
    start_date: '2024-06-01',
    due_date: '2024-11-30',
    created_at: '2024-05-15T10:00:00Z',
    updated_at: '2024-12-01T12:00:00Z',
    closed_at: '2024-12-01T12:00:00Z',
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/105',
    epicLevel: 'crew'
  },
  {
    id: 12345683,
    iid: 106,
    group_id: 557797,
    title: 'Infrastructure Cost Optimization',
    description: `# Infrastructure Cost Optimization

## Objective
Reduce cloud infrastructure costs by 30% while maintaining performance and reliability.

## Focus Areas

### Compute Optimization
- Right-size EC2 instances
- Implement auto-scaling policies
- Use spot instances for batch workloads

### Storage Optimization
- Implement data lifecycle policies
- Move cold data to cheaper tiers
- Deduplicate redundant storage

### Network Optimization
- Optimize data transfer
- Use CDN effectively
- Reduce cross-region traffic

## Expected Savings
| Category | Current | Target | Savings |
|----------|---------|--------|---------|
| Compute | $50k/mo | $35k/mo | $15k/mo |
| Storage | $20k/mo | $14k/mo | $6k/mo |
| Network | $10k/mo | $7k/mo | $3k/mo |
| **Total** | **$80k/mo** | **$56k/mo** | **$24k/mo** |
`,
    state: 'opened',
    confidential: false,
    author: {
      id: 1005,
      username: 'mike.johnson',
      name: 'Mike Johnson'
    },
    labels: ['pod::infra', 'epic-generator', 'cost-optimization'],
    start_date: '2025-01-15',
    due_date: '2025-06-30',
    created_at: '2025-01-08T11:00:00Z',
    updated_at: '2025-01-14T10:00:00Z',
    closed_at: null,
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/106',
    parent: {
      id: 12345678,
      iid: 101,
      title: 'Platform Modernization Initiative Q1 2025'
    },
    epicLevel: 'pod'
  },
  // ===========================================
  // DIAGRAM TYPE TEST EPICS
  // These epics are designed to test specific diagram type generation
  // Naming convention: {projectname}-{diagramtype}
  // ===========================================
  {
    id: 12345701,
    iid: 201,
    group_id: 557797,
    title: 'platform-flowchart',
    description: `# Platform Architecture Redesign

## Objective
Redesign the platform architecture to support microservices.

## Architecture Overview
The system consists of:
- API Gateway for request routing
- Auth Service for authentication
- User Service for user management
- Order Service for order processing
- Notification Service for alerts
- PostgreSQL database for persistence
- Redis cache for sessions
- Kafka for event streaming

## Features
- Service discovery and load balancing
- Centralized logging with ELK stack
- Distributed tracing with Jaeger
- Health monitoring with Prometheus

## Data Stores
- PostgreSQL: User data, Orders
- Redis: Session cache, Rate limiting
- Kafka: Event bus, Audit logs

## Service Interactions
- Web App connects to API Gateway
- API Gateway routes to Auth Service
- Auth Service validates and forwards to User Service
- Order Service processes orders and sends to Notification Service
- All services write to PostgreSQL
- Sessions cached in Redis
- Events published to Kafka
`,
    state: 'opened',
    confidential: false,
    author: { id: 1001, username: 'test.user', name: 'Test User' },
    labels: ['diagram-test::flowchart', 'epic-generator', 'test-epic'],
    start_date: '2025-01-01',
    due_date: '2025-03-31',
    created_at: '2025-01-15T10:00:00Z',
    updated_at: '2025-01-15T10:00:00Z',
    closed_at: null,
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/201',
    epicLevel: 'crew'
  },
  {
    id: 12345702,
    iid: 202,
    group_id: 557797,
    title: 'orderflow-sequence',
    description: `# Order Processing Workflow

## Objective
Implement end-to-end order processing flow.

## User Stories
- As a customer, I want to place an order so that I can purchase products
- As a customer, I want to receive order confirmation via email
- As an admin, I want to view order status in real-time

## Workflow
1. User submits order from web app
2. API Gateway validates request
3. Order Service creates order record
4. Payment Service processes payment
5. Inventory Service reserves items
6. Notification Service sends confirmation
7. User receives email confirmation

## Interactions
- Web App → API Gateway: Submit order
- API Gateway → Auth Service: Validate token
- Auth Service → API Gateway: Return validation result
- API Gateway → Order Service: Create order
- Order Service → Payment Gateway: Process payment
- Payment Gateway → Order Service: Payment result
- Order Service → Inventory Service: Reserve items
- Inventory Service → Order Service: Reservation confirmed
- Order Service → Notification Service: Send email
- Notification Service → User: Email confirmation

## Message Flow
The sequence of messages between services is critical for understanding the system behavior.
`,
    state: 'opened',
    confidential: false,
    author: { id: 1001, username: 'test.user', name: 'Test User' },
    labels: ['diagram-test::sequence', 'epic-generator', 'test-epic'],
    start_date: '2025-01-01',
    due_date: '2025-03-31',
    created_at: '2025-01-15T10:00:00Z',
    updated_at: '2025-01-15T10:00:00Z',
    closed_at: null,
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/202',
    epicLevel: 'crew'
  },
  {
    id: 12345703,
    iid: 203,
    group_id: 557797,
    title: 'datamodel-er',
    description: `# Database Schema Design

## Objective
Design the relational database schema for the e-commerce platform.

## Data Model
### Entities and Relationships:
- USER has many ORDERS (one-to-many)
- ORDER contains many ORDER_ITEMS (one-to-many)
- ORDER_ITEM references PRODUCT (many-to-one)
- PRODUCT belongs to CATEGORY (many-to-one)
- USER has one CART (one-to-one)
- CART contains many CART_ITEMS (one-to-many)
- CART_ITEM references PRODUCT (many-to-one)
- PRODUCT has many REVIEWS (one-to-many)
- REVIEW belongs to USER (many-to-one)

### Entity Attributes:
- USER: id (PK), email (UK), name, password_hash, created_at
- ORDER: id (PK), user_id (FK), status, total, shipping_address, created_at
- ORDER_ITEM: id (PK), order_id (FK), product_id (FK), quantity, price
- PRODUCT: id (PK), name, description, price, category_id (FK), stock
- CATEGORY: id (PK), name, parent_id (FK)
- CART: id (PK), user_id (FK), created_at
- CART_ITEM: id (PK), cart_id (FK), product_id (FK), quantity
- REVIEW: id (PK), product_id (FK), user_id (FK), rating, comment

## Constraints
- Referential integrity between orders and users
- Cascade delete for cart items when cart is deleted
- Unique constraint on user email
- Check constraint on rating (1-5)
`,
    state: 'opened',
    confidential: false,
    author: { id: 1001, username: 'test.user', name: 'Test User' },
    labels: ['diagram-test::er', 'epic-generator', 'test-epic'],
    start_date: '2025-01-01',
    due_date: '2025-03-31',
    created_at: '2025-01-15T10:00:00Z',
    updated_at: '2025-01-15T10:00:00Z',
    closed_at: null,
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/203',
    epicLevel: 'crew'
  },
  {
    id: 12345704,
    iid: 204,
    group_id: 557797,
    title: 'sdk-class',
    description: `# SDK Architecture Design

## Objective
Design the class structure for the payment SDK.

## Classes and Interfaces

### PaymentClient (Main Entry Point)
- Attributes: apiKey, baseUrl, timeout, httpClient
- Methods: charge(), refund(), getTransaction(), listTransactions()

### Transaction
- Attributes: id, amount, currency, status, createdAt, metadata
- Methods: process(), cancel(), getReceipt(), toJSON()

### PaymentMethod (Abstract Base Class)
- Attributes: type, lastFour, expiryDate
- Abstract Methods: validate(), tokenize()

### CreditCard extends PaymentMethod
- Attributes: cardNumber, expiry, cvv, cardholderName
- Methods: validate(), tokenize(), isExpired()

### BankTransfer extends PaymentMethod
- Attributes: accountNumber, routingNumber, bankName
- Methods: validate(), initiateTransfer(), verifyAccount()

### Wallet extends PaymentMethod
- Attributes: walletType, email, phoneNumber
- Methods: validate(), tokenize(), getBalance()

### PaymentResult
- Attributes: success, transactionId, errorCode, errorMessage
- Methods: isSuccessful(), getTransaction()

### PaymentError extends Error
- Attributes: code, message, details
- Methods: toJSON(), isRetryable()

## Inheritance Hierarchy
- PaymentMethod (abstract)
  - CreditCard
  - BankTransfer
  - Wallet

## Composition
- PaymentClient contains HttpClient
- PaymentClient uses PaymentMethod
- Transaction has PaymentResult
`,
    state: 'opened',
    confidential: false,
    author: { id: 1001, username: 'test.user', name: 'Test User' },
    labels: ['diagram-test::class', 'epic-generator', 'test-epic'],
    start_date: '2025-01-01',
    due_date: '2025-03-31',
    created_at: '2025-01-15T10:00:00Z',
    updated_at: '2025-01-15T10:00:00Z',
    closed_at: null,
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/204',
    epicLevel: 'crew'
  },
  {
    id: 12345705,
    iid: 205,
    group_id: 557797,
    title: 'workflow-state',
    description: `# Document Approval Workflow

## Objective
Implement state machine for document approval process.

## States
- Draft: Initial state when document is created
- Pending Review: Submitted for review
- Under Review: Reviewer is examining
- Changes Requested: Reviewer requested modifications
- Approved: Document approved
- Rejected: Document rejected
- Published: Document is live
- Archived: Document retired

## Transitions
- Draft → Pending Review: Author submits for review
- Pending Review → Under Review: Reviewer starts examination
- Under Review → Approved: Reviewer approves
- Under Review → Rejected: Reviewer rejects permanently
- Under Review → Changes Requested: Reviewer requests modifications
- Changes Requested → Draft: Author starts revisions
- Approved → Published: Admin publishes document
- Published → Archived: Admin archives document
- Rejected → Draft: Author can start over (optional)

## State Entry Actions
- Pending Review: Notify assigned reviewers
- Under Review: Lock document for editing
- Approved: Generate approval certificate
- Published: Index for search
- Archived: Remove from active listings

## Events
- submit, start_review, approve, reject, request_changes, revise, publish, archive

## Guards
- Can only submit if document has content
- Can only publish if has required approvals
`,
    state: 'opened',
    confidential: false,
    author: { id: 1001, username: 'test.user', name: 'Test User' },
    labels: ['diagram-test::state', 'epic-generator', 'test-epic'],
    start_date: '2025-01-01',
    due_date: '2025-03-31',
    created_at: '2025-01-15T10:00:00Z',
    updated_at: '2025-01-15T10:00:00Z',
    closed_at: null,
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/205',
    epicLevel: 'crew'
  },
  {
    id: 12345706,
    iid: 206,
    group_id: 557797,
    title: 'modernize-gantt',
    description: `# Platform Modernization Initiative

## Objective
Migrate legacy monolith to microservices architecture over 6 months.

## Timeline and Phases

### Phase 1: Foundation (Month 1-2)
- Week 1-2: Architecture design and review
- Week 3-4: Infrastructure setup (Kubernetes, CI/CD)
- Week 5-6: Database migration planning
- Week 7-8: API Gateway implementation

### Phase 2: Migration (Month 3-4)
- Week 9-10: Auth service extraction
- Week 11-12: User service extraction
- Week 13-14: Order service extraction
- Week 15-16: Integration testing

### Phase 3: Validation (Month 5-6)
- Week 17-18: Performance testing
- Week 19-20: Security audit
- Week 21-22: Gradual traffic migration
- Week 23-24: Legacy decommissioning

## Milestones
- M1: Architecture approved (Week 2)
- M2: Infrastructure ready (Week 8)
- M3: Core services migrated (Week 16)
- M4: Production ready (Week 24)

## Dependencies
- Infrastructure must complete before service migration
- Auth service required before User service
- User service required before Order service
- All services must pass security audit before production

## Task Details
- Architecture design: 2 weeks duration, starts Jan 1
- Infrastructure setup: 2 weeks, starts after architecture
- Database planning: 2 weeks, parallel with infrastructure
- API Gateway: 2 weeks, depends on infrastructure
- Auth service: 2 weeks, depends on API Gateway
- User service: 2 weeks, depends on Auth service
- Order service: 2 weeks, depends on User service
- Integration testing: 2 weeks, after all services
- Performance testing: 2 weeks, after integration
- Security audit: 2 weeks, parallel with performance
- Traffic migration: 2 weeks, after both audits
- Decommission: 2 weeks, final phase
`,
    state: 'opened',
    confidential: false,
    author: { id: 1001, username: 'test.user', name: 'Test User' },
    labels: ['diagram-test::gantt', 'epic-generator', 'test-epic'],
    start_date: '2025-01-01',
    due_date: '2025-06-30',
    created_at: '2025-01-15T10:00:00Z',
    updated_at: '2025-01-15T10:00:00Z',
    closed_at: null,
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/206',
    epicLevel: 'crew'
  },
  {
    id: 12345707,
    iid: 207,
    group_id: 557797,
    title: 'versioning-gitgraph',
    description: `# Release Branching Strategy

## Objective
Define Git branching strategy for release management.

## Branches
- main: Production-ready code, always deployable
- develop: Integration branch for features
- feature/*: Feature development branches
- release/*: Release preparation branches
- hotfix/*: Emergency fixes for production

## Workflow Steps
1. Create feature branch from develop
2. Develop and commit changes to feature branch
3. Merge feature to develop via Pull Request
4. Create release branch from develop when ready
5. Test and fix bugs in release branch
6. Merge release to main and develop
7. Tag release version on main
8. Hotfix branches created from main for emergencies
9. Hotfix merged back to both main and develop

## Commits History Example
- Initial commit on main
- Branch develop from main
- Feature A: Create branch, 3 commits, merge to develop
- Feature B: Create branch, 2 commits, merge to develop
- Release 1.0.0: Branch from develop, bug fixes, merge to main
- Tag v1.0.0 on main
- Hotfix 1.0.1: Branch from main, fix critical bug, merge to main and develop
- Tag v1.0.1 on main
- Feature C: Create branch, 4 commits, merge to develop
- Release 1.1.0: Branch from develop, testing, merge to main
- Tag v1.1.0 on main

## Branch Protection Rules
- main: Require PR reviews, no direct commits
- develop: Require PR reviews
- release/*: Restrict to release managers
`,
    state: 'opened',
    confidential: false,
    author: { id: 1001, username: 'test.user', name: 'Test User' },
    labels: ['diagram-test::gitgraph', 'epic-generator', 'test-epic'],
    start_date: '2025-01-01',
    due_date: '2025-03-31',
    created_at: '2025-01-15T10:00:00Z',
    updated_at: '2025-01-15T10:00:00Z',
    closed_at: null,
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/207',
    epicLevel: 'crew'
  },
  {
    id: 12345708,
    iid: 208,
    group_id: 557797,
    title: 'features-mindmap',
    description: `# Product Feature Brainstorm

## Objective
Map out all features for the next product version.

## Feature Categories

### User Management
- Registration
  - Email signup
  - Social login (Google, GitHub, Apple)
  - SSO integration for enterprise
  - Invite system
- Profile
  - Avatar upload
  - Preferences settings
  - Notification settings
  - Privacy controls
- Security
  - Two-factor authentication
  - Session management
  - Password policies
  - Login history

### Commerce
- Catalog
  - Product listing
  - Categories and subcategories
  - Search and filters
  - Product recommendations
- Cart
  - Add/remove items
  - Save for later
  - Quantity updates
  - Price calculations
- Checkout
  - Multiple payment methods
  - Address management
  - Order summary
  - Discount codes

### Analytics
- Dashboard
  - Sales overview
  - User metrics
  - Revenue charts
  - Conversion rates
- Reports
  - Export to CSV/Excel
  - Scheduled reports
  - Custom date ranges
  - Comparison views

### Admin
- Users
  - User management
  - Role assignment
  - Activity logs
- Content
  - Product management
  - Category management
  - Promotions
- Settings
  - System configuration
  - Integration settings
  - Notification templates
`,
    state: 'opened',
    confidential: false,
    author: { id: 1001, username: 'test.user', name: 'Test User' },
    labels: ['diagram-test::mindmap', 'epic-generator', 'test-epic'],
    start_date: '2025-01-01',
    due_date: '2025-03-31',
    created_at: '2025-01-15T10:00:00Z',
    updated_at: '2025-01-15T10:00:00Z',
    closed_at: null,
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/208',
    epicLevel: 'crew'
  },
  {
    id: 12345709,
    iid: 209,
    group_id: 557797,
    title: 'history-timeline',
    description: `# Company History

## Objective
Document key milestones in company history.

## Events by Year

### 2019: Foundation
- January: Company founded by three engineers
- March: Seed funding of $500K secured
- June: MVP launched to beta users
- September: First paying customer acquired
- December: Reached 100 active users

### 2020: Growth
- February: Series A funding of $5M
- May: Team grew to 20 employees
- August: Enterprise tier launched
- November: Reached 10,000 users milestone
- December: First international customer

### 2021: Expansion
- January: European market entry
- April: Series B funding of $25M
- July: Mobile app launched
- October: Reached 100,000 users milestone
- December: Opened second office

### 2022: Maturity
- March: SOC 2 Type II certification
- June: Strategic partnership with AWS
- September: IPO preparation begins
- December: Reached 1M users milestone

### 2023: Scale
- February: Acquired competitor company
- May: Global expansion to Asia
- August: AI features launched
- November: Achieved profitability
- December: Won industry innovation award

### 2024: Innovation
- January: New product line launched
- April: 100th enterprise customer
- July: Reached $100M ARR
- October: Expanded AI capabilities
`,
    state: 'opened',
    confidential: false,
    author: { id: 1001, username: 'test.user', name: 'Test User' },
    labels: ['diagram-test::timeline', 'epic-generator', 'test-epic'],
    start_date: '2025-01-01',
    due_date: '2025-03-31',
    created_at: '2025-01-15T10:00:00Z',
    updated_at: '2025-01-15T10:00:00Z',
    closed_at: null,
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/209',
    epicLevel: 'crew'
  },
  {
    id: 12345710,
    iid: 210,
    group_id: 557797,
    title: 'priority-quadrant',
    description: `# Feature Prioritization Matrix

## Objective
Prioritize features based on impact vs effort using a quadrant chart.

## Evaluation Criteria
- X-axis: Implementation Effort (Low 0.0 to High 1.0)
- Y-axis: Business Impact (Low 0.0 to High 1.0)

## Features Assessment

### Quadrant 1: High Impact, Low Effort (Quick Wins) - DO FIRST
- One-click checkout: Impact 0.9, Effort 0.2
- Email notifications: Impact 0.8, Effort 0.3
- Search improvements: Impact 0.75, Effort 0.25
- Cache optimization: Impact 0.7, Effort 0.2

### Quadrant 2: High Impact, High Effort (Strategic) - PLAN CAREFULLY
- Mobile app: Impact 0.95, Effort 0.9
- AI recommendations: Impact 0.85, Effort 0.8
- Multi-currency support: Impact 0.8, Effort 0.7
- Real-time collaboration: Impact 0.75, Effort 0.85

### Quadrant 3: Low Impact, Low Effort (Fill-ins) - DO WHEN TIME PERMITS
- Dark mode: Impact 0.3, Effort 0.2
- Avatar customization: Impact 0.25, Effort 0.15
- Export to PDF: Impact 0.35, Effort 0.3
- Keyboard shortcuts: Impact 0.3, Effort 0.25

### Quadrant 4: Low Impact, High Effort (Avoid) - DEPRIORITIZE
- Blockchain integration: Impact 0.2, Effort 0.9
- VR shopping experience: Impact 0.15, Effort 0.95
- Custom scripting language: Impact 0.1, Effort 0.8
- Full offline mode: Impact 0.25, Effort 0.85

## Quadrant Labels
- Top-Right: "Strategic Initiatives"
- Top-Left: "Quick Wins"
- Bottom-Right: "Reconsider"
- Bottom-Left: "Low Priority"
`,
    state: 'opened',
    confidential: false,
    author: { id: 1001, username: 'test.user', name: 'Test User' },
    labels: ['diagram-test::quadrant', 'epic-generator', 'test-epic'],
    start_date: '2025-01-01',
    due_date: '2025-03-31',
    created_at: '2025-01-15T10:00:00Z',
    updated_at: '2025-01-15T10:00:00Z',
    closed_at: null,
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/210',
    epicLevel: 'crew'
  },
  {
    id: 12345711,
    iid: 211,
    group_id: 557797,
    title: 'dataflow-sankey',
    description: `# Data Flow Analysis

## Objective
Visualize data flow between system components using a Sankey diagram.

## Data Sources and Volumes
- Web Application: 1000 requests/sec
- Mobile App: 500 requests/sec
- API Partners: 200 requests/sec

## Data Flow Mappings

### From Web Application (1000 total)
- Web Application,API Gateway,1000
- API Gateway,Auth Service,400
- API Gateway,User Service,300
- API Gateway,Order Service,300

### From Mobile App (500 total)
- Mobile App,API Gateway,500
- API Gateway,Auth Service,200
- API Gateway,User Service,200
- API Gateway,Order Service,100

### From API Partners (200 total)
- API Partners,API Gateway,200
- API Gateway,Auth Service,100
- API Gateway,Order Service,100

### Service to Database
- Auth Service,Redis,600
- User Service,PostgreSQL,500
- Order Service,PostgreSQL,400
- Order Service,Kafka,400

### Event Processing
- Kafka,Notification Service,400
- Kafka,Analytics Service,400

## Flow Summary
Total incoming: 1700 requests/sec
Auth validation: 700 requests/sec
User operations: 500 requests/sec
Order operations: 500 requests/sec
`,
    state: 'opened',
    confidential: false,
    author: { id: 1001, username: 'test.user', name: 'Test User' },
    labels: ['diagram-test::sankey', 'epic-generator', 'test-epic'],
    start_date: '2025-01-01',
    due_date: '2025-03-31',
    created_at: '2025-01-15T10:00:00Z',
    updated_at: '2025-01-15T10:00:00Z',
    closed_at: null,
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/211',
    epicLevel: 'crew'
  },
  {
    id: 12345712,
    iid: 212,
    group_id: 557797,
    title: 'budget-pie',
    description: `# Engineering Budget Distribution

## Objective
Visualize how engineering budget is allocated using a pie chart.

## Budget Breakdown

### Total Annual Budget: $2,000,000

### Personnel (60% = $1,200,000)
- Senior Engineers: 35%
- Mid-level Engineers: 15%
- Junior Engineers: 10%

### Infrastructure (25% = $500,000)
- Cloud Services AWS: 15%
- DevOps Tools: 5%
- Monitoring: 5%

### Tools and Licenses (10% = $200,000)
- Development Tools: 5%
- SaaS Subscriptions: 3%
- Security Tools: 2%

### Training and Development (5% = $100,000)
- Conferences: 2%
- Online Courses: 2%
- Books and Resources: 1%

## Pie Chart Data
- "Senior Engineers" : 35
- "Mid-level Engineers" : 15
- "Junior Engineers" : 10
- "Cloud Services" : 15
- "DevOps Tools" : 5
- "Monitoring" : 5
- "Dev Tools" : 5
- "SaaS" : 3
- "Security" : 2
- "Training" : 5
`,
    state: 'opened',
    confidential: false,
    author: { id: 1001, username: 'test.user', name: 'Test User' },
    labels: ['diagram-test::pie', 'epic-generator', 'test-epic'],
    start_date: '2025-01-01',
    due_date: '2025-03-31',
    created_at: '2025-01-15T10:00:00Z',
    updated_at: '2025-01-15T10:00:00Z',
    closed_at: null,
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/212',
    epicLevel: 'crew'
  },
  {
    id: 12345713,
    iid: 213,
    group_id: 557797,
    title: 'metrics-xychart',
    description: `# Performance Metrics Dashboard

## Objective
Track key performance metrics over time using an XY chart.

## Metrics Data (2023)

### Monthly Active Users
- January: 10000
- February: 12000
- March: 15000
- April: 18000
- May: 22000
- June: 28000
- July: 35000
- August: 42000
- September: 50000
- October: 58000
- November: 65000
- December: 75000

### Revenue in Thousands USD
- January: 50
- February: 60
- March: 75
- April: 90
- May: 110
- June: 140
- July: 175
- August: 210
- September: 250
- October: 290
- November: 325
- December: 375

### Response Time in Milliseconds
- January: 450
- February: 420
- March: 380
- April: 350
- May: 320
- June: 280
- July: 250
- August: 230
- September: 210
- October: 200
- November: 190
- December: 180

## Chart Configuration
- X-axis: Months (Jan-Dec)
- Y-axis: Values (varies by metric)
- Line chart for Users and Revenue
- Bar chart optional for Response Time
`,
    state: 'opened',
    confidential: false,
    author: { id: 1001, username: 'test.user', name: 'Test User' },
    labels: ['diagram-test::xychart', 'epic-generator', 'test-epic'],
    start_date: '2025-01-01',
    due_date: '2025-03-31',
    created_at: '2025-01-15T10:00:00Z',
    updated_at: '2025-01-15T10:00:00Z',
    closed_at: null,
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/213',
    epicLevel: 'crew'
  },
  {
    id: 12345714,
    iid: 214,
    group_id: 557797,
    title: 'infra-block',
    description: `# Infrastructure Architecture

## Objective
Document cloud infrastructure layout using a block diagram.

## Infrastructure Layers

### Edge Layer (Row 1)
- CloudFront CDN
- WAF Web Application Firewall
- Route 53 DNS

### Load Balancing (Row 2)
- Application Load Balancer ALB
- Network Load Balancer NLB

### Compute Layer (Row 3)
- EKS Kubernetes Cluster
  - Node Group 1: Web Services (10 nodes)
  - Node Group 2: API Services (8 nodes)
  - Node Group 3: Worker Services (5 nodes)

### Data Layer (Row 4)
- RDS PostgreSQL Multi-AZ
- ElastiCache Redis Cluster
- S3 Buckets for Assets and Backups
- DynamoDB for Sessions

### Monitoring Layer (Row 5)
- CloudWatch
- Prometheus plus Grafana
- ELK Stack

### Security Layer (Row 6)
- AWS KMS Key Management
- Secrets Manager
- IAM Roles and Policies

## Block Layout
- 3 columns layout
- Each layer spans full width or has multiple blocks
- Connections show data flow between layers
`,
    state: 'opened',
    confidential: false,
    author: { id: 1001, username: 'test.user', name: 'Test User' },
    labels: ['diagram-test::block', 'epic-generator', 'test-epic'],
    start_date: '2025-01-01',
    due_date: '2025-03-31',
    created_at: '2025-01-15T10:00:00Z',
    updated_at: '2025-01-15T10:00:00Z',
    closed_at: null,
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/214',
    epicLevel: 'crew'
  },
  {
    id: 12345715,
    iid: 215,
    group_id: 557797,
    title: 'sprint-kanban',
    description: `# Sprint Board

## Objective
Track sprint progress using Kanban board.

## Columns and Cards

### Backlog
- Implement user search functionality
- Add export to CSV functionality
- Performance optimization for dashboard
- Mobile responsive fixes for checkout
- Add bulk import feature

### Todo
- Fix login timeout bug
- Add password reset flow
- Update API documentation
- Add input validation

### In Progress
- Shopping cart redesign
- Payment integration with Stripe

### Code Review
- User profile page updates
- Notification system refactor
- Email template improvements

### Testing
- Order history feature
- Email notification templates
- Search functionality

### Done
- Homepage redesign
- Authentication flow
- Database migrations
- API rate limiting
- Error logging system

## Work In Progress Limits
- Todo: 4 items max
- In Progress: 2 items max
- Code Review: 3 items max
- Testing: 3 items max
`,
    state: 'opened',
    confidential: false,
    author: { id: 1001, username: 'test.user', name: 'Test User' },
    labels: ['diagram-test::kanban', 'epic-generator', 'test-epic'],
    start_date: '2025-01-01',
    due_date: '2025-03-31',
    created_at: '2025-01-15T10:00:00Z',
    updated_at: '2025-01-15T10:00:00Z',
    closed_at: null,
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/215',
    epicLevel: 'crew'
  },
  {
    id: 12345716,
    iid: 216,
    group_id: 557797,
    title: 'compliance-requirement',
    description: `# Compliance Requirements

## Objective
Track compliance requirements and their implementation using a requirement diagram.

## Requirements

### Security Requirements
- REQ-SEC-001: All data must be encrypted at rest
  - ID: REQ-001
  - Text: Data Encryption at Rest
  - Risk: High
  - Verification Method: Security audit
  - Status: Implemented

- REQ-SEC-002: All API calls must use TLS 1.3
  - ID: REQ-002
  - Text: TLS 1.3 for API
  - Risk: High
  - Verification Method: Penetration test
  - Status: Implemented

- REQ-SEC-003: Passwords must meet complexity requirements
  - ID: REQ-003
  - Text: Password Complexity
  - Risk: Medium
  - Verification Method: Unit tests
  - Status: Implemented

### Privacy Requirements
- REQ-PRI-001: GDPR data deletion within 30 days
  - ID: REQ-004
  - Text: GDPR Deletion
  - Risk: High
  - Verification Method: Process audit
  - Status: In Progress

- REQ-PRI-002: User consent before data collection
  - ID: REQ-005
  - Text: User Consent
  - Risk: High
  - Verification Method: UI review
  - Status: Implemented

### Compliance Elements (Services)
- Auth Service: Element type service
  - Satisfies REQ-001, REQ-002, REQ-003
- User Service: Element type service
  - Satisfies REQ-004, REQ-005
- Data Service: Element type service
  - Satisfies REQ-001
- API Gateway: Element type service
  - Satisfies REQ-002
`,
    state: 'opened',
    confidential: false,
    author: { id: 1001, username: 'test.user', name: 'Test User' },
    labels: ['diagram-test::requirement', 'epic-generator', 'test-epic'],
    start_date: '2025-01-01',
    due_date: '2025-03-31',
    created_at: '2025-01-15T10:00:00Z',
    updated_at: '2025-01-15T10:00:00Z',
    closed_at: null,
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/216',
    epicLevel: 'crew'
  },
  {
    id: 12345717,
    iid: 217,
    group_id: 557797,
    title: 'skills-radar',
    description: `# Team Skills Assessment

## Objective
Assess team capabilities across different skill areas using a radar chart.

## Skill Categories and Scores

### Frontend Team Assessment
- React: 90
- TypeScript: 85
- CSS and Styling: 80
- Testing: 70
- Performance: 75
- Accessibility: 65

### Backend Team Assessment
- Node.js: 85
- Python: 75
- Databases: 90
- API Design: 85
- Security: 80
- DevOps: 70

### DevOps Team Assessment
- Kubernetes: 90
- AWS: 85
- CI/CD: 95
- Monitoring: 80
- Security: 85
- Automation: 90

## Assessment Scale
- 0-40: Beginner level
- 41-60: Intermediate level
- 61-80: Advanced level
- 81-100: Expert level

## Radar Chart Configuration
- Multiple axes for each skill category
- Overlay multiple team assessments
- Scale from 0 to 100
- Show grid lines at 20, 40, 60, 80, 100
`,
    state: 'opened',
    confidential: false,
    author: { id: 1001, username: 'test.user', name: 'Test User' },
    labels: ['diagram-test::radar', 'epic-generator', 'test-epic'],
    start_date: '2025-01-01',
    due_date: '2025-03-31',
    created_at: '2025-01-15T10:00:00Z',
    updated_at: '2025-01-15T10:00:00Z',
    closed_at: null,
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/217',
    epicLevel: 'crew'
  }
];

// ===========================================
// MOCK LABELS DATA
// ===========================================
export const mockLabels: GitLabLabel[] = [
  { id: 1, name: 'crew::platform', color: '#428BCA', text_color: '#FFFFFF', description: 'Platform team epics' },
  { id: 2, name: 'crew::mobile', color: '#44AD8E', text_color: '#FFFFFF', description: 'Mobile team epics' },
  { id: 3, name: 'pod::auth', color: '#D10069', text_color: '#FFFFFF', description: 'Authentication pod' },
  { id: 4, name: 'pod::data', color: '#FA7035', text_color: '#FFFFFF', description: 'Data pipeline pod' },
  { id: 5, name: 'pod::infra', color: '#6B4FBB', text_color: '#FFFFFF', description: 'Infrastructure pod' },
  { id: 6, name: 'epic-generator', color: '#F0AD4E', text_color: '#333333', description: 'Generated by Epic Generator' },
  { id: 7, name: 'priority::high', color: '#CC0000', text_color: '#FFFFFF', description: 'High priority' },
  { id: 8, name: 'priority::medium', color: '#FFCC00', text_color: '#333333', description: 'Medium priority' },
  { id: 9, name: 'priority::low', color: '#009900', text_color: '#FFFFFF', description: 'Low priority' },
  { id: 10, name: 'security', color: '#FF0000', text_color: '#FFFFFF', description: 'Security related' },
  { id: 11, name: 'performance', color: '#0066CC', text_color: '#FFFFFF', description: 'Performance related' },
  { id: 12, name: 'ux', color: '#FF69B4', text_color: '#333333', description: 'User experience' },
  { id: 13, name: 'Q1-2025', color: '#808080', text_color: '#FFFFFF', description: 'Q1 2025 milestone' },
  { id: 14, name: 'completed', color: '#00CC00', text_color: '#FFFFFF', description: 'Work completed' },
  // Diagram Test Labels - for filtering test epics by diagram type
  { id: 101, name: 'diagram-test::flowchart', color: '#4F46E5', text_color: '#FFFFFF', description: 'Test epic for flowchart diagram' },
  { id: 102, name: 'diagram-test::sequence', color: '#0EA5E9', text_color: '#FFFFFF', description: 'Test epic for sequence diagram' },
  { id: 103, name: 'diagram-test::er', color: '#F59E0B', text_color: '#333333', description: 'Test epic for ER diagram' },
  { id: 104, name: 'diagram-test::class', color: '#8B5CF6', text_color: '#FFFFFF', description: 'Test epic for class diagram' },
  { id: 105, name: 'diagram-test::state', color: '#10B981', text_color: '#FFFFFF', description: 'Test epic for state diagram' },
  { id: 106, name: 'diagram-test::gantt', color: '#EF4444', text_color: '#FFFFFF', description: 'Test epic for gantt chart' },
  { id: 107, name: 'diagram-test::gitgraph', color: '#EC4899', text_color: '#FFFFFF', description: 'Test epic for git graph' },
  { id: 108, name: 'diagram-test::mindmap', color: '#14B8A6', text_color: '#FFFFFF', description: 'Test epic for mindmap' },
  { id: 109, name: 'diagram-test::timeline', color: '#F97316', text_color: '#FFFFFF', description: 'Test epic for timeline' },
  { id: 110, name: 'diagram-test::quadrant', color: '#6366F1', text_color: '#FFFFFF', description: 'Test epic for quadrant chart' },
  { id: 111, name: 'diagram-test::sankey', color: '#84CC16', text_color: '#333333', description: 'Test epic for sankey diagram' },
  { id: 112, name: 'diagram-test::pie', color: '#A855F7', text_color: '#FFFFFF', description: 'Test epic for pie chart' },
  { id: 113, name: 'diagram-test::xychart', color: '#22D3EE', text_color: '#333333', description: 'Test epic for xy chart' },
  { id: 114, name: 'diagram-test::block', color: '#64748B', text_color: '#FFFFFF', description: 'Test epic for block diagram' },
  { id: 115, name: 'diagram-test::kanban', color: '#FB923C', text_color: '#333333', description: 'Test epic for kanban board' },
  { id: 116, name: 'diagram-test::requirement', color: '#DC2626', text_color: '#FFFFFF', description: 'Test epic for requirement diagram' },
  { id: 117, name: 'diagram-test::radar', color: '#2563EB', text_color: '#FFFFFF', description: 'Test epic for radar chart' },
  { id: 118, name: 'test-epic', color: '#9333EA', text_color: '#FFFFFF', description: 'Test epic marker' },
];

// ===========================================
// MOCK CHILD EPICS DATA (Enhanced with labels, dates, authors)
// ===========================================
export const mockEpicChildren: Record<number, { epics: GitLabEpicChild[], issues: GitLabEpicChild[] }> = {
  // Epic 101: Platform Modernization Initiative - has 3 child epics + 5 issues
  101: {
    epics: [
      {
        id: 12345679, iid: 102, title: 'User Authentication Service Refactor', type: 'epic', state: 'opened',
        web_url: 'https://gitlab.example.com/groups/engineering/-/epics/102',
        labels: ['pod::auth', 'security', 'priority::high'],
        created_at: '2025-01-05T10:00:00Z', updated_at: '2025-01-14T15:30:00Z',
        author: { name: 'Sarah Mitchell' }, due_date: '2025-03-31'
      },
      {
        id: 12345680, iid: 103, title: 'Data Pipeline Optimization', type: 'epic', state: 'opened',
        web_url: 'https://gitlab.example.com/groups/engineering/-/epics/103',
        labels: ['pod::data', 'performance', 'priority::medium'],
        created_at: '2025-01-08T09:00:00Z', updated_at: '2025-01-12T11:45:00Z',
        author: { name: 'James Chen' }, due_date: '2025-04-15'
      },
      {
        id: 12345683, iid: 106, title: 'Infrastructure Cost Optimization', type: 'epic', state: 'opened',
        web_url: 'https://gitlab.example.com/groups/engineering/-/epics/106',
        labels: ['pod::infra', 'priority::low'],
        created_at: '2025-01-10T14:00:00Z', updated_at: '2025-01-15T09:20:00Z',
        author: { name: 'Michael Torres' }, due_date: '2025-05-01'
      },
    ],
    issues: [
      {
        id: 9001, iid: 501, title: 'Set up CI/CD pipeline for new architecture', type: 'issue', state: 'closed',
        web_url: 'https://gitlab.example.com/engineering/platform/-/issues/501',
        labels: ['pod::infra', 'devops'], weight: 5,
        created_at: '2025-01-02T08:00:00Z', updated_at: '2025-01-10T16:00:00Z',
        author: { name: 'Emily Watson' }, assignee: { name: 'David Kim' }, due_date: '2025-01-15'
      },
      {
        id: 9002, iid: 502, title: 'Create architecture decision records (ADRs)', type: 'issue', state: 'closed',
        web_url: 'https://gitlab.example.com/engineering/platform/-/issues/502',
        labels: ['documentation', 'priority::medium'], weight: 3,
        created_at: '2025-01-03T10:00:00Z', updated_at: '2025-01-08T14:30:00Z',
        author: { name: 'Sarah Mitchell' }, assignee: { name: 'Sarah Mitchell' }, due_date: '2025-01-10'
      },
      {
        id: 9003, iid: 503, title: 'Define API versioning strategy', type: 'issue', state: 'opened',
        web_url: 'https://gitlab.example.com/engineering/platform/-/issues/503',
        labels: ['design', 'priority::high'], weight: 8,
        created_at: '2025-01-05T11:00:00Z', updated_at: '2025-01-16T10:00:00Z',
        author: { name: 'James Chen' }, assignee: { name: 'Alex Rivera' }, due_date: '2025-01-25'
      },
      {
        id: 9004, iid: 504, title: 'Migrate legacy authentication tokens', type: 'issue', state: 'opened',
        web_url: 'https://gitlab.example.com/engineering/platform/-/issues/504',
        labels: ['security', 'migration', 'priority::high'], weight: 13,
        created_at: '2025-01-06T09:00:00Z', updated_at: '2025-01-15T11:00:00Z',
        author: { name: 'Michael Torres' }, assignee: null, due_date: '2025-02-15'
      },
      {
        id: 9005, iid: 505, title: 'Set up monitoring dashboards', type: 'issue', state: 'opened',
        web_url: 'https://gitlab.example.com/engineering/platform/-/issues/505',
        labels: ['pod::infra', 'monitoring'], weight: 5,
        created_at: '2025-01-07T14:00:00Z', updated_at: '2025-01-14T09:00:00Z',
        author: { name: 'Emily Watson' }, assignee: { name: 'David Kim' }, due_date: '2025-02-01'
      },
    ]
  },

  // Epic 102: User Authentication Service Refactor - has 0 child epics + 4 issues (leaf epic)
  102: {
    epics: [],
    issues: [
      {
        id: 9101, iid: 601, title: 'Implement OAuth 2.0 authorization server', type: 'issue', state: 'opened',
        web_url: 'https://gitlab.example.com/engineering/auth/-/issues/601',
        labels: ['security', 'backend', 'priority::high'], weight: 13,
        created_at: '2025-01-06T10:00:00Z', updated_at: '2025-01-16T14:00:00Z',
        author: { name: 'Sarah Mitchell' }, assignee: { name: 'Alex Rivera' }, due_date: '2025-02-28'
      },
      {
        id: 9102, iid: 602, title: 'Add SAML 2.0 IdP integration', type: 'issue', state: 'opened',
        web_url: 'https://gitlab.example.com/engineering/auth/-/issues/602',
        labels: ['security', 'integration', 'priority::medium'], weight: 8,
        created_at: '2025-01-07T11:00:00Z', updated_at: '2025-01-15T16:30:00Z',
        author: { name: 'Sarah Mitchell' }, assignee: { name: 'Jennifer Park' }, due_date: '2025-03-15'
      },
      {
        id: 9103, iid: 603, title: 'Implement WebAuthn/FIDO2 registration', type: 'issue', state: 'opened',
        web_url: 'https://gitlab.example.com/engineering/auth/-/issues/603',
        labels: ['security', 'frontend', 'priority::medium'], weight: 8,
        created_at: '2025-01-08T09:00:00Z', updated_at: '2025-01-14T10:00:00Z',
        author: { name: 'Alex Rivera' }, assignee: null, due_date: '2025-03-20'
      },
      {
        id: 9104, iid: 604, title: 'Add rate limiting middleware', type: 'issue', state: 'closed',
        web_url: 'https://gitlab.example.com/engineering/auth/-/issues/604',
        labels: ['security', 'backend'], weight: 3,
        created_at: '2025-01-05T14:00:00Z', updated_at: '2025-01-12T11:00:00Z',
        author: { name: 'David Kim' }, assignee: { name: 'David Kim' }, due_date: '2025-01-12'
      },
    ]
  },

  // Epic 103: Data Pipeline Optimization - has 0 child epics + 3 issues (leaf epic)
  103: {
    epics: [],
    issues: [
      {
        id: 9301, iid: 801, title: 'Optimize Kafka consumer batch processing', type: 'issue', state: 'opened',
        web_url: 'https://gitlab.example.com/engineering/data/-/issues/801',
        labels: ['performance', 'backend', 'priority::high'], weight: 8,
        created_at: '2025-01-09T10:00:00Z', updated_at: '2025-01-16T15:00:00Z',
        author: { name: 'James Chen' }, assignee: { name: 'Lisa Wang' }, due_date: '2025-02-15'
      },
      {
        id: 9302, iid: 802, title: 'Implement data partitioning strategy', type: 'issue', state: 'opened',
        web_url: 'https://gitlab.example.com/engineering/data/-/issues/802',
        labels: ['performance', 'design', 'priority::high'], weight: 13,
        created_at: '2025-01-10T09:00:00Z', updated_at: '2025-01-15T14:30:00Z',
        author: { name: 'James Chen' }, assignee: { name: 'James Chen' }, due_date: '2025-03-01'
      },
      {
        id: 9303, iid: 803, title: 'Add real-time data quality monitoring', type: 'issue', state: 'opened',
        web_url: 'https://gitlab.example.com/engineering/data/-/issues/803',
        labels: ['monitoring', 'priority::medium'], weight: 5,
        created_at: '2025-01-11T11:00:00Z', updated_at: '2025-01-14T16:00:00Z',
        author: { name: 'Lisa Wang' }, assignee: null, due_date: '2025-03-15'
      },
    ]
  },

  // Epic 104: Mobile App Redesign - has 1 child epic + 4 issues
  104: {
    epics: [
      {
        id: 12345684, iid: 107, title: 'Mobile Design System v2', type: 'epic', state: 'opened',
        web_url: 'https://gitlab.example.com/groups/engineering/-/epics/107',
        labels: ['pod::mobile', 'ux', 'priority::high'],
        created_at: '2025-01-12T10:00:00Z', updated_at: '2025-01-16T11:00:00Z',
        author: { name: 'Rachel Green' }, due_date: '2025-04-30'
      },
    ],
    issues: [
      {
        id: 9201, iid: 701, title: 'Design new navigation system', type: 'issue', state: 'closed',
        web_url: 'https://gitlab.example.com/engineering/mobile/-/issues/701',
        labels: ['ux', 'design'], weight: 5,
        created_at: '2025-01-04T10:00:00Z', updated_at: '2025-01-11T15:00:00Z',
        author: { name: 'Rachel Green' }, assignee: { name: 'Rachel Green' }, due_date: '2025-01-10'
      },
      {
        id: 9202, iid: 702, title: 'Implement offline storage layer', type: 'issue', state: 'opened',
        web_url: 'https://gitlab.example.com/engineering/mobile/-/issues/702',
        labels: ['mobile', 'backend', 'priority::high'], weight: 13,
        created_at: '2025-01-08T09:00:00Z', updated_at: '2025-01-16T10:30:00Z',
        author: { name: 'Tom Anderson' }, assignee: { name: 'Tom Anderson' }, due_date: '2025-02-28'
      },
      {
        id: 9203, iid: 703, title: 'Add biometric authentication', type: 'issue', state: 'opened',
        web_url: 'https://gitlab.example.com/engineering/mobile/-/issues/703',
        labels: ['security', 'mobile', 'priority::medium'], weight: 8,
        created_at: '2025-01-09T11:00:00Z', updated_at: '2025-01-15T09:00:00Z',
        author: { name: 'Sarah Mitchell' }, assignee: { name: 'Alex Rivera' }, due_date: '2025-03-10'
      },
      {
        id: 9204, iid: 704, title: 'Optimize app startup time', type: 'issue', state: 'opened',
        web_url: 'https://gitlab.example.com/engineering/mobile/-/issues/704',
        labels: ['performance', 'mobile', 'priority::medium'], weight: 5,
        created_at: '2025-01-10T14:00:00Z', updated_at: '2025-01-14T16:00:00Z',
        author: { name: 'Tom Anderson' }, assignee: null, due_date: '2025-02-15'
      },
    ]
  },

  // Epic 105: Legacy API Migration (closed) - has 0 child epics + 2 issues
  105: {
    epics: [],
    issues: [
      {
        id: 9401, iid: 901, title: 'Document legacy API endpoints', type: 'issue', state: 'closed',
        web_url: 'https://gitlab.example.com/engineering/api/-/issues/901',
        labels: ['documentation', 'completed'], weight: 3,
        created_at: '2024-11-01T10:00:00Z', updated_at: '2024-12-15T14:00:00Z',
        author: { name: 'Emily Watson' }, assignee: { name: 'Emily Watson' }, due_date: '2024-12-01'
      },
      {
        id: 9402, iid: 902, title: 'Migrate v1 endpoints to v2', type: 'issue', state: 'closed',
        web_url: 'https://gitlab.example.com/engineering/api/-/issues/902',
        labels: ['migration', 'backend', 'completed'], weight: 13,
        created_at: '2024-11-15T09:00:00Z', updated_at: '2024-12-20T16:00:00Z',
        author: { name: 'James Chen' }, assignee: { name: 'David Kim' }, due_date: '2024-12-20'
      },
    ]
  },
};

// ===========================================
// MOCK API FUNCTIONS
// ===========================================

// Simulate network delay
const simulateDelay = (ms: number = 500) => new Promise(resolve => setTimeout(resolve, ms));

// Mock: Fetch group epics
export async function mockFetchGroupEpics(
  config: GitLabConfig,
  params: GitLabEpicSearchParams = {}
): Promise<GitLabEpicListResult> {
  await simulateDelay(300);

  let results = [...mockEpics];

  // Apply search filter
  if (params.search) {
    const searchLower = params.search.toLowerCase();
    results = results.filter(e =>
      e.title.toLowerCase().includes(searchLower) ||
      e.description.toLowerCase().includes(searchLower)
    );
  }

  // Apply state filter
  if (params.state && params.state !== 'all') {
    results = results.filter(e => e.state === params.state);
  }

  // Apply label filter
  if (params.labels && params.labels.length > 0) {
    results = results.filter(e =>
      params.labels!.some(label => e.labels.includes(label))
    );
  }

  // Apply sorting
  const orderBy = params.order_by || 'updated_at';
  const sortDir = params.sort || 'desc';
  results.sort((a, b) => {
    const aVal = a[orderBy as keyof GitLabEpic] as string;
    const bVal = b[orderBy as keyof GitLabEpic] as string;
    const comparison = aVal < bVal ? -1 : aVal > bVal ? 1 : 0;
    return sortDir === 'desc' ? -comparison : comparison;
  });

  // Apply pagination
  const page = params.page || 1;
  const perPage = params.per_page || 20;
  const start = (page - 1) * perPage;
  const paginatedResults = results.slice(start, start + perPage);

  // Determine epic level based on labels
  const crewPrefix = config.crewLabelPrefix || 'crew::';
  const podPrefix = config.podLabelPrefix || 'pod::';

  const epicsWithLevel = paginatedResults.map(epic => ({
    ...epic,
    epicLevel: epic.labels.some(l => l.startsWith(crewPrefix)) ? 'crew' as const :
               epic.labels.some(l => l.startsWith(podPrefix)) ? 'pod' as const : 'unknown' as const
  }));

  console.log('[Mock GitLab] Fetched epics:', epicsWithLevel.length, 'of', results.length);

  return {
    success: true,
    data: epicsWithLevel,
    totalCount: results.length
  };
}

// Mock: Fetch epic details
export async function mockFetchEpicDetails(
  config: GitLabConfig,
  epicIid: number,
  groupId?: string
): Promise<GitLabEpicResult> {
  await simulateDelay(200);

  // FIX: Use BOTH iid AND group_id to find the correct epic
  // This fixes the bug where duplicate iids in different groups caused wrong epic to load
  let epic;
  if (groupId) {
    // If groupId provided, find by BOTH iid AND group_id
    epic = mockEpics.find(e => e.iid === epicIid && String(e.group_id) === groupId);
    console.log('[Mock GitLab] Finding epic with iid:', epicIid, 'AND group_id:', groupId);
  }
  if (!epic) {
    // Fallback to iid-only search if groupId not provided or no match found
    epic = mockEpics.find(e => e.iid === epicIid);
    console.log('[Mock GitLab] Fallback: Finding epic with iid only:', epicIid);
  }

  if (!epic) {
    console.log('[Mock GitLab] Epic not found - iid:', epicIid, 'groupId:', groupId);
    return { success: false, error: 'Epic not found' };
  }

  console.log('[Mock GitLab] Found epic:', epic.id, 'in group:', epic.group_id);

  const crewPrefix = config.crewLabelPrefix || 'crew::';
  const podPrefix = config.podLabelPrefix || 'pod::';

  console.log('[Mock GitLab] Fetched epic details:', epic.iid, epic.title);

  return {
    success: true,
    data: {
      ...epic,
      epicLevel: epic.labels.some(l => l.startsWith(crewPrefix)) ? 'crew' as const :
                 epic.labels.some(l => l.startsWith(podPrefix)) ? 'pod' as const : 'unknown' as const
    }
  };
}

// Mock: Fetch epic children
export async function mockFetchEpicChildren(
  _config: GitLabConfig,
  epicIid: number,
  groupId?: string
): Promise<GitLabEpicChildrenResult> {
  await simulateDelay(250);

  // Note: mockEpicChildren is keyed by epicIid only (not by group)
  // In a real scenario with duplicate iids, we'd need to key by {groupId}_{epicIid}
  console.log('[Mock GitLab] Fetching children for epic iid:', epicIid, 'groupId:', groupId);

  const children = mockEpicChildren[epicIid];

  if (!children) {
    console.log('[Mock GitLab] No children found for epic iid:', epicIid);
    return { success: true, epics: [], issues: [] };
  }

  console.log('[Mock GitLab] Fetched children for epic', epicIid, ':', children.epics.length, 'epics,', children.issues.length, 'issues');

  return {
    success: true,
    epics: children.epics,
    issues: children.issues
  };
}

// Mock: Create epic
export async function mockCreateGitLabEpic(
  config: GitLabConfig,
  params: GitLabCreateEpicParams
): Promise<GitLabEpicResult> {
  await simulateDelay(400);

  if (!params.title) {
    return { success: false, error: 'Title is required' };
  }

  const crewPrefix = config.crewLabelPrefix || 'crew::';
  const podPrefix = config.podLabelPrefix || 'pod::';

  // Use params.group_id if provided (for creating in subgroup), otherwise use rootGroupId
  const targetGroupId = params.group_id || config.rootGroupId;

  const newEpic: GitLabEpic = {
    id: Date.now(),
    iid: 200 + Math.floor(Math.random() * 100),
    group_id: parseInt(targetGroupId) || 557797,
    title: params.title,
    description: params.description || '',
    state: 'opened',
    confidential: params.confidential || false,
    author: {
      id: 1001,
      username: 'current.user',
      name: 'Current User'
    },
    labels: params.labels || [],
    start_date: params.start_date_fixed || null,
    due_date: params.due_date_fixed || null,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    closed_at: null,
    web_url: `https://gitlab.example.com/groups/engineering/-/epics/${Date.now()}`,
    parent: params.parent_id ? {
      id: params.parent_id,
      iid: mockEpics.find(e => e.id === params.parent_id)?.iid || 0,
      title: mockEpics.find(e => e.id === params.parent_id)?.title || ''
    } : undefined,
    epicLevel: (params.labels || []).some(l => l.startsWith(crewPrefix)) ? 'crew' :
               (params.labels || []).some(l => l.startsWith(podPrefix)) ? 'pod' : 'unknown'
  };

  // Add to mock data for this session
  mockEpics.unshift(newEpic);

  console.log('[Mock GitLab] Created epic:', newEpic.iid, newEpic.title);

  return {
    success: true,
    data: newEpic
  };
}

// Mock: Update epic
export async function mockUpdateGitLabEpic(
  config: GitLabConfig,
  epicIid: number,
  params: GitLabUpdateEpicParams,
  groupId?: string  // IMPORTANT: Use this to find epic in correct group
): Promise<GitLabEpicResult> {
  await simulateDelay(300);

  // DEBUG: Detailed logging for tracing update flow
  console.log('[Mock GitLab] ============ UPDATE EPIC CALLED ============');
  console.log('[Mock GitLab] Input Parameters:');
  console.log('  - epicIid:', epicIid);
  console.log('  - groupId (passed):', groupId || 'NOT PROVIDED');
  console.log('  - config.rootGroupId:', config.rootGroupId);
  console.log('  - params.title:', params.title);
  console.log('  - params.description length:', params.description?.length || 0);

  // FIX: Use BOTH iid AND group_id to find the correct epic
  // This fixes the bug where duplicate iids in different groups caused wrong epic to update
  let epicIndex = -1;
  if (groupId) {
    // If groupId provided, find by BOTH iid AND group_id
    epicIndex = mockEpics.findIndex(e => e.iid === epicIid && String(e.group_id) === groupId);
    console.log('[Mock GitLab] Finding epic with iid:', epicIid, 'AND group_id:', groupId, '-> index:', epicIndex);
  }
  if (epicIndex === -1) {
    // Fallback to iid-only search if groupId not provided or no match found
    epicIndex = mockEpics.findIndex(e => e.iid === epicIid);
    console.log('[Mock GitLab] Fallback: Finding epic with iid only:', epicIid, '-> index:', epicIndex);
  }

  if (epicIndex >= 0) {
    console.log('[Mock GitLab] Found epic at index:', epicIndex);
    console.log('[Mock GitLab] Epic id:', mockEpics[epicIndex].id);
    console.log('[Mock GitLab] Epic group_id:', mockEpics[epicIndex].group_id);
  }
  console.log('[Mock GitLab] ==========================================');

  if (epicIndex === -1) {
    return { success: false, error: 'Epic not found' };
  }

  const epic = mockEpics[epicIndex];

  // Update fields
  if (params.title !== undefined) epic.title = params.title;
  if (params.description !== undefined) epic.description = params.description;
  if (params.state_event === 'close') epic.state = 'closed';
  if (params.state_event === 'reopen') epic.state = 'opened';

  // Handle labels (non-destructive)
  if (params.add_labels) {
    params.add_labels.forEach(label => {
      if (!epic.labels.includes(label)) epic.labels.push(label);
    });
  }
  if (params.remove_labels) {
    epic.labels = epic.labels.filter(l => !params.remove_labels!.includes(l));
  }
  if (params.labels !== undefined) {
    epic.labels = params.labels;
  }

  epic.updated_at = new Date().toISOString();

  const crewPrefix = config.crewLabelPrefix || 'crew::';
  const podPrefix = config.podLabelPrefix || 'pod::';

  epic.epicLevel = epic.labels.some(l => l.startsWith(crewPrefix)) ? 'crew' :
                   epic.labels.some(l => l.startsWith(podPrefix)) ? 'pod' : 'unknown';

  console.log('[Mock GitLab] Updated epic:', epic.iid, epic.title);

  return {
    success: true,
    data: epic
  };
}

// Mock: Fetch labels
export async function mockFetchGroupLabels(
  _config: GitLabConfig
): Promise<GitLabLabelResult> {
  await simulateDelay(200);

  console.log('[Mock GitLab] Fetched labels:', mockLabels.length);

  return {
    success: true,
    data: mockLabels
  };
}

// ===========================================
// MOCK GROUP HIERARCHY FUNCTIONS
// ===========================================

// Mock: Fetch group metadata
export async function mockFetchGroupMetadata(
  _config: GitLabConfig,
  groupId: string
): Promise<{ success: boolean; data?: MockGitLabGroup; error?: string }> {
  await simulateDelay(150);

  const groupIdNum = parseInt(groupId, 10);
  const group = mockGroups.find(g => g.id === groupIdNum);

  if (!group) {
    return { success: false, error: 'Group not found' };
  }

  console.log('[Mock GitLab] Fetched group metadata:', group.name, 'parent_id:', group.parent_id);

  return {
    success: true,
    data: group
  };
}

// Mock: Fetch subgroups with full metadata
export async function mockFetchGitLabSubgroupsWithMetadata(
  _config: GitLabConfig,
  groupId: string
): Promise<{ success: boolean; data?: MockGitLabGroup[]; error?: string }> {
  await simulateDelay(200);

  const groupIdNum = parseInt(groupId, 10);
  const subgroups = mockGroups.filter(g => g.parent_id === groupIdNum);

  console.log('[Mock GitLab] Fetched subgroups for group', groupId, ':', subgroups.length);

  return {
    success: true,
    data: subgroups
  };
}

// Mock: Fetch epics for a specific group (used in hierarchy navigation)
export async function mockFetchGroupEpicsForHierarchy(
  config: GitLabConfig,
  groupId: string,
  includeDescendants: boolean = false
): Promise<GitLabEpicListResult> {
  await simulateDelay(250);

  const groupIdNum = parseInt(groupId, 10);

  // Get epic IIDs for this group
  let epicIids = mockEpicGroupMapping[groupIdNum] || [];

  // If including descendants, add epics from all child groups
  if (includeDescendants) {
    const childGroups = mockGroups.filter(g => g.parent_id === groupIdNum);
    for (const child of childGroups) {
      const childEpicIids = mockEpicGroupMapping[child.id] || [];
      epicIids = [...new Set([...epicIids, ...childEpicIids])];

      // Also check grandchildren
      const grandchildren = mockGroups.filter(g => g.parent_id === child.id);
      for (const grandchild of grandchildren) {
        const grandchildEpicIids = mockEpicGroupMapping[grandchild.id] || [];
        epicIids = [...new Set([...epicIids, ...grandchildEpicIids])];
      }
    }
  }

  // Filter epics by IIDs
  const epics = mockEpics.filter(e => epicIids.includes(e.iid));

  // Sort by updated_at desc
  epics.sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime());

  // Determine epic level based on labels
  const crewPrefix = config.crewLabelPrefix || 'crew::';
  const podPrefix = config.podLabelPrefix || 'pod::';

  const epicsWithLevel = epics.map(epic => ({
    ...epic,
    epicLevel: epic.labels.some(l => l.startsWith(crewPrefix)) ? 'crew' as const :
               epic.labels.some(l => l.startsWith(podPrefix)) ? 'pod' as const : 'unknown' as const
  }));

  console.log('[Mock GitLab] Fetched epics for group', groupId, ':', epicsWithLevel.length, 'includeDescendants:', includeDescendants);

  return {
    success: true,
    data: epicsWithLevel,
    totalCount: epicsWithLevel.length
  };
}

// ===========================================
// MOCK ISSUE CREATION
// ===========================================

let mockIssueCounter = 1000;
const mockCreatedIssues: Array<{ id: number; iid: number; title: string; description: string; state: string; web_url: string; labels: string[] }> = [];

export async function mockCreateGitLabIssue(
  _config: GitLabConfig,
  params: CreateIssueParams,
  _groupId?: string
): Promise<GitLabIssueResult> {
  if (!params.title) {
    return { success: false, error: 'Issue title is required' };
  }

  await new Promise(resolve => setTimeout(resolve, 200)); // Simulate API delay

  mockIssueCounter++;
  const issue = {
    id: mockIssueCounter,
    iid: mockIssueCounter - 999,
    title: params.title,
    description: params.description || '',
    state: 'opened',
    web_url: `https://gitlab.example.com/mock-project/issues/${mockIssueCounter - 999}`,
    labels: params.labels || [],
  };
  mockCreatedIssues.push(issue);

  console.log(`[Mock GitLab] Issue created: #${issue.iid} "${issue.title}"`);
  return { success: true, data: issue };
}

export async function mockLinkIssueToEpic(
  _config: GitLabConfig,
  epicIid: number,
  issueId: number,
  _groupId?: string
): Promise<{ success: boolean; error?: string }> {
  await new Promise(resolve => setTimeout(resolve, 100));
  console.log(`[Mock GitLab] Issue ${issueId} linked to epic ${epicIid}`);
  return { success: true };
}

export async function mockFetchEpicIssues(
  _config: GitLabConfig,
  epicIid: number,
  _groupId?: string
): Promise<{ success: boolean; data?: Array<{ id: number; iid: number; title: string; state: string; web_url: string }>; error?: string }> {
  await new Promise(resolve => setTimeout(resolve, 100));
  const issues = mockCreatedIssues.filter(() => true); // Return all mock issues
  console.log(`[Mock GitLab] Fetched ${issues.length} issues for epic ${epicIid}`);
  return { success: true, data: issues };
}

// ===========================================
// MOCK ISSUE NOTES (COMMENTS) API
// ===========================================

interface MockGitLabNote {
  id: number;
  body: string;
  author: { id: number; username: string; name: string };
  created_at: string;
  updated_at: string;
  system: boolean;
}

const mockNotes: MockGitLabNote[] = [
  {
    id: 50001,
    body: 'I have started working on this. Will update by EOD with the initial implementation approach.',
    author: { id: 1001, username: 'david.kim', name: 'David Kim' },
    created_at: '2025-01-14T09:30:00Z',
    updated_at: '2025-01-14T09:30:00Z',
    system: false,
  },
  {
    id: 50002,
    body: 'Blocked by the API versioning decision. Waiting on ADR review from the architecture team.',
    author: { id: 1002, username: 'sarah.mitchell', name: 'Sarah Mitchell' },
    created_at: '2025-01-15T11:00:00Z',
    updated_at: '2025-01-15T11:00:00Z',
    system: false,
  },
  {
    id: 50003,
    body: 'added ~priority::high label',
    author: { id: 1003, username: 'system', name: 'System' },
    created_at: '2025-01-15T11:05:00Z',
    updated_at: '2025-01-15T11:05:00Z',
    system: true,
  },
];

export async function mockResolveProjectIdFromIssueUrl(
  _config: GitLabConfig,
  issueWebUrl: string
): Promise<{ success: boolean; projectId?: number; error?: string }> {
  await new Promise(resolve => setTimeout(resolve, 50));
  console.log('[Mock GitLab] Resolving project ID from URL:', issueWebUrl);
  return { success: true, projectId: 99001 };
}

export async function mockFetchIssueNotes(
  _config: GitLabConfig,
  _projectId: number,
  issueIid: number,
  _perPage?: number
): Promise<{ success: boolean; data?: MockGitLabNote[]; error?: string }> {
  await new Promise(resolve => setTimeout(resolve, 150));
  console.log(`[Mock GitLab] Fetching notes for issue #${issueIid}`);
  return { success: true, data: [...mockNotes] };
}

let mockNoteCounter = 60000;

export async function mockPostIssueNote(
  _config: GitLabConfig,
  _projectId: number,
  issueIid: number,
  body: string
): Promise<{ success: boolean; data?: MockGitLabNote; error?: string }> {
  await new Promise(resolve => setTimeout(resolve, 300));
  mockNoteCounter++;
  const note: MockGitLabNote = {
    id: mockNoteCounter,
    body,
    author: { id: 1001, username: 'current.user', name: 'Current User' },
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    system: false,
  };
  console.log(`[Mock GitLab] Note posted to issue #${issueIid}: ${body.substring(0, 60)}...`);
  return { success: true, data: note };
}

// ===========================================
// MOCK API WRAPPER
// ===========================================
// These functions decide whether to use mock or real API

export function shouldUseMockGitLab(): boolean {
  return MOCK_GITLAB_ENABLED;
}
