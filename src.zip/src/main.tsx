import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import { AuthProvider, AuthGuard, MockAuthBadge } from './auth';
import './styles.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <AuthProvider>
      <AuthGuard>
        <App />
      </AuthGuard>
      {/* Shows visual indicator when mock auth is enabled */}
      <MockAuthBadge />
    </AuthProvider>
  </StrictMode>
);
