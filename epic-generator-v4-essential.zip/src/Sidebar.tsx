// Sidebar Component - Premium UBS Banking Theme
// Swiss precision, minimal, sophisticated design language

import { type FC, type ReactNode, useState, useEffect } from 'react';

interface NavItem {
  id: string;
  label: string;
  icon: ReactNode;
  isExternal?: boolean;
}

interface SidebarProps {
  activeItem: string;
  onNavigate: (itemId: string) => void;
  isCollapsed?: boolean;
  onToggleCollapse?: (collapsed: boolean) => void;
}

// Navigation items configuration
const navItems: NavItem[] = [
  {
    id: 'epic-planner',
    label: 'Epic Planner',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
      </svg>
    ),
  },
  {
    id: 'blueprints',
    label: 'Blueprints',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <rect x="3" y="3" width="18" height="6" rx="1" />
        <rect x="3" y="12" width="8" height="9" rx="1" />
        <rect x="14" y="12" width="7" height="9" rx="1" />
      </svg>
    ),
  },
  {
    id: 'settings',
    label: 'Settings',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <circle cx="12" cy="12" r="3" />
        <path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-2 2 2 2 0 01-2-2v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 01-2-2 2 2 0 012-2h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 010-2.83 2 2 0 012.83 0l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 012-2 2 2 0 012 2v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 0 2 2 0 010 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 012 2 2 2 0 01-2 2h-.09a1.65 1.65 0 00-1.51 1z" />
      </svg>
    ),
  },
];

// Layout constants - Swiss precision with 8px base unit
const COLLAPSED_WIDTH = '56px';
const EXPANDED_WIDTH = 'var(--sidebar-width, 200px)';

// Official UBS Brand Colors - Premium Banking Palette
const UBS_COLORS = {
  red: '#E60000',        // Official UBS Red
  redHover: '#CC0000',   // Darker UBS Red
  redSubtle: 'rgba(230, 0, 0, 0.04)',
  redGlow: 'rgba(230, 0, 0, 0.08)',
  black: '#000000',
  white: '#FFFFFF',
  warmWhite: '#FDFCFB',  // Slightly warm white for premium feel
  gray900: '#1A1A1A',
  gray700: '#404040',
  gray600: '#6B7280',
  gray500: '#9CA3AF',
  gray400: '#D1D5DB',
  gray300: '#E0E0E0',
  gray200: '#E5E7EB',
  gray150: '#EDEDED',
  gray100: '#F3F4F6',
  gray50: '#F9FAFB',
  // Premium shadow colors
  shadowLight: 'rgba(0, 0, 0, 0.02)',
  shadowMedium: 'rgba(0, 0, 0, 0.04)',
  shadowDeep: 'rgba(0, 0, 0, 0.06)',
  // Highlight colors for premium glow
  highlightTop: 'rgba(255, 255, 255, 0.9)',
  highlightInner: 'rgba(255, 255, 255, 0.5)',
};

/* Premium UBS Banking Sidebar Styles
   Design principles:
   - Swiss precision and minimalism
   - Confident, solid surfaces with subtle depth
   - Multi-layered shadows for realistic depth
   - Refined typography with tight letter-spacing
   - Architectural, precise corners
   - Subtle inner glow for premium feel
*/
const getSidebarStyles = (isCollapsed: boolean) => ({
  sidebarWrapper: {
    position: 'sticky' as const,
    top: '16px',
    height: 'calc(100vh - 32px)',
    margin: '16px 0 16px 16px',
    display: 'flex',
    alignItems: 'flex-start',
  },

  sidebar: {
    width: isCollapsed ? COLLAPSED_WIDTH : EXPANDED_WIDTH,
    minWidth: isCollapsed ? COLLAPSED_WIDTH : EXPANDED_WIDTH,
    height: '100%',
    // Premium gradient - subtle warmth for luxury feel
    background: `linear-gradient(180deg, ${UBS_COLORS.white} 0%, ${UBS_COLORS.warmWhite} 100%)`,
    display: 'flex',
    flexDirection: 'column' as const,
    position: 'relative' as const,
    // Architectural corners - precise, 12px for premium balance
    borderRadius: '12px',
    // Premium multi-layered shadow system - Swiss banking depth
    boxShadow: `
      0 0 0 1px ${UBS_COLORS.shadowLight},
      0 1px 2px ${UBS_COLORS.shadowLight},
      0 2px 4px ${UBS_COLORS.shadowLight},
      0 4px 8px ${UBS_COLORS.shadowMedium},
      0 8px 16px ${UBS_COLORS.shadowMedium},
      0 16px 32px ${UBS_COLORS.shadowDeep},
      inset 0 1px 0 ${UBS_COLORS.highlightTop}
    `,
    // Refined border with subtle distinction
    border: `1px solid rgba(0, 0, 0, 0.04)`,
    overflow: 'hidden',
    // Subtle transition for any state changes
    transition: 'box-shadow 0.3s ease, width 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
  },

  logoContainer: {
    padding: isCollapsed ? '16px 12px' : '20px 16px',
    borderBottom: `1px solid rgba(0, 0, 0, 0.05)`,
    // Subtle gradient for premium header section
    background: `linear-gradient(180deg, ${UBS_COLORS.white} 0%, rgba(249, 250, 251, 0.5) 100%)`,
    display: isCollapsed ? 'none' : 'flex',
    justifyContent: 'flex-start',
    alignItems: 'center',
    minHeight: '64px',
    gap: '12px',
    position: 'relative' as const,
  },

  // Toggle button container - positioned outside sidebar to the right
  toggleWrapper: {
    marginLeft: '-16px',
    marginTop: '16px',
    zIndex: 100,
  },

  logo: {
    display: isCollapsed ? 'none' : 'flex',
    alignItems: 'center',
    gap: '10px',
    overflow: 'hidden',
  },

  logoImage: {
    height: '32px',
    width: 'auto',
    flexShrink: 0,
    // HD rendering
    imageRendering: 'crisp-edges' as const,
    WebkitFontSmoothing: 'antialiased',
  },

  logoText: {
    fontSize: '17px',
    fontWeight: 700 as const,
    color: UBS_COLORS.black,
    // HD text rendering
    textRendering: 'optimizeLegibility' as const,
    WebkitFontSmoothing: 'antialiased',
    MozOsxFontSmoothing: 'grayscale' as const,
    letterSpacing: '0.08em',
    lineHeight: 1,
    whiteSpace: 'nowrap' as const,
    fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
    // Subtle shadow for HD depth
    textShadow: '0 0.5px 0 rgba(0, 0, 0, 0.1)',
  },

  // Toggle button - premium, refined with subtle depth
  toggleButton: {
    width: '32px',
    height: '32px',
    borderRadius: '8px',
    // Premium gradient background
    background: `linear-gradient(180deg, ${UBS_COLORS.white} 0%, ${UBS_COLORS.gray100} 100%)`,
    border: `1px solid ${UBS_COLORS.gray200}`,
    // Subtle multi-layered shadow for premium depth
    boxShadow: `
      0 1px 2px ${UBS_COLORS.shadowLight},
      0 2px 4px ${UBS_COLORS.shadowMedium},
      inset 0 1px 0 ${UBS_COLORS.highlightTop}
    `,
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
    transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
  },

  toggleButtonHover: {
    background: `linear-gradient(180deg, ${UBS_COLORS.gray50} 0%, ${UBS_COLORS.gray150} 100%)`,
    borderColor: UBS_COLORS.gray300,
    boxShadow: `
      0 2px 4px ${UBS_COLORS.shadowMedium},
      0 4px 8px ${UBS_COLORS.shadowMedium},
      inset 0 1px 0 ${UBS_COLORS.highlightTop}
    `,
    transform: 'translateY(-1px)',
  },

  toggleIcon: {
    color: UBS_COLORS.gray600,
    width: '14px',
    height: '14px',
    transform: isCollapsed ? 'rotate(180deg)' : 'rotate(0deg)',
    transition: 'transform 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
  },

  nav: {
    flex: 1,
    padding: isCollapsed ? '12px 8px' : '16px 12px',
    overflowY: 'auto' as const,
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '4px',
  },

  navButton: (isActive: boolean, isHovered: boolean) => ({
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    width: '100%',
    padding: isCollapsed ? '10px' : '12px 14px',
    cursor: 'pointer',
    color: isActive
      ? UBS_COLORS.white
      : isHovered
        ? UBS_COLORS.gray900
        : UBS_COLORS.gray600,
    // Premium active state with subtle gradient
    backgroundColor: isActive
      ? UBS_COLORS.red
      : isHovered
        ? `linear-gradient(180deg, ${UBS_COLORS.gray50} 0%, ${UBS_COLORS.gray100} 100%)`
        : 'transparent',
    background: isActive
      ? `linear-gradient(145deg, #E60000 0%, #D10000 50%, #CC0000 100%)`
      : isHovered
        ? `linear-gradient(180deg, ${UBS_COLORS.gray50} 0%, ${UBS_COLORS.gray100} 100%)`
        : 'transparent',
    border: 'none',
    borderRadius: '8px',
    fontSize: '14px',
    fontWeight: isActive ? 500 : 400,
    transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
    textDecoration: 'none',
    textAlign: 'left' as const,
    fontFamily: 'inherit',
    outline: 'none',
    letterSpacing: '-0.01em',
    position: 'relative' as const,
    // Premium multi-layered shadow for active state
    boxShadow: isActive
      ? `0 2px 4px rgba(230, 0, 0, 0.2), 0 4px 8px rgba(230, 0, 0, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.15)`
      : isHovered
        ? `0 1px 2px ${UBS_COLORS.shadowLight}, inset 0 1px 0 ${UBS_COLORS.highlightTop}`
        : 'none',
    justifyContent: isCollapsed ? 'center' : 'flex-start',
    overflow: 'hidden',
    // Subtle transform for hover state
    transform: isHovered && !isActive ? 'translateX(2px)' : 'none',
  }),

  navIcon: (isActive: boolean) => ({
    color: isActive
      ? UBS_COLORS.white
      : UBS_COLORS.gray500,
    flexShrink: 0,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    transition: 'color 0.15s ease-out',
  }),

  navLabel: {
    opacity: isCollapsed ? 0 : 1,
    display: isCollapsed ? 'none' : 'inline',
    whiteSpace: 'nowrap' as const,
  },

  externalIcon: {
    marginLeft: 'auto',
    opacity: 0.4,
    display: isCollapsed ? 'none' : 'block',
  },

  footer: {
    padding: isCollapsed ? '12px 8px' : '20px 16px',
    borderTop: `1px solid rgba(0, 0, 0, 0.05)`,
    // Subtle gradient for premium footer
    background: `linear-gradient(180deg, rgba(249, 250, 251, 0.3) 0%, rgba(243, 244, 246, 0.5) 100%)`,
    display: 'flex',
    flexDirection: 'column' as const,
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',
  },

  footerLogo: {
    height: isCollapsed ? '24px' : '40px',
    width: 'auto',
    // Increased opacity for better visibility - premium brands should be confident
    opacity: 0.5,
    transition: 'opacity 0.2s ease',
    // Subtle filter for premium feel
    filter: 'grayscale(0%)',
  },

  footerText: {
    fontSize: '11px',
    color: UBS_COLORS.gray500,
    letterSpacing: '0.02em',
    fontWeight: 400,
    textAlign: 'center' as const,
    display: isCollapsed ? 'none' : 'block',
    // Premium typography
    fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
  },

  tooltip: {
    position: 'absolute' as const,
    left: '100%',
    marginLeft: '12px',
    padding: '8px 12px',
    // Premium dark tooltip with subtle gradient
    background: `linear-gradient(180deg, ${UBS_COLORS.gray900} 0%, #0f0f0f 100%)`,
    color: UBS_COLORS.white,
    fontSize: '12px',
    fontWeight: 500,
    letterSpacing: '-0.01em',
    borderRadius: '8px',
    whiteSpace: 'nowrap' as const,
    // Premium multi-layered shadow
    boxShadow: `
      0 4px 8px rgba(0, 0, 0, 0.12),
      0 8px 16px rgba(0, 0, 0, 0.08),
      0 16px 32px rgba(0, 0, 0, 0.04)
    `,
    zIndex: 1000,
    pointerEvents: 'none' as const,
    opacity: 0,
    transform: 'translateX(-8px) scale(0.95)',
    transition: 'opacity 0.2s ease-out, transform 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
    // Subtle border for definition
    border: '1px solid rgba(255, 255, 255, 0.08)',
  },

  tooltipVisible: {
    opacity: 1,
    transform: 'translateX(0) scale(1)',
  },
});

/* Focus styles - UBS Red accent for accessibility with premium feel */
const focusStyles = `
  .sidebar-nav-button:focus-visible {
    outline: 2px solid ${UBS_COLORS.red};
    outline-offset: 2px;
    box-shadow: 0 0 0 4px ${UBS_COLORS.redGlow};
  }

  .sidebar-nav-button:active {
    transform: scale(0.98);
    transition: transform 0.1s ease;
  }

  .sidebar-toggle-btn:focus-visible {
    outline: 2px solid ${UBS_COLORS.red};
    outline-offset: 2px;
    box-shadow: 0 0 0 4px ${UBS_COLORS.redGlow};
  }

  .sidebar-toggle-btn:active {
    transform: scale(0.95);
    transition: transform 0.1s ease;
  }

  /* Premium hover effect for footer logo */
  .sidebar-footer-logo:hover {
    opacity: 0.7 !important;
    transition: opacity 0.2s ease;
  }
`;

const Sidebar: FC<SidebarProps> = ({
  activeItem,
  onNavigate,
  isCollapsed: controlledCollapsed,
  onToggleCollapse
}) => {
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);
  const [toggleHovered, setToggleHovered] = useState(false);
  const [internalCollapsed, setInternalCollapsed] = useState(false);

  // Use controlled or internal state
  const isCollapsed = controlledCollapsed !== undefined ? controlledCollapsed : internalCollapsed;

  const styles = getSidebarStyles(isCollapsed);

  const handleToggle = () => {
    const newCollapsed = !isCollapsed;
    if (onToggleCollapse) {
      onToggleCollapse(newCollapsed);
    } else {
      setInternalCollapsed(newCollapsed);
    }
  };

  // Update CSS variable for main content adjustment
  useEffect(() => {
    document.documentElement.style.setProperty(
      '--sidebar-actual-width',
      isCollapsed ? COLLAPSED_WIDTH : EXPANDED_WIDTH
    );
  }, [isCollapsed]);

  return (
    <div style={styles.sidebarWrapper}>
      {/* Inject focus styles */}
      <style>{focusStyles}</style>

      <aside
        style={styles.sidebar}
        aria-label="Main navigation"
        data-collapsed={isCollapsed}
      >
        {/* Logo */}
        <div style={styles.logoContainer}>
          <div style={styles.logo}>
            <img
              src="/UBS-3821101260.png"
              alt="UBS Logo"
              style={styles.logoImage}
            />
            {/* Separator line */}
            <div style={{
              width: '1px',
              height: '20px',
              backgroundColor: 'rgba(0, 0, 0, 0.15)',
              flexShrink: 0,
            }} />
            <span style={styles.logoText}>FRAME</span>
          </div>
        </div>

        {/* Navigation */}
        <nav style={styles.nav} aria-label="Main navigation">
          {navItems.map((item) => {
            const isActive = activeItem === item.id;
            const isHovered = hoveredItem === item.id;
            const showTooltip = isCollapsed && isHovered;

            return (
              <div key={item.id} style={{ position: 'relative' }}>
                <button
                  type="button"
                  className="sidebar-nav-button"
                  style={styles.navButton(isActive, isHovered)}
                  onClick={() => onNavigate(item.id)}
                  onMouseEnter={() => setHoveredItem(item.id)}
                  onMouseLeave={() => setHoveredItem(null)}
                  aria-current={isActive ? 'page' : undefined}
                  title={isCollapsed ? item.label : undefined}
                >
                  <span style={styles.navIcon(isActive)}>
                    {item.icon}
                  </span>
                  <span style={styles.navLabel}>{item.label}</span>
                  {item.isExternal && !isCollapsed && (
                    <svg
                      width="14"
                      height="14"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      style={{
                        ...styles.externalIcon,
                        opacity: isHovered ? 0.6 : 0.4,
                      }}
                      aria-hidden="true"
                    >
                      <path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6M15 3h6v6M10 14L21 3" />
                    </svg>
                  )}
                </button>

                {/* Tooltip for collapsed state */}
                {isCollapsed && (
                  <div
                    style={{
                      ...styles.tooltip,
                      ...(showTooltip ? styles.tooltipVisible : {}),
                    }}
                    role="tooltip"
                    aria-hidden={!showTooltip}
                  >
                    {item.label}
                  </div>
                )}
              </div>
            );
          })}
        </nav>

        {/* Footer with UBS Keys Logo - Premium styling */}
        <div style={styles.footer}>
          <img
            src="/ubs-keys-logo.png"
            alt="UBS Keys"
            style={styles.footerLogo}
            className="sidebar-footer-logo"
          />
          <span style={styles.footerText}>
            &copy; UBS {new Date().getFullYear()}
          </span>
        </div>
      </aside>

      {/* Toggle Button - positioned outside sidebar on the right edge */}
      <div style={styles.toggleWrapper}>
        <button
          type="button"
          className="sidebar-toggle-btn"
          style={{
            ...styles.toggleButton,
            ...(toggleHovered ? styles.toggleButtonHover : {}),
          }}
          onClick={handleToggle}
          onMouseEnter={() => setToggleHovered(true)}
          onMouseLeave={() => setToggleHovered(false)}
          aria-label={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          aria-expanded={!isCollapsed}
        >
          <svg
            width="14"
            height="14"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            style={styles.toggleIcon}
            aria-hidden="true"
          >
            <polyline points="15 18 9 12 15 6" />
          </svg>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
