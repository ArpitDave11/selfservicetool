// Epic Generator - Main Application with AI Assistance

import { useState, useCallback, useEffect, useRef } from 'react';
import { STAGES, EPIC_SECTIONS, type EpicState, type ChatMessage, type ChatState, type RefinementState, type EpicQualityReport, type SectionFeedback } from './types';
import { runSkill, getSuggestion, generatePlantUMLBlueprint, generateIntelligentBlueprint, fixMermaidDiagram, analyzeUserFeedback, processFeedback, analyzeAndRefineEpic, generateSectionImprovement, parseEpicToStageData, setConfig as setSkillsConfig, type RefineResult, type GenerateResult } from './skills';
import MarkdownPreview from './MarkdownPreview';
import Sidebar from './Sidebar';
import mermaid from 'mermaid';

// Initialize Mermaid for blueprint rendering
mermaid.initialize({
  startOnLoad: false,
  theme: 'default',
  securityLevel: 'loose',
  fontFamily: 'Frutiger, Helvetica Neue, Arial, sans-serif',
  flowchart: {
    useMaxWidth: true,
    htmlLabels: true,
    curve: 'basis',
  },
});
import {
  type AppConfig,
  type ModelFamily,
  type AIProvider,
  type GitLabEpic,
  type GitLabEpicChild,
  type GitLabLabel,
  type GitLabEpicSearchParams,
  DEFAULT_CONFIG,
  AZURE_API_VERSIONS,
  OPENAI_MODELS,
  MODEL_LIMITS,
  detectModelFamily,
  getOpenAIModelFamily,
  loadConfig,
  saveConfig,
  testGitLabConnection,
  testAzureOpenAI,
  testOpenAI,
  fetchGroupEpics,
  fetchEpicDetails,
  fetchEpicChildren,
  createGitLabEpic,
  updateGitLabEpic,
  fetchGroupLabels,
  isAIEnabled,
  getActiveAIProvider,
} from './config';

// Import mock GitLab functions for local testing
import {
  MOCK_GITLAB_ENABLED,
  shouldUseMockGitLab,
  mockFetchGroupEpics,
  mockFetchEpicDetails,
  mockFetchEpicChildren,
  mockCreateGitLabEpic,
  mockUpdateGitLabEpic,
  mockFetchGroupLabels,
} from './mockGitLabData';

// ============================================
// TOAST NOTIFICATION SYSTEM
// ============================================
type ToastType = 'success' | 'error' | 'info' | 'warning';

interface Toast {
  id: string;
  type: ToastType;
  title: string;
  message?: string;
  duration?: number;
  exiting?: boolean;
}

const ToastIcon = ({ type }: { type: ToastType }) => {
  switch (type) {
    case 'success':
      return (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
        </svg>
      );
    case 'error':
      return (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"/>
        </svg>
      );
    case 'warning':
      return (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
        </svg>
      );
    default:
      return (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
        </svg>
      );
  }
};

// ============================================
// CONFETTI COMPONENT
// ============================================
const Confetti = ({ active }: { active: boolean }) => {
  const colors = ['#3b82f6', '#8b5cf6', '#10b981', '#f59e0b', '#ef4444', '#ec4899'];
  const pieces = Array.from({ length: 50 }, (_, i) => ({
    id: i,
    left: Math.random() * 100,
    delay: Math.random() * 0.5,
    color: colors[Math.floor(Math.random() * colors.length)],
    size: 8 + Math.random() * 8,
  }));

  if (!active) return null;

  return (
    <div className="confetti-container">
      {pieces.map(piece => (
        <div
          key={piece.id}
          className="confetti-piece"
          style={{
            left: `${piece.left}%`,
            width: piece.size,
            height: piece.size,
            backgroundColor: piece.color,
            animationDelay: `${piece.delay}s`,
          }}
        />
      ))}
    </div>
  );
};

// Initial state
const initialState: EpicState = {
  currentStage: 0,
  data: {},
  diagramNodes: [],
  generatedEpic: null,
};

// Premium Fintech Styles - World-class banking UI
const styles = {
  // App layout - transparent, gradient shows through
  appLayout: {
    display: 'flex',
    minHeight: '100vh',
    gap: '24px',
  },
  // Main content area - refined spacing (8px grid)
  mainContent: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '16px',
    padding: '16px 24px 24px 0',  // 8px grid: was 20px
    maxWidth: 'calc(100vw - var(--sidebar-actual-width, var(--sidebar-width, 260px)) - 48px)',
    transition: 'max-width 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
  },
  // Premium Glass card - luxury banking glass morphism
  glassCard: {
    // Refined transparency - 72% for premium solidity while maintaining elegance
    backgroundColor: 'rgba(255, 255, 255, 0.72)',
    borderRadius: '16px',
    // Premium multi-layered shadow system for realistic depth
    boxShadow: `
      0 0 0 1px rgba(255, 255, 255, 0.5),
      0 1px 2px rgba(0, 0, 0, 0.02),
      0 2px 4px rgba(0, 0, 0, 0.02),
      0 4px 8px rgba(0, 0, 0, 0.03),
      0 8px 16px rgba(0, 0, 0, 0.03),
      0 16px 32px rgba(0, 0, 0, 0.04),
      inset 0 1px 0 rgba(255, 255, 255, 0.8),
      inset 0 0 0 1px rgba(255, 255, 255, 0.2)
    `,
    // Refined border with top highlight
    border: '1px solid rgba(255, 255, 255, 0.6)',
    borderTop: '1px solid rgba(255, 255, 255, 0.8)',
    // Premium blur for depth
    backdropFilter: 'blur(24px) saturate(180%)',
    WebkitBackdropFilter: 'blur(24px) saturate(180%)',
    position: 'relative' as const,
    overflow: 'hidden' as const,
    // Smooth transitions for hover states
    transition: 'transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), box-shadow 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
  },
  // Main container for content inside cards
  container: {
    padding: '24px 32px',  // 8px grid: was 28px 36px
    fontFamily: 'var(--font-sans, Inter, system-ui, sans-serif)',
  },
  // Modern header with refined typography
  header: {
    display: 'flex',
    flexDirection: 'column' as const,
    alignItems: 'center',
    justifyContent: 'center',
    gap: '8px',  // 8px grid: was 10px
    marginBottom: '32px',  // 8px grid: was 36px
    paddingBottom: '24px',  // 8px grid: was 28px
    borderBottom: '1px solid rgba(0, 0, 0, 0.06)',
  },
  headerIcon: {
    width: '48px',  // 8px grid: was 52px
    height: '48px',  // 8px grid: was 52px
    borderRadius: '12px',  // 8px grid: was 14px
    background: 'linear-gradient(145deg, #E60000 0%, #CC0000 100%)',  // UBS Red: was #E63946
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    boxShadow: '0 8px 20px rgba(230, 0, 0, 0.25), inset 0 1px 0 rgba(255, 255, 255, 0.2)',  // UBS Red rgba
  },
  headerContent: {
    textAlign: 'left' as const,
  },
  title: {
    fontSize: '24px',  // 8px grid: was 26px
    fontWeight: '700',
    color: '#1A1A1A',
    letterSpacing: '-0.03em',
    margin: 0,
    lineHeight: 1.2,
  },
  subtitle: {
    color: '#5C5C5C',
    marginTop: '8px',  // 8px grid: was 6px
    fontSize: '14px',
    letterSpacing: '-0.01em',
  },
  // Premium progress indicator - Gold/Amber connected stepper (matching reference)
  progressContainer: {
    marginBottom: '0',
    padding: '0',
    background: 'transparent',
    borderRadius: '0',
    border: 'none',
  },
  progress: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'flex-start',
    gap: '0',
    position: 'relative' as const,
  },
  progressStep: {
    display: 'flex',
    flexDirection: 'column' as const,
    alignItems: 'center',
    gap: '8px',  // 8px grid: was 10px
    flex: 1,
    position: 'relative' as const,
    minWidth: '88px',  // 8px grid: was 90px
  },
  // Gold/Amber stepper dots matching reference design
  progressDot: (active: boolean, completed: boolean) => ({
    width: '40px',  // 8px grid: was 42px
    height: '40px',  // 8px grid: was 42px
    borderRadius: '50%',
    // Gold/Amber gradient for active/completed, light gray for pending
    background: completed
      ? 'linear-gradient(145deg, #D4A853 0%, #C4963F 100%)'
      : active
        ? 'linear-gradient(145deg, #E5B761 0%, #D4A853 100%)'
        : 'linear-gradient(145deg, #F8F6F3 0%, #EFEBE5 100%)',
    transition: 'all 0.35s cubic-bezier(0.4, 0, 0.2, 1)',
    boxShadow: active
      ? '0 6px 20px rgba(212, 168, 83, 0.4), inset 0 2px 0 rgba(255, 255, 255, 0.25)'
      : completed
        ? '0 4px 16px rgba(212, 168, 83, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.2)'  // 8px grid: was 14px
        : '0 2px 8px rgba(0, 0, 0, 0.06), inset 0 1px 0 rgba(255, 255, 255, 0.8)',  // 8px grid: was 6px
    transform: active ? 'scale(1.1)' : 'scale(1)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: completed || active ? '#FFFFFF' : '#9CA3AF',
    fontSize: '14px',  // 8px grid: was 15px
    fontWeight: '700',
    border: active || completed ? '3px solid rgba(255, 255, 255, 0.3)' : '3px solid #E5E1DB',
    zIndex: 2,
  }),
  progressLabel: (active: boolean, completed: boolean) => ({
    fontSize: '12px',  // 8px grid: was 11px
    fontWeight: active ? '600' : '500',
    color: active ? '#1E293B' : completed ? '#64748B' : '#94A3B8',
    textAlign: 'center' as const,
    maxWidth: '88px',  // 8px grid: was 90px
    lineHeight: '1.4',
    letterSpacing: '-0.01em',
    transition: 'color 0.3s ease',
  }),
  // Connected line between steps
  progressLine: (completed: boolean) => ({
    position: 'absolute' as const,
    top: '21px',
    left: '50%',
    width: '100%',
    height: '4px',
    background: completed
      ? 'linear-gradient(90deg, #D4A853, #C4963F)'
      : 'linear-gradient(90deg, #E5E1DB, #D9D5CE)',
    borderRadius: '2px',
    zIndex: 1,
    transition: 'background 0.4s ease',
  }),
  card: {
    background: 'rgba(255, 255, 255, 0.95)',
    backdropFilter: 'blur(20px)',
    WebkitBackdropFilter: 'blur(20px)',
    borderRadius: '12px',  // UBS standard: was 16px
    padding: '24px',  // 8px grid: was 28px
    boxShadow: '0 4px 16px rgba(0, 0, 0, 0.05), 0 1px 4px rgba(0, 0, 0, 0.03)',  // 8px grid: was 20px
    border: '1px solid rgba(0, 0, 0, 0.04)',
    marginBottom: '24px',  // 8px grid: was 20px
    transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
  },
  stageTitle: {
    fontSize: '24px',  // 8px grid: was 22px
    fontWeight: '600',
    marginBottom: '8px',  // 8px grid: was 10px
    color: '#1A1A1A',
    letterSpacing: '-0.02em',
    lineHeight: 1.3,
  },
  stageDesc: {
    color: '#5C5C5C',
    marginBottom: '24px',
    fontSize: '14px',
    lineHeight: 1.5,
  },
  fieldGroup: { marginBottom: '24px' },
  labelRow: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '8px',
  },
  label: {
    fontWeight: '500',
    color: '#1A1A1A',
    fontSize: '14px',
    letterSpacing: '-0.01em',
  },
  input: {
    width: '100%',
    padding: '12px 16px',
    border: '1px solid #E8E4E0',
    borderRadius: '8px',  // UBS standard: was 10px
    fontSize: '14px',
    boxSizing: 'border-box' as const,
    background: '#F9F7F5',
    color: '#1A1A1A',
    transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
    outline: 'none',
  },
  textarea: {
    width: '100%',
    padding: '12px 16px',  // 8px grid: was 14px 16px
    border: '1px solid #E8E4E0',
    borderRadius: '8px',  // UBS standard: was 10px
    fontSize: '14px',
    minHeight: '120px',
    resize: 'vertical' as const,
    boxSizing: 'border-box' as const,
    background: '#F9F7F5',
    color: '#1A1A1A',
    lineHeight: 1.6,
    transition: 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)',
    outline: 'none',
  },
  buttonRow: {
    display: 'flex',
    gap: '8px',  // 8px grid: was 12px (button groups use 8px)
    justifyContent: 'flex-end',
    marginTop: '24px',  // 8px grid: was 28px
    paddingTop: '16px',  // 8px grid: was 20px
    borderTop: '1px solid rgba(0, 0, 0, 0.04)',
  },
  // Premium UBS Banking Button - Official brand colors with Swiss precision
  button: (primary: boolean) => ({
    padding: '12px 24px',
    borderRadius: '8px',
    border: primary ? 'none' : '1px solid #D1D5DB',
    cursor: 'pointer',
    fontWeight: '500',
    fontSize: '14px',
    letterSpacing: '-0.01em',
    position: 'relative' as const,
    overflow: 'hidden' as const,
    background: primary
      ? 'linear-gradient(145deg, #E60000 0%, #CC0000 50%, #B30000 100%)'  // Official UBS Red
      : 'linear-gradient(180deg, #FFFFFF 0%, #F9FAFB 100%)',
    color: primary ? 'white' : '#374151',
    boxShadow: primary
      ? '0 2px 4px rgba(230, 0, 0, 0.15), 0 4px 8px rgba(230, 0, 0, 0.12), inset 0 1px 0 rgba(255, 255, 255, 0.15)'
      : '0 1px 2px rgba(0, 0, 0, 0.05), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
    textShadow: primary ? '0 1px 1px rgba(0, 0, 0, 0.1)' : 'none',
    transition: 'all 0.15s ease-out',
  }),
  // Premium AI Suggest Button - Purple accent with depth
  suggestButton: {
    padding: '8px 16px',  // 8px grid: was 6px 14px
    borderRadius: '8px',
    border: 'none',
    cursor: 'pointer',
    background: 'linear-gradient(145deg, #8B5CF6 0%, #7C3AED 50%, #6D28D9 100%)',
    color: 'white',
    fontSize: '12px',
    fontWeight: '500',
    display: 'flex',
    alignItems: 'center',
    gap: '4px',  // 8px grid: was 5px
    boxShadow: '0 2px 4px rgba(139, 92, 246, 0.2), 0 4px 8px rgba(139, 92, 246, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.15)',
    textShadow: '0 1px 1px rgba(0, 0, 0, 0.1)',
    transition: 'all 0.2s cubic-bezier(0.34, 1.56, 0.64, 1)',
  },
  // Premium Auto-Suggest Button - Green accent with depth
  suggestButtonAuto: {
    padding: '8px 16px',  // 8px grid: was 6px 14px
    borderRadius: '8px',
    border: 'none',
    cursor: 'pointer',
    background: 'linear-gradient(145deg, #22C55E 0%, #16A34A 50%, #15803D 100%)',
    color: 'white',
    fontSize: '12px',
    fontWeight: '500',
    display: 'flex',
    alignItems: 'center',
    gap: '4px',  // 8px grid: was 5px
    boxShadow: '0 2px 4px rgba(34, 197, 94, 0.2), 0 4px 8px rgba(34, 197, 94, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.15)',
    textShadow: '0 1px 1px rgba(0, 0, 0, 0.1)',
    transition: 'all 0.2s cubic-bezier(0.34, 1.56, 0.64, 1)',
  },
  // Loading state for suggest buttons - Shimmer effect
  suggestButtonLoading: {
    padding: '8px 16px',  // 8px grid: was 6px 14px
    borderRadius: '8px',
    border: '1px solid #E8E4E0',
    cursor: 'not-allowed',
    background: 'linear-gradient(90deg, #F5F3F0 25%, #E8E4E0 50%, #F5F3F0 75%)',
    backgroundSize: '200% 100%',
    animation: 'shimmer 1.5s ease-in-out infinite',
    color: '#8A8A8A',
    fontSize: '12px',
    fontWeight: '500',
    boxShadow: 'inset 0 1px 2px rgba(0, 0, 0, 0.04)',
  },
  suggestButtonGroup: {
    display: 'flex',
    gap: '8px',
    alignItems: 'center',
  },
  refinedSection: {
    marginTop: '16px',  // 8px grid: was 14px
    padding: '16px',  // 8px grid: was 14px 16px
    backgroundColor: '#ECFDF5',
    borderRadius: '8px',  // UBS standard: was 10px
    border: '1px solid rgba(16, 185, 129, 0.2)',
  },
  refinedHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '8px',  // 8px grid: was 10px
  },
  refinedBadge: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '4px',  // 8px grid: was 5px
    padding: '4px 8px',  // 8px grid: was 4px 10px
    backgroundColor: '#D1FAE5',
    color: '#065F46',
    borderRadius: '4px',  // Badge standard: was 6px
    fontSize: '12px',
    fontWeight: '500',
  },
  // Premium Edit Button - Outline style with hover effect
  editButton: {
    padding: '8px 12px',  // 8px grid: was 5px 12px
    borderRadius: '8px',  // UBS standard: was 6px
    border: '1.5px solid #10B981',
    cursor: 'pointer',
    background: 'linear-gradient(180deg, #FFFFFF 0%, #F0FDF4 100%)',
    color: '#10B981',
    fontSize: '12px',  // Standard: was 11px
    fontWeight: '500',  // Consistent: was 600
    boxShadow: '0 1px 2px rgba(16, 185, 129, 0.08)',
    transition: 'all 0.2s cubic-bezier(0.34, 1.56, 0.64, 1)',
  },
  refinedTextarea: {
    width: '100%',
    padding: '12px',  // 8px grid: was 10px 12px
    border: '1px solid rgba(16, 185, 129, 0.3)',
    borderRadius: '8px',
    fontSize: '14px',  // Standard: was 13px
    backgroundColor: 'white',
    minHeight: '80px',
    resize: 'vertical' as const,
    boxSizing: 'border-box' as const,
    lineHeight: 1.5,
    outline: 'none',
  },
  refinedPreview: {
    fontSize: '14px',  // Standard: was 13px
    color: '#1A1A1A',
    whiteSpace: 'pre-wrap' as const,
    lineHeight: '1.6',
  },
  alternativesSection: {
    marginTop: '8px',  // 8px grid: was 10px
    padding: '8px 12px',  // 8px grid: was 10px 12px
    backgroundColor: '#FAF5FF',
    borderRadius: '8px',
    border: '1px dashed rgba(139, 92, 246, 0.3)',
  },
  alternativeChip: {
    display: 'inline-block',
    padding: '8px 12px',  // 8px grid: was 5px 10px
    margin: '4px',  // 8px grid: was 3px
    borderRadius: '8px',  // UBS standard: was 6px
    backgroundColor: 'white',
    border: '1px solid rgba(139, 92, 246, 0.3)',
    cursor: 'pointer',
    fontSize: '12px',
    color: '#7c3aed',
    fontWeight: '500',
    transition: 'all 0.2s ease',
  },
  // Premium tab navigation - refined fintech look
  tabsContainer: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '0',
    padding: '4px',
    background: '#F5F3F0',
    borderRadius: '12px',
  },
  tabsGroup: {
    display: 'flex',
    gap: '4px',  // 8px grid: was 2px
  },
  tabs: {
    display: 'flex',
    gap: '4px',  // 8px grid: was 2px
    marginBottom: '0',
  },
  // Premium Tab Button - Refined fintech look with active state
  tab: (active: boolean) => ({
    padding: '12px 20px',  // 8px grid: was 11px 20px
    borderRadius: '8px',  // UBS standard: was 10px
    border: 'none',
    cursor: 'pointer',
    background: active
      ? 'linear-gradient(180deg, #FFFFFF 0%, #FAFAFA 100%)'
      : 'transparent',
    color: active ? '#1A1A1A' : '#5C5C5C',
    fontWeight: active ? '600' : '500',
    fontSize: '14px',
    letterSpacing: '-0.01em',
    boxShadow: active
      ? '0 2px 8px rgba(0, 0, 0, 0.08), 0 1px 2px rgba(0, 0, 0, 0.04), inset 0 1px 0 rgba(255, 255, 255, 0.9)'
      : 'none',
    transition: 'all 0.25s cubic-bezier(0.4, 0, 0.2, 1)',
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    position: 'relative' as const,
    transform: active ? 'translateY(-1px)' : 'translateY(0)',
  }),
  tabIcon: {
    width: '16px',
    height: '16px',
    opacity: 0.8,
    transition: 'opacity 0.2s ease',
  },
  sectionPreview: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(176px, 1fr))',  // 8px grid: was 180px
    gap: '8px',
    marginTop: '16px',  // 8px grid: was 14px
  },
  sectionChip: (populated: boolean) => ({
    padding: '8px 12px',
    borderRadius: '8px',
    fontSize: '12px',
    fontWeight: '500',
    lineHeight: '1.35',
    backgroundColor: populated ? '#ECFDF5' : '#F5F3F0',
    color: populated ? '#065F46' : '#5C5C5C',
    border: populated ? '1px solid rgba(16, 185, 129, 0.2)' : '1px solid #E8E4E0',
    minHeight: '40px',
    display: 'flex',
    alignItems: 'center',
    transition: 'all 0.2s ease',
  }),
  helpBanner: {
    padding: '16px 24px',  // 8px grid: was 16px 20px
    background: 'linear-gradient(135deg, rgba(139, 92, 246, 0.06) 0%, rgba(124, 58, 237, 0.04) 100%)',
    borderRadius: '12px',  // 8px grid: was 14px
    marginBottom: '24px',
    display: 'flex',
    alignItems: 'center',
    gap: '16px',  // 8px grid: was 14px
    border: '1px solid rgba(139, 92, 246, 0.12)',
    boxShadow: '0 2px 8px rgba(139, 92, 246, 0.04)',
  },
  helpIcon: {
    fontSize: '16px',  // 8px grid: was 18px
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: '#7C3AED',
    backgroundColor: 'rgba(139, 92, 246, 0.1)',
    borderRadius: '8px',  // UBS standard: was 10px
    padding: '8px',
    flexShrink: 0,
  },
  helpText: {
    fontSize: '14px',  // Standard: was 13px
    color: '#5B21B6',
    lineHeight: '1.6',
    fontWeight: '400',
  },
  // Premium split screen - refined visual hierarchy
  splitContainer: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '16px',  // 8px grid: was 20px
    height: 'calc(100vh - 304px)',  // 8px grid: was 300px
    minHeight: '480px',
  },
  splitPane: {
    display: 'flex',
    flexDirection: 'column' as const,
    height: '100%',
    overflow: 'hidden',
    borderRadius: '12px',
  },
  paneHeader: {
    padding: '12px 16px',  // 8px grid: was 12px 18px
    background: 'linear-gradient(145deg, #FAF8F6 0%, #F5F3F0 100%)',
    borderBottom: '1px solid #E8E4E0',
    fontWeight: '600',
    fontSize: '14px',  // Standard: was 13px
    letterSpacing: '-0.01em',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderRadius: '12px 12px 0 0',
    color: '#1A1A1A',
  },
  editorPane: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column' as const,
    borderRadius: '12px',
    overflow: 'hidden',
    backgroundColor: '#1e293b',
    boxShadow: '0 4px 16px rgba(0, 0, 0, 0.08), 0 1px 4px rgba(0, 0, 0, 0.04)',
  },
  previewPane: {
    flex: 1,
    borderRadius: '12px',
    overflow: 'auto',
    backgroundColor: 'white',
    boxShadow: '0 4px 16px rgba(0, 0, 0, 0.05), 0 1px 4px rgba(0, 0, 0, 0.03)',
    border: '1px solid #E8E4E0',
  },
  editor: {
    flex: 1,
    width: '100%',
    padding: '16px 20px',  // 8px grid: was 18px 20px
    border: 'none',
    outline: 'none',
    resize: 'none' as const,
    fontSize: '14px',  // Standard: was 13px
    fontFamily: 'var(--font-mono, "JetBrains Mono", "Fira Code", monospace)',
    lineHeight: '1.7',
    boxSizing: 'border-box' as const,
    backgroundColor: '#1e293b',
    color: '#e2e8f0',
    letterSpacing: '0.01em',
  },
  actionBar: {
    padding: '16px',  // 8px grid: was 14px 18px
    backgroundColor: '#FAF8F6',
    borderTop: '1px solid #E8E4E0',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
};

// Mermaid Blueprint Renderer Component - MUST be outside App to prevent remounting
const MermaidBlueprint = ({
  code,
  zoom = 100,
  onRequestFix,
  onSvgReady
}: {
  code: string;
  zoom?: number;
  onRequestFix?: (failedCode: string, errorMessage: string) => Promise<string | null>;
  onSvgReady?: (svg: string) => void;
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [svg, setSvg] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [isFixing, setIsFixing] = useState(false);

  // Use refs to prevent re-render loops and track state across renders
  const onRequestFixRef = useRef(onRequestFix);
  const onSvgReadyRef = useRef(onSvgReady);
  const renderIdRef = useRef(0);
  const hasAttemptedFixRef = useRef(false);

  // Keep callback refs updated
  useEffect(() => {
    onRequestFixRef.current = onRequestFix;
    onSvgReadyRef.current = onSvgReady;
  }, [onRequestFix, onSvgReady]);

  // Single effect that handles rendering
  useEffect(() => {
    if (!code) {
      return;
    }

    // Increment render ID to track this specific render attempt
    renderIdRef.current += 1;
    const currentRenderId = renderIdRef.current;
    hasAttemptedFixRef.current = false;

    const renderDiagram = async () => {
      try {
        setError(null);
        setIsFixing(false);
        const id = `mermaid-blueprint-${Date.now()}`;

        // Unescape HTML entities
        const unescapedCode = code
          .replace(/&gt;/g, '>')
          .replace(/&lt;/g, '<')
          .replace(/&amp;/g, '&')
          .replace(/&quot;/g, '"')
          .replace(/&#39;/g, "'");

        const { svg: renderedSvg } = await mermaid.render(id, unescapedCode);

        // Check if this render is still current (another render might have started)
        if (currentRenderId !== renderIdRef.current) {
          return;
        }

        // Update state
        setSvg(renderedSvg);

        // Notify parent
        if (onSvgReadyRef.current) {
          onSvgReadyRef.current(renderedSvg);
        }
      } catch (err) {
        // Check if this render is still current
        if (currentRenderId !== renderIdRef.current) {
          return;
        }

        const errorMsg = err instanceof Error ? err.message : 'Failed to render diagram';

        // Attempt AI fix if available and not already attempted
        if (onRequestFixRef.current && !hasAttemptedFixRef.current) {
          hasAttemptedFixRef.current = true;
          setIsFixing(true);
          try {
            const fixedCode = await onRequestFixRef.current(code, errorMsg);
            if (fixedCode && fixedCode !== code) {
              setIsFixing(false);
              return; // Parent will update code, triggering re-render
            }
          } catch {
            // AI fix failed, continue to show error
          }
          setIsFixing(false);
        }

        setError(errorMsg);
      }
    };

    renderDiagram();
  }, [code]); // ONLY depend on code

  // Show fixing state
  if (isFixing) {
    return (
      <div style={{ textAlign: 'center', padding: '40px', color: '#666' }}>
        <div className="skeleton" style={{
          width: '48px',
          height: '48px',
          borderRadius: '50%',
          margin: '0 auto 16px',
        }} />
        <p style={{ fontSize: '16px', marginBottom: '8px', color: '#3b82f6' }}>
          AI is fixing the diagram...
        </p>
        <p style={{ fontSize: '13px', color: '#999' }}>
          Correcting syntax errors automatically
        </p>
      </div>
    );
  }

  if (error) {
    return (
      <div style={{ textAlign: 'center', padding: '40px', color: '#666' }}>
        <div style={{ fontSize: '48px', marginBottom: '16px' }}>⚠️</div>
        <p style={{ fontSize: '16px', marginBottom: '12px' }}>Unable to render diagram</p>
        <p style={{ fontSize: '13px', color: '#999' }}>{error}</p>
        <p style={{ fontSize: '13px', marginTop: '12px' }}>
          Try editing the Mermaid code below or click Regenerate
        </p>
      </div>
    );
  }

  if (!svg) {
    return (
      <div style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: '200px',
        color: '#999',
        fontSize: '14px',
      }}>
        Loading diagram...
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'flex-start',
        transform: `scale(${zoom / 100})`,
        transformOrigin: 'top center',
        transition: 'transform 0.2s ease',
      }}
      dangerouslySetInnerHTML={{ __html: svg }}
    />
  );
};

export default function App() {
  const [state, setState] = useState<EpicState>(initialState);
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [editingRefined, setEditingRefined] = useState<Record<string, boolean>>({});
  const [loadingSuggestion, setLoadingSuggestion] = useState<Record<string, boolean>>({});
  const [alternatives, setAlternatives] = useState<Record<string, string[]>>({});
  const [isRefining, setIsRefining] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeTab, setActiveTab] = useState<'wizard' | 'epic' | 'blueprint' | 'settings'>('epic'); // Default to Epic Editor
  const [sidebarActive, setSidebarActive] = useState<string>('epic-planner'); // Sidebar navigation state
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false); // Sidebar collapse state
  const [editableEpic, setEditableEpic] = useState<string>('');
  const [blueprintCode, setBlueprintCode] = useState<string>('');
  const [blueprintType, setBlueprintType] = useState<string>('');
  const [blueprintReasoning, setBlueprintReasoning] = useState<string>('');
  const [isGeneratingBlueprint, setIsGeneratingBlueprint] = useState(false);
  const [blueprintZoom, setBlueprintZoom] = useState<number>(100); // Zoom percentage
  const [blueprintFullscreen, setBlueprintFullscreen] = useState(false); // Fullscreen mode
  const [blueprintSvg, setBlueprintSvg] = useState<string>(''); // SVG content for export

  // Config state
  const [config, setConfig] = useState<AppConfig>(DEFAULT_CONFIG);
  const [isPublishing, setIsPublishing] = useState(false);
  const [publishStatus, setPublishStatus] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [gitlabTestStatus, setGitlabTestStatus] = useState<{ testing: boolean; result?: string } | null>(null);
  const [azureTestStatus, setAzureTestStatus] = useState<{ testing: boolean; result?: string } | null>(null);
  const [openaiTestStatus, setOpenaiTestStatus] = useState<{ testing: boolean; result?: string } | null>(null);

  // GitLab Epic Management state (new epic-focused approach)
  const [gitlabEpics, setGitlabEpics] = useState<import('./config').GitLabEpic[]>([]);
  const [loadingGitLabEpics, setLoadingGitLabEpics] = useState(false);
  const [gitlabEpicsTotalCount, setGitlabEpicsTotalCount] = useState(0);
  const [selectedGitLabEpic, setSelectedGitLabEpic] = useState<import('./config').GitLabEpic | null>(null);
  const [epicChildren, setEpicChildren] = useState<{ epics: import('./config').GitLabEpicChild[]; issues: import('./config').GitLabEpicChild[] }>({ epics: [], issues: [] });
  const [loadingEpicDetails, setLoadingEpicDetails] = useState(false);
  const [epicSearchTerm, setEpicSearchTerm] = useState('');
  const [epicFilterLabels, setEpicFilterLabels] = useState<string[]>([]);
  const [epicFilterState, setEpicFilterState] = useState<'opened' | 'closed' | 'all'>('opened');
  const [epicPage, setEpicPage] = useState(1);
  const [availableLabels, setAvailableLabels] = useState<import('./config').GitLabLabel[]>([]);
  const [epicEditorMode, setEpicEditorMode] = useState<'browse' | 'view' | 'edit'>('browse');
  const [showPublishAsEpicModal, setShowPublishAsEpicModal] = useState(false);
  const [publishAsEpicLevel, setPublishAsEpicLevel] = useState<'crew' | 'pod'>('pod');
  const [publishAsEpicParentId, setPublishAsEpicParentId] = useState<number | null>(null);

  // Load Epic Modal state
  const [showLoadEpicModal, setShowLoadEpicModal] = useState(false);
  const [loadEpicSearchTerm, setLoadEpicSearchTerm] = useState('');
  const [loadEpicFilterState, setLoadEpicFilterState] = useState<'opened' | 'closed' | 'all'>('opened');
  const [loadEpicResults, setLoadEpicResults] = useState<import('./config').GitLabEpic[]>([]);
  const [loadingLoadEpicResults, setLoadingLoadEpicResults] = useState(false);

  // Toast notifications state
  const [toasts, setToasts] = useState<Toast[]>([]);
  const toastIdRef = useRef(0);
  const hasAutoLoadedEpicsRef = useRef(false);  // Prevent multiple auto-loads in mock mode

  // Confetti state
  const [showConfetti, setShowConfetti] = useState(false);

  // Generation progress state
  const [generationProgress, setGenerationProgress] = useState({ current: 0, total: 17, section: '' });

  // Chat/Feedback state
  const [chatState, setChatState] = useState<ChatState>({
    messages: [],
    isOpen: false,
    isProcessing: false,
  });
  const [chatInput, setChatInput] = useState('');
  const chatMessagesRef = useRef<HTMLDivElement>(null);

  // AI Refinement state
  const [refinementState, setRefinementState] = useState<RefinementState>({
    isRefining: false,
    progress: { current: 0, total: 17, section: '' },
    report: null,
    showReport: false,
  });
  const [lastRefinementScore, setLastRefinementScore] = useState<number | null>(null);

  // Smart Refine state
  const [isSmartRefining, setIsSmartRefining] = useState(false);
  const [smartRefineProgress, setSmartRefineProgress] = useState({ stage: '', field: '', current: 0, total: 0 });
  const [autoGeneratedFields, setAutoGeneratedFields] = useState<string[]>([]);  // Fields that were auto-generated
  const [smartRefineReview, setSmartRefineReview] = useState<EpicQualityReport | null>(null);  // AI Critique review
  const [warningsExpanded, setWarningsExpanded] = useState(true);  // Collapsible warnings panel state

  // Apply AI Suggestions state
  const [isApplyingSuggestions, setIsApplyingSuggestions] = useState(false);
  const [applySuggestionsProgress, setApplySuggestionsProgress] = useState({
    current: 0,
    total: 0,
    phase: 'idle' as 'idle' | 'applying' | 'reanalyzing' | 'done'
  });

  // Toast helper function
  const showToast = useCallback((type: ToastType, title: string, message?: string, duration = 3000) => {
    const id = `toast-${++toastIdRef.current}`;
    setToasts(prev => [...prev, { id, type, title, message, duration }]);

    // Auto dismiss
    setTimeout(() => {
      setToasts(prev => prev.map(t => t.id === id ? { ...t, exiting: true } : t));
      setTimeout(() => {
        setToasts(prev => prev.filter(t => t.id !== id));
      }, 300);
    }, duration);
  }, []);

  // Trigger confetti
  const triggerConfetti = useCallback(() => {
    setShowConfetti(true);
    setTimeout(() => setShowConfetti(false), 3000);
  }, []);

  // ============================================
  // CHAT/FEEDBACK FUNCTIONS
  // ============================================

  // Toggle chat panel
  const toggleChat = useCallback(() => {
    setChatState(prev => ({ ...prev, isOpen: !prev.isOpen }));
  }, []);

  // Add message to chat
  const addChatMessage = useCallback((message: Omit<ChatMessage, 'id' | 'timestamp'>) => {
    setChatState(prev => ({
      ...prev,
      messages: [...prev.messages, {
        ...message,
        id: `msg-${Date.now()}`,
        timestamp: new Date(),
      }],
    }));
    // Scroll to bottom
    setTimeout(() => {
      chatMessagesRef.current?.scrollTo({ top: chatMessagesRef.current.scrollHeight, behavior: 'smooth' });
    }, 100);
  }, []);

  // Replace section in epic markdown
  const replaceSection = useCallback((epic: string, sectionNum: number, newContent: string): string => {
    const sectionInfo = EPIC_SECTIONS[sectionNum - 1];
    if (!sectionInfo) return epic;

    // Escape special regex characters in section title
    const escapedTitle = sectionInfo.title.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

    // Match the section header and its content until the next section or end
    const sectionRegex = new RegExp(
      `(## ${sectionNum}\\. ${escapedTitle}[\\s\\S]*?)(?=## \\d+\\.|$)`,
      'i'
    );

    return epic.replace(sectionRegex, newContent + '\n\n');
  }, []);

  // Handle section selection from chat dropdown
  const handleSectionSelect = useCallback(async (sectionNum: number, messageId: string) => {
    if (!chatState.pendingFeedback) return;

    // Mark the question as answered
    setChatState(prev => ({
      ...prev,
      messages: prev.messages.map(m =>
        m.id === messageId ? { ...m, isAnswered: true, selectedValue: `${sectionNum}` } : m
      ),
      isProcessing: true,
      pendingSection: sectionNum,
    }));

    try {
      const result = await processFeedback(chatState.pendingFeedback, editableEpic, sectionNum);

      // Update the epic with the new section
      const updatedEpic = replaceSection(editableEpic, sectionNum, result.updatedSection);
      setEditableEpic(updatedEpic);

      addChatMessage({
        role: 'assistant',
        content: `Done! ${result.explanation}`,
      });

      showToast('success', 'Section Updated', `Updated: ${EPIC_SECTIONS[sectionNum - 1].title}`);
    } catch (err) {
      console.error('Failed to process feedback:', err);
      addChatMessage({
        role: 'assistant',
        content: 'Sorry, I failed to update the section. Please try again.',
      });
      showToast('error', 'Update Failed', 'Could not update the section');
    } finally {
      setChatState(prev => ({
        ...prev,
        isProcessing: false,
        pendingSection: undefined,
        pendingFeedback: undefined,
      }));
    }
  }, [chatState.pendingFeedback, editableEpic, replaceSection, addChatMessage, showToast]);

  // Handle confirm button (when AI suggests a section)
  const handleConfirmSection = useCallback(async (confirmed: boolean, messageId: string) => {
    // Mark the question as answered
    setChatState(prev => ({
      ...prev,
      messages: prev.messages.map(m =>
        m.id === messageId ? { ...m, isAnswered: true, selectedValue: confirmed ? 'yes' : 'no' } : m
      ),
    }));

    if (confirmed && chatState.pendingSection) {
      await handleSectionSelect(chatState.pendingSection, messageId);
    } else {
      // User said no, ask which section they want
      addChatMessage({
        role: 'assistant',
        content: 'Which section would you like me to update instead?',
        questionType: 'section-select',
        options: EPIC_SECTIONS.map(s => `${s.num}. ${s.title}`),
      });
    }
  }, [chatState.pendingSection, handleSectionSelect, addChatMessage]);

  // Handle sending a chat message
  const handleSendChatMessage = useCallback(async () => {
    if (!chatInput.trim() || chatState.isProcessing) return;

    const feedback = chatInput.trim();
    setChatInput('');

    // Add user message
    addChatMessage({ role: 'user', content: feedback });

    // Store the feedback for later use
    setChatState(prev => ({
      ...prev,
      isProcessing: true,
      pendingFeedback: feedback,
    }));

    try {
      // Analyze feedback to determine section
      const analysis = await analyzeUserFeedback(
        feedback,
        EPIC_SECTIONS.map(s => s.title)
      );

      if (analysis.needsClarification || !analysis.suggestedSection) {
        // Ask which section to update
        addChatMessage({
          role: 'assistant',
          content: analysis.followUpQuestion || 'Which section would you like me to update?',
          questionType: 'section-select',
          options: EPIC_SECTIONS.map(s => `${s.num}. ${s.title}`),
        });
        setChatState(prev => ({ ...prev, isProcessing: false }));
      } else {
        // AI detected a section - confirm with user
        const sectionTitle = EPIC_SECTIONS[analysis.suggestedSection - 1]?.title || 'Unknown';
        addChatMessage({
          role: 'assistant',
          content: `I'll update section ${analysis.suggestedSection} "${sectionTitle}". Is that correct?`,
          questionType: 'confirm',
        });
        setChatState(prev => ({
          ...prev,
          isProcessing: false,
          pendingSection: analysis.suggestedSection,
        }));
      }
    } catch (err) {
      console.error('Failed to analyze feedback:', err);
      addChatMessage({
        role: 'assistant',
        content: 'Sorry, I encountered an error. Which section would you like me to update?',
        questionType: 'section-select',
        options: EPIC_SECTIONS.map(s => `${s.num}. ${s.title}`),
      });
      setChatState(prev => ({ ...prev, isProcessing: false }));
    }
  }, [chatInput, chatState.isProcessing, addChatMessage]);

  // Load config on mount
  useEffect(() => {
    const loaded = loadConfig();
    setConfig(loaded);
    setSkillsConfig(loaded); // Pass config to skills module for AI calls
  }, []);

  // Sync sidebar state with active tab
  useEffect(() => {
    const tabToSidebar: Record<string, string> = {
      'wizard': 'epic-planner',
      'epic': 'epic-planner',
      'blueprint': 'blueprints',
      'settings': 'settings',
    };
    const newSidebarItem = tabToSidebar[activeTab];
    if (newSidebarItem && newSidebarItem !== sidebarActive) {
      setSidebarActive(newSidebarItem);
    }
  }, [activeTab, sidebarActive]);

  // Handle ESC key to exit fullscreen mode
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && blueprintFullscreen) {
        setBlueprintFullscreen(false);
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [blueprintFullscreen]);

  // Save config when it changes
  const updateConfig = (newConfig: AppConfig) => {
    setConfig(newConfig);
    saveConfig(newConfig);
    setSkillsConfig(newConfig); // Update skills module config for AI calls
  };

  const currentStage = STAGES[state.currentStage];
  const isLastStage = state.currentStage === STAGES.length - 1;
  const hasEpic = state.generatedEpic !== null;

  // Build context from all data
  const getContext = useCallback(() => {
    const context: Record<string, string> = {};
    Object.entries(formData).forEach(([key, value]) => {
      context[key] = value;
    });
    Object.entries(state.data).forEach(([key, value]) => {
      context[key] = value.original;
    });
    return context;
  }, [formData, state.data]);

  // Handle sidebar navigation
  const handleSidebarNavigate = (itemId: string) => {
    setSidebarActive(itemId);
    // Map sidebar items to tabs
    if (itemId === 'epic-planner') {
      setActiveTab('wizard');
    } else if (itemId === 'blueprints') {
      setActiveTab('blueprint');
    } else if (itemId === 'settings') {
      setActiveTab('settings');
    }
  };

  // Handle field input
  const handleFieldChange = (fieldName: string, value: string) => {
    setFormData(prev => ({ ...prev, [fieldName]: value }));
  };

  // Handle refined content edit
  const handleRefinedChange = (fieldName: string, value: string) => {
    setState(prev => ({
      ...prev,
      data: {
        ...prev.data,
        [fieldName]: {
          ...prev.data[fieldName],
          refined: value,
        },
      },
    }));
  };

  // Get AI suggestion for a field
  // mode: 'with-context' uses user's input as keywords, 'auto' generates from scratch
  // Typewriter state
  const [typingField, setTypingField] = useState<string | null>(null);

  // Typewriter effect function
  const typewriterEffect = useCallback((fieldName: string, text: string, speed = 15) => {
    setTypingField(fieldName);
    let index = 0;
    setFormData(prev => ({ ...prev, [fieldName]: '' }));

    const typeInterval = setInterval(() => {
      if (index < text.length) {
        setFormData(prev => ({
          ...prev,
          [fieldName]: text.slice(0, index + 1),
        }));
        index++;
      } else {
        clearInterval(typeInterval);
        setTypingField(null);
      }
    }, speed);

    return () => clearInterval(typeInterval);
  }, []);

  const handleGetSuggestion = async (fieldName: string, mode: 'with-context' | 'auto') => {
    setLoadingSuggestion(prev => ({ ...prev, [fieldName]: true }));

    const context = getContext();

    // If 'with-context' mode and user has typed something, include it as hint
    if (mode === 'with-context' && formData[fieldName]?.trim()) {
      context['_userHint'] = formData[fieldName].trim();
    }

    const result = await getSuggestion(currentStage.id, fieldName, context, mode);

    // Use typewriter effect for the suggestion
    typewriterEffect(fieldName, result.suggestion);

    if (result.alternatives) {
      setAlternatives(prev => ({ ...prev, [fieldName]: result.alternatives! }));
    }

    setLoadingSuggestion(prev => ({ ...prev, [fieldName]: false }));
  };

  // Use an alternative suggestion
  const handleUseAlternative = (fieldName: string, alt: string) => {
    setFormData(prev => ({ ...prev, [fieldName]: alt }));
  };

  // Refine current stage inputs
  const refineStage = useCallback(async () => {
    setIsRefining(true);
    const newData = { ...state.data };
    const newDiagramNodes = [...state.diagramNodes];

    const context = getContext();

    // Refine each field in the current stage
    for (const field of currentStage.fields) {
      const input = formData[field.name] || '';
      if (input.trim()) {
        const result = await runSkill('refine', {
          stageId: currentStage.id,
          fieldName: field.name,
          input,
          context,
        }) as RefineResult;

        newData[field.name] = {
          original: input,
          refined: result.refined,
          diagramNode: result.diagramNode,
        };

        // Only add diagram node if not already present
        if (!newDiagramNodes.includes(result.diagramNode)) {
          newDiagramNodes.push(result.diagramNode);
        }
      }
    }

    setState(prev => ({
      ...prev,
      data: newData,
      diagramNodes: newDiagramNodes,
    }));
    setIsRefining(false);
  }, [currentStage, formData, state.data, state.diagramNodes, getContext]);

  // Navigate to next stage
  const nextStage = async () => {
    await refineStage();
    if (isLastStage) {
      generateEpic();
    } else {
      setState(prev => ({ ...prev, currentStage: prev.currentStage + 1 }));
      setFormData({});
      setAlternatives({});
      setEditingRefined({});
    }
  };

  // Navigate to previous stage
  const prevStage = () => {
    if (state.currentStage > 0) {
      setState(prev => ({ ...prev, currentStage: prev.currentStage - 1 }));
      // Restore form data for previous stage
      const prevStageFields = STAGES[state.currentStage - 1].fields;
      const restoredData: Record<string, string> = {};
      prevStageFields.forEach(field => {
        if (state.data[field.name]) {
          restoredData[field.name] = state.data[field.name].original;
        }
      });
      setFormData(restoredData);
      setAlternatives({});
      setEditingRefined({});
    }
  };

  // Generate final epic with progress tracking
  const generateEpic = async () => {
    setIsGenerating(true);
    const projectName = state.data['projectName']?.original || 'Untitled Project';

    // Simulate progress through sections
    const sections = [
      'Objective', 'Background & Context', 'Scope', 'Assumptions',
      'Architecture Overview', 'Architecture Diagrams', 'Team & Roles',
      'Environments & CI/CD', 'Data Security', 'Data Stores & Services',
      'Key Features', 'Non-Functional Requirements', 'Dependencies & Risks',
      'Deliverables', 'Next Steps', 'Definition of Done', 'Approvals'
    ];

    // Animate progress
    for (let i = 0; i < sections.length; i++) {
      setGenerationProgress({ current: i + 1, total: 17, section: sections[i] });
      await new Promise(resolve => setTimeout(resolve, 100)); // Brief delay for visual effect
    }

    // Generate Blueprint first so it can be included in the Epic
    setIsGeneratingBlueprint(true);
    setGenerationProgress({ current: 17, total: 17, section: 'Generating Blueprint...' });
    let generatedBlueprintCode = '';
    try {
      const blueprintResult = await generateIntelligentBlueprint(state.data, projectName);
      generatedBlueprintCode = blueprintResult.diagram;
      setBlueprintCode(blueprintResult.diagram);
      setBlueprintType(blueprintResult.type);
      setBlueprintReasoning(blueprintResult.reasoning);
    } catch (error) {
      // Fallback to legacy blueprint if intelligent generation fails
      console.error('Intelligent blueprint failed, using legacy:', error);
      const blueprint = generatePlantUMLBlueprint(state.data, projectName);
      generatedBlueprintCode = blueprint;
      setBlueprintCode(blueprint);
      setBlueprintType('multilayer');
      setBlueprintReasoning('Using comprehensive 7-layer epic blueprint.');
    }
    setIsGeneratingBlueprint(false);

    // Generate Epic with blueprint included in Architecture Diagrams section
    const result = await runSkill('generate', {
      data: state.data,
      projectName,
      blueprintCode: generatedBlueprintCode,
    }) as GenerateResult;

    setState(prev => ({ ...prev, generatedEpic: result.epic }));
    setEditableEpic(result.epic);

    setActiveTab('epic');
    setIsGenerating(false);

    // Trigger confetti celebration!
    triggerConfetti();
    showToast('success', 'Epic Generated!', 'Your 17-section epic document is ready.');
  };

  // Reset and start over
  const resetWizard = () => {
    setState(initialState);
    setFormData({});
    setAlternatives({});
    setEditingRefined({});
    setEditableEpic('');
    setBlueprintCode('');
    setBlueprintType('');
    setBlueprintReasoning('');
    setActiveTab('wizard');
    // Clear loaded epic reference so publish creates new instead of updating
    setSelectedGitLabEpic(null);
    setEpicChildren({ epics: [], issues: [] });
  };

  // Check which sections will be populated
  const getPopulatedSections = () => {
    const populated = new Set<number>();
    STAGES.slice(0, state.currentStage + 1).forEach(stage => {
      const hasData = stage.fields.some(f => state.data[f.name]?.refined);
      if (hasData) {
        stage.populatesSections.forEach(s => populated.add(s));
      }
    });
    return populated;
  };

  const populatedSections = getPopulatedSections();

  // Render wizard stage
  const renderWizard = () => (
    <div style={styles.card}>
      {/* Help banner */}
      <div style={styles.helpBanner}>
        <span style={styles.helpIcon}>
          <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
            <path d="M8 1.5a6.5 6.5 0 100 13 6.5 6.5 0 000-13zM0 8a8 8 0 1116 0A8 8 0 010 8zm6.5-.25A.75.75 0 017.25 7h1a.75.75 0 01.75.75v2.75h.25a.75.75 0 010 1.5h-2a.75.75 0 010-1.5h.25v-2h-.25a.75.75 0 01-.75-.75zM8 6a1 1 0 100-2 1 1 0 000 2z"/>
          </svg>
        </span>
        <span style={styles.helpText}>
          <span style={{ fontWeight: '600', color: '#1F2937' }}>Two ways to get suggestions</span> — Type keywords then click <span style={{
            background: 'linear-gradient(145deg, #8B5CF6 0%, #7C3AED 100%)',
            color: '#ffffff',
            padding: '4px 10px',
            fontSize: '10px',
            fontWeight: 600,
            textTransform: 'uppercase' as const,
            letterSpacing: '0.5px',
            marginLeft: '6px',
            marginRight: '6px',
            borderRadius: '6px',
            boxShadow: '0 1px 3px rgba(139, 92, 246, 0.3)',
            display: 'inline-block',
            verticalAlign: 'middle',
          }}>Refine</span> for tailored content, or click <span style={{
            background: 'linear-gradient(145deg, #22C55E 0%, #16A34A 100%)',
            color: '#ffffff',
            padding: '4px 10px',
            fontSize: '10px',
            fontWeight: 600,
            textTransform: 'uppercase' as const,
            letterSpacing: '0.5px',
            marginLeft: '6px',
            marginRight: '6px',
            borderRadius: '6px',
            boxShadow: '0 1px 3px rgba(34, 197, 94, 0.3)',
            display: 'inline-block',
            verticalAlign: 'middle',
          }}>Auto</span> for AI-generated suggestions.
        </span>
      </div>

      <div style={styles.stageTitle}>
        Stage {state.currentStage + 1}: {currentStage.title}
      </div>
      <div style={styles.stageDesc}>{currentStage.description}</div>

      {currentStage.fields.map(field => {
        const hasRefined = state.data[field.name]?.refined;
        const isEditing = editingRefined[field.name];
        const isLoadingSuggestion = loadingSuggestion[field.name];
        const fieldAlternatives = alternatives[field.name];

        return (
          <div key={field.name} style={styles.fieldGroup}>
            {/* Label row with dual-mode suggest buttons */}
            <div style={styles.labelRow}>
              <label style={styles.label}>
                {field.label}
                {field.required && <span style={{ color: '#ef4444' }}> *</span>}
              </label>
              <div style={styles.suggestButtonGroup}>
                {/* With Context button - uses user's keywords */}
                <button
                  style={isLoadingSuggestion ? styles.suggestButtonLoading : styles.suggestButton}
                  onClick={() => handleGetSuggestion(field.name, 'with-context')}
                  disabled={isLoadingSuggestion || !formData[field.name]?.trim()}
                  title={formData[field.name]?.trim() ? 'Generate suggestion based on your keywords' : 'Type some keywords first'}
                >
                  {isLoadingSuggestion ? (
                    '...'
                  ) : (
                    <>
                      <svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor" style={{ marginRight: 4 }}>
                        <path d="M8 4a.5.5 0 01.5.5v3h3a.5.5 0 010 1h-3v3a.5.5 0 01-1 0v-3h-3a.5.5 0 010-1h3v-3A.5.5 0 018 4z"/>
                        <path d="M8 0a8 8 0 100 16A8 8 0 008 0zM1 8a7 7 0 1114 0A7 7 0 011 8z"/>
                      </svg>
                      Refine
                    </>
                  )}
                </button>
                {/* Auto suggest button - generates from scratch */}
                <button
                  style={isLoadingSuggestion ? styles.suggestButtonLoading : styles.suggestButtonAuto}
                  onClick={() => handleGetSuggestion(field.name, 'auto')}
                  disabled={isLoadingSuggestion}
                  title="Generate suggestion automatically from project context"
                >
                  {isLoadingSuggestion ? (
                    '...'
                  ) : (
                    <>
                      <svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor" style={{ marginRight: 4 }}>
                        <path d="M5.433 2.304A4.492 4.492 0 003.5 6c0 1.598.832 3.002 2.09 3.802.518.329.91.765 1.128 1.26H6.75a.75.75 0 000 1.5h2.5a.75.75 0 000-1.5h-.032c.218-.495.61-.931 1.128-1.26A4.492 4.492 0 0012.5 6a4.492 4.492 0 00-1.933-3.696.75.75 0 00-.838 1.243A2.993 2.993 0 0111 6c0 1.06-.55 1.993-1.38 2.527-.614.396-1.07.894-1.37 1.473h-.5c-.3-.579-.756-1.077-1.37-1.473A2.993 2.993 0 015 6c0-1.033.522-1.945 1.271-2.453a.75.75 0 00-.838-1.243z"/>
                        <path d="M7.25 13a.75.75 0 01.75-.75h.5a.75.75 0 010 1.5H8a.75.75 0 01-.75-.75zM7.25 15a.75.75 0 01.75-.75h.5a.75.75 0 010 1.5H8a.75.75 0 01-.75-.75z"/>
                      </svg>
                      Auto
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Input field */}
            {field.type === 'textarea' ? (
              <div style={{ position: 'relative' }}>
                <textarea
                  style={styles.textarea}
                  placeholder={field.placeholder}
                  value={formData[field.name] || ''}
                  onChange={(e) => handleFieldChange(field.name, e.target.value)}
                  className={typingField === field.name ? 'typewriter-text' : ''}
                />
                {typingField === field.name && (
                  <span className="typewriter-cursor" style={{ position: 'absolute', bottom: '12px', marginLeft: '-4px' }} />
                )}
              </div>
            ) : (
              <div style={{ position: 'relative' }}>
                <input
                  type="text"
                  style={styles.input}
                  placeholder={field.placeholder}
                  value={formData[field.name] || ''}
                  onChange={(e) => handleFieldChange(field.name, e.target.value)}
                  className={typingField === field.name ? 'typewriter-text' : ''}
                />
                {typingField === field.name && (
                  <span className="typewriter-cursor" style={{ position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)' }} />
                )}
              </div>
            )}

            {/* Alternative suggestions */}
            {fieldAlternatives && fieldAlternatives.length > 0 && (
              <div style={styles.alternativesSection}>
                <span style={{ fontSize: '11px', color: '#7c3aed', marginRight: '8px' }}>
                  Other ideas:
                </span>
                {fieldAlternatives.map((alt, idx) => (
                  <span
                    key={idx}
                    style={styles.alternativeChip}
                    onClick={() => handleUseAlternative(field.name, alt)}
                  >
                    {alt.length > 40 ? alt.slice(0, 40) + '...' : alt}
                  </span>
                ))}
              </div>
            )}

            {/* Refined content (editable) */}
            {hasRefined && (
              <div style={styles.refinedSection}>
                <div style={styles.refinedHeader}>
                  <span style={styles.refinedBadge}>
                    <span style={{ fontWeight: 'bold' }}>✓</span> AI Refined
                  </span>
                  <button
                    style={styles.editButton}
                    onClick={() => setEditingRefined(prev => ({ ...prev, [field.name]: !prev[field.name] }))}
                  >
                    {isEditing ? 'Done' : 'Edit'}
                  </button>
                </div>
                {isEditing ? (
                  <textarea
                    style={styles.refinedTextarea}
                    value={state.data[field.name].refined}
                    onChange={(e) => handleRefinedChange(field.name, e.target.value)}
                  />
                ) : (
                  <div style={styles.refinedPreview}>
                    {state.data[field.name].refined}
                  </div>
                )}
              </div>
            )}
          </div>
        );
      })}

      <div style={styles.buttonRow}>
        {state.currentStage > 0 && (
          <button style={styles.button(false)} onClick={prevStage}>
            ← Previous
          </button>
        )}
        <button
          style={{
            ...styles.button(true),
            background: isRefining
              ? 'linear-gradient(90deg, #FF4D4D 25%, #E60000 50%, #FF4D4D 75%)'
              : 'linear-gradient(145deg, #E60000 0%, #CC0000 50%, #B30000 100%)',
            backgroundSize: isRefining ? '200% 100%' : '100% 100%',
            animation: isRefining ? 'shimmer 1.5s ease-in-out infinite' : 'none',
            display: 'inline-flex',
            alignItems: 'center',
            gap: '8px',
            color: '#FFFFFF',
          }}
          onClick={nextStage}
          disabled={isRefining}
        >
          {isRefining ? 'Refining...' : isLastStage ? 'Generate Epic' : 'Next'}
        </button>
      </div>

      {/* Sections preview */}
      <div style={{ marginTop: '16px', paddingTop: '12px', borderTop: '1px solid #e0e0e0' }}>
        <div style={{ fontSize: '11px', fontWeight: '600', marginBottom: '6px', color: '#666', textTransform: 'uppercase' }}>
          Epic Sections:
        </div>
        <div style={styles.sectionPreview}>
          {EPIC_SECTIONS.map(section => (
            <div key={section.num} style={styles.sectionChip(populatedSections.has(section.num))}>
              {section.num}. {section.title}
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  // Regenerate blueprint with intelligent selection
  const regenerateBlueprint = async () => {
    const projectName = state.data['projectName']?.original || 'Untitled Project';
    setIsGeneratingBlueprint(true);
    setBlueprintReasoning('Analyzing epic content...');
    try {
      const blueprintResult = await generateIntelligentBlueprint(state.data, projectName);
      setBlueprintCode(blueprintResult.diagram);
      setBlueprintType(blueprintResult.type);
      setBlueprintReasoning(blueprintResult.reasoning);

      // Update the Epic with the new blueprint diagram
      if (editableEpic) {
        const result = await runSkill('generate', {
          data: state.data,
          projectName,
          blueprintCode: blueprintResult.diagram,
        }) as GenerateResult;
        setState(prev => ({ ...prev, generatedEpic: result.epic }));
        setEditableEpic(result.epic);
      }
    } catch (error) {
      console.error('Blueprint regeneration failed:', error);
      setBlueprintReasoning('Failed to regenerate. Using previous diagram.');
    } finally {
      setIsGeneratingBlueprint(false);
    }
  };

  // Handler for AI-assisted diagram fix when Mermaid rendering fails
  const handleRequestDiagramFix = async (failedCode: string, errorMessage: string): Promise<string | null> => {
    if (!isAIEnabled(config)) {
      return null;
    }

    try {
      const fixedCode = await fixMermaidDiagram(failedCode, errorMessage);
      if (fixedCode && fixedCode !== failedCode) {
        setBlueprintCode(fixedCode);
        showToast('success', 'Diagram Fixed', 'AI corrected the diagram syntax');
        return fixedCode;
      }
    } catch (err) {
      console.error('Failed to fix diagram with AI:', err);
      showToast('error', 'Fix Failed', 'AI could not fix the diagram');
    }
    return null;
  };

  // Export diagram as SVG file
  const exportAsSVG = () => {
    if (!blueprintSvg) {
      showToast('warning', 'No Diagram', 'Please generate a blueprint first');
      return;
    }
    const blob = new Blob([blueprintSvg], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `epic-blueprint-${Date.now()}.svg`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('success', 'SVG Exported', 'Blueprint saved as SVG file');
  };

  // Export diagram as PNG file
  const exportAsPNG = async () => {
    if (!blueprintSvg) {
      showToast('warning', 'No Diagram', 'Please generate a blueprint first');
      return;
    }

    try {
      // Create a canvas element
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        throw new Error('Canvas context not available');
      }

      // Create an image from the SVG
      const img = new Image();
      const svgBlob = new Blob([blueprintSvg], { type: 'image/svg+xml;charset=utf-8' });
      const url = URL.createObjectURL(svgBlob);

      await new Promise<void>((resolve, reject) => {
        img.onload = () => {
          // Scale up for better quality
          const scale = 2;
          canvas.width = img.width * scale;
          canvas.height = img.height * scale;

          // Fill with white background
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, canvas.width, canvas.height);

          // Draw the image scaled up
          ctx.scale(scale, scale);
          ctx.drawImage(img, 0, 0);

          // Convert to PNG and download
          canvas.toBlob((blob) => {
            if (blob) {
              const pngUrl = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = pngUrl;
              a.download = `epic-blueprint-${Date.now()}.png`;
              document.body.appendChild(a);
              a.click();
              document.body.removeChild(a);
              URL.revokeObjectURL(pngUrl);
              showToast('success', 'PNG Exported', 'Blueprint saved as PNG file');
              resolve();
            } else {
              reject(new Error('Failed to create PNG blob'));
            }
          }, 'image/png');

          URL.revokeObjectURL(url);
        };
        img.onerror = () => {
          URL.revokeObjectURL(url);
          reject(new Error('Failed to load SVG image'));
        };
        img.src = url;
      });
    } catch (err) {
      console.error('PNG export error:', err);
      showToast('error', 'Export Failed', 'Could not export as PNG');
    }
  };

  // ========== GITLAB EPIC MANAGEMENT HANDLERS ==========

  // Fetch GitLab epics with current filters
  const handleFetchGitLabEpics = async (resetPage = true) => {
    // Skip config check if using mock mode
    if (!shouldUseMockGitLab() && (!config.gitlab.enabled || !config.gitlab.rootGroupId)) {
      showToast('warning', 'GitLab Not Configured', 'Enable GitLab and set Group ID first');
      return;
    }

    setLoadingGitLabEpics(true);

    const searchParams: GitLabEpicSearchParams = {
      search: epicSearchTerm || undefined,
      labels: epicFilterLabels.length > 0 ? epicFilterLabels : undefined,
      state: epicFilterState,
      order_by: 'updated_at',
      sort: 'desc',
      per_page: 20,
      page: resetPage ? 1 : epicPage,
      include_descendant_groups: true
    };

    // Use mock or real API based on toggle
    const result = shouldUseMockGitLab()
      ? await mockFetchGroupEpics(config.gitlab, searchParams)
      : await fetchGroupEpics(config.gitlab, searchParams);

    if (result.success && result.data) {
      setGitlabEpics(result.data);
      setGitlabEpicsTotalCount(result.totalCount || 0);
      if (resetPage) setEpicPage(1);
      showToast('success', 'Epics Loaded', `Found ${result.data.length} epics`);
    } else {
      showToast('error', 'Failed to Load Epics', result.error || 'Unknown error');
    }

    setLoadingGitLabEpics(false);
  };

  // View epic details
  const handleViewEpicDetails = async (epicIid: number) => {
    setLoadingEpicDetails(true);
    setEpicEditorMode('view');

    // Use mock or real API based on toggle
    const [detailsResult, childrenResult] = shouldUseMockGitLab()
      ? await Promise.all([
          mockFetchEpicDetails(config.gitlab, epicIid),
          mockFetchEpicChildren(config.gitlab, epicIid)
        ])
      : await Promise.all([
          fetchEpicDetails(config.gitlab, epicIid),
          fetchEpicChildren(config.gitlab, epicIid)
        ]);

    if (detailsResult.success && detailsResult.data) {
      setSelectedGitLabEpic(detailsResult.data);

      if (childrenResult.success) {
        setEpicChildren({
          epics: childrenResult.epics || [],
          issues: childrenResult.issues || []
        });
      }

      showToast('info', 'Epic Loaded', detailsResult.data.title);
    } else {
      showToast('error', 'Failed to Load Epic', detailsResult.error || 'Unknown error');
      setEpicEditorMode('browse');
    }

    setLoadingEpicDetails(false);
  };

  // Publish generated epic as GitLab epic
  const handlePublishAsGitLabEpic = async () => {
    // Skip config check if using mock mode
    if (!shouldUseMockGitLab() && (!config.gitlab.enabled || !config.gitlab.rootGroupId)) {
      showToast('error', 'GitLab Not Configured', 'Enable GitLab first');
      return;
    }

    const projectName = state.data['projectName']?.original || 'Untitled Epic';

    // Determine level label
    const levelLabel = publishAsEpicLevel === 'crew'
      ? `crew::${projectName.toLowerCase().replace(/\s+/g, '-')}`
      : `pod::${projectName.toLowerCase().replace(/\s+/g, '-')}`;

    const params = {
      title: projectName,
      description: editableEpic,
      labels: [levelLabel, 'epic-generator'],
      parent_id: publishAsEpicParentId || undefined
    };

    setIsPublishing(true);
    // Use mock or real API based on toggle
    const result = shouldUseMockGitLab()
      ? await mockCreateGitLabEpic(config.gitlab, params)
      : await createGitLabEpic(config.gitlab, params);
    setIsPublishing(false);

    if (result.success && result.data) {
      showToast('success', 'Epic Created!', `View at: ${result.data.web_url}`);
      setPublishStatus({
        type: 'success',
        message: `Epic created successfully! View at: ${result.data.web_url}`
      });
      setShowPublishAsEpicModal(false);

      // Refresh epic list
      handleFetchGitLabEpics();
    } else {
      showToast('error', 'Failed to Create Epic', result.error || 'Unknown error');
      setPublishStatus({ type: 'error', message: result.error || 'Failed to create epic' });
    }
  };

  // Update an existing GitLab epic
  const handleUpdateGitLabEpic = async () => {
    if (!selectedGitLabEpic) return;

    // Extract title from the first heading in editableEpic, or use original title
    const firstLine = editableEpic.split('\n')[0];
    const titleMatch = firstLine.match(/^#\s+(.+)$/);
    const newTitle = titleMatch ? titleMatch[1].trim() : selectedGitLabEpic.title;

    const params = {
      title: newTitle,
      description: editableEpic  // Use the edited content, not the original
    };

    setIsPublishing(true);
    // Use mock or real API based on toggle
    const result = shouldUseMockGitLab()
      ? await mockUpdateGitLabEpic(config.gitlab, selectedGitLabEpic.iid, params)
      : await updateGitLabEpic(config.gitlab, selectedGitLabEpic.iid, params);
    setIsPublishing(false);

    if (result.success && result.data) {
      setSelectedGitLabEpic(result.data);
      showToast('success', 'Epic Updated!', `Epic #${selectedGitLabEpic.iid} saved to GitLab`);
      setShowPublishAsEpicModal(false);
      handleFetchGitLabEpics(false);
    } else {
      showToast('error', 'Update Failed', result.error || 'Unknown error');
    }
  };

  // Fetch available labels
  const handleFetchLabels = async () => {
    // Use mock or real API based on toggle
    const result = shouldUseMockGitLab()
      ? await mockFetchGroupLabels(config.gitlab)
      : await fetchGroupLabels(config.gitlab);
    if (result.success && result.data) {
      setAvailableLabels(result.data);
    }
  };

  // ============================================
  // AI REFINEMENT HANDLER
  // ============================================
  const handleAIRefine = async () => {
    if (!editableEpic.trim()) {
      showToast('warning', 'No Content', 'Load or generate an epic first');
      return;
    }

    if (!isAIEnabled(config)) {
      showToast('error', 'AI Not Configured', 'Enable AI in Settings first');
      return;
    }

    setRefinementState(prev => ({
      ...prev,
      isRefining: true,
      progress: { current: 0, total: 17, section: 'Analyzing...' }
    }));

    try {
      // Simulate progress updates
      const sections = EPIC_SECTIONS.map(s => s.title);
      for (let i = 0; i < sections.length; i++) {
        setRefinementState(prev => ({
          ...prev,
          progress: { current: i + 1, total: 17, section: sections[i] }
        }));
        await new Promise(resolve => setTimeout(resolve, 50)); // Brief delay for visual feedback
      }

      const report = await analyzeAndRefineEpic(editableEpic);

      setRefinementState({
        isRefining: false,
        progress: { current: 17, total: 17, section: 'Complete' },
        report,
        showReport: true,
      });
      setLastRefinementScore(report.overallScore);

      // Show toast based on score
      if (report.overallScore >= 8) {
        showToast('success', 'Great Epic!', `Score: ${report.overallScore.toFixed(1)}/10`);
      } else if (report.overallScore >= 5) {
        showToast('info', 'Room for Improvement', `Score: ${report.overallScore.toFixed(1)}/10`);
      } else {
        showToast('warning', 'Needs Work', `Score: ${report.overallScore.toFixed(1)}/10`);
      }
    } catch (error) {
      showToast('error', 'Refinement Failed', error instanceof Error ? error.message : 'Unknown error');
      setRefinementState(prev => ({ ...prev, isRefining: false }));
    }
  };

  // Apply AI suggestions to improve weak sections
  const handleApplySuggestions = async () => {
    if (!refinementState.report) return;

    const weakSections = refinementState.report.sections.filter(
      s => s.status === 'weak' || s.status === 'missing'
    );

    if (weakSections.length === 0) {
      showToast('info', 'No Weak Sections', 'All sections are already adequate or better');
      return;
    }

    // Store original score for comparison
    const originalScore = refinementState.report.overallScore;

    // Phase 1: Start applying suggestions
    setIsApplyingSuggestions(true);
    setApplySuggestionsProgress({ current: 0, total: weakSections.length, phase: 'applying' });

    let updatedEpic = editableEpic;

    for (let i = 0; i < weakSections.length; i++) {
      const section = weakSections[i];
      setApplySuggestionsProgress({
        current: i + 1,
        total: weakSections.length,
        phase: 'applying'
      });

      try {
        const improved = await generateSectionImprovement(
          section.sectionNum,
          extractSectionContent(editableEpic, section.sectionNum),
          section.issues,
          editableEpic
        );

        // Replace section in epic
        updatedEpic = replaceSectionInEpic(updatedEpic, section.sectionNum, improved);
      } catch (error) {
        console.error(`Failed to improve section ${section.sectionNum}:`, error);
      }
    }

    // Update epic in editor
    setEditableEpic(updatedEpic);

    // Phase 2: Re-run critique to get updated scores
    setApplySuggestionsProgress({ current: 0, total: 0, phase: 'reanalyzing' });

    try {
      const newReport = await analyzeAndRefineEpic(updatedEpic);

      // Update the report in state (keep modal open)
      setRefinementState(prev => ({
        ...prev,
        report: newReport,
        // showReport stays true - don't close modal
      }));

      // Show score improvement toast
      const scoreDiff = newReport.overallScore - originalScore;
      if (scoreDiff > 0) {
        showToast('success', 'Score Improved!',
          `${originalScore.toFixed(1)} → ${newReport.overallScore.toFixed(1)} (+${scoreDiff.toFixed(1)})`);
      } else {
        showToast('success', 'Improvements Applied', 'Critique report updated with new scores');
      }
    } catch (error) {
      console.error('Failed to re-analyze epic:', error);
      showToast('error', 'Analysis Failed', 'Improvements applied but could not update critique');
      setRefinementState(prev => ({ ...prev, showReport: false }));
    } finally {
      setIsApplyingSuggestions(false);
      setApplySuggestionsProgress({ current: 0, total: 0, phase: 'idle' });
    }
  };

  // Helper: Extract content for a specific section
  const extractSectionContent = (epic: string, sectionNum: number): string => {
    const section = EPIC_SECTIONS.find(s => s.num === sectionNum);
    if (!section) return '';

    const escapedTitle = section.title.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(
      `##\\s*${sectionNum}\\.\\s*${escapedTitle}[\\s\\S]*?(?=##\\s*\\d+\\.|$)`,
      'i'
    );
    const match = epic.match(regex);
    return match ? match[0] : '';
  };

  // Helper: Replace section content in epic
  const replaceSectionInEpic = (epic: string, sectionNum: number, newContent: string): string => {
    const section = EPIC_SECTIONS.find(s => s.num === sectionNum);
    if (!section) return epic;

    const escapedTitle = section.title.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(
      `(##\\s*${sectionNum}\\.\\s*${escapedTitle}[\\s\\S]*?)(?=##\\s*\\d+\\.|$)`,
      'i'
    );

    return epic.replace(regex, newContent + '\n\n');
  };

  // ============================================
  // SMART REFINE HANDLER
  // ============================================
  const handleSmartRefine = async () => {
    if (!editableEpic.trim()) {
      showToast('warning', 'No Epic', 'Load an epic first');
      return;
    }

    setIsSmartRefining(true);
    setAutoGeneratedFields([]);
    setSmartRefineReview(null);

    try {
      // Step 1: Parse epic back to stage fields
      const { data, missingFields, projectName } = parseEpicToStageData(editableEpic);

      // Step 2: Build context from existing data
      const buildContext = (currentData: typeof data): Record<string, string> => {
        const context: Record<string, string> = {};
        for (const [key, value] of Object.entries(currentData)) {
          if (value?.refined || value?.original) {
            context[key] = value.refined || value.original;
          }
        }
        return context;
      };

      // Step 3: Process each field - REFINE if has content, AUTO if empty
      const refinedData: typeof data = {};
      const autoGenerated: string[] = [];
      const allFields = STAGES.flatMap(s => s.fields);
      const totalFields = allFields.length;
      let currentFieldIndex = 0;

      for (const stage of STAGES) {
        for (const field of stage.fields) {
          currentFieldIndex++;
          setSmartRefineProgress({
            stage: stage.title,
            field: field.label,
            current: currentFieldIndex,
            total: totalFields
          });

          const originalContent = data[field.name]?.original || '';
          const context = buildContext(refinedData);

          if (originalContent.trim()) {
            // HAS CONTENT → Use REFINE (enhance existing)
            const result = await runSkill('refine', {
              stageId: stage.id,
              fieldName: field.name,
              input: originalContent,
              context
            }) as RefineResult;

            refinedData[field.name] = {
              original: originalContent,
              refined: result.refined,
              diagramNode: result.diagramNode
            };
          } else {
            // EMPTY → Use AUTO (generate from context)
            const suggestion = await getSuggestion(stage.id, field.name, context, 'auto');

            refinedData[field.name] = {
              original: suggestion.suggestion,  // Auto-generated becomes the "original"
              refined: suggestion.suggestion,
              diagramNode: `${field.name}["${field.label}"]`
            };

            autoGenerated.push(field.label);  // Track as AI-generated
          }
        }
      }

      setAutoGeneratedFields(autoGenerated);

      // Step 4: Generate Blueprint first (so it can be included in Epic)
      setSmartRefineProgress({
        stage: 'Blueprint',
        field: 'Generating Diagram',
        current: totalFields,
        total: totalFields + 2  // +2 for blueprint and epic generation
      });

      let generatedBlueprintCode = '';
      try {
        const blueprintResult = await generateIntelligentBlueprint(refinedData, projectName);
        if (blueprintResult.diagram) {
          generatedBlueprintCode = blueprintResult.diagram;
          setBlueprintCode(blueprintResult.diagram);
          setBlueprintType(blueprintResult.type);
          setBlueprintReasoning(blueprintResult.reasoning);
        } else {
          // AI returned empty diagram, use fallback
          console.warn('AI returned empty diagram, using fallback');
          const fallbackBlueprint = generatePlantUMLBlueprint(refinedData, projectName);
          generatedBlueprintCode = fallbackBlueprint;
          setBlueprintCode(fallbackBlueprint);
          setBlueprintType('multilayer');
          setBlueprintReasoning('Using comprehensive 7-layer epic blueprint.');
        }
      } catch (blueprintError) {
        // Fallback to legacy blueprint if intelligent generation fails
        console.error('Blueprint generation failed, using legacy:', blueprintError);
        const blueprint = generatePlantUMLBlueprint(refinedData, projectName);
        generatedBlueprintCode = blueprint;
        setBlueprintCode(blueprint);
        setBlueprintType('multilayer');
        setBlueprintReasoning('Using comprehensive 7-layer epic blueprint.');
      }

      // Step 5: Regenerate complete epic with blueprint included
      setSmartRefineProgress({
        stage: 'Generating',
        field: 'Complete Epic',
        current: totalFields + 1,
        total: totalFields + 2
      });

      const result = await runSkill('generate', {
        data: refinedData,
        projectName,
        blueprintCode: generatedBlueprintCode,
      }) as GenerateResult;

      // Step 6: Update editor with improved epic
      setEditableEpic(result.epic);
      // Also set state.generatedEpic and state.data to enable Blueprint tab and ensure regenerateBlueprint works
      setState(prev => ({
        ...prev,
        generatedEpic: result.epic,
        data: refinedData  // Update state.data so regenerateBlueprint uses the refined data
      }));

      // Step 7: AI Critique Review of generated content
      setSmartRefineProgress({
        stage: 'Reviewing',
        field: 'Quality Check',
        current: totalFields + 2,
        total: totalFields + 2
      });

      const review = await analyzeAndRefineEpic(result.epic);
      setSmartRefineReview(review);
      setLastRefinementScore(review.overallScore);

      // Step 8: Show summary toast
      const lowQualitySections = review.sections.filter(s => s.score < 5).length;

      if (autoGenerated.length > 0 || lowQualitySections > 0) {
        showToast('warning', 'Review Required',
          `${autoGenerated.length} AI-generated, ${lowQualitySections} need attention`
        );
      } else {
        showToast('success', 'Epic Complete', `Quality Score: ${review.overallScore.toFixed(1)}/10`);
      }

    } catch (error) {
      showToast('error', 'Refine Failed', error instanceof Error ? error.message : 'Unknown error');
    } finally {
      setIsSmartRefining(false);
      setSmartRefineProgress({ stage: '', field: '', current: 0, total: 0 });
    }
  };

  // Load labels when GitLab is enabled OR when mock mode is active
  useEffect(() => {
    if (shouldUseMockGitLab() || (config.gitlab.enabled && config.gitlab.rootGroupId && config.gitlab.accessToken)) {
      handleFetchLabels();
      // Also auto-load epics in mock mode (only once)
      if (shouldUseMockGitLab() && !hasAutoLoadedEpicsRef.current) {
        hasAutoLoadedEpicsRef.current = true;
        handleFetchGitLabEpics();
      }
    }
  }, [config.gitlab.enabled, config.gitlab.rootGroupId, config.gitlab.accessToken]);

  // ========== LOAD EPIC HANDLERS ==========

  // Search epics for loading into editor
  const handleSearchEpicsForLoad = async () => {
    // Skip config check if using mock mode
    if (!shouldUseMockGitLab() && (!config.gitlab.enabled || !config.gitlab.rootGroupId)) {
      showToast('warning', 'GitLab Not Configured', 'Enable GitLab first');
      return;
    }

    setLoadingLoadEpicResults(true);

    const searchParams: GitLabEpicSearchParams = {
      search: loadEpicSearchTerm || undefined,
      state: loadEpicFilterState,
      order_by: 'updated_at',
      sort: 'desc',
      per_page: 20,
      include_descendant_groups: true
    };

    // Use mock or real API based on toggle
    const result = shouldUseMockGitLab()
      ? await mockFetchGroupEpics(config.gitlab, searchParams)
      : await fetchGroupEpics(config.gitlab, searchParams);

    if (result.success && result.data) {
      setLoadEpicResults(result.data);
      showToast('success', 'Epics Found', `Found ${result.data.length} epics`);
    } else {
      showToast('error', 'Search Failed', result.error || 'Unknown error');
    }

    setLoadingLoadEpicResults(false);
  };

  // Load selected epic into editor
  const handleLoadEpicIntoEditor = async (epicIid: number) => {
    setLoadingLoadEpicResults(true);

    try {
      // Step 1: Fetch epic details
      const result = shouldUseMockGitLab()
        ? await mockFetchEpicDetails(config.gitlab, epicIid)
        : await fetchEpicDetails(config.gitlab, epicIid);

      if (result.success && result.data) {
        setEditableEpic(result.data.description || '');
        setSelectedGitLabEpic(result.data);

        // Clear previous reports/reviews when loading new epic
        setRefinementState({
          isRefining: false,
          progress: { current: 0, total: 17, section: '' },
          report: null,
          showReport: false
        });
        setLastRefinementScore(null);
        setSmartRefineReview(null);
        setAutoGeneratedFields([]);

        // Step 2: Fetch child items (epics and issues)
        const childrenResult = shouldUseMockGitLab()
          ? await mockFetchEpicChildren(config.gitlab, epicIid)
          : await fetchEpicChildren(config.gitlab, epicIid);

        if (childrenResult.success) {
          setEpicChildren({
            epics: childrenResult.epics || [],
            issues: childrenResult.issues || []
          });
        } else {
          setEpicChildren({ epics: [], issues: [] });
        }

        setShowLoadEpicModal(false);
        setActiveTab('epic');

        const childCount = (childrenResult.epics?.length || 0) + (childrenResult.issues?.length || 0);
        const childInfo = childCount > 0 ? ` with ${childrenResult.epics?.length || 0} child epics and ${childrenResult.issues?.length || 0} issues` : '';
        showToast('success', 'Epic Loaded', `Loaded: ${result.data.title}${childInfo}`);
      } else {
        showToast('error', 'Failed to Load', result.error || 'Unknown error');
      }
    } catch (error) {
      showToast('error', 'Failed to Load', error instanceof Error ? error.message : 'Unknown error');
    } finally {
      setLoadingLoadEpicResults(false);
    }
  };

  // Render Mermaid Blueprint view
  const renderBlueprint = () => (
    <div>
      {/* Action bar */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={styles.stageTitle}>Epic Blueprint</div>
            {blueprintType && (
              <span style={{
                padding: '4px 12px',
                backgroundColor: 'rgba(230, 0, 0, 0.08)',  // UBS Red subtle background
                color: '#E60000',  // UBS Red text
                borderRadius: '4px',  // Swiss precision corners
                fontSize: '11px',
                fontWeight: '600',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
                border: '1px solid rgba(230, 0, 0, 0.15)',
              }}>
                {blueprintType.replace('-', ' ')}
              </span>
            )}
          </div>
          <div style={{ color: '#666', fontSize: '13px', marginTop: '4px' }}>
            {blueprintReasoning || 'Intelligent Mermaid diagram based on your epic content'}
          </div>
        </div>
        <div style={{ display: 'flex', gap: '8px', flexWrap: 'nowrap', alignItems: 'center' }}>
          <button
            style={{
              ...styles.button(true),
              height: '40px',
              minWidth: '110px',
              padding: '0 16px',
              whiteSpace: 'nowrap',
              fontSize: '13px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              background: isGeneratingBlueprint
                ? 'linear-gradient(90deg, #FF4D4D 25%, #E60000 50%, #FF4D4D 75%)'  // UBS Red shimmer
                : 'linear-gradient(145deg, #E60000 0%, #CC0000 50%, #B30000 100%)',  // Official UBS Red
              backgroundSize: isGeneratingBlueprint ? '200% 100%' : '100% 100%',
              animation: isGeneratingBlueprint ? 'shimmer 1.5s ease-in-out infinite' : 'none',
            }}
            onClick={regenerateBlueprint}
            disabled={isGeneratingBlueprint}
            title="Re-analyze the epic and generate the best diagram type"
          >
            {isGeneratingBlueprint ? 'Analyzing...' : 'Regenerate'}
          </button>
          <button
            style={{
              ...styles.button(false),
              height: '40px',
              minWidth: '80px',
              padding: '0 16px',
              whiteSpace: 'nowrap',
              fontSize: '13px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
            onClick={() => {
              navigator.clipboard.writeText(blueprintCode);
              showToast('success', 'Copied!', 'Mermaid code copied to clipboard');
            }}
            title="Copy Mermaid code to clipboard"
          >
            Copy
          </button>
          <button
            style={{
              ...styles.button(false),
              height: '40px',
              minWidth: '100px',
              padding: '0 16px',
              whiteSpace: 'nowrap',
              fontSize: '13px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
            onClick={() => {
              const blob = new Blob([blueprintCode], { type: 'text/plain' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'epic-blueprint.mmd';
              a.click();
              URL.revokeObjectURL(url);
              showToast('success', 'Downloaded!', 'Blueprint saved as epic-blueprint.mmd');
            }}
            title="Download as .mmd file"
          >
            Download
          </button>
          <button
            style={{
              ...styles.button(false),
              height: '40px',
              minWidth: '90px',
              padding: '0 16px',
              whiteSpace: 'nowrap',
              fontSize: '13px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '6px',
            }}
            onClick={() => {
              // Open Mermaid Live Editor with the code
              const encoded = btoa(blueprintCode);
              window.open(`https://mermaid.live/edit#base64:${encoded}`, '_blank');
            }}
            title="Open in Mermaid Live Editor"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14L21 3"/>
            </svg>
            Editor
          </button>
          <div style={{ width: '1px', height: '24px', backgroundColor: '#d1d5db', flexShrink: 0 }} />
          <button
            style={{
              ...styles.button(false),
              height: '40px',
              minWidth: '70px',
              padding: '0 16px',
              whiteSpace: 'nowrap',
              fontSize: '13px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '6px',
            }}
            onClick={exportAsSVG}
            disabled={!blueprintSvg}
            title="Export diagram as SVG"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>
            </svg>
            SVG
          </button>
          <button
            style={{
              ...styles.button(false),
              height: '40px',
              minWidth: '70px',
              padding: '0 16px',
              whiteSpace: 'nowrap',
              fontSize: '13px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '6px',
            }}
            onClick={exportAsPNG}
            disabled={!blueprintSvg}
            title="Export diagram as PNG"
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>
            </svg>
            PNG
          </button>
        </div>
      </div>

      {/* Blueprint content - Full width diagram view */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
        {/* Live Diagram Preview */}
        <div style={{
          border: '1px solid #d0d7de',
          borderRadius: '8px',
          backgroundColor: 'white',
          overflow: 'hidden',
        }}>
          <div style={{
            ...styles.paneHeader,
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}>
            <div>
              <span>Live Blueprint Diagram</span>
              <span style={{ fontSize: '12px', color: '#666', marginLeft: '8px' }}>Rendered locally with Mermaid.js</span>
            </div>
            {/* Zoom Controls - Free Slider */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <span style={{ fontSize: '12px', color: '#6b7280' }}>10%</span>
              <input
                type="range"
                min={10}
                max={400}
                step={5}
                value={blueprintZoom}
                onChange={(e) => setBlueprintZoom(parseInt(e.target.value))}
                style={{
                  width: '160px',
                  cursor: 'pointer',
                  accentColor: '#E60000',  // UBS Red accent
                }}
                title={`Zoom: ${blueprintZoom}%`}
              />
              <span style={{ fontSize: '12px', color: '#6b7280' }}>400%</span>
              <div style={{
                minWidth: '50px',
                textAlign: 'center',
                fontSize: '13px',
                fontWeight: '500',
                color: '#374151',
                padding: '4px 8px',
                backgroundColor: '#f3f4f6',
                borderRadius: '4px',
              }}>
                {blueprintZoom}%
              </div>
              <button
                onClick={() => setBlueprintZoom(100)}
                style={{
                  padding: '4px 10px',
                  borderRadius: '6px',
                  border: '1px solid #d1d5db',
                  background: blueprintZoom === 100 ? '#e5e7eb' : 'white',
                  cursor: 'pointer',
                  fontSize: '12px',
                  color: '#374151',
                }}
                title="Reset to 100%"
              >
                Reset
              </button>
              <div style={{ width: '1px', height: '20px', backgroundColor: '#d1d5db', margin: '0 4px' }} />
              <button
                onClick={() => setBlueprintFullscreen(true)}
                style={{
                  width: '28px',
                  height: '28px',
                  borderRadius: '6px',
                  border: '1px solid #d1d5db',
                  background: 'white',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: '#374151',
                }}
                title="Fullscreen"
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z"/>
                </svg>
              </button>
            </div>
          </div>
          <div style={{
            padding: '20px',
            backgroundColor: '#fafafa',
            minHeight: '500px',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'flex-start',
            overflow: 'auto',
          }}>
            <MermaidBlueprint code={blueprintCode} zoom={blueprintZoom} onRequestFix={isAIEnabled(config) ? handleRequestDiagramFix : undefined} onSvgReady={setBlueprintSvg} />
          </div>
        </div>

        {/* Fullscreen Overlay */}
        {blueprintFullscreen && (
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(255, 255, 255, 0.98)',
            zIndex: 9999,
            display: 'flex',
            flexDirection: 'column',
            overflow: 'hidden',
          }}>
            {/* Fullscreen Header */}
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              padding: '16px 24px',
              borderBottom: '1px solid #e5e7eb',
              backgroundColor: 'white',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <span style={{ fontWeight: '600', fontSize: '16px' }}>Blueprint Diagram</span>
                {blueprintType && (
                  <span style={{
                    padding: '4px 12px',
                    backgroundColor: 'rgba(230, 0, 0, 0.08)',  // UBS Red subtle background
                    color: '#E60000',  // UBS Red text
                    borderRadius: '4px',  // Swiss precision corners
                    fontSize: '11px',
                    fontWeight: '600',
                    textTransform: 'uppercase',
                    letterSpacing: '0.05em',
                    border: '1px solid rgba(230, 0, 0, 0.15)',
                  }}>
                    {blueprintType.replace('-', ' ')}
                  </span>
                )}
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                {/* Zoom Controls in Fullscreen - Free Slider */}
                <span style={{ fontSize: '13px', color: '#6b7280' }}>10%</span>
                <input
                  type="range"
                  min={10}
                  max={400}
                  step={5}
                  value={blueprintZoom}
                  onChange={(e) => setBlueprintZoom(parseInt(e.target.value))}
                  style={{
                    width: '180px',
                    cursor: 'pointer',
                    accentColor: '#E60000',  // UBS Red accent
                  }}
                  title={`Zoom: ${blueprintZoom}%`}
                />
                <span style={{ fontSize: '13px', color: '#6b7280' }}>400%</span>
                <div style={{
                  minWidth: '60px',
                  textAlign: 'center',
                  fontSize: '14px',
                  fontWeight: '500',
                  color: '#374151',
                  padding: '6px 12px',
                  backgroundColor: '#f3f4f6',
                  borderRadius: '6px',
                }}>
                  {blueprintZoom}%
                </div>
                <button
                  onClick={() => setBlueprintZoom(100)}
                  style={{
                    padding: '6px 14px',
                    borderRadius: '6px',
                    border: '1px solid #d1d5db',
                    background: blueprintZoom === 100 ? '#e5e7eb' : 'white',
                    cursor: 'pointer',
                    fontSize: '13px',
                    color: '#374151',
                  }}
                  title="Reset to 100%"
                >
                  Reset
                </button>
                <div style={{ width: '1px', height: '24px', backgroundColor: '#d1d5db', margin: '0 8px' }} />
                <button
                  onClick={() => setBlueprintFullscreen(false)}
                  style={{
                    padding: '8px 16px',
                    borderRadius: '6px',
                    border: 'none',
                    background: 'linear-gradient(145deg, #E60000 0%, #CC0000 50%, #B30000 100%)',  // UBS Red
                    cursor: 'pointer',
                    fontSize: '13px',
                    fontWeight: '500',
                    color: 'white',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '6px',
                  }}
                  title="Exit Fullscreen"
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M5 16h3v3h2v-5H5v2zm3-8H5v2h5V5H8v3zm6 11h2v-3h3v-2h-5v5zm2-11V5h-2v5h5V8h-3z"/>
                  </svg>
                  Exit Fullscreen
                </button>
              </div>
            </div>
            {/* Fullscreen Diagram Area */}
            <div style={{
              flex: 1,
              overflow: 'auto',
              padding: '40px',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'flex-start',
              backgroundColor: '#fafafa',
            }}>
              <MermaidBlueprint code={blueprintCode} zoom={blueprintZoom} onRequestFix={isAIEnabled(config) ? handleRequestDiagramFix : undefined} onSvgReady={setBlueprintSvg} />
            </div>
          </div>
        )}

        {/* Split: Code editor and Legend */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
          {/* Code pane */}
          <div style={styles.editorPane}>
            <div style={styles.paneHeader}>
              <span>Mermaid Code (Editable)</span>
              <span style={{ fontSize: '12px', color: '#666' }}>
                {blueprintCode.split('\n').length} lines
              </span>
            </div>
            <textarea
              style={{ ...styles.editor, height: '400px' }}
              value={blueprintCode}
              onChange={(e) => setBlueprintCode(e.target.value)}
              spellCheck={false}
            />
          </div>

          {/* Legend pane */}
          <div style={styles.previewPane}>
            <div style={styles.paneHeader}>
              <span>Diagram Guide</span>
            </div>
            <div style={{ padding: '16px', overflow: 'auto', height: '355px' }}>
              {/* Dynamic info based on diagram type */}
              <div style={{ marginBottom: '16px' }}>
                <h3 style={{ fontSize: '14px', fontWeight: '600', marginBottom: '10px' }}>
                  {blueprintType === 'c4-container' ? 'C4 Container Diagram' :
                   blueprintType === 'sequence' ? 'Sequence Diagram' :
                   blueprintType === 'deployment' ? 'Deployment Diagram' :
                   blueprintType === 'component' ? 'Component Diagram' :
                   '7-Layer Epic Architecture'}
                </h3>

                {blueprintType === 'c4-container' && (
                  <div style={{ display: 'grid', gap: '6px' }}>
                    {[
                      { color: '#438DD5', name: 'Person', desc: 'Users of the system' },
                      { color: '#85BBF0', name: 'Container', desc: 'Deployable units (apps, services)' },
                      { color: '#438DD5', name: 'Database', desc: 'Data storage systems' },
                      { color: '#999999', name: 'External', desc: 'Third-party systems' },
                    ].map((item, i) => (
                      <div key={i} style={{
                        padding: '8px 10px', backgroundColor: `${item.color}20`,
                        borderRadius: '6px', border: `1px solid ${item.color}40`,
                        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                      }}>
                        <div style={{ fontWeight: '600', fontSize: '12px' }}>{item.name}</div>
                        <div style={{ fontSize: '11px', color: '#666' }}>{item.desc}</div>
                      </div>
                    ))}
                  </div>
                )}

                {blueprintType === 'sequence' && (
                  <div style={{ display: 'grid', gap: '6px' }}>
                    {[
                      { color: '#10b981', name: 'Actor', desc: 'User initiating actions' },
                      { color: '#3b82f6', name: 'Participant', desc: 'System components' },
                      { color: '#8b5cf6', name: 'Activate/Deactivate', desc: 'Processing time' },
                      { color: '#f59e0b', name: 'Messages', desc: 'Requests and responses' },
                    ].map((item, i) => (
                      <div key={i} style={{
                        padding: '8px 10px', backgroundColor: `${item.color}20`,
                        borderRadius: '6px', border: `1px solid ${item.color}40`,
                        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                      }}>
                        <div style={{ fontWeight: '600', fontSize: '12px' }}>{item.name}</div>
                        <div style={{ fontSize: '11px', color: '#666' }}>{item.desc}</div>
                      </div>
                    ))}
                  </div>
                )}

                {blueprintType === 'deployment' && (
                  <div style={{ display: 'grid', gap: '6px' }}>
                    {[
                      { color: '#E3F2FD', name: 'Node', desc: 'Physical/virtual machines' },
                      { color: '#E8F5E9', name: 'Component', desc: 'Deployed applications' },
                      { color: '#FFF3E0', name: 'Database', desc: 'Data storage' },
                      { color: '#F3E5F5', name: 'CI/CD', desc: 'Build and deploy pipeline' },
                    ].map((item, i) => (
                      <div key={i} style={{
                        padding: '8px 10px', backgroundColor: item.color,
                        borderRadius: '6px', border: '1px solid rgba(0,0,0,0.1)',
                        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                      }}>
                        <div style={{ fontWeight: '600', fontSize: '12px' }}>{item.name}</div>
                        <div style={{ fontSize: '11px', color: '#666' }}>{item.desc}</div>
                      </div>
                    ))}
                  </div>
                )}

                {blueprintType === 'component' && (
                  <div style={{ display: 'grid', gap: '6px' }}>
                    {[
                      { color: '#dbeafe', name: 'Package', desc: 'Logical grouping of components' },
                      { color: '#dcfce7', name: 'Component', desc: 'Functional unit' },
                      { color: '#fef3c7', name: 'Interface', desc: 'Connection points' },
                      { color: '#f3e8ff', name: 'Database', desc: 'Data persistence' },
                    ].map((item, i) => (
                      <div key={i} style={{
                        padding: '8px 10px', backgroundColor: item.color,
                        borderRadius: '6px', border: '1px solid rgba(0,0,0,0.1)',
                        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                      }}>
                        <div style={{ fontWeight: '600', fontSize: '12px' }}>{item.name}</div>
                        <div style={{ fontSize: '11px', color: '#666' }}>{item.desc}</div>
                      </div>
                    ))}
                  </div>
                )}

                {(!blueprintType || blueprintType === 'multilayer') && (
                  <div style={{ display: 'grid', gap: '6px' }}>
                    {[
                      { color: '#E3F2FD', name: '1. Stakeholders', desc: 'Who is involved' },
                      { color: '#E8F5E9', name: '2. Requirements', desc: 'What we\'re building' },
                      { color: '#FFF3E0', name: '3. Architecture', desc: 'How it\'s structured' },
                      { color: '#F3E5F5', name: '4. Team', desc: 'Who builds it' },
                      { color: '#FFEBEE', name: '5. Quality', desc: 'Standards & security' },
                      { color: '#FBE9E7', name: '6. Risks', desc: 'What could go wrong' },
                      { color: '#E8EAF6', name: '7. Deliverables', desc: 'What we produce' },
                    ].map((layer, i) => (
                      <div key={i} style={{
                        padding: '8px 10px', backgroundColor: layer.color,
                        borderRadius: '6px', border: '1px solid rgba(0,0,0,0.1)',
                        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                      }}>
                        <div style={{ fontWeight: '600', fontSize: '12px' }}>{layer.name}</div>
                        <div style={{ fontSize: '11px', color: '#666' }}>{layer.desc}</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* AI Reasoning */}
              {blueprintReasoning && (
                <div style={{
                  padding: '12px',
                  backgroundColor: '#f0f9ff',
                  borderRadius: '8px',
                  border: '1px solid #bae6fd',
                  marginBottom: '12px',
                }}>
                  <h4 style={{ fontSize: '12px', fontWeight: '600', marginBottom: '6px', color: '#0369a1' }}>
                    AI Selection Reasoning
                  </h4>
                  <div style={{ fontSize: '11px', color: '#475569', lineHeight: '1.6' }}>
                    {blueprintReasoning}
                  </div>
                </div>
              )}

              {/* Mermaid Syntax Quick Reference */}
              <div style={{
                padding: '12px',
                backgroundColor: '#fefce8',
                borderRadius: '8px',
                border: '1px solid #fef08a',
              }}>
                <h4 style={{ fontSize: '12px', fontWeight: '600', marginBottom: '8px', color: '#854d0e' }}>
                  Mermaid Syntax Tips
                </h4>
                <div style={{ fontSize: '11px', color: '#713f12', lineHeight: '1.6' }}>
                  <code style={{ display: 'block', marginBottom: '4px' }}>A[Box] B((Circle)) C[(Database)]</code>
                  <code style={{ display: 'block', marginBottom: '4px' }}>A --&gt; B (arrow) A -..-&gt; B (dotted)</code>
                  <code style={{ display: 'block' }}>subgraph Name ... end</code>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  // Render Settings Panel
  const renderSettings = () => {
    const handleTestGitLab = async () => {
      setGitlabTestStatus({ testing: true });
      const result = await testGitLabConnection(config.gitlab);
      if (result.success) {
        setGitlabTestStatus({ testing: false, result: `Connected to: ${result.projectName}` });
      } else {
        setGitlabTestStatus({ testing: false, result: `Error: ${result.error}` });
      }
    };

    const handleTestAzure = async () => {
      setAzureTestStatus({ testing: true });
      const result = await testAzureOpenAI(config.azureOpenAI);
      if (result.success) {
        setAzureTestStatus({ testing: false, result: 'Connection successful!' });
      } else {
        setAzureTestStatus({ testing: false, result: `Error: ${result.error}` });
      }
    };

    const handleTestOpenAI = async () => {
      setOpenaiTestStatus({ testing: true });
      const result = await testOpenAI(config.openAI);
      if (result.success) {
        setOpenaiTestStatus({ testing: false, result: `Connected! Model: ${result.model}` });
      } else {
        setOpenaiTestStatus({ testing: false, result: `Error: ${result.error}` });
      }
    };

    // Handle AI provider change
    const handleAIProviderChange = (provider: AIProvider) => {
      const newConfig = { ...config, aiProvider: provider };

      // Update enabled flags based on provider selection
      if (provider === 'openai') {
        newConfig.openAI = { ...newConfig.openAI, enabled: true };
        newConfig.azureOpenAI = { ...newConfig.azureOpenAI, enabled: false };
      } else if (provider === 'azure') {
        newConfig.openAI = { ...newConfig.openAI, enabled: false };
        newConfig.azureOpenAI = { ...newConfig.azureOpenAI, enabled: true };
      } else {
        newConfig.openAI = { ...newConfig.openAI, enabled: false };
        newConfig.azureOpenAI = { ...newConfig.azureOpenAI, enabled: false };
      }

      updateConfig(newConfig);
    };

    const openaiEnabled = config.aiProvider === 'openai' && config.openAI.enabled;
    const azureEnabled = config.aiProvider === 'azure' && config.azureOpenAI.enabled;
    const aiEnabled = openaiEnabled || azureEnabled;
    const gitlabEnabled = config.gitlab.enabled;

    // Reusable toggle switch component
    const ToggleSwitch = ({ checked, onChange, label }: { checked: boolean; onChange: (e: React.ChangeEvent<HTMLInputElement>) => void; label: string }) => (
      <label style={{
        display: 'flex',
        alignItems: 'center',
        gap: '8px',
        cursor: 'pointer',
        padding: '4px 8px',
        borderRadius: '6px',
        backgroundColor: checked ? '#dcfce7' : '#f3f4f6',
        border: `1px solid ${checked ? '#86efac' : '#e5e7eb'}`,
        transition: 'all 0.2s ease',
      }}>
        <input
          type="checkbox"
          checked={checked}
          onChange={onChange}
          style={{ display: 'none' }}
        />
        <div style={{
          width: '36px',
          height: '20px',
          borderRadius: '10px',
          backgroundColor: checked ? '#22c55e' : '#d1d5db',
          position: 'relative',
          transition: 'background-color 0.2s ease',
        }}>
          <div style={{
            width: '16px',
            height: '16px',
            borderRadius: '50%',
            backgroundColor: 'white',
            position: 'absolute',
            top: '2px',
            left: checked ? '18px' : '2px',
            transition: 'left 0.2s ease',
            boxShadow: '0 1px 3px rgba(0,0,0,0.2)',
          }} />
        </div>
        <span style={{ fontSize: '13px', fontWeight: 500, color: checked ? '#166534' : '#6b7280' }}>{label}</span>
      </label>
    );

    // Premium Test Button component - World-class fintech styling
    const TestButton = ({ testing, onClick, color }: { testing: boolean; onClick: () => void; color: string }) => {
      // Determine gradient colors based on base color
      const gradientColors = {
        '#10b981': { start: '#22C55E', mid: '#16A34A', end: '#15803D' },
        '#3b82f6': { start: '#60A5FA', mid: '#3B82F6', end: '#2563EB' },
        '#8b5cf6': { start: '#A78BFA', mid: '#8B5CF6', end: '#7C3AED' },
      };
      const colors = gradientColors[color as keyof typeof gradientColors] || { start: color, mid: color, end: color };

      return (
        <button
          style={{
            padding: '10px 18px',
            borderRadius: '8px',
            border: 'none',
            color: 'white',
            fontSize: '13px',
            fontWeight: 500,
            cursor: testing ? 'wait' : 'pointer',
            background: testing
              ? `linear-gradient(90deg, ${color}60 25%, ${color} 50%, ${color}60 75%)`
              : `linear-gradient(145deg, ${colors.start} 0%, ${colors.mid} 50%, ${colors.end} 100%)`,
            backgroundSize: testing ? '200% 100%' : '100% 100%',
            animation: testing ? 'shimmer 1.5s ease-in-out infinite' : 'none',
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            boxShadow: testing
              ? 'inset 0 1px 2px rgba(0, 0, 0, 0.1)'
              : `0 2px 4px ${color}30, 0 4px 8px ${color}20, inset 0 1px 0 rgba(255, 255, 255, 0.15)`,
            textShadow: '0 1px 1px rgba(0, 0, 0, 0.1)',
            transition: 'all 0.2s cubic-bezier(0.34, 1.56, 0.64, 1)',
            opacity: testing ? 0.85 : 1,
          }}
          onClick={onClick}
          disabled={testing}
        >
          {testing ? (
            <>
              <span style={{
                width: '14px',
                height: '14px',
                border: '2px solid rgba(255, 255, 255, 0.3)',
                borderTopColor: 'white',
                borderRadius: '50%',
                animation: 'spin 0.8s linear infinite'
              }} />
              Testing...
            </>
          ) : (
            <>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M5 12h14M12 5l7 7-7 7"/>
              </svg>
              Test Connection
            </>
          )}
        </button>
      );
    };

    // Status result component
    const StatusResult = ({ result }: { result: string }) => (
      <div style={{
        marginTop: '8px',
        padding: '8px 12px',
        borderRadius: '6px',
        fontSize: '13px',
        display: 'flex',
        alignItems: 'center',
        gap: '8px',
        backgroundColor: result.startsWith('Error') ? '#fee2e2' : '#dcfce7',
        color: result.startsWith('Error') ? '#991b1b' : '#166534',
      }}>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          {result.startsWith('Error') ? (
            <path d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
          ) : (
            <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
          )}
        </svg>
        {result}
      </div>
    );

    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
        {/* AI Provider Selector */}
        <div style={{
          ...styles.card,
          background: 'linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%)',
          border: '1px solid #bae6fd',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px', marginBottom: '16px' }}>
            <div style={{
              width: '40px',
              height: '40px',
              borderRadius: '10px',
              background: 'linear-gradient(135deg, #0ea5e9, #6366f1)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="white">
                <path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"/>
              </svg>
            </div>
            <div>
              <div style={{ ...styles.stageTitle, margin: 0 }}>AI Provider</div>
              <div style={{ color: '#0369a1', fontSize: '13px' }}>
                Select which AI service to use for suggestions and refinements
              </div>
            </div>
          </div>

          <div style={{ display: 'flex', gap: '12px' }}>
            {/* No AI Option */}
            <button
              onClick={() => handleAIProviderChange('none')}
              style={{
                flex: 1,
                padding: '14px 16px',
                borderRadius: '10px',
                border: config.aiProvider === 'none' ? '2px solid #64748b' : '1px solid #cbd5e1',
                background: config.aiProvider === 'none' ? '#f1f5f9' : 'white',
                cursor: 'pointer',
                textAlign: 'left',
                transition: 'all 0.2s ease',
              }}
            >
              <div style={{ fontWeight: 600, fontSize: '14px', color: '#374151', marginBottom: '4px' }}>
                None (Mock Mode)
              </div>
              <div style={{ fontSize: '12px', color: '#6b7280' }}>
                No AI - returns input as-is
              </div>
            </button>

            {/* OpenAI Option */}
            <button
              onClick={() => handleAIProviderChange('openai')}
              style={{
                flex: 1,
                padding: '14px 16px',
                borderRadius: '10px',
                border: config.aiProvider === 'openai' ? '2px solid #10b981' : '1px solid #cbd5e1',
                background: config.aiProvider === 'openai' ? '#ecfdf5' : 'white',
                cursor: 'pointer',
                textAlign: 'left',
                transition: 'all 0.2s ease',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="#10b981">
                  <path d="M22.2819 9.8211a5.9847 5.9847 0 0 0-.5157-4.9108 6.0462 6.0462 0 0 0-6.5098-2.9A6.0651 6.0651 0 0 0 4.9807 4.1818a5.9847 5.9847 0 0 0-3.9977 2.9 6.0462 6.0462 0 0 0 .7427 7.0966 5.98 5.98 0 0 0 .511 4.9107 6.051 6.051 0 0 0 6.5146 2.9001A5.9847 5.9847 0 0 0 13.2599 24a6.0557 6.0557 0 0 0 5.7718-4.2058 5.9894 5.9894 0 0 0 3.9977-2.9001 6.0557 6.0557 0 0 0-.7475-7.0729zm-9.022 12.6081a4.4755 4.4755 0 0 1-2.8764-1.0408l.1419-.0804 4.7783-2.7582a.7948.7948 0 0 0 .3927-.6813v-6.7369l2.02 1.1686a.071.071 0 0 1 .038.052v5.5826a4.504 4.504 0 0 1-4.4945 4.4944zm-9.6607-4.1254a4.4708 4.4708 0 0 1-.5346-3.0137l.142.0852 4.783 2.7582a.7712.7712 0 0 0 .7806 0l5.8428-3.3685v2.3324a.0804.0804 0 0 1-.0332.0615L9.74 19.9502a4.4992 4.4992 0 0 1-6.1408-1.6464zM2.3408 7.8956a4.485 4.485 0 0 1 2.3655-1.9728V11.6a.7664.7664 0 0 0 .3879.6765l5.8144 3.3543-2.0201 1.1685a.0757.0757 0 0 1-.071 0l-4.8303-2.7865A4.504 4.504 0 0 1 2.3408 7.8956zm16.5963 3.8558L13.1038 8.364l2.0201-1.1638a.0757.0757 0 0 1 .071 0l4.8303 2.7913a4.4944 4.4944 0 0 1-.6765 8.1042v-5.6772a.79.79 0 0 0-.407-.667zm2.0107-3.0231l-.142-.0852-4.7735-2.7818a.7759.7759 0 0 0-.7854 0L9.409 9.2297V6.8974a.0662.0662 0 0 1 .0284-.0615l4.8303-2.7866a4.4992 4.4992 0 0 1 6.6802 4.66zM8.3065 12.863l-2.02-1.1638a.0804.0804 0 0 1-.038-.0567V6.0742a4.4992 4.4992 0 0 1 7.3757-3.4537l-.142.0805L8.704 5.459a.7948.7948 0 0 0-.3927.6813zm1.0976-2.3654l2.602-1.4998 2.6069 1.4998v2.9994l-2.5974 1.4997-2.6067-1.4997Z"/>
                </svg>
                <span style={{ fontWeight: 600, fontSize: '14px', color: '#374151' }}>OpenAI</span>
              </div>
              <div style={{ fontSize: '12px', color: '#6b7280' }}>
                Direct API (GPT-4o, GPT-4, etc.)
              </div>
            </button>

            {/* Azure OpenAI Option */}
            <button
              onClick={() => handleAIProviderChange('azure')}
              style={{
                flex: 1,
                padding: '14px 16px',
                borderRadius: '10px',
                border: config.aiProvider === 'azure' ? '2px solid #3b82f6' : '1px solid #cbd5e1',
                background: config.aiProvider === 'azure' ? '#eff6ff' : 'white',
                cursor: 'pointer',
                textAlign: 'left',
                transition: 'all 0.2s ease',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="#3b82f6">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/>
                </svg>
                <span style={{ fontWeight: 600, fontSize: '14px', color: '#374151' }}>Azure OpenAI</span>
              </div>
              <div style={{ fontSize: '12px', color: '#6b7280' }}>
                Enterprise deployment
              </div>
            </button>
          </div>
        </div>

        {/* AI Configuration Panels - show based on selected provider */}
        <div style={{ display: 'grid', gridTemplateColumns: config.aiProvider === 'none' ? '1fr' : '1fr 1fr', gap: '24px' }}>

          {/* OpenAI Configuration - Show when OpenAI is selected */}
          {config.aiProvider === 'openai' && (
            <div style={{
              ...styles.card,
              border: openaiEnabled ? '2px solid #10b981' : '1px solid #e5e7eb',
              position: 'relative',
              overflow: 'hidden',
            }}>
              {/* Header with gradient accent */}
              <div style={{
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                height: '4px',
                background: 'linear-gradient(90deg, #10b981, #34d399)',
                opacity: openaiEnabled ? 1 : 0.3,
              }} />

              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px', paddingTop: '8px' }}>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '4px' }}>
                    <div style={{
                      width: '32px',
                      height: '32px',
                      borderRadius: '8px',
                      background: 'linear-gradient(135deg, #10b981, #34d399)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}>
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="white">
                        <path d="M22.2819 9.8211a5.9847 5.9847 0 0 0-.5157-4.9108 6.0462 6.0462 0 0 0-6.5098-2.9A6.0651 6.0651 0 0 0 4.9807 4.1818a5.9847 5.9847 0 0 0-3.9977 2.9 6.0462 6.0462 0 0 0 .7427 7.0966 5.98 5.98 0 0 0 .511 4.9107 6.051 6.051 0 0 0 6.5146 2.9001A5.9847 5.9847 0 0 0 13.2599 24a6.0557 6.0557 0 0 0 5.7718-4.2058 5.9894 5.9894 0 0 0 3.9977-2.9001 6.0557 6.0557 0 0 0-.7475-7.0729z"/>
                      </svg>
                    </div>
                    <div style={{ ...styles.stageTitle, margin: 0 }}>OpenAI</div>
                  </div>
                  <div style={{ color: '#666', fontSize: '12px', marginLeft: '42px' }}>
                    Direct API access
                  </div>
                </div>
              </div>

              <div style={{ opacity: 1, transition: 'opacity 0.2s ease' }}>
                {/* API Key */}
                <div style={{ ...styles.fieldGroup, marginBottom: '12px' }}>
                  <label style={{ ...styles.label, fontSize: '12px' }}>API Key</label>
                  <input
                    type="password"
                    style={{ ...styles.input, fontSize: '13px', padding: '8px 10px' }}
                    placeholder="sk-..."
                    value={config.openAI.apiKey}
                    onChange={(e) => updateConfig({ ...config, openAI: { ...config.openAI, apiKey: e.target.value } })}
                  />
                  <div style={{ fontSize: '11px', color: '#888', marginTop: '4px' }}>
                    Get your API key from <a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener noreferrer" style={{ color: '#10b981' }}>platform.openai.com</a>
                  </div>
                </div>

                {/* Model Selection */}
                <div style={{ ...styles.fieldGroup, marginBottom: '12px' }}>
                  <label style={{ ...styles.label, fontSize: '12px' }}>Model</label>
                  <select
                    style={{ ...styles.input, fontSize: '13px', padding: '8px 10px', cursor: 'pointer' }}
                    value={config.openAI.model}
                    onChange={(e) => updateConfig({ ...config, openAI: { ...config.openAI, model: e.target.value } })}
                  >
                    {OPENAI_MODELS.map((m) => (
                      <option key={m.id} value={m.id}>{m.name}</option>
                    ))}
                  </select>
                </div>

                {/* Organization ID (optional) */}
                <div style={{ ...styles.fieldGroup, marginBottom: '12px' }}>
                  <label style={{ ...styles.label, fontSize: '12px' }}>Organization ID (Optional)</label>
                  <input
                    type="text"
                    style={{ ...styles.input, fontSize: '13px', padding: '8px 10px' }}
                    placeholder="org-..."
                    value={config.openAI.organizationId || ''}
                    onChange={(e) => updateConfig({ ...config, openAI: { ...config.openAI, organizationId: e.target.value } })}
                  />
                </div>

                {/* Model Parameters */}
                <div style={{
                  marginBottom: '12px',
                  padding: '10px 12px',
                  borderRadius: '8px',
                  backgroundColor: '#f8fafc',
                  border: '1px solid #e2e8f0',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
                    <span style={{ fontSize: '12px', fontWeight: 500, color: '#475569' }}>Model Family</span>
                    <span style={{
                      fontSize: '11px',
                      fontWeight: 600,
                      padding: '2px 8px',
                      borderRadius: '4px',
                      backgroundColor: getOpenAIModelFamily(config.openAI.model) === 'gpt-4' ? '#dcfce7' : '#fef3c7',
                      color: getOpenAIModelFamily(config.openAI.model) === 'gpt-4' ? '#166534' : '#92400e',
                    }}>
                      {getOpenAIModelFamily(config.openAI.model).toUpperCase()}
                    </span>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
                    <div style={styles.fieldGroup}>
                      <label style={{ fontSize: '11px', color: '#64748b' }}>
                        Max Tokens (limit: {MODEL_LIMITS[getOpenAIModelFamily(config.openAI.model)].maxTokens.toLocaleString()})
                      </label>
                      <input
                        type="number"
                        style={{ ...styles.input, fontSize: '12px', padding: '6px 8px' }}
                        value={config.openAI.maxTokens}
                        onChange={(e) => {
                          const family = getOpenAIModelFamily(config.openAI.model);
                          const maxAllowed = MODEL_LIMITS[family].maxTokens;
                          const value = Math.min(parseInt(e.target.value) || 2048, maxAllowed);
                          updateConfig({ ...config, openAI: { ...config.openAI, maxTokens: value } });
                        }}
                        min={100}
                        max={MODEL_LIMITS[getOpenAIModelFamily(config.openAI.model)].maxTokens}
                      />
                    </div>
                    <div style={styles.fieldGroup}>
                      <label style={{ fontSize: '11px', color: '#64748b' }}>
                        Temperature (max: {MODEL_LIMITS[getOpenAIModelFamily(config.openAI.model)].maxTemperature})
                      </label>
                      <input
                        type="number"
                        step="0.1"
                        style={{ ...styles.input, fontSize: '12px', padding: '6px 8px' }}
                        value={config.openAI.temperature}
                        onChange={(e) => {
                          const family = getOpenAIModelFamily(config.openAI.model);
                          const maxAllowed = MODEL_LIMITS[family].maxTemperature;
                          const value = Math.min(parseFloat(e.target.value) || 0.7, maxAllowed);
                          updateConfig({ ...config, openAI: { ...config.openAI, temperature: value } });
                        }}
                        min={0}
                        max={MODEL_LIMITS[getOpenAIModelFamily(config.openAI.model)].maxTemperature}
                      />
                    </div>
                  </div>
                </div>

                {/* Test connection */}
                <div style={{ marginTop: '16px', paddingTop: '16px', borderTop: '1px solid #e5e7eb' }}>
                  <TestButton testing={openaiTestStatus?.testing || false} onClick={handleTestOpenAI} color="#10b981" />
                  {openaiTestStatus?.result && <StatusResult result={openaiTestStatus.result} />}
                </div>
              </div>
            </div>
          )}

          {/* Azure OpenAI Configuration - Show when Azure is selected */}
          {config.aiProvider === 'azure' && (
            <div style={{
              ...styles.card,
              border: azureEnabled ? '2px solid #3b82f6' : '1px solid #e5e7eb',
              position: 'relative',
              overflow: 'hidden',
            }}>
              {/* Header with gradient accent */}
              <div style={{
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                height: '4px',
                background: 'linear-gradient(90deg, #3b82f6, #8b5cf6)',
                opacity: azureEnabled ? 1 : 0.3,
              }} />

              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px', paddingTop: '8px' }}>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '4px' }}>
                    <div style={{
                      width: '32px',
                      height: '32px',
                      borderRadius: '8px',
                      background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}>
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="white">
                        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/>
                      </svg>
                    </div>
                    <div style={{ ...styles.stageTitle, margin: 0 }}>Azure OpenAI</div>
                  </div>
                  <div style={{ color: '#666', fontSize: '12px', marginLeft: '42px' }}>
                    Enterprise AI deployment
                  </div>
                </div>
              </div>

              <div style={{ opacity: 1, transition: 'opacity 0.2s ease' }}>
              {/* Endpoint & Deployment in 2 columns */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '12px' }}>
                <div style={styles.fieldGroup}>
                  <label style={{ ...styles.label, fontSize: '12px' }}>Endpoint</label>
                  <input
                    type="text"
                    style={{ ...styles.input, fontSize: '13px', padding: '8px 10px' }}
                    placeholder="https://your-resource.openai.azure.com"
                    value={config.azureOpenAI.endpoint}
                    onChange={(e) => updateConfig({ ...config, azureOpenAI: { ...config.azureOpenAI, endpoint: e.target.value } })}
                  />
                </div>
                <div style={styles.fieldGroup}>
                  <label style={{ ...styles.label, fontSize: '12px' }}>Deployment</label>
                  <input
                    type="text"
                    style={{ ...styles.input, fontSize: '13px', padding: '8px 10px' }}
                    placeholder="gpt-4o-deployment"
                    value={config.azureOpenAI.deploymentName}
                    onChange={(e) => updateConfig({ ...config, azureOpenAI: { ...config.azureOpenAI, deploymentName: e.target.value } })}
                  />
                </div>
              </div>

              {/* API Key & Version in 2 columns */}
              <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '12px', marginBottom: '12px' }}>
                <div style={styles.fieldGroup}>
                  <label style={{ ...styles.label, fontSize: '12px' }}>API Key</label>
                  <input
                    type="password"
                    style={{ ...styles.input, fontSize: '13px', padding: '8px 10px' }}
                    placeholder="Your Azure OpenAI API key"
                    value={config.azureOpenAI.apiKey}
                    onChange={(e) => updateConfig({ ...config, azureOpenAI: { ...config.azureOpenAI, apiKey: e.target.value } })}
                  />
                </div>
                <div style={styles.fieldGroup}>
                  <label style={{ ...styles.label, fontSize: '12px' }}>API Version</label>
                  <select
                    style={{ ...styles.input, fontSize: '13px', padding: '8px 10px', cursor: 'pointer' }}
                    value={config.azureOpenAI.apiVersion}
                    onChange={(e) => updateConfig({ ...config, azureOpenAI: { ...config.azureOpenAI, apiVersion: e.target.value } })}
                  >
                    {AZURE_API_VERSIONS.map((v) => (
                      <option key={v} value={v}>{v}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Model Family Detection & Parameters */}
              {config.azureOpenAI.deploymentName && (
                <div style={{
                  marginBottom: '12px',
                  padding: '10px 12px',
                  borderRadius: '8px',
                  backgroundColor: '#f8fafc',
                  border: '1px solid #e2e8f0',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
                    <span style={{ fontSize: '12px', fontWeight: 500, color: '#475569' }}>Detected Model Family</span>
                    <span style={{
                      fontSize: '11px',
                      fontWeight: 600,
                      padding: '2px 8px',
                      borderRadius: '4px',
                      backgroundColor: (config.azureOpenAI.modelFamily || detectModelFamily(config.azureOpenAI.deploymentName)) === 'gpt-5'
                        ? '#fef3c7'
                        : (config.azureOpenAI.modelFamily || detectModelFamily(config.azureOpenAI.deploymentName)) === 'gpt-4'
                          ? '#dbeafe'
                          : '#f3f4f6',
                      color: (config.azureOpenAI.modelFamily || detectModelFamily(config.azureOpenAI.deploymentName)) === 'gpt-5'
                        ? '#92400e'
                        : (config.azureOpenAI.modelFamily || detectModelFamily(config.azureOpenAI.deploymentName)) === 'gpt-4'
                          ? '#1e40af'
                          : '#4b5563',
                    }}>
                      {(config.azureOpenAI.modelFamily || detectModelFamily(config.azureOpenAI.deploymentName)).toUpperCase()}
                    </span>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
                    <div style={styles.fieldGroup}>
                      <label style={{ fontSize: '11px', color: '#64748b' }}>
                        Max Tokens (limit: {MODEL_LIMITS[config.azureOpenAI.modelFamily || detectModelFamily(config.azureOpenAI.deploymentName)].maxTokens.toLocaleString()})
                      </label>
                      <input
                        type="number"
                        style={{ ...styles.input, fontSize: '12px', padding: '6px 8px' }}
                        value={config.azureOpenAI.maxTokens}
                        onChange={(e) => {
                          const family = config.azureOpenAI.modelFamily || detectModelFamily(config.azureOpenAI.deploymentName);
                          const maxAllowed = MODEL_LIMITS[family].maxTokens;
                          const value = Math.min(parseInt(e.target.value) || 2048, maxAllowed);
                          updateConfig({ ...config, azureOpenAI: { ...config.azureOpenAI, maxTokens: value } });
                        }}
                        min={100}
                        max={MODEL_LIMITS[config.azureOpenAI.modelFamily || detectModelFamily(config.azureOpenAI.deploymentName)].maxTokens}
                      />
                    </div>
                    <div style={styles.fieldGroup}>
                      <label style={{ fontSize: '11px', color: '#64748b' }}>
                        Temperature (max: {MODEL_LIMITS[config.azureOpenAI.modelFamily || detectModelFamily(config.azureOpenAI.deploymentName)].maxTemperature})
                      </label>
                      <input
                        type="number"
                        step="0.1"
                        style={{ ...styles.input, fontSize: '12px', padding: '6px 8px' }}
                        value={config.azureOpenAI.temperature}
                        onChange={(e) => {
                          const family = config.azureOpenAI.modelFamily || detectModelFamily(config.azureOpenAI.deploymentName);
                          const maxAllowed = MODEL_LIMITS[family].maxTemperature;
                          const value = Math.min(parseFloat(e.target.value) || 0.7, maxAllowed);
                          updateConfig({ ...config, azureOpenAI: { ...config.azureOpenAI, temperature: value } });
                        }}
                        min={0}
                        max={MODEL_LIMITS[config.azureOpenAI.modelFamily || detectModelFamily(config.azureOpenAI.deploymentName)].maxTemperature}
                      />
                    </div>
                  </div>
                  <div style={{ marginTop: '8px' }}>
                    <label style={{ fontSize: '11px', color: '#64748b' }}>Override Model Family (if auto-detect is wrong)</label>
                    <select
                      style={{ ...styles.input, fontSize: '12px', padding: '6px 8px', marginTop: '4px' }}
                      value={config.azureOpenAI.modelFamily || 'auto'}
                      onChange={(e) => {
                        const value = e.target.value === 'auto' ? undefined : e.target.value as ModelFamily;
                        updateConfig({ ...config, azureOpenAI: { ...config.azureOpenAI, modelFamily: value } });
                      }}
                    >
                      <option value="auto">Auto-detect</option>
                      <option value="gpt-4">GPT-4 Series</option>
                      <option value="gpt-5">GPT-5 / o1 / o3 Series</option>
                    </select>
                  </div>
                </div>
              )}

              {/* Test connection */}
              <div style={{ marginTop: '16px', paddingTop: '16px', borderTop: '1px solid #e5e7eb' }}>
                <TestButton testing={azureTestStatus?.testing || false} onClick={handleTestAzure} color="#3b82f6" />
                {azureTestStatus?.result && <StatusResult result={azureTestStatus.result} />}
              </div>
              </div>
            </div>
          )}

          {/* GitLab Configuration */}
          <div style={{
            ...styles.card,
            border: gitlabEnabled ? '2px solid #fc6d26' : '1px solid #e5e7eb',
            position: 'relative',
            overflow: 'hidden',
          }}>
            {/* Header with gradient accent */}
            <div style={{
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              height: '4px',
              background: 'linear-gradient(90deg, #fc6d26, #fca326)',
              opacity: gitlabEnabled ? 1 : 0.3,
            }} />

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px', paddingTop: '8px' }}>
              <div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '4px' }}>
                  <div style={{
                    width: '32px',
                    height: '32px',
                    borderRadius: '8px',
                    background: 'linear-gradient(135deg, #fc6d26, #fca326)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="white">
                      <path d="M22.65 14.39L12 22.13 1.35 14.39a.84.84 0 01-.3-.94l1.22-3.78 2.44-7.51A.42.42 0 014.82 2a.43.43 0 01.58 0 .42.42 0 01.11.18l2.44 7.49h8.1l2.44-7.51A.42.42 0 0118.6 2a.43.43 0 01.58 0 .42.42 0 01.11.18l2.44 7.51L23 13.45a.84.84 0 01-.35.94z"/>
                    </svg>
                  </div>
                  <div style={{ ...styles.stageTitle, margin: 0 }}>GitLab</div>
                </div>
                <div style={{ color: '#666', fontSize: '12px', marginLeft: '42px' }}>
                  Push epics to repository
                </div>
              </div>
              <ToggleSwitch
                checked={config.gitlab.enabled}
                onChange={(e) => updateConfig({ ...config, gitlab: { ...config.gitlab, enabled: e.target.checked } })}
                label={gitlabEnabled ? 'On' : 'Off'}
              />
            </div>

            <div style={{ opacity: gitlabEnabled ? 1 : 0.5, transition: 'opacity 0.2s ease' }}>
              {/* GitLab URL */}
              <div style={{ ...styles.fieldGroup, marginBottom: '12px' }}>
                <label style={{ ...styles.label, fontSize: '12px' }}>GitLab URL</label>
                <input
                  type="text"
                  style={{ ...styles.input, fontSize: '13px', padding: '8px 10px' }}
                  placeholder="https://gitlab.com"
                  value={config.gitlab.baseUrl}
                  onChange={(e) => updateConfig({ ...config, gitlab: { ...config.gitlab, baseUrl: e.target.value } })}
                  disabled={!gitlabEnabled}
                />
              </div>

              {/* Access Token - full width */}
              <div style={{ ...styles.fieldGroup, marginBottom: '12px' }}>
                <label style={{ ...styles.label, fontSize: '12px' }}>Personal Access Token</label>
                <input
                  type="password"
                  style={{ ...styles.input, fontSize: '13px', padding: '8px 10px' }}
                  placeholder="glpat-..."
                  value={config.gitlab.accessToken}
                  onChange={(e) => updateConfig({ ...config, gitlab: { ...config.gitlab, accessToken: e.target.value } })}
                  disabled={!gitlabEnabled}
                />
                <div style={{ fontSize: '11px', color: '#888', marginTop: '4px' }}>
                  Needs <code style={{ background: '#f3f4f6', padding: '1px 4px', borderRadius: '3px' }}>api</code> scope
                </div>
              </div>

              {/* Group ID */}
              <div style={{ ...styles.fieldGroup, marginBottom: '12px' }}>
                <label style={{ ...styles.label, fontSize: '12px' }}>Group ID</label>
                <input
                  type="text"
                  style={{ ...styles.input, fontSize: '13px', padding: '8px 10px' }}
                  placeholder="484540"
                  value={config.gitlab.rootGroupId}
                  onChange={(e) => updateConfig({ ...config, gitlab: { ...config.gitlab, rootGroupId: e.target.value } })}
                  disabled={!gitlabEnabled}
                />
              </div>

              {/* Test connection */}
              {gitlabEnabled && (
                <div style={{ marginTop: '16px', paddingTop: '16px', borderTop: '1px solid #e5e7eb' }}>
                  <TestButton testing={gitlabTestStatus?.testing || false} onClick={handleTestGitLab} color="#fc6d26" />
                  {gitlabTestStatus?.result && <StatusResult result={gitlabTestStatus.result} />}
                </div>
              )}

            </div>
          </div>
        </div>

        {/* Quick status footer */}
        <div style={{
          display: 'flex',
          gap: '16px',
          padding: '12px 16px',
          backgroundColor: '#f8fafc',
          borderRadius: '8px',
          border: '1px solid #e2e8f0',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <div style={{
              width: '8px',
              height: '8px',
              borderRadius: '50%',
              backgroundColor: aiEnabled ? '#22c55e' : '#d1d5db',
            }} />
            <span style={{ fontSize: '13px', color: '#64748b' }}>
              AI: {aiEnabled ? <span style={{ color: '#166534', fontWeight: 500 }}>{getActiveAIProvider(config)}</span> : 'Disabled'}
            </span>
          </div>
          <div style={{ width: '1px', backgroundColor: '#e2e8f0' }} />
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <div style={{
              width: '8px',
              height: '8px',
              borderRadius: '50%',
              backgroundColor: gitlabEnabled ? '#22c55e' : '#d1d5db',
            }} />
            <span style={{ fontSize: '13px', color: '#64748b' }}>
              GitLab: {gitlabEnabled ? <span style={{ color: '#166534', fontWeight: 500 }}>Connected</span> : 'Disabled'}
            </span>
          </div>
          <div style={{ flex: 1 }} />
          <span style={{ fontSize: '12px', color: '#94a3b8' }}>
            Settings auto-save to browser
          </span>
        </div>
      </div>
    );
  };

  const renderEpicEditor = () => (
    <div style={{ display: 'flex', gap: '16px' }}>
      {/* Empty State when no epic is loaded */}
      {!editableEpic ? (
        <div style={{
          flex: 1,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          minHeight: '500px',
          textAlign: 'center',
          padding: '40px',
          backgroundColor: 'white',
          borderRadius: '12px',
          border: '1px solid #e5e7eb',
        }}>
          <svg width="80" height="80" viewBox="0 0 24 24" fill="#d1d5db" style={{ marginBottom: '24px' }}>
            <path d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/>
          </svg>
          <h2 style={{ margin: '0 0 12px 0', color: '#374151', fontSize: '24px', fontWeight: 600 }}>No Epic Loaded</h2>
          <p style={{ color: '#6b7280', marginBottom: '32px', maxWidth: '400px', lineHeight: '1.6' }}>
            Generate a new epic using the Wizard, or load an existing one from GitLab to edit.
          </p>
          <div style={{ display: 'flex', gap: '16px' }}>
            <button
              style={styles.button(true)}
              onClick={() => setActiveTab('wizard')}
            >
              Go to Wizard
            </button>
            <button
              style={{
                ...styles.button(false),
                border: config.gitlab.enabled ? '1px solid #3b82f6' : '1px solid #d1d5db',
                color: config.gitlab.enabled ? '#3b82f6' : '#9ca3af',
                cursor: config.gitlab.enabled ? 'pointer' : 'not-allowed',
              }}
              onClick={() => config.gitlab.enabled && setShowLoadEpicModal(true)}
              disabled={!config.gitlab.enabled}
              title={config.gitlab.enabled ? 'Load an epic from GitLab' : 'Enable GitLab in Settings first'}
            >
              Load from GitLab
            </button>
          </div>
        </div>
      ) : (
      <>
      {/* Main Editor Area */}
      <div style={{ flex: chatState.isOpen ? '1 1 70%' : '1 1 100%', transition: 'flex 0.3s ease' }}>
        {/* CMS-Style Header Toolbar - Premium Fintech Design */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: '16px',
          padding: '14px 20px',
          background: 'linear-gradient(180deg, #FFFFFF 0%, #FAFAF9 100%)',
          borderRadius: '14px',
          border: '1px solid rgba(0, 0, 0, 0.06)',
          boxShadow: '0 2px 8px rgba(0, 0, 0, 0.04), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
        }}>
          {/* Left side: Title + Status Badges */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
            <span style={{ fontSize: '15px', fontWeight: '600', color: '#1F2937', letterSpacing: '-0.02em' }}>
              Epic Editor
            </span>
            {/* MOCK badge - pill style */}
            {shouldUseMockGitLab() && (
              <span style={{
                padding: '4px 10px',
                fontSize: '10px',
                fontWeight: '600',
                background: 'linear-gradient(145deg, #FEF3C7 0%, #FDE68A 100%)',
                color: '#92400E',
                borderRadius: '8px',
                textTransform: 'uppercase',
                letterSpacing: '0.5px',
                border: '1px solid rgba(217, 119, 6, 0.15)',
                boxShadow: '0 1px 2px rgba(217, 119, 6, 0.08)',
              }}>
                Mock
              </span>
            )}
            {/* Editing badge - shown when epic is loaded from GitLab */}
            {selectedGitLabEpic && (
              <span style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '6px',
                padding: '4px 12px',
                fontSize: '11px',
                fontWeight: '500',
                background: 'linear-gradient(145deg, #EEF2FF 0%, #E0E7FF 100%)',
                color: '#4338CA',
                borderRadius: '8px',
                border: '1px solid rgba(99, 102, 241, 0.15)',
                boxShadow: '0 1px 2px rgba(99, 102, 241, 0.08)',
              }}>
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                  <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
                </svg>
                Editing #{selectedGitLabEpic.iid}
              </span>
            )}
            {/* Score badge - shown after refinement */}
            {lastRefinementScore !== null && (
              <button
                onClick={() => setRefinementState(prev => ({ ...prev, showReport: true }))}
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '4px',
                  padding: '2px 8px',
                  fontSize: '11px',
                  fontWeight: '600',
                  backgroundColor: lastRefinementScore >= 8 ? '#dcfce7' : lastRefinementScore >= 5 ? '#fef9c3' : '#fee2e2',
                  color: lastRefinementScore >= 8 ? '#166534' : lastRefinementScore >= 5 ? '#854d0e' : '#991b1b',
                  borderRadius: '9999px',
                  border: 'none',
                  cursor: 'pointer',
                }}
                title="Click to view refinement report"
              >
                <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/>
                </svg>
                {lastRefinementScore.toFixed(1)}
              </button>
            )}
            {/* Line count - Premium badge */}
            <span style={{
              fontSize: '11px',
              color: '#8A8A8A',
              backgroundColor: '#F5F3F0',
              padding: '4px 10px',
              borderRadius: '6px',
              fontWeight: '500',
              fontVariantNumeric: 'tabular-nums',
              border: '1px solid rgba(0, 0, 0, 0.04)',
            }}>
              {editableEpic.split('\n').length} lines
            </span>
          </div>

          {/* Right side: All action buttons - Premium Fintech Toolbar */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            {/* Load & New buttons - Secondary style */}
            <button
              onClick={() => setShowLoadEpicModal(true)}
              disabled={!shouldUseMockGitLab() && !config.gitlab.enabled}
              style={{
                padding: '7px 14px',
                fontSize: '13px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                borderRadius: '8px',
                cursor: (shouldUseMockGitLab() || config.gitlab.enabled) ? 'pointer' : 'not-allowed',
                background: 'linear-gradient(180deg, #FFFFFF 0%, #F9F7F5 100%)',
                border: '1px solid #E8E4E0',
                color: (shouldUseMockGitLab() || config.gitlab.enabled) ? '#374151' : '#9ca3af',
                boxShadow: '0 1px 2px rgba(0, 0, 0, 0.04), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
                transition: 'all 0.2s cubic-bezier(0.34, 1.56, 0.64, 1)',
                opacity: (shouldUseMockGitLab() || config.gitlab.enabled) ? 1 : 0.6,
              }}
              title={(shouldUseMockGitLab() || config.gitlab.enabled) ? 'Load an existing epic' : 'Enable GitLab in Settings first'}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>
              </svg>
              Load
            </button>
            <button
              onClick={resetWizard}
              style={{
                padding: '7px 14px',
                fontSize: '13px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                borderRadius: '8px',
                cursor: 'pointer',
                background: 'linear-gradient(180deg, #FFFFFF 0%, #F9F7F5 100%)',
                border: '1px solid #E8E4E0',
                color: '#374151',
                boxShadow: '0 1px 2px rgba(0, 0, 0, 0.04), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
                transition: 'all 0.2s cubic-bezier(0.34, 1.56, 0.64, 1)',
              }}
              title="Clear editor and start fresh"
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="1 4 1 10 7 10"/>
                <path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/>
              </svg>
              New
            </button>

            {/* Subtle divider - Premium style */}
            <div style={{ width: '1px', height: '24px', background: 'linear-gradient(180deg, transparent, #E8E4E0, transparent)', margin: '0 8px' }} />

            {/* AI buttons - Premium purple accent with depth */}
            <button
              onClick={handleSmartRefine}
              disabled={isSmartRefining || !editableEpic.trim()}
              style={{
                padding: '7px 14px',
                fontSize: '13px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                borderRadius: '8px',
                cursor: isSmartRefining || !editableEpic.trim() ? 'not-allowed' : 'pointer',
                background: isSmartRefining
                  ? 'linear-gradient(180deg, #f9fafb 0%, #f3f4f6 100%)'
                  : 'linear-gradient(180deg, #FAF5FF 0%, #F3E8FF 100%)',
                border: isSmartRefining ? '1px solid #e5e7eb' : '1px solid #DDD6FE',
                color: isSmartRefining ? '#9ca3af' : '#7c3aed',
                boxShadow: isSmartRefining
                  ? 'inset 0 1px 2px rgba(0, 0, 0, 0.04)'
                  : '0 1px 2px rgba(139, 92, 246, 0.08), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
                transition: 'all 0.2s cubic-bezier(0.34, 1.56, 0.64, 1)',
                opacity: isSmartRefining || !editableEpic.trim() ? 0.6 : 1,
              }}
              title={!editableEpic.trim() ? 'Load an epic first' : 'Refine all sections using AI'}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
              </svg>
              {isSmartRefining ? `${smartRefineProgress.current}/${smartRefineProgress.total}` : 'Refine'}
            </button>
            {isAIEnabled(config) && (
              <button
                onClick={handleAIRefine}
                disabled={refinementState.isRefining || !editableEpic.trim()}
                style={{
                  padding: '7px 14px',
                  fontSize: '13px',
                  fontWeight: '500',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  borderRadius: '8px',
                  cursor: refinementState.isRefining || !editableEpic.trim() ? 'not-allowed' : 'pointer',
                  background: refinementState.isRefining
                    ? 'linear-gradient(180deg, #f9fafb 0%, #f3f4f6 100%)'
                    : 'linear-gradient(180deg, #FFF7ED 0%, #FFEDD5 100%)',
                  border: refinementState.isRefining ? '1px solid #e5e7eb' : '1px solid #FED7AA',
                  color: refinementState.isRefining ? '#9ca3af' : '#EA580C',
                  boxShadow: refinementState.isRefining
                    ? 'inset 0 1px 2px rgba(0, 0, 0, 0.04)'
                    : '0 1px 2px rgba(234, 88, 12, 0.08), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
                  transition: 'all 0.2s cubic-bezier(0.34, 1.56, 0.64, 1)',
                  opacity: refinementState.isRefining || !editableEpic.trim() ? 0.6 : 1,
                }}
                title={!editableEpic.trim() ? 'Load an epic first' : 'Analyze epic quality'}
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/>
                </svg>
                {refinementState.isRefining ? 'Analyzing...' : 'Critique'}
              </button>
            )}
            {!chatState.isOpen && isAIEnabled(config) && (
              <button
                onClick={toggleChat}
                style={{
                  padding: '7px 14px',
                  fontSize: '13px',
                  fontWeight: '500',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '6px',
                  borderRadius: '8px',
                  cursor: 'pointer',
                  background: 'linear-gradient(180deg, #FAF5FF 0%, #F3E8FF 100%)',
                  border: '1px solid #DDD6FE',
                  color: '#7C3AED',
                  boxShadow: '0 1px 2px rgba(139, 92, 246, 0.08), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
                  transition: 'all 0.2s cubic-bezier(0.34, 1.56, 0.64, 1)',
                }}
                title="Open AI Feedback Chat"
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                </svg>
                Chat
              </button>
            )}

            {/* Subtle divider - Premium style */}
            <div style={{ width: '1px', height: '24px', background: 'linear-gradient(180deg, transparent, #E8E4E0, transparent)', margin: '0 8px' }} />

            {/* Icon-only buttons: Copy, Download - Premium hover effect */}
            <button
              onClick={() => {
                navigator.clipboard.writeText(editableEpic);
                showToast('success', 'Copied!', 'Markdown copied to clipboard');
              }}
              style={{
                padding: '8px',
                borderRadius: '8px',
                cursor: 'pointer',
                background: 'transparent',
                border: 'none',
                color: '#6b7280',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                transition: 'all 0.2s cubic-bezier(0.34, 1.56, 0.64, 1)',
              }}
              title="Copy markdown to clipboard"
              onMouseEnter={(e) => {
                e.currentTarget.style.background = 'linear-gradient(180deg, #F9FAFB 0%, #F3F4F6 100%)';
                e.currentTarget.style.color = '#374151';
                e.currentTarget.style.boxShadow = '0 2px 4px rgba(0, 0, 0, 0.06)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'transparent';
                e.currentTarget.style.color = '#6b7280';
                e.currentTarget.style.boxShadow = 'none';
              }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
              </svg>
            </button>
            <button
              onClick={() => {
                const blob = new Blob([editableEpic], { type: 'text/markdown' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'epic.md';
                a.click();
                URL.revokeObjectURL(url);
                showToast('success', 'Downloaded!', 'Epic saved as epic.md');
              }}
              style={{
                padding: '8px',
                borderRadius: '8px',
                cursor: 'pointer',
                background: 'transparent',
                border: 'none',
                color: '#6b7280',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                transition: 'all 0.2s cubic-bezier(0.34, 1.56, 0.64, 1)',
              }}
              title="Download as markdown file"
              onMouseEnter={(e) => {
                e.currentTarget.style.background = 'linear-gradient(180deg, #F9FAFB 0%, #F3F4F6 100%)';
                e.currentTarget.style.color = '#374151';
                e.currentTarget.style.boxShadow = '0 2px 4px rgba(0, 0, 0, 0.06)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'transparent';
                e.currentTarget.style.color = '#6b7280';
                e.currentTarget.style.boxShadow = 'none';
              }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                <polyline points="7 10 12 15 17 10"/>
                <line x1="12" y1="15" x2="12" y2="3"/>
              </svg>
            </button>

            {/* Subtle divider - Premium style */}
            <div style={{ width: '1px', height: '24px', background: 'linear-gradient(180deg, transparent, #E8E4E0, transparent)', margin: '0 8px' }} />

            {/* Primary button - Publish (Premium purple gradient) */}
            <button
              onClick={() => setShowPublishAsEpicModal(true)}
              disabled={!shouldUseMockGitLab() && !config.gitlab.enabled}
              style={{
                padding: '9px 18px',
                fontSize: '13px',
                fontWeight: '500',
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                borderRadius: '8px',
                cursor: (shouldUseMockGitLab() || config.gitlab.enabled) ? 'pointer' : 'not-allowed',
                background: (shouldUseMockGitLab() || config.gitlab.enabled)
                  ? 'linear-gradient(145deg, #8B5CF6 0%, #7C3AED 50%, #6D28D9 100%)'
                  : 'linear-gradient(180deg, #F3F4F6 0%, #E5E7EB 100%)',
                border: 'none',
                color: (shouldUseMockGitLab() || config.gitlab.enabled) ? 'white' : '#9ca3af',
                boxShadow: (shouldUseMockGitLab() || config.gitlab.enabled)
                  ? '0 2px 4px rgba(139, 92, 246, 0.2), 0 4px 8px rgba(139, 92, 246, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.15)'
                  : 'inset 0 1px 2px rgba(0, 0, 0, 0.04)',
                textShadow: (shouldUseMockGitLab() || config.gitlab.enabled) ? '0 1px 1px rgba(0, 0, 0, 0.1)' : 'none',
                transition: 'all 0.2s cubic-bezier(0.34, 1.56, 0.64, 1)',
                opacity: (shouldUseMockGitLab() || config.gitlab.enabled) ? 1 : 0.6,
              }}
              title={(shouldUseMockGitLab() || config.gitlab.enabled) ? 'Publish this epic to GitLab' : 'Enable GitLab in Settings first'}
            >
              {shouldUseMockGitLab() ? 'Publish' : 'Publish'}
            </button>
          </div>
        </div>

        {/* Publish status */}
        {publishStatus && (
          <div style={{
            padding: '12px 16px',
            marginBottom: '16px',
            borderRadius: '8px',
            backgroundColor: publishStatus.type === 'success' ? '#dcfce7' : '#fee2e2',
            color: publishStatus.type === 'success' ? '#166534' : '#991b1b',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}>
            <span>{publishStatus.message}</span>
            <button
              style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '16px' }}
              onClick={() => setPublishStatus(null)}
            >
              ✕
            </button>
          </div>
        )}

        {/* Smart Refine Progress Indicator */}
        {isSmartRefining && (
          <div style={{
            padding: '12px 16px',
            marginBottom: '16px',
            borderRadius: '8px',
            backgroundColor: '#f3e8ff',
            border: '1px solid #c4b5fd',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '8px' }}>
              <div style={{
                width: '20px',
                height: '20px',
                border: '2px solid #8b5cf6',
                borderTopColor: 'transparent',
                borderRadius: '50%',
                animation: 'spin 1s linear infinite',
              }} />
              <span style={{ fontWeight: 500, color: '#7c3aed' }}>
                Refining Epic...
              </span>
            </div>
            <div style={{
              height: '6px',
              backgroundColor: '#e9d5ff',
              borderRadius: '3px',
              overflow: 'hidden',
            }}>
              <div style={{
                width: `${(smartRefineProgress.current / smartRefineProgress.total) * 100}%`,
                height: '100%',
                backgroundColor: '#8b5cf6',
                transition: 'width 0.3s ease',
              }} />
            </div>
            <div style={{ fontSize: '12px', color: '#6b7280', marginTop: '6px' }}>
              Stage: <strong>{smartRefineProgress.stage}</strong> → {smartRefineProgress.field}
              <span style={{ float: 'right' }}>{smartRefineProgress.current}/{smartRefineProgress.total}</span>
            </div>
          </div>
        )}

        {/* Smart Refine Review Panel - Collapsible */}
        {(autoGeneratedFields.length > 0 || smartRefineReview) && !isSmartRefining && (
          <div style={{
            marginBottom: '16px',
            borderRadius: '10px',
            border: '1px solid #e2e8f0',
            overflow: 'hidden',
            boxShadow: '0 1px 3px rgba(0,0,0,0.05)',
          }}>
            {/* Collapsible Header */}
            <button
              onClick={() => setWarningsExpanded(!warningsExpanded)}
              style={{
                width: '100%',
                padding: '10px 16px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                border: 'none',
                cursor: 'pointer',
                background: 'linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%)',
                borderBottom: warningsExpanded ? '1px solid #e2e8f0' : 'none',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
                  <line x1="12" y1="9" x2="12" y2="13"/>
                  <line x1="12" y1="17" x2="12.01" y2="17"/>
                </svg>
                <span style={{ fontSize: '13px', fontWeight: '600', color: '#374151' }}>
                  Review Items
                </span>
                <div style={{ display: 'flex', gap: '6px' }}>
                  {autoGeneratedFields.length > 0 && (
                    <span style={{
                      padding: '2px 8px',
                      backgroundColor: '#fef3c7',
                      color: '#92400e',
                      borderRadius: '10px',
                      fontSize: '11px',
                      fontWeight: '500',
                    }}>
                      {autoGeneratedFields.length} AI-generated
                    </span>
                  )}
                  {smartRefineReview && smartRefineReview.sections.filter(s => s.score < 5).length > 0 && (
                    <span style={{
                      padding: '2px 8px',
                      backgroundColor: '#fee2e2',
                      color: '#991b1b',
                      borderRadius: '10px',
                      fontSize: '11px',
                      fontWeight: '500',
                    }}>
                      {smartRefineReview.sections.filter(s => s.score < 5).length} need attention
                    </span>
                  )}
                </div>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                {smartRefineReview && (
                  <span style={{
                    padding: '3px 10px',
                    borderRadius: '6px',
                    fontSize: '12px',
                    fontWeight: '600',
                    backgroundColor: smartRefineReview.overallScore >= 7 ? '#dcfce7' :
                      smartRefineReview.overallScore >= 5 ? '#fef3c7' : '#fee2e2',
                    color: smartRefineReview.overallScore >= 7 ? '#166534' :
                      smartRefineReview.overallScore >= 5 ? '#92400e' : '#991b1b',
                  }}>
                    {smartRefineReview.overallScore.toFixed(1)}/10
                  </span>
                )}
                <svg
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="#64748b"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  style={{
                    transform: warningsExpanded ? 'rotate(180deg)' : 'rotate(0)',
                    transition: 'transform 0.2s ease',
                  }}
                >
                  <polyline points="6 9 12 15 18 9"/>
                </svg>
              </div>
            </button>

            {/* Expandable Content */}
            {warningsExpanded && (
              <div style={{ padding: '12px 16px', backgroundColor: 'white' }}>
                {/* AI-Generated Sections Warning (Yellow) */}
                {autoGeneratedFields.length > 0 && (
                  <div style={{
                    padding: '12px 14px',
                    marginBottom: smartRefineReview ? '10px' : '0',
                    borderRadius: '8px',
                    backgroundColor: '#fffbeb',
                    border: '1px solid #fde68a',
                  }}>
                    <div style={{ display: 'flex', alignItems: 'flex-start', gap: '10px' }}>
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#d97706" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0, marginTop: '2px' }}>
                        <circle cx="12" cy="12" r="10"/>
                        <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/>
                        <line x1="12" y1="17" x2="12.01" y2="17"/>
                      </svg>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: '13px', fontWeight: '600', color: '#92400e', marginBottom: '6px' }}>
                          AI-Generated Content
                        </div>
                        <div style={{ fontSize: '12px', color: '#78350f', lineHeight: '1.5' }}>
                          {autoGeneratedFields.slice(0, 4).join(' • ')}
                          {autoGeneratedFields.length > 4 && ` • +${autoGeneratedFields.length - 4} more`}
                        </div>
                      </div>
                      <button
                        style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '2px', color: '#92400e', opacity: 0.6 }}
                        onClick={(e) => { e.stopPropagation(); setAutoGeneratedFields([]); }}
                        title="Dismiss"
                      >
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <line x1="18" y1="6" x2="6" y2="18"/>
                          <line x1="6" y1="6" x2="18" y2="18"/>
                        </svg>
                      </button>
                    </div>
                  </div>
                )}

                {/* Low Quality Sections Warning (Red) */}
                {smartRefineReview && smartRefineReview.sections.filter(s => s.score < 5).length > 0 && (
                  <div style={{
                    padding: '12px 14px',
                    marginBottom: '10px',
                    borderRadius: '8px',
                    backgroundColor: '#fef2f2',
                    border: '1px solid #fecaca',
                  }}>
                    <div style={{ display: 'flex', alignItems: 'flex-start', gap: '10px' }}>
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#dc2626" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0, marginTop: '2px' }}>
                        <circle cx="12" cy="12" r="10"/>
                        <line x1="12" y1="8" x2="12" y2="12"/>
                        <line x1="12" y1="16" x2="12.01" y2="16"/>
                      </svg>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: '13px', fontWeight: '600', color: '#991b1b', marginBottom: '6px' }}>
                          Needs Attention
                        </div>
                        <div style={{ fontSize: '12px', color: '#7f1d1d', lineHeight: '1.5' }}>
                          {smartRefineReview.sections
                            .filter(s => s.score < 5)
                            .slice(0, 3)
                            .map(s => `${s.sectionTitle} (${s.score}/10)`)
                            .join(' • ')}
                        </div>
                      </div>
                      <button
                        style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '2px', color: '#991b1b', opacity: 0.6 }}
                        onClick={(e) => { e.stopPropagation(); setSmartRefineReview(null); }}
                        title="Dismiss"
                      >
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <line x1="18" y1="6" x2="6" y2="18"/>
                          <line x1="6" y1="6" x2="18" y2="18"/>
                        </svg>
                      </button>
                    </div>
                  </div>
                )}

                {/* View Full Report Button */}
                {smartRefineReview && (
                  <button
                    onClick={() => setRefinementState(prev => ({ ...prev, showReport: true, report: smartRefineReview }))}
                    style={{
                      width: '100%',
                      padding: '10px 16px',
                      borderRadius: '8px',
                      border: '1px solid #e2e8f0',
                      backgroundColor: 'white',
                      color: '#374151',
                      fontSize: '13px',
                      fontWeight: '500',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '8px',
                      transition: 'all 0.15s ease',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = '#f8fafc';
                      e.currentTarget.style.borderColor = '#3b82f6';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = 'white';
                      e.currentTarget.style.borderColor = '#e2e8f0';
                    }}
                  >
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                      <polyline points="14 2 14 8 20 8"/>
                      <line x1="16" y1="13" x2="8" y2="13"/>
                      <line x1="16" y1="17" x2="8" y2="17"/>
                    </svg>
                    View Full Quality Report
                  </button>
                )}
              </div>
            )}
          </div>
        )}

        {/* Split screen - Enhanced with distinct visual styling */}
        <div style={styles.splitContainer}>
          {/* Editor pane - Dark theme */}
          <div style={styles.splitPane}>
            <div style={styles.editorPane}>
              <div style={{
                ...styles.paneHeader,
                background: 'linear-gradient(135deg, #334155 0%, #1e293b 100%)',
                borderBottom: '1px solid #475569',
                color: '#e2e8f0',
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="4 7 4 4 20 4 20 7"/>
                    <line x1="9" y1="20" x2="15" y2="20"/>
                    <line x1="12" y1="4" x2="12" y2="20"/>
                  </svg>
                  <span>Editor</span>
                  <span style={{
                    padding: '2px 8px',
                    backgroundColor: '#475569',
                    borderRadius: '4px',
                    fontSize: '10px',
                    color: '#94a3b8',
                    fontWeight: '500',
                  }}>
                    Markdown
                  </span>
                </div>
                <span style={{
                  fontSize: '11px',
                  color: '#94a3b8',
                  padding: '2px 8px',
                  backgroundColor: '#334155',
                  borderRadius: '4px',
                }}>
                  {editableEpic.split('\n').length} lines
                </span>
              </div>
              <textarea
                style={styles.editor}
                value={editableEpic}
                onChange={(e) => setEditableEpic(e.target.value)}
                spellCheck={false}
                placeholder="Start writing your epic here, or load one from GitLab..."
              />
            </div>
          </div>

          {/* Preview pane - Light theme */}
          <div style={styles.splitPane}>
            <div style={styles.previewPane}>
              <div style={{
                ...styles.paneHeader,
                background: 'linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%)',
                borderBottom: '1px solid #e2e8f0',
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#64748b" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                    <circle cx="12" cy="12" r="3"/>
                  </svg>
                  <span>Preview</span>
                  <span style={{
                    padding: '2px 8px',
                    backgroundColor: '#dbeafe',
                    borderRadius: '4px',
                    fontSize: '10px',
                    color: '#3b82f6',
                    fontWeight: '500',
                  }}>
                    Live
                  </span>
                </div>
                <span style={{
                  fontSize: '11px',
                  color: '#64748b',
                }}>
                  Rendered Output
                </span>
              </div>
              <div style={{ overflow: 'auto', height: 'calc(100% - 45px)', padding: '16px' }}>
                <MarkdownPreview content={editableEpic} />
              </div>
            </div>
          </div>
        </div>

        {/* Child Items Section - Modern Card Layout */}
        {(epicChildren.epics.length > 0 || epicChildren.issues.length > 0) && (
          <div style={{
            marginTop: '24px',
            padding: '20px',
            background: 'linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%)',
            borderRadius: '12px',
            border: '1px solid #e2e8f0',
          }}>
            {/* Section Header */}
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '12px',
              marginBottom: '16px',
            }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#64748b" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/>
                <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>
              </svg>
              <span style={{ fontSize: '15px', fontWeight: '600', color: '#374151' }}>
                Linked Items
              </span>
              <span style={{
                fontSize: '12px',
                color: '#64748b',
                padding: '2px 8px',
                backgroundColor: '#e2e8f0',
                borderRadius: '4px',
              }}>
                {epicChildren.epics.length + epicChildren.issues.length} total
              </span>
            </div>

            <div style={{
              display: 'flex',
              gap: '24px',
              flexWrap: 'wrap',
            }}>
              {/* Child Epics - Card Layout */}
              {epicChildren.epics.length > 0 && (
                <div style={{ flex: '1 1 400px', minWidth: '350px' }}>
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    marginBottom: '12px',
                  }}>
                    <span style={{
                      background: 'linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%)',
                      color: 'white',
                      padding: '3px 10px',
                      borderRadius: '6px',
                      fontSize: '11px',
                      fontWeight: '600',
                    }}>
                      {epicChildren.epics.length}
                    </span>
                    <span style={{ fontSize: '13px', fontWeight: '600', color: '#6b7280' }}>Child Epics</span>
                  </div>
                  <div style={{
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '8px',
                  }}>
                    {epicChildren.epics.map((epic) => (
                      <div
                        key={epic.id}
                        onClick={() => window.open(epic.web_url, '_blank')}
                        style={{
                          padding: '12px 14px',
                          backgroundColor: 'white',
                          borderRadius: '8px',
                          border: '1px solid #e5e7eb',
                          cursor: 'pointer',
                          transition: 'all 0.15s ease',
                          boxShadow: '0 1px 2px rgba(0,0,0,0.04)',
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.borderColor = '#8b5cf6';
                          e.currentTarget.style.boxShadow = '0 2px 8px rgba(139,92,246,0.15)';
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.borderColor = '#e5e7eb';
                          e.currentTarget.style.boxShadow = '0 1px 2px rgba(0,0,0,0.04)';
                        }}
                      >
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
                          <span style={{ fontSize: '12px', fontWeight: '600', color: '#8b5cf6' }}>#{epic.iid}</span>
                          <span style={{
                            padding: '2px 8px',
                            borderRadius: '10px',
                            fontSize: '10px',
                            fontWeight: '500',
                            background: epic.state === 'opened' ? '#dcfce7' : '#f3f4f6',
                            color: epic.state === 'opened' ? '#166534' : '#6b7280',
                          }}>
                            {epic.state}
                          </span>
                        </div>
                        <div style={{
                          fontSize: '13px',
                          fontWeight: '500',
                          color: '#374151',
                          marginBottom: '8px',
                          lineHeight: '1.4',
                          display: '-webkit-box',
                          WebkitLineClamp: 2,
                          WebkitBoxOrient: 'vertical',
                          overflow: 'hidden',
                        }}>
                          {epic.title}
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px' }}>
                            {(epic.labels || []).slice(0, 2).map((label, idx) => (
                              <span key={idx} style={{
                                padding: '2px 6px',
                                borderRadius: '4px',
                                fontSize: '10px',
                                fontWeight: '500',
                                background: label.includes('priority::high') ? '#fee2e2' :
                                  label.includes('priority::') ? '#fef3c7' : '#ede9fe',
                                color: label.includes('priority::high') ? '#991b1b' :
                                  label.includes('priority::') ? '#92400e' : '#6d28d9',
                              }}>
                                {label.replace('::', ': ')}
                              </span>
                            ))}
                          </div>
                          {epic.due_date && (
                            <span style={{ fontSize: '11px', color: '#9ca3af' }}>
                              Due {new Date(epic.due_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Issues - Card Layout */}
              {epicChildren.issues.length > 0 && (
                <div style={{ flex: '1 1 400px', minWidth: '350px' }}>
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    marginBottom: '12px',
                  }}>
                    <span style={{
                      background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
                      color: 'white',
                      padding: '3px 10px',
                      borderRadius: '6px',
                      fontSize: '11px',
                      fontWeight: '600',
                    }}>
                      {epicChildren.issues.length}
                    </span>
                    <span style={{ fontSize: '13px', fontWeight: '600', color: '#6b7280' }}>Issues</span>
                  </div>
                  <div style={{
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '8px',
                  }}>
                    {epicChildren.issues.map((issue) => (
                      <div
                        key={issue.id}
                        onClick={() => window.open(issue.web_url, '_blank')}
                        style={{
                          padding: '12px 14px',
                          backgroundColor: 'white',
                          borderRadius: '8px',
                          border: '1px solid #e5e7eb',
                          cursor: 'pointer',
                          transition: 'all 0.15s ease',
                          boxShadow: '0 1px 2px rgba(0,0,0,0.04)',
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.borderColor = '#10b981';
                          e.currentTarget.style.boxShadow = '0 2px 8px rgba(16,185,129,0.15)';
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.borderColor = '#e5e7eb';
                          e.currentTarget.style.boxShadow = '0 1px 2px rgba(0,0,0,0.04)';
                        }}
                      >
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
                          <span style={{ fontSize: '12px', fontWeight: '600', color: '#10b981' }}>#{issue.iid}</span>
                          <span style={{
                            padding: '2px 8px',
                            borderRadius: '10px',
                            fontSize: '10px',
                            fontWeight: '500',
                            background: issue.state === 'opened' ? '#dcfce7' : '#f3f4f6',
                            color: issue.state === 'opened' ? '#166534' : '#6b7280',
                          }}>
                            {issue.state === 'closed' ? '✓ closed' : 'open'}
                          </span>
                        </div>
                        <div style={{
                          fontSize: '13px',
                          fontWeight: '500',
                          color: '#374151',
                          marginBottom: '8px',
                          lineHeight: '1.4',
                          display: '-webkit-box',
                          WebkitLineClamp: 2,
                          WebkitBoxOrient: 'vertical',
                          overflow: 'hidden',
                        }}>
                          {issue.title}
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px' }}>
                            {(issue.labels || []).slice(0, 2).map((label, idx) => (
                              <span key={idx} style={{
                                padding: '2px 6px',
                                borderRadius: '4px',
                                fontSize: '10px',
                                fontWeight: '500',
                                background: label.includes('priority::high') ? '#fee2e2' :
                                  label.includes('security') ? '#fef3c7' : '#ecfdf5',
                                color: label.includes('priority::high') ? '#991b1b' :
                                  label.includes('security') ? '#92400e' : '#047857',
                              }}>
                                {label.replace('::', ': ')}
                              </span>
                            ))}
                          </div>
                          {issue.assignee?.name && (
                            <span style={{
                              fontSize: '11px',
                              color: '#6b7280',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '4px',
                            }}>
                              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                                <circle cx="12" cy="7" r="4"/>
                              </svg>
                              {issue.assignee.name.split(' ')[0]}
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Chat Panel */}
      {chatState.isOpen && (
        <div style={{
          flex: '0 0 340px',
          display: 'flex',
          flexDirection: 'column',
          height: '700px',
          background: 'white',
          borderRadius: '12px',
          border: '1px solid #e5e7eb',
          overflow: 'hidden',
          boxShadow: '0 4px 20px rgba(0, 0, 0, 0.08)',
        }}>
          {/* Chat Header */}
          <div style={{
            padding: '14px 16px',
            background: 'linear-gradient(135deg, #8b5cf6 0%, #6366f1 100%)',
            color: 'white',
            fontWeight: 600,
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H6l-2 2V4h16v12z"/>
              </svg>
              Epic Feedback
            </div>
            <button
              onClick={toggleChat}
              style={{
                background: 'rgba(255,255,255,0.2)',
                border: 'none',
                borderRadius: '6px',
                cursor: 'pointer',
                color: 'white',
                width: '28px',
                height: '28px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
              </svg>
            </button>
          </div>

          {/* Chat Messages */}
          <div
            ref={chatMessagesRef}
            style={{
              flex: 1,
              overflowY: 'auto',
              padding: '16px',
              display: 'flex',
              flexDirection: 'column',
              gap: '12px',
              backgroundColor: '#f9fafb',
            }}
          >
            {/* Welcome message if no messages */}
            {chatState.messages.length === 0 && (
              <div style={{
                padding: '16px',
                background: 'white',
                borderRadius: '12px',
                border: '1px solid #e5e7eb',
                textAlign: 'center',
                color: '#6b7280',
              }}>
                <div style={{ fontSize: '24px', marginBottom: '8px' }}>
                  <svg width="32" height="32" viewBox="0 0 24 24" fill="#8b5cf6" style={{ margin: '0 auto' }}>
                    <path d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/>
                  </svg>
                </div>
                <div style={{ fontWeight: 500, marginBottom: '4px', color: '#374151' }}>AI-Powered Feedback</div>
                <div style={{ fontSize: '13px' }}>
                  Describe changes you'd like to make to your epic. I'll help you update specific sections.
                </div>
              </div>
            )}

            {/* Chat messages */}
            {chatState.messages.map((msg) => (
              <div
                key={msg.id}
                style={{
                  alignSelf: msg.role === 'user' ? 'flex-end' : 'flex-start',
                  maxWidth: '85%',
                }}
              >
                <div style={{
                  padding: '10px 14px',
                  borderRadius: msg.role === 'user' ? '14px 14px 4px 14px' : '14px 14px 14px 4px',
                  background: msg.role === 'user'
                    ? 'linear-gradient(135deg, #8b5cf6 0%, #6366f1 100%)'
                    : 'white',
                  color: msg.role === 'user' ? 'white' : '#374151',
                  border: msg.role === 'assistant' ? '1px solid #e5e7eb' : 'none',
                  boxShadow: msg.role === 'assistant' ? '0 1px 3px rgba(0,0,0,0.05)' : 'none',
                }}>
                  <div style={{ fontSize: '14px', lineHeight: '1.5' }}>{msg.content}</div>

                  {/* Section dropdown if needed and not answered */}
                  {msg.questionType === 'section-select' && !msg.isAnswered && (
                    <select
                      onChange={(e) => {
                        const sectionNum = parseInt(e.target.value);
                        if (sectionNum) handleSectionSelect(sectionNum, msg.id);
                      }}
                      style={{
                        marginTop: '10px',
                        width: '100%',
                        padding: '10px 12px',
                        borderRadius: '8px',
                        border: '1px solid #d1d5db',
                        backgroundColor: 'white',
                        fontSize: '13px',
                        cursor: 'pointer',
                      }}
                      defaultValue=""
                    >
                      <option value="" disabled>Select a section...</option>
                      {EPIC_SECTIONS.map(s => (
                        <option key={s.num} value={s.num}>{s.num}. {s.title}</option>
                      ))}
                    </select>
                  )}

                  {/* Show selected section */}
                  {msg.questionType === 'section-select' && msg.isAnswered && msg.selectedValue && (
                    <div style={{
                      marginTop: '8px',
                      padding: '6px 10px',
                      background: '#f3f4f6',
                      borderRadius: '6px',
                      fontSize: '12px',
                      color: '#6b7280',
                    }}>
                      Selected: {EPIC_SECTIONS[parseInt(msg.selectedValue) - 1]?.title}
                    </div>
                  )}

                  {/* Confirm buttons if needed and not answered */}
                  {msg.questionType === 'confirm' && !msg.isAnswered && (
                    <div style={{ marginTop: '10px', display: 'flex', gap: '8px' }}>
                      <button
                        onClick={() => handleConfirmSection(true, msg.id)}
                        style={{
                          flex: 1,
                          padding: '8px 12px',
                          borderRadius: '6px',
                          border: 'none',
                          background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
                          color: 'white',
                          fontSize: '13px',
                          fontWeight: 500,
                          cursor: 'pointer',
                        }}
                      >
                        Yes, update it
                      </button>
                      <button
                        onClick={() => handleConfirmSection(false, msg.id)}
                        style={{
                          flex: 1,
                          padding: '8px 12px',
                          borderRadius: '6px',
                          border: '1px solid #d1d5db',
                          background: 'white',
                          color: '#374151',
                          fontSize: '13px',
                          fontWeight: 500,
                          cursor: 'pointer',
                        }}
                      >
                        No, different
                      </button>
                    </div>
                  )}

                  {/* Show confirmation result */}
                  {msg.questionType === 'confirm' && msg.isAnswered && (
                    <div style={{
                      marginTop: '8px',
                      padding: '6px 10px',
                      background: '#f3f4f6',
                      borderRadius: '6px',
                      fontSize: '12px',
                      color: '#6b7280',
                    }}>
                      {msg.selectedValue === 'yes' ? 'Confirmed' : 'Selected different section'}
                    </div>
                  )}
                </div>
              </div>
            ))}

            {/* Processing indicator */}
            {chatState.isProcessing && (
              <div style={{
                alignSelf: 'flex-start',
                padding: '10px 14px',
                borderRadius: '14px 14px 14px 4px',
                background: 'white',
                border: '1px solid #e5e7eb',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                color: '#6b7280',
              }}>
                <div style={{
                  width: '8px',
                  height: '8px',
                  borderRadius: '50%',
                  background: '#8b5cf6',
                  animation: 'pulse 1s ease-in-out infinite',
                }} />
                Thinking...
              </div>
            )}
          </div>

          {/* Chat Input */}
          <div style={{
            padding: '12px',
            borderTop: '1px solid #e5e7eb',
            background: 'white',
            display: 'flex',
            gap: '8px',
          }}>
            <input
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendChatMessage();
                }
              }}
              placeholder="Describe what you'd like to change..."
              disabled={chatState.isProcessing}
              style={{
                flex: 1,
                padding: '10px 14px',
                borderRadius: '20px',
                border: '1px solid #d1d5db',
                fontSize: '14px',
                outline: 'none',
              }}
            />
            <button
              onClick={handleSendChatMessage}
              disabled={chatState.isProcessing || !chatInput.trim()}
              style={{
                padding: '10px 16px',
                borderRadius: '20px',
                border: 'none',
                background: chatInput.trim() && !chatState.isProcessing
                  ? 'linear-gradient(135deg, #8b5cf6 0%, #6366f1 100%)'
                  : '#e5e7eb',
                color: chatInput.trim() && !chatState.isProcessing ? 'white' : '#9ca3af',
                fontSize: '14px',
                fontWeight: 500,
                cursor: chatInput.trim() && !chatState.isProcessing ? 'pointer' : 'not-allowed',
                display: 'flex',
                alignItems: 'center',
                gap: '4px',
              }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
              </svg>
            </button>
          </div>
        </div>
      )}
      </>
      )}
    </div>
  );

  return (
    <div style={styles.appLayout}>
      {/* Sidebar Navigation - Premium Floating Card with Collapse */}
      <Sidebar
        activeItem={sidebarActive}
        onNavigate={handleSidebarNavigate}
        isCollapsed={sidebarCollapsed}
        onToggleCollapse={setSidebarCollapsed}
      />

      {/* Main Content Area */}
      <div style={styles.mainContent}>
        {/* Progress Card - Premium Glass Effect with Gold/Amber Stepper */}
        <div style={{ ...styles.glassCard, padding: '24px 32px' }}>
            {/* Progress Steps - Connected line stepper */}
            <div style={styles.progressContainer}>
              <div className="wizard-stepper" style={styles.progress}>
                {/* Background progress line - spans entire stepper */}
                <div
                  style={{
                    position: 'absolute',
                    top: '21px',
                    left: '45px',
                    right: '45px',
                    height: '4px',
                    background: 'linear-gradient(90deg, #E5E1DB, #D9D5CE)',
                    borderRadius: '2px',
                    zIndex: 0,
                  }}
                />
                {/* Filled progress line - shows completed progress */}
                <div
                  style={{
                    position: 'absolute',
                    top: '21px',
                    left: '45px',
                    height: '4px',
                    width: `calc(${(Math.max(0, state.currentStage) / STAGES.length) * 100}% * 0.86)`,
                    background: 'linear-gradient(90deg, #D4A853, #C4963F)',
                    borderRadius: '2px',
                    zIndex: 1,
                    transition: 'width 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
                  }}
                />
                {STAGES.map((stage, index) => {
                  const isActive = index === state.currentStage;
                  const isCompleted = index < state.currentStage;
                  return (
                    <div key={index} style={styles.progressStep}>
                      <div style={styles.progressDot(isActive, isCompleted)}>
                        {isCompleted ? (
                          <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
                          </svg>
                        ) : (
                          index + 1
                        )}
                      </div>
                      <div style={styles.progressLabel(isActive, isCompleted)}>
                        {stage.title}
                      </div>
                    </div>
                  );
                })}
                {/* Final step - Epic with document icon */}
                <div style={styles.progressStep}>
                  <div style={styles.progressDot(hasEpic && activeTab !== 'wizard', hasEpic)}>
                    {hasEpic ? (
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
                      </svg>
                    ) : (
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z"/>
                      </svg>
                    )}
                  </div>
                  <div style={styles.progressLabel(hasEpic && activeTab !== 'wizard', hasEpic)}>
                    Epic
                  </div>
                </div>
              </div>
            </div>
        </div>

        {/* Tabs Card - Premium Glass Effect */}
        <div style={{ ...styles.glassCard, padding: '6px 8px' }}>
            {/* Tab Navigation */}
            <div style={styles.tabsContainer}>
        <div style={styles.tabsGroup}>
          <button style={styles.tab(activeTab === 'wizard')} onClick={() => setActiveTab('wizard')}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" style={styles.tabIcon}>
              <path d="M13.5 5.5c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zM9.8 8.9L7 23h2.1l1.8-8 2.1 2v6h2v-7.5l-2.1-2 .6-3C14.8 12 16.8 13 19 13v-2c-1.9 0-3.5-1-4.3-2.4l-1-1.6c-.4-.6-1-1-1.7-1-.3 0-.5.1-.8.1L6 8.3V13h2V9.6l1.8-.7"/>
            </svg>
            Wizard
          </button>
          <button style={styles.tab(activeTab === 'epic')} onClick={() => setActiveTab('epic')}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" style={styles.tabIcon}>
              <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/>
            </svg>
            Epic Editor
          </button>
          {hasEpic && (
            <button style={styles.tab(activeTab === 'blueprint')} onClick={() => setActiveTab('blueprint')}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" style={styles.tabIcon}>
                <path d="M22 9V7h-2V5c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2v-2h2v-2h-2v-2h2v-2h-2V9h2zm-4 10H4V5h14v14zM6 13h5v4H6zm6-6h4v3h-4zM6 7h5v5H6zm6 4h4v6h-4z"/>
              </svg>
              Blueprint
            </button>
          )}
        </div>
        <button
          style={{
            ...styles.tab(activeTab === 'settings'),
            background: activeTab === 'settings' ? 'white' : 'transparent',
          }}
          onClick={() => setActiveTab('settings')}
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" style={styles.tabIcon}>
            <path d="M19.14 12.94c.04-.31.06-.63.06-.94 0-.31-.02-.63-.06-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.04.31-.06.63-.06.94s.02.63.06.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/>
          </svg>
          Settings
        </button>
            </div>
        </div>

        {/* Content Card - Premium Glass Effect */}
        <div style={{ ...styles.glassCard, flex: 1, display: 'flex', flexDirection: 'column' as const, overflow: 'auto', padding: '28px' }}>
      {/* Content */}
      {isGenerating ? (
        <div className="generation-progress" style={{ padding: '32px' }}>
          {/* Progress Header */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
            <span className="progress-percentage">{Math.round((generationProgress.current / generationProgress.total) * 100)}%</span>
            <span style={{ fontSize: '14px', color: '#666' }}>
              Section {generationProgress.current} of {generationProgress.total}
            </span>
          </div>

          {/* Progress Bar */}
          <div className="progress-bar-container">
            <div
              className="progress-bar-fill"
              style={{ width: `${(generationProgress.current / generationProgress.total) * 100}%` }}
            />
          </div>

          {/* Current Section */}
          <div style={{ textAlign: 'center', marginTop: '20px' }}>
            <div className="progress-section-name" style={{ marginBottom: '8px' }}>
              {generationProgress.section || 'Preparing...'}
            </div>
            <div style={{ fontSize: '13px', color: '#9ca3af' }}>
              Building your comprehensive epic document
            </div>
          </div>

          {/* Skeleton preview */}
          <div style={{ marginTop: '24px', opacity: 0.5 }}>
            <div className="skeleton" style={{ height: '60px', borderRadius: '8px', marginBottom: '12px' }} />
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
              <div className="skeleton" style={{ height: '40px', borderRadius: '8px' }} />
              <div className="skeleton" style={{ height: '40px', borderRadius: '8px' }} />
            </div>
          </div>
        </div>
      ) : activeTab === 'wizard' ? (
        renderWizard()
      ) : activeTab === 'blueprint' ? (
        renderBlueprint()
      ) : activeTab === 'settings' ? (
        renderSettings()
      ) : (
        renderEpicEditor()
      )}

      {/* Publish as Epic Modal */}
      {showPublishAsEpicModal && (
        <div style={{
          position: 'fixed',
          inset: 0,
          backgroundColor: 'rgba(0,0,0,0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div style={{
            backgroundColor: 'white',
            borderRadius: '12px',
            padding: '24px',
            width: '450px',
            maxWidth: '90%',
            boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)'
          }}>
            {/* Title changes based on Update vs Create mode */}
            <h3 style={{ margin: '0 0 16px 0', fontSize: '18px' }}>
              {selectedGitLabEpic ? 'Update Epic on GitLab' : 'Create Epic on GitLab'}
            </h3>

            {/* UPDATE MODE: Show which epic is being updated */}
            {selectedGitLabEpic ? (
              <>
                <div style={{
                  marginBottom: '16px',
                  padding: '16px',
                  backgroundColor: '#f0fdf4',
                  borderRadius: '8px',
                  border: '1px solid #86efac'
                }}>
                  <div style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    marginBottom: '8px'
                  }}>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#16a34a" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                      <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
                    </svg>
                    <span style={{ fontSize: '13px', fontWeight: 600, color: '#166534' }}>
                      Updating Existing Epic
                    </span>
                  </div>
                  <div style={{ fontSize: '14px', fontWeight: 600, color: '#1f2937' }}>
                    #{selectedGitLabEpic.iid} - {selectedGitLabEpic.title}
                  </div>
                  <div style={{ fontSize: '12px', color: '#6b7280', marginTop: '4px' }}>
                    Your changes in the editor will replace the current epic content.
                  </div>
                </div>

                <p style={{ fontSize: '13px', color: '#6b7280', marginBottom: '16px' }}>
                  The epic description will be updated with the current editor content.
                  Labels and hierarchy will remain unchanged.
                </p>
              </>
            ) : (
              <>
                {/* CREATE MODE: Show level selection and options */}
                <p style={{ fontSize: '13px', color: '#6b7280', marginBottom: '16px' }}>
                  This will create a new GitLab Epic with the generated content as its description.
                </p>

                {/* Epic Level Selection */}
                <div style={{ marginBottom: '16px' }}>
                  <label style={{ display: 'block', fontSize: '12px', color: '#6b7280', marginBottom: '8px', fontWeight: 500 }}>
                    Epic Level
                  </label>
                  <div style={{ display: 'flex', gap: '8px' }}>
                    <button
                      onClick={() => setPublishAsEpicLevel('crew')}
                      style={{
                        flex: 1,
                        padding: '12px',
                        borderRadius: '8px',
                        border: publishAsEpicLevel === 'crew' ? '2px solid #3b82f6' : '1px solid #e5e7eb',
                        backgroundColor: publishAsEpicLevel === 'crew' ? '#eff6ff' : 'white',
                        cursor: 'pointer',
                        textAlign: 'left'
                      }}
                    >
                      <div style={{ fontWeight: 600, fontSize: '14px', color: '#1e40af' }}>Crew Level</div>
                      <div style={{ fontSize: '11px', color: '#6b7280', marginTop: '4px' }}>High-level strategic epic</div>
                    </button>
                    <button
                      onClick={() => setPublishAsEpicLevel('pod')}
                      style={{
                        flex: 1,
                        padding: '12px',
                        borderRadius: '8px',
                        border: publishAsEpicLevel === 'pod' ? '2px solid #10b981' : '1px solid #e5e7eb',
                        backgroundColor: publishAsEpicLevel === 'pod' ? '#ecfdf5' : 'white',
                        cursor: 'pointer',
                        textAlign: 'left'
                      }}
                    >
                      <div style={{ fontWeight: 600, fontSize: '14px', color: '#166534' }}>Pod Level</div>
                      <div style={{ fontSize: '11px', color: '#6b7280', marginTop: '4px' }}>Implementation epic</div>
                    </button>
                  </div>
                </div>

                {/* Parent Epic Selection - Required for Pod Level */}
                {publishAsEpicLevel === 'pod' && (
                  <div style={{ marginBottom: '16px' }}>
                    <label style={{ display: 'block', fontSize: '12px', color: '#6b7280', marginBottom: '8px', fontWeight: 500 }}>
                      Parent Crew Epic <span style={{ color: '#ef4444' }}>*</span>
                    </label>
                    <select
                      value={publishAsEpicParentId || ''}
                      onChange={(e) => setPublishAsEpicParentId(e.target.value ? Number(e.target.value) : null)}
                      style={{
                        width: '100%',
                        padding: '10px',
                        borderRadius: '6px',
                        border: !publishAsEpicParentId ? '1px solid #fca5a5' : '1px solid #e5e7eb',
                        fontSize: '13px',
                        backgroundColor: !publishAsEpicParentId ? '#fef2f2' : 'white'
                      }}
                    >
                      <option value="">Select a parent crew epic...</option>
                      {gitlabEpics.filter(e => e.epicLevel === 'crew').map(epic => (
                        <option key={epic.id} value={epic.id}>{epic.title}</option>
                      ))}
                    </select>
                    <div style={{ fontSize: '11px', color: '#9ca3af', marginTop: '4px' }}>
                      Pod-level epics must be nested under a crew-level epic
                    </div>
                    {gitlabEpics.filter(e => e.epicLevel === 'crew').length === 0 && (
                      <div style={{ fontSize: '11px', color: '#ef4444', marginTop: '4px' }}>
                        No crew-level epics found. Search for epics in Settings first, or create a Crew Level epic.
                      </div>
                    )}
                  </div>
                )}

                {/* Epic Preview - Only for CREATE mode */}
                <div style={{ marginBottom: '16px', padding: '12px', backgroundColor: '#f9fafb', borderRadius: '6px' }}>
                  <div style={{ fontSize: '11px', color: '#6b7280', marginBottom: '4px' }}>Epic will be created as:</div>
                  <div style={{ fontSize: '14px', fontWeight: 600 }}>
                    {state.data['projectName']?.original || 'Untitled Epic'}
                  </div>
                  <div style={{ fontSize: '11px', color: '#6b7280', marginTop: '4px' }}>
                    Labels: <code style={{ backgroundColor: '#e5e7eb', padding: '2px 4px', borderRadius: '3px' }}>
                      {publishAsEpicLevel}::{(state.data['projectName']?.original || 'untitled').toLowerCase().replace(/\s+/g, '-')}
                    </code>, <code style={{ backgroundColor: '#e5e7eb', padding: '2px 4px', borderRadius: '3px' }}>epic-generator</code>
                  </div>
                </div>
              </>
            )}

            {/* Actions - Premium Modal Buttons */}
            <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end' }}>
              <button
                onClick={() => setShowPublishAsEpicModal(false)}
                style={{
                  padding: '11px 22px',
                  borderRadius: '8px',
                  border: '1px solid #E8E4E0',
                  background: 'linear-gradient(180deg, #FFFFFF 0%, #F9F7F5 100%)',
                  cursor: 'pointer',
                  fontSize: '13px',
                  fontWeight: 500,
                  color: '#5C5C5C',
                  boxShadow: '0 1px 2px rgba(0, 0, 0, 0.04), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
                  transition: 'all 0.2s cubic-bezier(0.34, 1.56, 0.64, 1)',
                }}
              >
                Cancel
              </button>
              <button
                onClick={selectedGitLabEpic ? handleUpdateGitLabEpic : handlePublishAsGitLabEpic}
                disabled={isPublishing || (!selectedGitLabEpic && publishAsEpicLevel === 'pod' && !publishAsEpicParentId)}
                style={{
                  padding: '11px 22px',
                  borderRadius: '8px',
                  border: 'none',
                  background: (isPublishing || (!selectedGitLabEpic && publishAsEpicLevel === 'pod' && !publishAsEpicParentId))
                    ? 'linear-gradient(180deg, #E5E7EB 0%, #D1D5DB 100%)'
                    : selectedGitLabEpic
                      ? 'linear-gradient(145deg, #22C55E 0%, #16A34A 50%, #15803D 100%)'
                      : 'linear-gradient(145deg, #8B5CF6 0%, #7C3AED 50%, #6D28D9 100%)',
                  color: 'white',
                  cursor: (isPublishing || (!selectedGitLabEpic && publishAsEpicLevel === 'pod' && !publishAsEpicParentId)) ? 'not-allowed' : 'pointer',
                  fontSize: '13px',
                  fontWeight: 500,
                  boxShadow: (isPublishing || (!selectedGitLabEpic && publishAsEpicLevel === 'pod' && !publishAsEpicParentId))
                    ? 'inset 0 1px 2px rgba(0, 0, 0, 0.05)'
                    : selectedGitLabEpic
                      ? '0 2px 4px rgba(34, 197, 94, 0.2), 0 4px 8px rgba(34, 197, 94, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.15)'
                      : '0 2px 4px rgba(139, 92, 246, 0.2), 0 4px 8px rgba(139, 92, 246, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.15)',
                  textShadow: (isPublishing || (!selectedGitLabEpic && publishAsEpicLevel === 'pod' && !publishAsEpicParentId)) ? 'none' : '0 1px 1px rgba(0, 0, 0, 0.1)',
                  transition: 'all 0.2s cubic-bezier(0.34, 1.56, 0.64, 1)',
                  opacity: (isPublishing || (!selectedGitLabEpic && publishAsEpicLevel === 'pod' && !publishAsEpicParentId)) ? 0.6 : 1,
                }}
              >
                {isPublishing
                  ? (selectedGitLabEpic ? 'Updating...' : 'Creating...')
                  : (selectedGitLabEpic ? 'Update Epic' : 'Create Epic')
                }
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Load Epic Modal */}
      {showLoadEpicModal && (
        <div style={{
          position: 'fixed',
          inset: 0,
          backgroundColor: 'rgba(0,0,0,0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div style={{
            backgroundColor: 'white',
            borderRadius: '12px',
            padding: '24px',
            width: '600px',
            maxWidth: '90%',
            maxHeight: '80vh',
            overflow: 'hidden',
            display: 'flex',
            flexDirection: 'column',
            boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1)'
          }}>
            <h3 style={{ margin: '0 0 16px 0', fontSize: '18px' }}>Load Epic from GitLab</h3>

            {/* Search Controls */}
            <div style={{ display: 'flex', gap: '8px', marginBottom: '16px' }}>
              <input
                type="text"
                placeholder="Search epics by title..."
                value={loadEpicSearchTerm}
                onChange={(e) => setLoadEpicSearchTerm(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearchEpicsForLoad()}
                style={{
                  flex: 1,
                  padding: '10px 12px',
                  borderRadius: '6px',
                  border: '1px solid #e5e7eb',
                  fontSize: '13px'
                }}
              />
              <select
                value={loadEpicFilterState}
                onChange={(e) => setLoadEpicFilterState(e.target.value as 'opened' | 'closed' | 'all')}
                style={{
                  width: '100px',
                  padding: '10px',
                  borderRadius: '6px',
                  border: '1px solid #e5e7eb',
                  fontSize: '13px'
                }}
              >
                <option value="opened">Open</option>
                <option value="closed">Closed</option>
                <option value="all">All</option>
              </select>
              <button
                onClick={handleSearchEpicsForLoad}
                disabled={loadingLoadEpicResults}
                style={{
                  padding: '10px 18px',
                  borderRadius: '8px',
                  border: 'none',
                  background: loadingLoadEpicResults
                    ? 'linear-gradient(180deg, #E5E7EB 0%, #D1D5DB 100%)'
                    : 'linear-gradient(145deg, #3B82F6 0%, #2563EB 50%, #1D4ED8 100%)',
                  color: 'white',
                  fontSize: '13px',
                  fontWeight: 500,
                  cursor: loadingLoadEpicResults ? 'not-allowed' : 'pointer',
                  boxShadow: loadingLoadEpicResults
                    ? 'inset 0 1px 2px rgba(0, 0, 0, 0.05)'
                    : '0 2px 4px rgba(59, 130, 246, 0.2), 0 4px 8px rgba(59, 130, 246, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.15)',
                  textShadow: loadingLoadEpicResults ? 'none' : '0 1px 1px rgba(0, 0, 0, 0.1)',
                  transition: 'all 0.2s cubic-bezier(0.34, 1.56, 0.64, 1)',
                  opacity: loadingLoadEpicResults ? 0.6 : 1,
                }}
              >
                {loadingLoadEpicResults ? 'Searching...' : 'Search'}
              </button>
            </div>

            {/* Epic List */}
            <div style={{
              flex: 1,
              overflowY: 'auto',
              border: '1px solid #e5e7eb',
              borderRadius: '6px',
              backgroundColor: '#fafafa',
              minHeight: '300px',
              maxHeight: '400px',
            }}>
              {loadEpicResults.length === 0 ? (
                <div style={{ padding: '40px 24px', textAlign: 'center', color: '#6b7280' }}>
                  <svg width="48" height="48" viewBox="0 0 24 24" fill="#d1d5db" style={{ marginBottom: '12px' }}>
                    <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
                  </svg>
                  <div style={{ fontSize: '14px', fontWeight: 500 }}>Search for epics</div>
                  <div style={{ fontSize: '12px', marginTop: '4px' }}>
                    Enter a search term and click Search to find epics
                  </div>
                </div>
              ) : (
                loadEpicResults.map(epic => (
                  <div
                    key={epic.id}
                    onClick={() => handleLoadEpicIntoEditor(epic.iid)}
                    style={{
                      padding: '12px 16px',
                      borderBottom: '1px solid #e5e7eb',
                      cursor: 'pointer',
                      backgroundColor: 'white',
                      transition: 'background-color 0.15s',
                    }}
                    onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#f3f4f6'}
                    onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'white'}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span style={{
                        padding: '2px 6px',
                        fontSize: '10px',
                        fontWeight: 600,
                        borderRadius: '4px',
                        backgroundColor: epic.epicLevel === 'crew' ? '#dbeafe' : epic.epicLevel === 'pod' ? '#dcfce7' : '#f3f4f6',
                        color: epic.epicLevel === 'crew' ? '#1e40af' : epic.epicLevel === 'pod' ? '#166534' : '#6b7280',
                      }}>
                        {epic.epicLevel === 'crew' ? 'CREW' : epic.epicLevel === 'pod' ? 'POD' : 'EPIC'}
                      </span>
                      <span style={{ fontWeight: 500, flex: 1, fontSize: '14px' }}>{epic.title}</span>
                      <span style={{
                        fontSize: '10px',
                        padding: '2px 6px',
                        borderRadius: '4px',
                        backgroundColor: epic.state === 'opened' ? '#dcfce7' : '#fee2e2',
                        color: epic.state === 'opened' ? '#166534' : '#991b1b',
                      }}>
                        {epic.state}
                      </span>
                    </div>
                    <div style={{ fontSize: '11px', color: '#6b7280', marginTop: '6px' }}>
                      #{epic.iid} • Updated {new Date(epic.updated_at).toLocaleDateString()}
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Actions - Premium Modal Button */}
            <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end', marginTop: '16px' }}>
              <button
                onClick={() => {
                  setShowLoadEpicModal(false);
                  setLoadEpicResults([]);
                  setLoadEpicSearchTerm('');
                }}
                style={{
                  padding: '11px 22px',
                  borderRadius: '8px',
                  border: '1px solid #E8E4E0',
                  background: 'linear-gradient(180deg, #FFFFFF 0%, #F9F7F5 100%)',
                  cursor: 'pointer',
                  fontSize: '13px',
                  fontWeight: 500,
                  color: '#5C5C5C',
                  boxShadow: '0 1px 2px rgba(0, 0, 0, 0.04), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
                  transition: 'all 0.2s cubic-bezier(0.34, 1.56, 0.64, 1)',
                }}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* AI Critique Report Modal */}
      {refinementState.showReport && refinementState.report && (
        <div style={{
          position: 'fixed',
          inset: 0,
          backgroundColor: 'rgba(0,0,0,0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div style={{
            backgroundColor: 'white',
            borderRadius: '12px',
            padding: '24px',
            width: '700px',
            maxWidth: '95%',
            maxHeight: '85vh',
            overflow: 'hidden',
            display: 'flex',
            flexDirection: 'column',
            boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1)',
            position: 'relative'
          }}>
            {/* Loading Overlay - shown when applying suggestions */}
            {isApplyingSuggestions && (
              <div style={{
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                backgroundColor: 'rgba(255, 255, 255, 0.95)',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                zIndex: 10,
                borderRadius: '12px'
              }}>
                {/* Spinner */}
                <div style={{
                  width: '48px',
                  height: '48px',
                  border: '4px solid #e5e7eb',
                  borderTop: '4px solid #10b981',
                  borderRadius: '50%',
                  animation: 'spin 1s linear infinite'
                }} />

                {/* Status Text */}
                <div style={{
                  marginTop: '16px',
                  fontSize: '16px',
                  fontWeight: 600,
                  color: '#374151'
                }}>
                  {applySuggestionsProgress.phase === 'applying'
                    ? `Applying AI Suggestions... (${applySuggestionsProgress.current}/${applySuggestionsProgress.total})`
                    : 'Updating critique report...'
                  }
                </div>

                {/* Sub-text */}
                <div style={{
                  marginTop: '8px',
                  fontSize: '13px',
                  color: '#6b7280'
                }}>
                  {applySuggestionsProgress.phase === 'applying'
                    ? 'AI is improving weak sections'
                    : 'Recalculating scores with improvements'
                  }
                </div>
              </div>
            )}

            {/* Header */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
              <h3 style={{ margin: 0, fontSize: '20px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <svg width="24" height="24" viewBox="0 0 24 24" fill="#f59e0b">
                  <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/>
                </svg>
                AI Critique Report
              </h3>
              <button
                onClick={() => setRefinementState(prev => ({ ...prev, showReport: false }))}
                style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '20px', color: '#6b7280' }}
              >
                ✕
              </button>
            </div>

            {/* Score Box */}
            <div style={{
              padding: '16px',
              borderRadius: '10px',
              backgroundColor: refinementState.report.overallScore >= 8 ? '#dcfce7' :
                             refinementState.report.overallScore >= 5 ? '#fef3c7' : '#fee2e2',
              marginBottom: '20px'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '16px', marginBottom: '12px' }}>
                <div style={{
                  fontSize: '36px',
                  fontWeight: 'bold',
                  color: refinementState.report.overallScore >= 8 ? '#166534' :
                         refinementState.report.overallScore >= 5 ? '#92400e' : '#991b1b',
                }}>
                  {refinementState.report.overallScore.toFixed(1)}/10
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{
                    height: '8px',
                    backgroundColor: '#e5e7eb',
                    borderRadius: '4px',
                    overflow: 'hidden'
                  }}>
                    <div style={{
                      width: `${refinementState.report.overallScore * 10}%`,
                      height: '100%',
                      backgroundColor: refinementState.report.overallScore >= 8 ? '#22c55e' :
                                      refinementState.report.overallScore >= 5 ? '#f59e0b' : '#ef4444',
                      borderRadius: '4px',
                      transition: 'width 0.5s ease'
                    }} />
                  </div>
                </div>
              </div>
              <p style={{ margin: 0, fontSize: '13px', color: '#374151', lineHeight: 1.5 }}>
                {refinementState.report.summary}
              </p>
            </div>

            {/* Critical Issues */}
            {refinementState.report.criticalIssues.length > 0 && (
              <div style={{ marginBottom: '16px' }}>
                <div style={{ fontSize: '13px', fontWeight: 600, color: '#991b1b', marginBottom: '8px', display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <span style={{ fontSize: '14px' }}>⚠️</span>
                  Critical Issues ({refinementState.report.criticalIssues.length})
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
                  {refinementState.report.criticalIssues.map((issue, i) => (
                    <div key={i} style={{ fontSize: '12px', color: '#991b1b', padding: '6px 10px', backgroundColor: '#fef2f2', borderRadius: '4px' }}>
                      {issue}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Section Breakdown - Scrollable */}
            <div style={{ flex: 1, overflow: 'auto', marginBottom: '16px' }}>
              <div style={{ fontSize: '13px', fontWeight: 600, color: '#374151', marginBottom: '12px' }}>
                Section Breakdown
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {refinementState.report.sections.map((section) => (
                  <div
                    key={section.sectionNum}
                    style={{
                      padding: '12px',
                      borderRadius: '8px',
                      border: '1px solid #e5e7eb',
                      backgroundColor: section.status === 'strong' ? '#f0fdf4' :
                                      section.status === 'adequate' ? '#fffbeb' :
                                      section.status === 'weak' ? '#fef2f2' : '#f9fafb'
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' }}>
                      <span style={{ fontSize: '14px' }}>
                        {section.status === 'strong' ? '✅' :
                         section.status === 'adequate' ? '🔶' :
                         section.status === 'weak' ? '⚠️' : '❌'}
                      </span>
                      <span style={{ fontWeight: 600, fontSize: '13px', flex: 1 }}>
                        {section.sectionNum}. {section.sectionTitle}
                      </span>
                      <span style={{
                        padding: '2px 8px',
                        borderRadius: '10px',
                        fontSize: '11px',
                        fontWeight: 600,
                        backgroundColor: section.status === 'strong' ? '#dcfce7' :
                                        section.status === 'adequate' ? '#fef3c7' :
                                        section.status === 'weak' ? '#fee2e2' : '#f3f4f6',
                        color: section.status === 'strong' ? '#166534' :
                               section.status === 'adequate' ? '#92400e' :
                               section.status === 'weak' ? '#991b1b' : '#6b7280'
                      }}>
                        {section.score}/10
                      </span>
                    </div>
                    {section.issues.length > 0 && (
                      <div style={{ fontSize: '12px', color: '#6b7280', marginLeft: '26px' }}>
                        {section.issues.map((issue, i) => (
                          <div key={i} style={{ marginBottom: '2px' }}>• {issue}</div>
                        ))}
                      </div>
                    )}
                    {section.suggestions.length > 0 && (
                      <div style={{ fontSize: '12px', color: '#059669', marginLeft: '26px', marginTop: '4px' }}>
                        {section.suggestions.map((sug, i) => (
                          <div key={i} style={{ marginBottom: '2px' }}>→ {sug}</div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Strengths */}
            {refinementState.report.strengthAreas.length > 0 && (
              <div style={{ marginBottom: '16px' }}>
                <div style={{ fontSize: '13px', fontWeight: 600, color: '#166534', marginBottom: '8px', display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <span style={{ fontSize: '14px' }}>✓</span>
                  Strengths
                </div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                  {refinementState.report.strengthAreas.map((strength, i) => (
                    <span key={i} style={{ fontSize: '11px', padding: '4px 10px', backgroundColor: '#dcfce7', color: '#166534', borderRadius: '12px' }}>
                      {strength}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Actions - Premium Modal Buttons */}
            <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end', borderTop: '1px solid #E8E4E0', paddingTop: '16px' }}>
              <button
                onClick={() => {
                  // Export report as text
                  const reportText = `AI Critique Report\n${'='.repeat(50)}\n\nOverall Score: ${refinementState.report!.overallScore.toFixed(1)}/10\n\nSummary:\n${refinementState.report!.summary}\n\nCritical Issues:\n${refinementState.report!.criticalIssues.map(i => '- ' + i).join('\n') || 'None'}\n\nSection Breakdown:\n${refinementState.report!.sections.map(s => `${s.sectionNum}. ${s.sectionTitle}: ${s.score}/10 (${s.status})\n   Issues: ${s.issues.join(', ') || 'None'}\n   Suggestions: ${s.suggestions.join(', ') || 'None'}`).join('\n\n')}\n\nStrengths:\n${refinementState.report!.strengthAreas.map(s => '- ' + s).join('\n') || 'None'}`;
                  navigator.clipboard.writeText(reportText);
                  showToast('success', 'Report Copied', 'Critique report copied to clipboard');
                }}
                style={{
                  padding: '11px 22px',
                  borderRadius: '8px',
                  border: '1px solid #E8E4E0',
                  background: 'linear-gradient(180deg, #FFFFFF 0%, #F9F7F5 100%)',
                  cursor: 'pointer',
                  fontSize: '13px',
                  fontWeight: 500,
                  color: '#5C5C5C',
                  boxShadow: '0 1px 2px rgba(0, 0, 0, 0.04), inset 0 1px 0 rgba(255, 255, 255, 0.8)',
                  transition: 'all 0.2s cubic-bezier(0.34, 1.56, 0.64, 1)',
                }}
              >
                Export Report
              </button>
              {refinementState.report.sections.filter(s => s.status === 'weak' || s.status === 'missing').length > 0 && (
                <button
                  onClick={handleApplySuggestions}
                  disabled={isApplyingSuggestions}
                  style={{
                    padding: '11px 22px',
                    borderRadius: '8px',
                    border: 'none',
                    background: isApplyingSuggestions
                      ? 'linear-gradient(180deg, #E5E7EB 0%, #D1D5DB 100%)'
                      : 'linear-gradient(145deg, #22C55E 0%, #16A34A 50%, #15803D 100%)',
                    color: 'white',
                    cursor: isApplyingSuggestions ? 'not-allowed' : 'pointer',
                    fontSize: '13px',
                    fontWeight: 500,
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    boxShadow: isApplyingSuggestions
                      ? 'inset 0 1px 2px rgba(0, 0, 0, 0.05)'
                      : '0 2px 4px rgba(34, 197, 94, 0.2), 0 4px 8px rgba(34, 197, 94, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.15)',
                    textShadow: isApplyingSuggestions ? 'none' : '0 1px 1px rgba(0, 0, 0, 0.1)',
                    transition: 'all 0.2s cubic-bezier(0.34, 1.56, 0.64, 1)',
                    opacity: isApplyingSuggestions ? 0.6 : 1,
                  }}
                >
                  {isApplyingSuggestions && (
                    <span style={{
                      display: 'inline-block',
                      width: '14px',
                      height: '14px',
                      border: '2px solid rgba(255,255,255,0.3)',
                      borderTop: '2px solid white',
                      borderRadius: '50%',
                      animation: 'spin 0.8s linear infinite'
                    }} />
                  )}
                  {isApplyingSuggestions
                    ? 'Applying...'
                    : `Apply AI Suggestions (${refinementState.report.sections.filter(s => s.status === 'weak' || s.status === 'missing').length})`
                  }
                </button>
              )}
              <button
                onClick={() => setRefinementState(prev => ({ ...prev, showReport: false }))}
                style={{
                  padding: '11px 22px',
                  borderRadius: '8px',
                  border: 'none',
                  background: 'linear-gradient(145deg, #3B82F6 0%, #2563EB 50%, #1D4ED8 100%)',
                  color: 'white',
                  cursor: 'pointer',
                  fontSize: '13px',
                  fontWeight: 500,
                  boxShadow: '0 2px 4px rgba(59, 130, 246, 0.2), 0 4px 8px rgba(59, 130, 246, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.15)',
                  textShadow: '0 1px 1px rgba(0, 0, 0, 0.1)',
                  transition: 'all 0.2s cubic-bezier(0.34, 1.56, 0.64, 1)',
                }}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Toast Notifications */}
      <div className="toast-container">
        {toasts.map(toast => (
          <div
            key={toast.id}
            className={`toast toast-${toast.type}${toast.exiting ? ' toast-exit' : ''}`}
          >
            <div className="toast-icon">
              <ToastIcon type={toast.type} />
            </div>
            <div className="toast-content">
              <div className="toast-title">{toast.title}</div>
              {toast.message && <div className="toast-message">{toast.message}</div>}
            </div>
            <div
              className="toast-progress"
              style={{
                animation: `progressShrink ${toast.duration || 3000}ms linear forwards`,
              }}
            />
          </div>
        ))}
      </div>

      {/* Confetti Celebration */}
      <Confetti active={showConfetti} />
        </div>
      </div>
    </div>
  );
}
