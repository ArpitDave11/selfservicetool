# Epic Generator - Installation Guide

## Prerequisites

1. **Node.js** (v18 or higher)
   - Download from: https://nodejs.org/
   - Or use nvm: `nvm install 20`

2. **npm** (comes with Node.js)

## Quick Start

### 1. Extract the zip file

```bash
unzip epic-generator.zip
cd epic-generator
```

### 2. Install dependencies

```bash
npm install
```

### 3. Run the development server

```bash
npm run dev
```

### 4. Open in browser

Navigate to: http://localhost:3002

## Configuration

### LLM Provider Setup (Optional)

By default, the app runs in **Mock mode** (no API calls). To enable real AI:

1. Click the **Settings** tab
2. Select your provider:
   - **OpenAI**: Get API key from https://platform.openai.com/api-keys
   - **Anthropic**: Get API key from https://console.anthropic.com/
   - **Azure OpenAI**: Use your Azure deployment URL and key
3. Enter your API key
4. Select a model
5. Settings are saved automatically to localStorage

### GitLab Integration Setup (Optional)

1. Click the **Settings** tab
2. Enable GitLab integration
3. Configure:
   - **GitLab URL**: `https://gitlab.com` or your self-hosted URL
   - **Project ID**: Your project path (e.g., `username/project-name`) or numeric ID
   - **Access Token**: Create at GitLab → Settings → Access Tokens with `api` scope
   - **Branch**: Target branch (default: `main`)
   - **Epic File Path**: Directory for epics (e.g., `docs/epics/`)
4. Click "Test Connection" to verify

## Production Build

To build for production:

```bash
npm run build
```

Output will be in the `dist/` folder. Serve with any static file server:

```bash
npm run preview
# or
npx serve dist
```

## Project Structure

```
epic-generator/
├── index.html          # Entry HTML
├── package.json        # Dependencies
├── vite.config.js      # Vite configuration
├── tsconfig.json       # TypeScript config
└── src/
    ├── main.tsx        # React entry point
    ├── App.tsx         # Main application
    ├── types.ts        # TypeScript types
    ├── skills.ts       # AI skills & prompts
    ├── config.ts       # LLM & GitLab config
    └── MarkdownPreview.tsx  # Markdown renderer
```

## Features

- **6-Stage Wizard**: Project → Objective → Architecture → Features → Team → Delivery
- **AI Suggestions**: Click "Suggest" to get AI-powered content (requires API key)
- **17-Section Epic**: Generates comprehensive technical design document
- **Live Preview**: Split-screen markdown editor with GitHub-style preview
- **Mermaid Diagrams**: Embedded architecture diagrams
- **PlantUML Blueprint**: 7-layer epic visualization
- **GitLab Push**: Publish directly to GitLab repository

## Troubleshooting

### Port already in use
```bash
npm run dev -- --port 3003
```

### Node version issues
```bash
node --version  # Should be v18+
nvm use 20      # If using nvm
```

### Clear cache
```bash
rm -rf node_modules
npm install
```

## License

MIT
