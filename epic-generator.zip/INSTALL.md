# Epic Generator - Installation Guide

## Prerequisites

1. **Node.js** (v18 or higher)
   - Download from: https://nodejs.org/
   - Or use nvm: `nvm install 20`

2. **npm** (comes with Node.js)

## Quick Start

### 1. Extract the zip file

```bash
unzip epic-generator.zip
cd epic-generator
```

### 2. Install dependencies

```bash
npm install
```

### 3. Run the development server

```bash
npm run dev
```

### 4. Open in browser

Navigate to: http://localhost:3002

## Configuration

### Azure OpenAI Setup (Optional)

By default, the app runs in **Mock mode** (no API calls). To enable real AI:

1. Click the **Settings** tab
2. Enable Azure OpenAI
3. Configure:
   - **Endpoint**: Your Azure OpenAI resource URL (e.g., `https://your-resource.openai.azure.com`)
   - **Deployment Name**: Your model deployment name
   - **API Key**: Your Azure OpenAI API key
   - **API Version**: Select the API version (default: `2024-02-15-preview`)
4. Click "Test Connection" to verify
5. Settings are saved automatically to localStorage

### GitLab Integration Setup (Optional)

1. Click the **Settings** tab
2. Enable GitLab integration
3. Configure:
   - **GitLab URL**: `https://gitlab.com` or your self-hosted URL
   - **Project ID**: Your project path (e.g., `username/project-name`) or numeric ID
   - **Access Token**: Create at GitLab → Settings → Access Tokens with `api` scope
   - **Branch**: Target branch (default: `main`)
   - **Epic File Path**: Directory for epics (e.g., `docs/epics/`)
4. Click "Test Connection" to verify

## Production Build

To build for production:

```bash
npm run build
```

Output will be in the `dist/` folder. Serve with any static file server:

```bash
npm run preview
# or
npx serve dist
```

## Project Structure

```
epic-generator/
├── index.html          # Entry HTML
├── package.json        # Dependencies
├── package-lock.json   # Locked dependencies
├── vite.config.js      # Vite configuration
├── tsconfig.json       # TypeScript config
├── INSTALL.md          # This file
└── src/
    ├── main.tsx        # React entry point
    ├── App.tsx         # Main application (UI + logic)
    ├── styles.css      # CSS animations & styles
    ├── types.ts        # TypeScript types
    ├── skills.ts       # AI skills & prompts
    ├── config.ts       # Azure OpenAI & GitLab config
    └── MarkdownPreview.tsx  # Markdown renderer with Mermaid
```

## Features

- **6-Stage Wizard**: Project → Objective → Architecture → Features → Team → Delivery
- **AI Suggestions**: Click "Suggest" to get AI-powered content (requires Azure OpenAI)
- **17-Section Epic**: Generates comprehensive technical design document
- **Live Preview**: Split-screen markdown editor with GitHub-style preview
- **Mermaid Diagrams**: Embedded architecture diagrams
- **PlantUML Blueprint**: Intelligent diagram generation based on epic content
- **GitLab Push**: Publish directly to GitLab repository

## Troubleshooting

### Port already in use
```bash
npm run dev -- --port 3003
```

### Node version issues
```bash
node --version  # Should be v18+
nvm use 20      # If using nvm
```

### Clear cache
```bash
rm -rf node_modules
npm install
```

## Remote Desktop Deployment

If you're deploying on a remote desktop environment:

### Windows Remote Desktop

1. **Install Node.js**:
   - Download the Windows installer from https://nodejs.org/
   - Or use Chocolatey: `choco install nodejs`

2. **Extract and Run**:
   ```cmd
   # Extract the zip file
   # Open Command Prompt or PowerShell in the extracted folder

   npm install
   npm run dev
   ```

3. **Access via browser**: Open http://localhost:3002

### Linux Remote Desktop (VNC/RDP)

1. **Install Node.js**:
   ```bash
   # Ubuntu/Debian
   curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
   sudo apt-get install -y nodejs

   # Or using nvm
   curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
   nvm install 20
   ```

2. **Extract and Run**:
   ```bash
   unzip epic-generator.zip
   cd epic-generator
   npm install
   npm run dev
   ```

### Running as Background Service

To keep the server running after closing the terminal:

```bash
# Using nohup
nohup npm run dev &

# Or using pm2 (recommended)
npm install -g pm2
pm2 start "npm run dev" --name epic-generator
pm2 save

# View logs
pm2 logs epic-generator

# Stop
pm2 stop epic-generator
```

### Network Access (Allow Remote Connections)

If you need to access from another machine on the network:

1. Modify `vite.config.js` to add host:
   ```js
   export default {
     plugins: [react()],
     server: {
       host: '0.0.0.0',  // Allow network access
       port: 3002
     }
   }
   ```

2. Access via: `http://<remote-desktop-ip>:3002`

## License

MIT
