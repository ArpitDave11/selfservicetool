// Epic Generator - Main Application with AI Assistance

import { useState, useCallback, useEffect } from 'react';
import { STAGES, EPIC_SECTIONS, type RefinedData, type EpicState } from './types';
import { runSkill, getSuggestion, generatePlantUMLBlueprint, type RefineResult, type GenerateResult } from './skills';
import MarkdownPreview from './MarkdownPreview';
import plantumlEncoder from 'plantuml-encoder';
import {
  type AppConfig,
  DEFAULT_CONFIG,
  AZURE_API_VERSIONS,
  loadConfig,
  saveConfig,
  publishToGitLab,
  testGitLabConnection,
  testAzureOpenAI,
} from './config';

// Initial state
const initialState: EpicState = {
  currentStage: 0,
  data: {},
  diagramNodes: [],
  generatedEpic: null,
};

// Styles
const styles = {
  container: { maxWidth: '1400px', margin: '0 auto', padding: '20px', fontFamily: 'system-ui, sans-serif' },
  header: { textAlign: 'center' as const, marginBottom: '30px' },
  title: { fontSize: '28px', fontWeight: 'bold', color: '#1a1a2e' },
  subtitle: { color: '#666', marginTop: '8px' },
  progress: { display: 'flex', justifyContent: 'center', gap: '8px', marginBottom: '30px' },
  progressDot: (active: boolean, completed: boolean) => ({
    width: '12px', height: '12px', borderRadius: '50%',
    backgroundColor: completed ? '#10b981' : active ? '#3b82f6' : '#e5e7eb',
    transition: 'all 0.3s',
  }),
  card: { backgroundColor: 'white', borderRadius: '12px', padding: '24px', boxShadow: '0 2px 8px rgba(0,0,0,0.1)', marginBottom: '20px' },
  stageTitle: { fontSize: '20px', fontWeight: '600', marginBottom: '8px', color: '#1a1a2e' },
  stageDesc: { color: '#666', marginBottom: '20px' },
  fieldGroup: { marginBottom: '20px' },
  labelRow: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' },
  label: { fontWeight: '500', color: '#374151' },
  input: { width: '100%', padding: '10px 12px', border: '1px solid #d1d5db', borderRadius: '8px', fontSize: '14px', boxSizing: 'border-box' as const },
  textarea: { width: '100%', padding: '10px 12px', border: '1px solid #d1d5db', borderRadius: '8px', fontSize: '14px', minHeight: '100px', resize: 'vertical' as const, boxSizing: 'border-box' as const },
  buttonRow: { display: 'flex', gap: '12px', justifyContent: 'flex-end', marginTop: '20px' },
  button: (primary: boolean) => ({
    padding: '10px 20px', borderRadius: '8px', border: 'none', cursor: 'pointer', fontWeight: '500',
    backgroundColor: primary ? '#3b82f6' : '#e5e7eb', color: primary ? 'white' : '#374151',
  }),
  suggestButton: {
    padding: '4px 10px', borderRadius: '6px', border: '1px solid #8b5cf6', cursor: 'pointer',
    backgroundColor: 'white', color: '#8b5cf6', fontSize: '12px', fontWeight: '500',
    display: 'flex', alignItems: 'center', gap: '4px',
  },
  suggestButtonLoading: {
    padding: '4px 10px', borderRadius: '6px', border: '1px solid #d1d5db', cursor: 'not-allowed',
    backgroundColor: '#f3f4f6', color: '#9ca3af', fontSize: '12px', fontWeight: '500',
  },
  refinedSection: {
    marginTop: '12px', padding: '12px', backgroundColor: '#f0fdf4', borderRadius: '8px',
    border: '1px solid #bbf7d0',
  },
  refinedHeader: {
    display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px',
  },
  refinedBadge: {
    display: 'inline-flex', alignItems: 'center', gap: '4px', padding: '2px 8px',
    backgroundColor: '#dcfce7', color: '#166534', borderRadius: '4px', fontSize: '12px', fontWeight: '500',
  },
  editButton: {
    padding: '2px 8px', borderRadius: '4px', border: '1px solid #22c55e', cursor: 'pointer',
    backgroundColor: 'white', color: '#22c55e', fontSize: '11px',
  },
  refinedTextarea: {
    width: '100%', padding: '8px', border: '1px solid #bbf7d0', borderRadius: '6px',
    fontSize: '13px', backgroundColor: 'white', minHeight: '80px', resize: 'vertical' as const,
    boxSizing: 'border-box' as const,
  },
  refinedPreview: {
    fontSize: '13px', color: '#374151', whiteSpace: 'pre-wrap' as const, lineHeight: '1.5',
  },
  alternativesSection: {
    marginTop: '8px', padding: '8px', backgroundColor: '#faf5ff', borderRadius: '6px',
    border: '1px dashed #c4b5fd',
  },
  alternativeChip: {
    display: 'inline-block', padding: '4px 8px', margin: '2px', borderRadius: '4px',
    backgroundColor: 'white', border: '1px solid #c4b5fd', cursor: 'pointer', fontSize: '12px',
    color: '#7c3aed',
  },
  tabs: { display: 'flex', gap: '4px', marginBottom: '16px' },
  tab: (active: boolean) => ({ padding: '8px 16px', borderRadius: '6px', border: 'none', cursor: 'pointer', backgroundColor: active ? '#3b82f6' : '#e5e7eb', color: active ? 'white' : '#374151' }),
  sectionPreview: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '8px', marginTop: '16px' },
  sectionChip: (populated: boolean) => ({ padding: '8px 12px', borderRadius: '6px', fontSize: '13px', backgroundColor: populated ? '#dcfce7' : '#f3f4f6', color: populated ? '#166534' : '#9ca3af' }),
  helpBanner: {
    padding: '12px 16px', backgroundColor: '#eff6ff', borderRadius: '8px', marginBottom: '20px',
    display: 'flex', alignItems: 'center', gap: '10px', border: '1px solid #bfdbfe',
  },
  helpIcon: { fontSize: '20px' },
  helpText: { fontSize: '14px', color: '#1e40af' },
  // Split screen styles
  splitContainer: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '16px',
    height: 'calc(100vh - 200px)',
    minHeight: '600px',
  },
  splitPane: {
    display: 'flex',
    flexDirection: 'column' as const,
    height: '100%',
    overflow: 'hidden',
  },
  paneHeader: {
    padding: '12px 16px',
    backgroundColor: '#f6f8fa',
    borderBottom: '1px solid #d0d7de',
    fontWeight: '600',
    fontSize: '14px',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderRadius: '8px 8px 0 0',
  },
  editorPane: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column' as const,
    border: '1px solid #d0d7de',
    borderRadius: '8px',
    overflow: 'hidden',
    backgroundColor: 'white',
  },
  previewPane: {
    flex: 1,
    border: '1px solid #d0d7de',
    borderRadius: '8px',
    overflow: 'auto',
    backgroundColor: 'white',
  },
  editor: {
    flex: 1,
    width: '100%',
    padding: '16px',
    border: 'none',
    outline: 'none',
    resize: 'none' as const,
    fontSize: '14px',
    fontFamily: 'ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace',
    lineHeight: '1.6',
    boxSizing: 'border-box' as const,
  },
  actionBar: {
    padding: '12px 16px',
    backgroundColor: '#f6f8fa',
    borderTop: '1px solid #d0d7de',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
};

export default function App() {
  const [state, setState] = useState<EpicState>(initialState);
  const [formData, setFormData] = useState<Record<string, string>>({});
  const [editingRefined, setEditingRefined] = useState<Record<string, boolean>>({});
  const [loadingSuggestion, setLoadingSuggestion] = useState<Record<string, boolean>>({});
  const [alternatives, setAlternatives] = useState<Record<string, string[]>>({});
  const [isRefining, setIsRefining] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeTab, setActiveTab] = useState<'wizard' | 'epic' | 'blueprint' | 'settings'>('wizard');
  const [editableEpic, setEditableEpic] = useState<string>('');
  const [blueprintCode, setBlueprintCode] = useState<string>('');

  // Config state
  const [config, setConfig] = useState<AppConfig>(DEFAULT_CONFIG);
  const [isPublishing, setIsPublishing] = useState(false);
  const [publishStatus, setPublishStatus] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [gitlabTestStatus, setGitlabTestStatus] = useState<{ testing: boolean; result?: string } | null>(null);
  const [azureTestStatus, setAzureTestStatus] = useState<{ testing: boolean; result?: string } | null>(null);

  // Load config on mount
  useEffect(() => {
    setConfig(loadConfig());
  }, []);

  // Save config when it changes
  const updateConfig = (newConfig: AppConfig) => {
    setConfig(newConfig);
    saveConfig(newConfig);
  };

  const currentStage = STAGES[state.currentStage];
  const isLastStage = state.currentStage === STAGES.length - 1;
  const hasEpic = state.generatedEpic !== null;

  // Build context from all data
  const getContext = useCallback(() => {
    const context: Record<string, string> = {};
    Object.entries(formData).forEach(([key, value]) => {
      context[key] = value;
    });
    Object.entries(state.data).forEach(([key, value]) => {
      context[key] = value.original;
    });
    return context;
  }, [formData, state.data]);

  // Handle field input
  const handleFieldChange = (fieldName: string, value: string) => {
    setFormData(prev => ({ ...prev, [fieldName]: value }));
  };

  // Handle refined content edit
  const handleRefinedChange = (fieldName: string, value: string) => {
    setState(prev => ({
      ...prev,
      data: {
        ...prev.data,
        [fieldName]: {
          ...prev.data[fieldName],
          refined: value,
        },
      },
    }));
  };

  // Get AI suggestion for a field
  const handleGetSuggestion = async (fieldName: string) => {
    setLoadingSuggestion(prev => ({ ...prev, [fieldName]: true }));

    const context = getContext();
    const result = await getSuggestion(currentStage.id, fieldName, context);

    setFormData(prev => ({ ...prev, [fieldName]: result.suggestion }));
    if (result.alternatives) {
      setAlternatives(prev => ({ ...prev, [fieldName]: result.alternatives! }));
    }

    setLoadingSuggestion(prev => ({ ...prev, [fieldName]: false }));
  };

  // Use an alternative suggestion
  const handleUseAlternative = (fieldName: string, alt: string) => {
    setFormData(prev => ({ ...prev, [fieldName]: alt }));
  };

  // Refine current stage inputs
  const refineStage = useCallback(async () => {
    setIsRefining(true);
    const newData = { ...state.data };
    const newDiagramNodes = [...state.diagramNodes];

    const context = getContext();

    // Refine each field in the current stage
    for (const field of currentStage.fields) {
      const input = formData[field.name] || '';
      if (input.trim()) {
        const result = await runSkill('refine', {
          stageId: currentStage.id,
          fieldName: field.name,
          input,
          context,
        }) as RefineResult;

        newData[field.name] = {
          original: input,
          refined: result.refined,
          diagramNode: result.diagramNode,
        };

        // Only add diagram node if not already present
        if (!newDiagramNodes.includes(result.diagramNode)) {
          newDiagramNodes.push(result.diagramNode);
        }
      }
    }

    setState(prev => ({
      ...prev,
      data: newData,
      diagramNodes: newDiagramNodes,
    }));
    setIsRefining(false);
  }, [currentStage, formData, state.data, state.diagramNodes, getContext]);

  // Navigate to next stage
  const nextStage = async () => {
    await refineStage();
    if (isLastStage) {
      generateEpic();
    } else {
      setState(prev => ({ ...prev, currentStage: prev.currentStage + 1 }));
      setFormData({});
      setAlternatives({});
      setEditingRefined({});
    }
  };

  // Navigate to previous stage
  const prevStage = () => {
    if (state.currentStage > 0) {
      setState(prev => ({ ...prev, currentStage: prev.currentStage - 1 }));
      // Restore form data for previous stage
      const prevStageFields = STAGES[state.currentStage - 1].fields;
      const restoredData: Record<string, string> = {};
      prevStageFields.forEach(field => {
        if (state.data[field.name]) {
          restoredData[field.name] = state.data[field.name].original;
        }
      });
      setFormData(restoredData);
      setAlternatives({});
      setEditingRefined({});
    }
  };

  // Generate final epic
  const generateEpic = async () => {
    setIsGenerating(true);
    const projectName = state.data['projectName']?.original || 'Untitled Project';
    const result = await runSkill('generate', {
      data: state.data,
      projectName,
    }) as GenerateResult;

    setState(prev => ({ ...prev, generatedEpic: result.epic }));
    setEditableEpic(result.epic);

    // Generate PlantUML blueprint
    const blueprint = generatePlantUMLBlueprint(state.data, projectName);
    setBlueprintCode(blueprint);

    setActiveTab('epic');
    setIsGenerating(false);
  };

  // Reset and start over
  const resetWizard = () => {
    setState(initialState);
    setFormData({});
    setAlternatives({});
    setEditingRefined({});
    setEditableEpic('');
    setBlueprintCode('');
    setActiveTab('wizard');
  };

  // Check which sections will be populated
  const getPopulatedSections = () => {
    const populated = new Set<number>();
    STAGES.slice(0, state.currentStage + 1).forEach(stage => {
      const hasData = stage.fields.some(f => state.data[f.name]?.refined);
      if (hasData) {
        stage.populatesSections.forEach(s => populated.add(s));
      }
    });
    return populated;
  };

  const populatedSections = getPopulatedSections();

  // Render wizard stage
  const renderWizard = () => (
    <div style={styles.card}>
      {/* Help banner */}
      <div style={styles.helpBanner}>
        <span style={styles.helpIcon}>💡</span>
        <span style={styles.helpText}>
          <strong>Need help?</strong> Click "Suggest" on any field to get AI-powered suggestions. You can edit everything before moving to the next stage.
        </span>
      </div>

      <div style={styles.stageTitle}>
        Stage {state.currentStage + 1}: {currentStage.title}
      </div>
      <div style={styles.stageDesc}>{currentStage.description}</div>

      {currentStage.fields.map(field => {
        const hasRefined = state.data[field.name]?.refined;
        const isEditing = editingRefined[field.name];
        const isLoadingSuggestion = loadingSuggestion[field.name];
        const fieldAlternatives = alternatives[field.name];

        return (
          <div key={field.name} style={styles.fieldGroup}>
            {/* Label row with suggest button */}
            <div style={styles.labelRow}>
              <label style={styles.label}>
                {field.label}
                {field.required && <span style={{ color: '#ef4444' }}> *</span>}
              </label>
              <button
                style={isLoadingSuggestion ? styles.suggestButtonLoading : styles.suggestButton}
                onClick={() => handleGetSuggestion(field.name)}
                disabled={isLoadingSuggestion}
              >
                {isLoadingSuggestion ? (
                  '...'
                ) : (
                  <>
                    <span>✨</span> Suggest
                  </>
                )}
              </button>
            </div>

            {/* Input field */}
            {field.type === 'textarea' ? (
              <textarea
                style={styles.textarea}
                placeholder={field.placeholder}
                value={formData[field.name] || ''}
                onChange={(e) => handleFieldChange(field.name, e.target.value)}
              />
            ) : (
              <input
                type="text"
                style={styles.input}
                placeholder={field.placeholder}
                value={formData[field.name] || ''}
                onChange={(e) => handleFieldChange(field.name, e.target.value)}
              />
            )}

            {/* Alternative suggestions */}
            {fieldAlternatives && fieldAlternatives.length > 0 && (
              <div style={styles.alternativesSection}>
                <span style={{ fontSize: '11px', color: '#7c3aed', marginRight: '8px' }}>
                  Other ideas:
                </span>
                {fieldAlternatives.map((alt, idx) => (
                  <span
                    key={idx}
                    style={styles.alternativeChip}
                    onClick={() => handleUseAlternative(field.name, alt)}
                  >
                    {alt.length > 40 ? alt.slice(0, 40) + '...' : alt}
                  </span>
                ))}
              </div>
            )}

            {/* Refined content (editable) */}
            {hasRefined && (
              <div style={styles.refinedSection}>
                <div style={styles.refinedHeader}>
                  <span style={styles.refinedBadge}>
                    <span>✓</span> AI Refined
                  </span>
                  <button
                    style={styles.editButton}
                    onClick={() => setEditingRefined(prev => ({ ...prev, [field.name]: !prev[field.name] }))}
                  >
                    {isEditing ? 'Done' : 'Edit'}
                  </button>
                </div>
                {isEditing ? (
                  <textarea
                    style={styles.refinedTextarea}
                    value={state.data[field.name].refined}
                    onChange={(e) => handleRefinedChange(field.name, e.target.value)}
                  />
                ) : (
                  <div style={styles.refinedPreview}>
                    {state.data[field.name].refined}
                  </div>
                )}
              </div>
            )}
          </div>
        );
      })}

      <div style={styles.buttonRow}>
        {state.currentStage > 0 && (
          <button style={styles.button(false)} onClick={prevStage}>
            ← Previous
          </button>
        )}
        <button
          style={styles.button(true)}
          onClick={nextStage}
          disabled={isRefining}
        >
          {isRefining ? 'Refining...' : isLastStage ? 'Generate Epic →' : 'Next →'}
        </button>
      </div>

      {/* Sections preview */}
      <div style={{ marginTop: '24px', paddingTop: '16px', borderTop: '1px solid #e5e7eb' }}>
        <div style={{ fontSize: '14px', fontWeight: '500', marginBottom: '8px' }}>
          Epic Sections Progress:
        </div>
        <div style={styles.sectionPreview}>
          {EPIC_SECTIONS.map(section => (
            <div key={section.num} style={styles.sectionChip(populatedSections.has(section.num))}>
              {section.num}. {section.title}
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  // Get PlantUML image URL using proper encoder
  const getPlantUMLImageUrl = (puml: string): string => {
    const encoded = plantumlEncoder.encode(puml);
    return `https://www.plantuml.com/plantuml/svg/${encoded}`;
  };

  // Render PlantUML Blueprint view
  const renderBlueprint = () => (
    <div>
      {/* Action bar */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
        <div>
          <div style={styles.stageTitle}>Epic Blueprint</div>
          <div style={{ color: '#666', fontSize: '13px' }}>Multilayer PlantUML diagram showing the complete epic narrative</div>
        </div>
        <div style={{ display: 'flex', gap: '8px' }}>
          <button
            style={styles.button(false)}
            onClick={() => navigator.clipboard.writeText(blueprintCode)}
          >
            📋 Copy PlantUML
          </button>
          <button
            style={styles.button(false)}
            onClick={() => {
              const blob = new Blob([blueprintCode], { type: 'text/plain' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'epic-blueprint.puml';
              a.click();
              URL.revokeObjectURL(url);
            }}
          >
            💾 Download .puml
          </button>
          <button
            style={{ ...styles.button(true), backgroundColor: '#7c3aed' }}
            onClick={() => {
              // Open PlantUML online editor
              window.open('https://www.plantuml.com/plantuml/uml/', '_blank');
            }}
          >
            🌐 Open PlantUML Editor
          </button>
        </div>
      </div>

      {/* Blueprint content - Full width diagram view */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
        {/* Live Diagram Preview */}
        <div style={{
          border: '1px solid #d0d7de',
          borderRadius: '8px',
          backgroundColor: 'white',
          overflow: 'hidden',
        }}>
          <div style={styles.paneHeader}>
            <span>🗺️ Live Blueprint Diagram</span>
            <span style={{ fontSize: '12px', color: '#666' }}>Rendered via PlantUML Server</span>
          </div>
          <div style={{
            padding: '20px',
            backgroundColor: '#fafafa',
            minHeight: '500px',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'flex-start',
            overflow: 'auto',
          }}>
            <img
              src={getPlantUMLImageUrl(blueprintCode)}
              alt="Epic Blueprint Diagram"
              style={{
                maxWidth: '100%',
                height: 'auto',
                backgroundColor: 'white',
                borderRadius: '8px',
                boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
              }}
              onError={(e) => {
                // Show error message
                const target = e.target as HTMLImageElement;
                target.style.display = 'none';
                target.parentElement!.innerHTML = `
                  <div style="text-align: center; padding: 40px; color: #666;">
                    <p style="font-size: 16px; margin-bottom: 12px;">⚠️ Unable to render diagram</p>
                    <p style="font-size: 13px;">Copy the PlantUML code and paste it at <a href="https://www.plantuml.com/plantuml" target="_blank">plantuml.com</a></p>
                  </div>
                `;
              }}
            />
          </div>
        </div>

        {/* Split: Code editor and Legend */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
          {/* Code pane */}
          <div style={styles.editorPane}>
            <div style={styles.paneHeader}>
              <span>📐 PlantUML Code (Editable)</span>
              <span style={{ fontSize: '12px', color: '#666' }}>
                {blueprintCode.split('\n').length} lines
              </span>
            </div>
            <textarea
              style={{ ...styles.editor, height: '400px' }}
              value={blueprintCode}
              onChange={(e) => setBlueprintCode(e.target.value)}
              spellCheck={false}
            />
          </div>

          {/* Legend pane */}
          <div style={styles.previewPane}>
            <div style={styles.paneHeader}>
              <span>📊 Layer Legend</span>
            </div>
            <div style={{ padding: '16px', overflow: 'auto', height: '355px' }}>
              {/* Layer legend */}
              <div style={{ marginBottom: '16px' }}>
                <h3 style={{ fontSize: '14px', fontWeight: '600', marginBottom: '10px' }}>7-Layer Epic Architecture</h3>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: '6px' }}>
                  {[
                    { color: '#E3F2FD', name: '1. Stakeholders & Input', desc: 'Who is involved and what they want' },
                    { color: '#E8F5E9', name: '2. Requirements & Scope', desc: 'What we\'re building (and not)' },
                    { color: '#FFF3E0', name: '3. Architecture & Design', desc: 'How the system is structured' },
                    { color: '#F3E5F5', name: '4. Team & Execution', desc: 'Who builds it and how' },
                    { color: '#FFEBEE', name: '5. Quality & Compliance', desc: 'NFRs, security, standards' },
                    { color: '#FBE9E7', name: '6. Risks & Dependencies', desc: 'What could go wrong' },
                    { color: '#E8EAF6', name: '7. Deliverables & Outcomes', desc: 'What we produce' },
                  ].map((layer, i) => (
                    <div key={i} style={{
                      padding: '8px 10px',
                      backgroundColor: layer.color,
                      borderRadius: '6px',
                      border: '1px solid rgba(0,0,0,0.1)',
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                    }}>
                      <div style={{ fontWeight: '600', fontSize: '12px' }}>{layer.name}</div>
                      <div style={{ fontSize: '11px', color: '#666' }}>{layer.desc}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Flow */}
              <div style={{
                padding: '12px',
                backgroundColor: '#f0f9ff',
                borderRadius: '8px',
                border: '1px solid #bae6fd',
              }}>
                <h4 style={{ fontSize: '12px', fontWeight: '600', marginBottom: '6px', color: '#0369a1' }}>
                  Epic Flow Narrative
                </h4>
                <div style={{ fontSize: '11px', color: '#475569', lineHeight: '1.6' }}>
                  Vision → Scope → Architecture → Team → Quality → Risks → Deliverables → Approvals
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  // Render Settings Panel
  const renderSettings = () => {
    const handleTestGitLab = async () => {
      setGitlabTestStatus({ testing: true });
      const result = await testGitLabConnection(config.gitlab);
      if (result.success) {
        setGitlabTestStatus({ testing: false, result: `Connected to: ${result.projectName}` });
      } else {
        setGitlabTestStatus({ testing: false, result: `Error: ${result.error}` });
      }
    };

    const handleTestAzure = async () => {
      setAzureTestStatus({ testing: true });
      const result = await testAzureOpenAI(config.azureOpenAI);
      if (result.success) {
        setAzureTestStatus({ testing: false, result: 'Connection successful!' });
      } else {
        setAzureTestStatus({ testing: false, result: `Error: ${result.error}` });
      }
    };

    return (
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
        {/* Azure OpenAI Configuration */}
        <div style={styles.card}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
            <div style={styles.stageTitle}>Azure OpenAI</div>
            <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
              <input
                type="checkbox"
                checked={config.azureOpenAI.enabled}
                onChange={(e) => updateConfig({
                  ...config,
                  azureOpenAI: { ...config.azureOpenAI, enabled: e.target.checked },
                })}
              />
              <span style={{ fontSize: '14px' }}>Enable</span>
            </label>
          </div>
          <div style={{ color: '#666', marginBottom: '20px', fontSize: '13px' }}>
            Connect to Azure OpenAI for AI-powered refinements and suggestions.
          </div>

          {/* Endpoint */}
          <div style={styles.fieldGroup}>
            <label style={styles.label}>Azure OpenAI Endpoint</label>
            <input
              type="text"
              style={styles.input}
              placeholder="https://your-resource.openai.azure.com"
              value={config.azureOpenAI.endpoint}
              onChange={(e) => updateConfig({
                ...config,
                azureOpenAI: { ...config.azureOpenAI, endpoint: e.target.value },
              })}
              disabled={!config.azureOpenAI.enabled}
            />
            <div style={{ fontSize: '11px', color: '#666', marginTop: '4px' }}>
              Found in Azure Portal → Your OpenAI Resource → Keys and Endpoint
            </div>
          </div>

          {/* Deployment Name */}
          <div style={styles.fieldGroup}>
            <label style={styles.label}>Deployment Name</label>
            <input
              type="text"
              style={styles.input}
              placeholder="gpt-4o-deployment"
              value={config.azureOpenAI.deploymentName}
              onChange={(e) => updateConfig({
                ...config,
                azureOpenAI: { ...config.azureOpenAI, deploymentName: e.target.value },
              })}
              disabled={!config.azureOpenAI.enabled}
            />
            <div style={{ fontSize: '11px', color: '#666', marginTop: '4px' }}>
              The name of your model deployment in Azure OpenAI Studio
            </div>
          </div>

          {/* API Key */}
          <div style={styles.fieldGroup}>
            <label style={styles.label}>API Key</label>
            <input
              type="password"
              style={styles.input}
              placeholder="Your Azure OpenAI API key"
              value={config.azureOpenAI.apiKey}
              onChange={(e) => updateConfig({
                ...config,
                azureOpenAI: { ...config.azureOpenAI, apiKey: e.target.value },
              })}
              disabled={!config.azureOpenAI.enabled}
            />
          </div>

          {/* API Version */}
          <div style={styles.fieldGroup}>
            <label style={styles.label}>API Version</label>
            <select
              style={{ ...styles.input, cursor: config.azureOpenAI.enabled ? 'pointer' : 'not-allowed' }}
              value={config.azureOpenAI.apiVersion}
              onChange={(e) => updateConfig({
                ...config,
                azureOpenAI: { ...config.azureOpenAI, apiVersion: e.target.value },
              })}
              disabled={!config.azureOpenAI.enabled}
            >
              {AZURE_API_VERSIONS.map((v) => (
                <option key={v} value={v}>{v}</option>
              ))}
            </select>
          </div>

          {/* Advanced settings */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
            <div style={styles.fieldGroup}>
              <label style={styles.label}>Max Tokens</label>
              <input
                type="number"
                style={styles.input}
                value={config.azureOpenAI.maxTokens}
                onChange={(e) => updateConfig({
                  ...config,
                  azureOpenAI: { ...config.azureOpenAI, maxTokens: parseInt(e.target.value) || 4096 },
                })}
                disabled={!config.azureOpenAI.enabled}
              />
            </div>
            <div style={styles.fieldGroup}>
              <label style={styles.label}>Temperature</label>
              <input
                type="number"
                step="0.1"
                min="0"
                max="2"
                style={styles.input}
                value={config.azureOpenAI.temperature}
                onChange={(e) => updateConfig({
                  ...config,
                  azureOpenAI: { ...config.azureOpenAI, temperature: parseFloat(e.target.value) || 0.7 },
                })}
                disabled={!config.azureOpenAI.enabled}
              />
            </div>
          </div>

          {/* Test connection button */}
          {config.azureOpenAI.enabled && (
            <div style={{ marginTop: '16px' }}>
              <button
                style={{ ...styles.button(true), backgroundColor: '#0078d4' }}
                onClick={handleTestAzure}
                disabled={azureTestStatus?.testing}
              >
                {azureTestStatus?.testing ? '⏳ Testing...' : '🔗 Test Connection'}
              </button>
              {azureTestStatus?.result && (
                <div style={{
                  marginTop: '8px',
                  padding: '8px 12px',
                  borderRadius: '6px',
                  fontSize: '13px',
                  backgroundColor: azureTestStatus.result.startsWith('Error') ? '#fee2e2' : '#dcfce7',
                  color: azureTestStatus.result.startsWith('Error') ? '#991b1b' : '#166534',
                }}>
                  {azureTestStatus.result}
                </div>
              )}
            </div>
          )}

          {/* Mock mode notice */}
          {!config.azureOpenAI.enabled && (
            <div style={{
              marginTop: '16px',
              padding: '12px',
              backgroundColor: '#fef3c7',
              borderRadius: '8px',
              color: '#92400e',
              fontSize: '13px',
            }}>
              <strong>Mock Mode:</strong> Azure OpenAI is not enabled. The app uses predefined responses for testing. Enable and configure Azure OpenAI for real AI refinements.
            </div>
          )}
        </div>

        {/* GitLab Configuration */}
        <div style={styles.card}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
            <div style={styles.stageTitle}>GitLab Integration</div>
            <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
              <input
                type="checkbox"
                checked={config.gitlab.enabled}
                onChange={(e) => updateConfig({
                  ...config,
                  gitlab: { ...config.gitlab, enabled: e.target.checked },
                })}
              />
              <span style={{ fontSize: '14px' }}>Enable</span>
            </label>
          </div>
          <div style={{ color: '#666', marginBottom: '20px', fontSize: '13px' }}>
            Configure GitLab to push your epics directly to a repository.
          </div>

          <div style={styles.fieldGroup}>
            <label style={styles.label}>GitLab URL</label>
            <input
              type="text"
              style={styles.input}
              placeholder="https://gitlab.com"
              value={config.gitlab.baseUrl}
              onChange={(e) => updateConfig({
                ...config,
                gitlab: { ...config.gitlab, baseUrl: e.target.value },
              })}
              disabled={!config.gitlab.enabled}
            />
            <div style={{ fontSize: '11px', color: '#666', marginTop: '4px' }}>
              Use https://gitlab.com for GitLab.com or your self-hosted URL
            </div>
          </div>

          <div style={styles.fieldGroup}>
            <label style={styles.label}>Project ID or Path</label>
            <input
              type="text"
              style={styles.input}
              placeholder="group/project or 12345678"
              value={config.gitlab.projectId}
              onChange={(e) => updateConfig({
                ...config,
                gitlab: { ...config.gitlab, projectId: e.target.value },
              })}
              disabled={!config.gitlab.enabled}
            />
          </div>

          <div style={styles.fieldGroup}>
            <label style={styles.label}>Personal Access Token</label>
            <input
              type="password"
              style={styles.input}
              placeholder="glpat-..."
              value={config.gitlab.accessToken}
              onChange={(e) => updateConfig({
                ...config,
                gitlab: { ...config.gitlab, accessToken: e.target.value },
              })}
              disabled={!config.gitlab.enabled}
            />
            <div style={{ fontSize: '11px', color: '#666', marginTop: '4px' }}>
              Token needs <code>api</code> scope. Create at GitLab → Settings → Access Tokens
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
            <div style={styles.fieldGroup}>
              <label style={styles.label}>Branch</label>
              <input
                type="text"
                style={styles.input}
                value={config.gitlab.branch}
                onChange={(e) => updateConfig({
                  ...config,
                  gitlab: { ...config.gitlab, branch: e.target.value },
                })}
                disabled={!config.gitlab.enabled}
              />
            </div>
            <div style={styles.fieldGroup}>
              <label style={styles.label}>Epic File Path</label>
              <input
                type="text"
                style={styles.input}
                placeholder="docs/epics/"
                value={config.gitlab.epicFilePath}
                onChange={(e) => updateConfig({
                  ...config,
                  gitlab: { ...config.gitlab, epicFilePath: e.target.value },
                })}
                disabled={!config.gitlab.enabled}
              />
            </div>
          </div>

          {/* Test connection button */}
          {config.gitlab.enabled && (
            <div style={{ marginTop: '16px' }}>
              <button
                style={{ ...styles.button(true), backgroundColor: '#fc6d26' }}
                onClick={handleTestGitLab}
                disabled={gitlabTestStatus?.testing}
              >
                {gitlabTestStatus?.testing ? '⏳ Testing...' : '🔗 Test Connection'}
              </button>
              {gitlabTestStatus?.result && (
                <div style={{
                  marginTop: '8px',
                  padding: '8px 12px',
                  borderRadius: '6px',
                  fontSize: '13px',
                  backgroundColor: gitlabTestStatus.result.startsWith('Error') ? '#fee2e2' : '#dcfce7',
                  color: gitlabTestStatus.result.startsWith('Error') ? '#991b1b' : '#166534',
                }}>
                  {gitlabTestStatus.result}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    );
  };

  // Publish to GitLab
  const handlePublishToGitLab = async () => {
    if (!config.gitlab.enabled) {
      setPublishStatus({ type: 'error', message: 'GitLab integration is not enabled. Configure it in Settings.' });
      return;
    }

    setIsPublishing(true);
    setPublishStatus(null);

    const projectName = state.data['projectName']?.original || 'untitled';
    const fileName = `${projectName.toLowerCase().replace(/\s+/g, '-')}-epic.md`;
    const commitMessage = `Add epic: ${projectName}`;

    const result = await publishToGitLab(config.gitlab, fileName, editableEpic, commitMessage);

    if (result.success) {
      setPublishStatus({ type: 'success', message: `Published successfully! View at: ${result.url}` });
    } else {
      setPublishStatus({ type: 'error', message: result.error || 'Failed to publish' });
    }

    setIsPublishing(false);
  };

  const renderEpicEditor = () => (
    <div>
      {/* Action bar */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
        <div style={styles.stageTitle}>Epic Editor</div>
        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          <button
            style={styles.button(false)}
            onClick={() => navigator.clipboard.writeText(editableEpic)}
          >
            📋 Copy Markdown
          </button>
          <button
            style={styles.button(false)}
            onClick={() => {
              const blob = new Blob([editableEpic], { type: 'text/markdown' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'epic.md';
              a.click();
              URL.revokeObjectURL(url);
            }}
          >
            💾 Download .md
          </button>
          <button
            style={{
              ...styles.button(true),
              backgroundColor: config.gitlab.enabled ? '#fc6d26' : '#9ca3af',
              cursor: config.gitlab.enabled && !isPublishing ? 'pointer' : 'not-allowed',
            }}
            onClick={handlePublishToGitLab}
            disabled={isPublishing || !config.gitlab.enabled}
            title={config.gitlab.enabled ? 'Publish to GitLab' : 'Enable GitLab in Settings first'}
          >
            {isPublishing ? '⏳ Publishing...' : '🦊 Push to GitLab'}
          </button>
          <button style={styles.button(false)} onClick={resetWizard}>
            🔄 Start Over
          </button>
        </div>
      </div>

      {/* Publish status */}
      {publishStatus && (
        <div style={{
          padding: '12px 16px',
          marginBottom: '16px',
          borderRadius: '8px',
          backgroundColor: publishStatus.type === 'success' ? '#dcfce7' : '#fee2e2',
          color: publishStatus.type === 'success' ? '#166534' : '#991b1b',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}>
          <span>{publishStatus.message}</span>
          <button
            style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '16px' }}
            onClick={() => setPublishStatus(null)}
          >
            ✕
          </button>
        </div>
      )}

      {/* Split screen */}
      <div style={styles.splitContainer}>
        {/* Editor pane */}
        <div style={styles.splitPane}>
          <div style={styles.editorPane}>
            <div style={styles.paneHeader}>
              <span>📝 Editor (Markdown)</span>
              <span style={{ fontSize: '12px', color: '#666' }}>
                {editableEpic.split('\n').length} lines
              </span>
            </div>
            <textarea
              style={styles.editor}
              value={editableEpic}
              onChange={(e) => setEditableEpic(e.target.value)}
              spellCheck={false}
            />
          </div>
        </div>

        {/* Preview pane */}
        <div style={styles.splitPane}>
          <div style={styles.previewPane}>
            <div style={styles.paneHeader}>
              <span>👁️ Preview (GitHub Style)</span>
              <span style={{ fontSize: '12px', color: '#666' }}>Live Preview</span>
            </div>
            <div style={{ overflow: 'auto', height: 'calc(100% - 45px)' }}>
              <MarkdownPreview content={editableEpic} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div style={styles.container}>
      {/* Header */}
      <div style={styles.header}>
        <div style={styles.title}>Epic Generator</div>
        <div style={styles.subtitle}>Create comprehensive technical design epics with AI assistance</div>
      </div>

      {/* Progress dots */}
      <div style={styles.progress}>
        {STAGES.map((_, index) => (
          <div
            key={index}
            style={styles.progressDot(index === state.currentStage, index < state.currentStage)}
            title={STAGES[index].title}
          />
        ))}
        <div
          style={styles.progressDot(hasEpic, hasEpic)}
          title="Epic Generated"
        />
      </div>

      {/* Tabs */}
      <div style={{ ...styles.tabs, justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', gap: '4px' }}>
          <button style={styles.tab(activeTab === 'wizard')} onClick={() => setActiveTab('wizard')}>
            📋 Wizard
          </button>
          {hasEpic && (
            <>
              <button style={styles.tab(activeTab === 'epic')} onClick={() => setActiveTab('epic')}>
                ✏️ Epic Editor
              </button>
              <button style={styles.tab(activeTab === 'blueprint')} onClick={() => setActiveTab('blueprint')}>
                🗺️ Blueprint
              </button>
            </>
          )}
        </div>
        <button
          style={{
            ...styles.tab(activeTab === 'settings'),
            backgroundColor: activeTab === 'settings' ? '#6b7280' : '#e5e7eb',
          }}
          onClick={() => setActiveTab('settings')}
        >
          ⚙️ Settings
        </button>
      </div>

      {/* Content */}
      {isGenerating ? (
        <div style={{ ...styles.card, textAlign: 'center', padding: '60px' }}>
          <div style={{ fontSize: '18px', marginBottom: '12px' }}>Generating your epic...</div>
          <div style={{ color: '#666' }}>Compiling all 17 sections with diagrams</div>
        </div>
      ) : activeTab === 'wizard' ? (
        renderWizard()
      ) : activeTab === 'blueprint' ? (
        renderBlueprint()
      ) : activeTab === 'settings' ? (
        renderSettings()
      ) : (
        renderEpicEditor()
      )}
    </div>
  );
}
