// Configuration for Epic Generator
// Azure OpenAI + GitLab Integration

// ===========================================
// AZURE OPENAI CONFIGURATION
// ===========================================
export interface AzureOpenAIConfig {
  enabled: boolean;
  endpoint: string;        // e.g., "https://your-resource.openai.azure.com"
  deploymentName: string;  // Your deployment name
  apiKey: string;
  apiVersion: string;      // e.g., "2024-02-15-preview"
  maxTokens: number;
  temperature: number;
}

export interface GitLabConfig {
  enabled: boolean;
  baseUrl: string;           // e.g., "https://gitlab.com" or self-hosted
  projectId: string;         // Project ID or path (e.g., "group/project")
  accessToken: string;       // Personal Access Token with api scope
  branch: string;            // Target branch for commits
  epicFilePath: string;      // Path where epic.md will be saved
}

export interface AppConfig {
  azureOpenAI: AzureOpenAIConfig;
  gitlab: GitLabConfig;
}

// Default configuration
export const DEFAULT_CONFIG: AppConfig = {
  azureOpenAI: {
    enabled: false,
    endpoint: '',
    deploymentName: '',
    apiKey: '',
    apiVersion: '2024-02-15-preview',
    maxTokens: 4096,
    temperature: 0.7,
  },
  gitlab: {
    enabled: false,
    baseUrl: 'https://gitlab.com',
    projectId: '',
    accessToken: '',
    branch: 'main',
    epicFilePath: 'docs/epics/',
  },
};

// Available API versions for Azure OpenAI
export const AZURE_API_VERSIONS = [
  '2024-02-15-preview',
  '2024-05-01-preview',
  '2024-06-01',
  '2023-12-01-preview',
  '2023-05-15',
];

// ===========================================
// CONFIG STORAGE (localStorage)
// ===========================================
const CONFIG_STORAGE_KEY = 'epic-generator-config';

export function loadConfig(): AppConfig {
  try {
    const stored = localStorage.getItem(CONFIG_STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      // Merge with defaults to handle new fields
      return {
        azureOpenAI: { ...DEFAULT_CONFIG.azureOpenAI, ...parsed.azureOpenAI },
        gitlab: { ...DEFAULT_CONFIG.gitlab, ...parsed.gitlab },
      };
    }
  } catch (e) {
    console.error('Failed to load config:', e);
  }
  return DEFAULT_CONFIG;
}

export function saveConfig(config: AppConfig): void {
  try {
    localStorage.setItem(CONFIG_STORAGE_KEY, JSON.stringify(config));
  } catch (e) {
    console.error('Failed to save config:', e);
  }
}

// ===========================================
// AZURE OPENAI API CALLS
// ===========================================
export async function callAzureOpenAI(
  config: AzureOpenAIConfig,
  systemPrompt: string,
  userPrompt: string
): Promise<string> {
  if (!config.enabled) {
    // Return mock response when Azure is not configured
    await new Promise(resolve => setTimeout(resolve, 300));
    return userPrompt; // Just return the input as-is in mock mode
  }

  if (!config.endpoint || !config.apiKey || !config.deploymentName) {
    throw new Error('Azure OpenAI is not fully configured. Please check Settings.');
  }

  const url = `${config.endpoint}/openai/deployments/${config.deploymentName}/chat/completions?api-version=${config.apiVersion}`;

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'api-key': config.apiKey,
    },
    body: JSON.stringify({
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
      max_tokens: config.maxTokens,
      temperature: config.temperature,
    }),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: { message: response.statusText } }));
    throw new Error(`Azure OpenAI error: ${error.error?.message || response.statusText}`);
  }

  const data = await response.json();
  return data.choices[0].message.content;
}

// Test Azure OpenAI connection
export async function testAzureOpenAI(config: AzureOpenAIConfig): Promise<{ success: boolean; error?: string }> {
  if (!config.endpoint || !config.apiKey || !config.deploymentName) {
    return { success: false, error: 'Endpoint, API Key, and Deployment Name are required' };
  }

  try {
    const result = await callAzureOpenAI(
      { ...config, enabled: true },
      'You are a helpful assistant.',
      'Say "Connection successful" in exactly those words.'
    );

    if (result.toLowerCase().includes('connection successful')) {
      return { success: true };
    }
    return { success: true }; // Any response means it worked
  } catch (e) {
    return { success: false, error: e instanceof Error ? e.message : 'Connection failed' };
  }
}

// ===========================================
// UNIFIED AI CALL - Uses Azure OpenAI or mock
// ===========================================
export async function callAI(
  config: AppConfig,
  systemPrompt: string,
  userPrompt: string
): Promise<string> {
  if (config.azureOpenAI.enabled) {
    return callAzureOpenAI(config.azureOpenAI, systemPrompt, userPrompt);
  }
  // Mock mode - return input as-is
  await new Promise(resolve => setTimeout(resolve, 300));
  return userPrompt;
}

// ===========================================
// GITLAB API CALLS
// ===========================================
export interface GitLabPublishResult {
  success: boolean;
  url?: string;
  error?: string;
}

export async function publishToGitLab(
  config: GitLabConfig,
  fileName: string,
  content: string,
  commitMessage: string
): Promise<GitLabPublishResult> {
  if (!config.enabled) {
    return { success: false, error: 'GitLab integration is not enabled' };
  }

  if (!config.accessToken || !config.projectId) {
    return { success: false, error: 'GitLab access token and project ID are required' };
  }

  const filePath = `${config.epicFilePath}${fileName}`.replace(/\/+/g, '/');
  const encodedPath = encodeURIComponent(filePath);
  const encodedProjectId = encodeURIComponent(config.projectId);

  try {
    // Check if file exists
    const checkResponse = await fetch(
      `${config.baseUrl}/api/v4/projects/${encodedProjectId}/repository/files/${encodedPath}?ref=${config.branch}`,
      {
        headers: {
          'PRIVATE-TOKEN': config.accessToken,
        },
      }
    );

    const fileExists = checkResponse.ok;

    // Create or update file
    const method = fileExists ? 'PUT' : 'POST';
    const response = await fetch(
      `${config.baseUrl}/api/v4/projects/${encodedProjectId}/repository/files/${encodedPath}`,
      {
        method,
        headers: {
          'Content-Type': 'application/json',
          'PRIVATE-TOKEN': config.accessToken,
        },
        body: JSON.stringify({
          branch: config.branch,
          content: content,
          commit_message: commitMessage,
          encoding: 'text',
        }),
      }
    );

    if (!response.ok) {
      const error = await response.json();
      return { success: false, error: error.message || response.statusText };
    }

    const fileUrl = `${config.baseUrl}/${config.projectId}/-/blob/${config.branch}/${filePath}`;

    return { success: true, url: fileUrl };
  } catch (e) {
    return { success: false, error: e instanceof Error ? e.message : 'Unknown error' };
  }
}

// Test GitLab connection
export async function testGitLabConnection(config: GitLabConfig): Promise<{ success: boolean; error?: string; projectName?: string }> {
  if (!config.accessToken || !config.projectId) {
    return { success: false, error: 'Access token and project ID are required' };
  }

  try {
    const encodedProjectId = encodeURIComponent(config.projectId);
    const response = await fetch(
      `${config.baseUrl}/api/v4/projects/${encodedProjectId}`,
      {
        headers: {
          'PRIVATE-TOKEN': config.accessToken,
        },
      }
    );

    if (!response.ok) {
      return { success: false, error: `Failed to connect: ${response.statusText}` };
    }

    const data = await response.json();
    return { success: true, projectName: data.name_with_namespace };
  } catch (e) {
    return { success: false, error: e instanceof Error ? e.message : 'Connection failed' };
  }
}
