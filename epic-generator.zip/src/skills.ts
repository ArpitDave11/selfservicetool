// Epic Generator Skills & Prompts

import { STAGES, EPIC_SECTIONS, type RefinedData } from './types';

// Skill Types
export interface RefineResult {
  refined: string;
  diagramNode: string;
  suggestions?: string[];
}

export interface GenerateResult {
  epic: string;
  diagram: string;
}

export interface SuggestionResult {
  suggestion: string;
  alternatives?: string[];
}

// Mock delay to simulate AI response
const mockDelay = () => new Promise(resolve => setTimeout(resolve, 300));

// AI Suggestions - Help users when they're stuck
const FIELD_SUGGESTIONS: Record<string, Record<string, (context: Record<string, string>) => SuggestionResult>> = {
  project: {
    projectName: () => ({
      suggestion: 'Customer Portal Modernization',
      alternatives: ['API Gateway Implementation', 'Data Analytics Platform', 'Mobile App Redesign'],
    }),
    background: (ctx) => ({
      suggestion: `The ${ctx.projectName || 'project'} initiative addresses the need for improved efficiency and user experience. Current systems are outdated and require modernization to meet growing business demands and customer expectations.`,
      alternatives: [
        'Legacy systems are causing operational bottlenecks and need replacement.',
        'Market competition requires us to innovate and deliver new capabilities.',
      ],
    }),
  },
  objective_scope: {
    objective: (ctx) => ({
      suggestion: `Deliver a modern, scalable ${ctx.projectName || 'solution'} that improves user experience by 50%, reduces operational costs by 30%, and enables future growth capabilities.`,
      alternatives: [
        'Automate manual processes to increase team productivity by 40%.',
        'Create a unified platform that consolidates multiple legacy systems.',
      ],
    }),
    inScope: (ctx) => ({
      suggestion: `User authentication and authorization
Dashboard and reporting features
API integrations with existing systems
Mobile-responsive design
Data migration from legacy system`,
      alternatives: [
        'Core functionality only\nAdmin panel\nBasic reporting',
      ],
    }),
    outOfScope: () => ({
      suggestion: `Third-party payment processing
Legacy system decommissioning
Training and documentation (separate initiative)
Performance optimization phase 2`,
    }),
  },
  architecture: {
    assumptions: () => ({
      suggestion: `Cloud infrastructure (AWS/GCP/Azure) is available
Development team has React and Node.js expertise
API rate limits from third-party services are sufficient
Existing authentication system will be reused`,
    }),
    architectureOverview: (ctx) => ({
      suggestion: `The ${ctx.projectName || 'system'} follows a microservices architecture with:

**Frontend:** React SPA with TypeScript
**API Layer:** Node.js/Express REST APIs
**Backend Services:** Containerized microservices
**Database:** PostgreSQL for relational data, Redis for caching
**Infrastructure:** Kubernetes on cloud platform with auto-scaling`,
    }),
    dataStores: () => ({
      suggestion: `**Primary Database:** PostgreSQL 15
- User data, transactions, configurations

**Cache Layer:** Redis Cluster
- Session management, API response caching

**Search:** Elasticsearch
- Full-text search, logging

**Message Queue:** RabbitMQ
- Async processing, event-driven workflows`,
    }),
  },
  features: {
    features: (ctx) => ({
      suggestion: `User registration and SSO login
Interactive dashboard with real-time updates
Advanced search and filtering
Export functionality (PDF, Excel)
Notification system (email, in-app)
Admin panel for user management
Audit logging and compliance reports`,
    }),
    userStories: () => ({
      suggestion: `As a user, I want to log in with my company SSO so that I don't need separate credentials.

As an admin, I want to view user activity logs so that I can monitor system usage.

As a manager, I want to generate monthly reports so that I can track team performance.

As a user, I want to receive notifications so that I stay informed about important updates.`,
    }),
    nfrs: () => ({
      suggestion: `**Performance:**
- Page load time < 2 seconds
- API response time < 500ms (p95)

**Scalability:**
- Support 10,000 concurrent users
- Handle 1M requests/day

**Availability:**
- 99.9% uptime SLA
- Disaster recovery < 4 hours RTO

**Security:**
- SOC 2 compliance
- Data encryption at rest and in transit`,
    }),
    deliverables: () => ({
      suggestion: `Functional web application
API documentation (OpenAPI/Swagger)
Database schema and migration scripts
CI/CD pipeline configuration
User guide and admin documentation
Load testing results
Security assessment report`,
    }),
  },
  team_env: {
    teams: () => ({
      suggestion: `Product Owner - Requirements and prioritization
Tech Lead - Architecture and technical decisions
Frontend Developers (2) - UI implementation
Backend Developers (2) - API and services
QA Engineer - Testing and quality
DevOps Engineer - Infrastructure and deployment
UX Designer - User experience (part-time)`,
    }),
    environments: () => ({
      suggestion: `**Development:** Local + shared dev server
- Feature branches, daily deployments

**Staging:** Production-like environment
- Integration testing, UAT
- Weekly releases from main branch

**Production:** High-availability cluster
- Blue-green deployments
- Automated rollback capability

**CI/CD:** GitHub Actions
- Automated tests on PR
- Security scanning
- Container builds`,
    }),
    security: () => ({
      suggestion: `**Authentication:** OAuth 2.0 / OIDC with company SSO
**Authorization:** Role-based access control (RBAC)
**Data Protection:** AES-256 encryption at rest, TLS 1.3 in transit
**Secrets:** HashiCorp Vault for credential management
**Audit:** All user actions logged with timestamps
**Compliance:** GDPR data handling, SOC 2 controls`,
    }),
  },
  delivery: {
    dependencies: () => ({
      suggestion: `SSO/Identity provider team - authentication integration
Platform team - Kubernetes cluster provisioning
Data team - access to source data for migration
Legal - privacy policy review and approval
Third-party API vendor - rate limit increase request`,
    }),
    risks: () => ({
      suggestion: `**Resource Risk:** Key developer availability during holiday season
Mitigation: Cross-train team members, document critical paths

**Technical Risk:** Legacy system API instability
Mitigation: Build retry logic, maintain fallback options

**Timeline Risk:** Third-party dependency delays
Mitigation: Start integration early, have contingency plan

**Scope Risk:** Feature creep from stakeholders
Mitigation: Strict change control process`,
    }),
    nextSteps: () => ({
      suggestion: `Finalize and approve this epic document
Set up development environment and repositories
Complete technical design for first sprint
Schedule kick-off meeting with full team
Begin Sprint 1 with authentication module`,
    }),
    dod: () => ({
      suggestion: `All user stories completed and accepted by Product Owner
Unit test coverage > 80%
Integration tests passing
Security scan with no critical/high vulnerabilities
Performance benchmarks met
Documentation complete and reviewed
Deployed to production with monitoring enabled`,
    }),
    approvers: () => ({
      suggestion: `Engineering Manager - Technical approval
Product Director - Business approval
Security Lead - Security sign-off
Platform Architect - Architecture review`,
    }),
  },
};

// Get AI suggestion for a field
export async function getSuggestion(
  stageId: string,
  fieldName: string,
  context: Record<string, string>
): Promise<SuggestionResult> {
  await mockDelay();

  const stageSuggestions = FIELD_SUGGESTIONS[stageId];
  if (stageSuggestions && stageSuggestions[fieldName]) {
    return stageSuggestions[fieldName](context);
  }

  // Default suggestion
  return {
    suggestion: `Enter your ${fieldName.replace(/([A-Z])/g, ' $1').toLowerCase()} here...`,
  };
}

// Refine Skill - Enhances user input at each stage
async function refineInput(
  stageId: string,
  fieldName: string,
  userInput: string,
  context: Record<string, string>
): Promise<RefineResult> {
  await mockDelay();

  // Mock refinement based on stage and field
  const refinements: Record<string, Record<string, (input: string) => RefineResult>> = {
    project: {
      projectName: (input) => ({
        refined: input,
        diagramNode: `Project["${input}"]`,
      }),
      background: (input) => ({
        refined: `**Context:** ${input}\n\n**Business Need:** This initiative addresses key organizational requirements and strategic objectives.`,
        diagramNode: `Context["Background & Context"]`,
      }),
    },
    objective_scope: {
      objective: (input) => ({
        refined: `**Primary Goal:** ${input}\n\n**Success Metrics:** Measurable outcomes will be defined during implementation.`,
        diagramNode: `Objective["${input.slice(0, 30)}..."]`,
      }),
      inScope: (input) => ({
        refined: input.split('\n').map(line => line.trim()).filter(Boolean).map(line => `- ${line}`).join('\n'),
        diagramNode: `Scope["In Scope Items"]`,
      }),
      outOfScope: (input) => ({
        refined: input ? input.split('\n').map(line => line.trim()).filter(Boolean).map(line => `- ${line}`).join('\n') : '- To be determined based on project constraints',
        diagramNode: `OutScope["Out of Scope"]`,
      }),
    },
    architecture: {
      assumptions: (input) => ({
        refined: input ? input.split('\n').map(line => line.trim()).filter(Boolean).map(line => `- ${line}`).join('\n') : '- Standard infrastructure availability\n- Team availability for implementation',
        diagramNode: `Assumptions["Assumptions"]`,
      }),
      architectureOverview: (input) => ({
        refined: `**System Architecture:**\n\n${input}\n\n**Key Components:** The system follows a modular architecture pattern enabling scalability and maintainability.`,
        diagramNode: `Architecture["System Architecture"]`,
      }),
      dataStores: (input) => ({
        refined: `**Data Layer:**\n\n${input}\n\n**Integration Points:** APIs and services will follow RESTful conventions with appropriate authentication.`,
        diagramNode: `DataStores["Data & Services"]`,
      }),
    },
    features: {
      features: (input) => ({
        refined: input.split('\n').map(line => line.trim()).filter(Boolean).map((line, i) => `${i + 1}. **${line}**`).join('\n'),
        diagramNode: `Features["Key Features"]`,
      }),
      userStories: (input) => ({
        refined: input || 'User stories to be elaborated during sprint planning.',
        diagramNode: `Stories["User Stories"]`,
      }),
      nfrs: (input) => ({
        refined: input ? `**Performance & Quality Requirements:**\n\n${input}` : '- Performance: Response time < 2s\n- Availability: 99.9% uptime\n- Security: Industry standard encryption',
        diagramNode: `NFRs["NFRs"]`,
      }),
      deliverables: (input) => ({
        refined: input.split('\n').map(line => line.trim()).filter(Boolean).map(line => `- [ ] ${line}`).join('\n'),
        diagramNode: `Deliverables["Deliverables"]`,
      }),
    },
    team_env: {
      teams: (input) => ({
        refined: input,
        diagramNode: `Team["Team Structure"]`,
      }),
      environments: (input) => ({
        refined: `**Environment Strategy:**\n\n${input}\n\n**Deployment:** CI/CD pipeline with automated testing and staged rollouts.`,
        diagramNode: `Environments["Environments"]`,
      }),
      security: (input) => ({
        refined: input ? `**Security Controls:**\n\n${input}` : '- Role-based access control (RBAC)\n- Data encryption at rest and in transit\n- Audit logging enabled',
        diagramNode: `Security["Security"]`,
      }),
    },
    delivery: {
      dependencies: (input) => ({
        refined: input ? input.split('\n').map(line => line.trim()).filter(Boolean).map(line => `- ${line}`).join('\n') : '- No critical external dependencies identified',
        diagramNode: `Dependencies["Dependencies"]`,
      }),
      risks: (input) => ({
        refined: input ? input.split('\n').map(line => line.trim()).filter(Boolean).map(line => `- **Risk:** ${line}`).join('\n') : '- Resource availability\n- Timeline constraints',
        diagramNode: `Risks["Risks"]`,
      }),
      nextSteps: (input) => ({
        refined: input.split('\n').map(line => line.trim()).filter(Boolean).map((line, i) => `${i + 1}. ${line}`).join('\n'),
        diagramNode: `NextSteps["Next Steps"]`,
      }),
      dod: (input) => ({
        refined: input.split('\n').map(line => line.trim()).filter(Boolean).map(line => `- [ ] ${line}`).join('\n'),
        diagramNode: `DoD["Definition of Done"]`,
      }),
      approvers: (input) => ({
        refined: input || 'Project stakeholders and technical leads',
        diagramNode: `Approvers["Approvers"]`,
      }),
    },
  };

  const stageRefinements = refinements[stageId];
  if (stageRefinements && stageRefinements[fieldName]) {
    return stageRefinements[fieldName](userInput);
  }

  // Default refinement
  return {
    refined: userInput,
    diagramNode: `Node_${fieldName}["${fieldName}"]`,
  };
}

// Generate Epic Skill - Creates full 17-section epic
async function generateEpic(data: RefinedData, projectName: string): Promise<GenerateResult> {
  await mockDelay();

  // Build the epic document
  let epic = `# Technical Design Epic: ${projectName}\n\n`;
  epic += `*Generated on ${new Date().toLocaleDateString()}*\n\n---\n\n`;

  // Generate each section
  for (const section of EPIC_SECTIONS) {
    epic += `## ${section.num}. ${section.title}\n\n`;

    if (section.subsections) {
      // Handle sections with subsections (Scope, Dependencies & Risks)
      section.dataKeys.forEach((key, idx) => {
        const subsectionTitle = section.subsections![idx];
        const content = data[key]?.refined || '_To be defined_';
        epic += `### ${section.num}.${idx + 1} ${subsectionTitle}\n\n${content}\n\n`;
      });
    } else if (section.isTable && section.dataKeys[0] === 'teams') {
      // Team & Roles table
      epic += `| Role | Responsibility |\n|------|----------------|\n`;
      const teamData = data['teams']?.refined || 'Team structure to be defined';
      teamData.split('\n').filter(Boolean).forEach(line => {
        epic += `| ${line} | TBD |\n`;
      });
      epic += '\n';
    } else if (section.isTable && section.dataKeys[0] === 'approvers') {
      // Approvals table
      epic += `| Approver | Role | Status |\n|----------|------|--------|\n`;
      const approverData = data['approvers']?.refined || 'Stakeholders';
      approverData.split('\n').filter(Boolean).forEach(line => {
        epic += `| ${line.trim()} | Stakeholder | Pending |\n`;
      });
      epic += '\n';
    } else if (section.hasDiagram) {
      // Architecture with diagram
      const content = data[section.dataKeys[0]]?.refined || '_Architecture details to be defined_';
      epic += `${content}\n\n`;
      epic += '```mermaid\n';
      epic += generateArchitectureDiagram(data);
      epic += '```\n\n';
    } else if (section.isReference) {
      // Architecture diagrams reference
      epic += '_See Mermaid diagram in Section 5 above._\n\n';
    } else {
      // Standard section
      const content = section.dataKeys
        .map(key => data[key]?.refined)
        .filter(Boolean)
        .join('\n\n') || '_To be defined_';
      epic += `${content}\n\n`;
    }
  }

  // Generate the multilayer summary diagram
  const diagram = generateMultilayerDiagram(data, projectName);

  return { epic, diagram };
}

// Generate architecture diagram from refined data
function generateArchitectureDiagram(data: RefinedData): string {
  const hasDataStores = data['dataStores']?.refined;
  const hasFeatures = data['features']?.refined;

  let diagram = 'graph TD\n';
  diagram += '    User[User/Client] --> API[API Gateway]\n';
  diagram += '    API --> Services[Service Layer]\n';

  if (hasFeatures) {
    diagram += '    Services --> Features[Feature Modules]\n';
  }

  if (hasDataStores) {
    diagram += '    Services --> DB[(Database)]\n';
    diagram += '    Services --> Cache[(Cache)]\n';
  } else {
    diagram += '    Services --> DB[(Data Store)]\n';
  }

  diagram += '    Services --> External[External Services]\n';

  return diagram;
}

// Generate multilayer diagram showing the full flow
function generateMultilayerDiagram(data: RefinedData, projectName: string): string {
  let diagram = 'graph TD\n';

  // Input Layer
  diagram += '    subgraph Input["Input Layer"]\n';
  diagram += '        I1[Project Info]\n';
  diagram += '        I2[Objective & Scope]\n';
  diagram += '        I3[Architecture]\n';
  diagram += '        I4[Features]\n';
  diagram += '        I5[Team & Env]\n';
  diagram += '        I6[Delivery]\n';
  diagram += '    end\n\n';

  // Refinement Layer
  diagram += '    subgraph Refine["AI Refinement Layer"]\n';
  diagram += '        R1[Refined Background]\n';
  diagram += '        R2[Refined Scope]\n';
  diagram += '        R3[Refined Architecture]\n';
  diagram += '        R4[Refined Features]\n';
  diagram += '        R5[Refined Team]\n';
  diagram += '        R6[Refined Delivery]\n';
  diagram += '    end\n\n';

  // Connections
  diagram += '    I1 --> R1\n';
  diagram += '    I2 --> R2\n';
  diagram += '    I3 --> R3\n';
  diagram += '    I4 --> R4\n';
  diagram += '    I5 --> R5\n';
  diagram += '    I6 --> R6\n\n';

  // Epic Document
  diagram += `    subgraph Epic["${projectName} Epic"]\n`;
  diagram += '        E[17-Section Document]\n';
  diagram += '    end\n\n';

  diagram += '    R1 --> E\n';
  diagram += '    R2 --> E\n';
  diagram += '    R3 --> E\n';
  diagram += '    R4 --> E\n';
  diagram += '    R5 --> E\n';
  diagram += '    R6 --> E\n';

  return diagram;
}

// Main skill runner
export async function runSkill(
  skill: 'refine' | 'generate',
  params: {
    stageId?: string;
    fieldName?: string;
    input?: string;
    context?: Record<string, string>;
    data?: RefinedData;
    projectName?: string;
  }
): Promise<RefineResult | GenerateResult> {
  if (skill === 'refine') {
    return refineInput(
      params.stageId!,
      params.fieldName!,
      params.input!,
      params.context || {}
    );
  } else {
    return generateEpic(params.data!, params.projectName!);
  }
}

// Generate PlantUML Blueprint - Multilayer Epic Narrative Diagram
export function generatePlantUMLBlueprint(data: RefinedData, projectName: string): string {
  // Extract key data for the diagram
  const features = data['features']?.original?.split('\n').filter(Boolean).slice(0, 5) || ['Feature 1', 'Feature 2'];
  const teams = data['teams']?.original?.split('\n').filter(Boolean).slice(0, 4) || ['Team Member'];
  const dataStores = data['dataStores']?.original ? true : false;
  const hasNFRs = data['nfrs']?.original ? true : false;
  const risks = data['risks']?.original?.split('\n').filter(Boolean).slice(0, 3) || [];
  const deliverables = data['deliverables']?.original?.split('\n').filter(Boolean).slice(0, 4) || ['Deliverable 1'];

  let puml = `@startuml
!theme plain
skinparam backgroundColor #FEFEFE
skinparam roundcorner 8
skinparam packageStyle rectangle
skinparam defaultFontName "Segoe UI"
skinparam defaultFontSize 11
skinparam ArrowColor #666666
skinparam PackageBorderColor #CCCCCC
skinparam PackageBackgroundColor #F8F9FA
skinparam RectangleBorderColor #AAAAAA

title <size:18><b>${projectName}</b></size>\\n<size:12>Epic Blueprint - Multilayer Architecture</size>

' ============================================
' LAYER 1: STAKEHOLDERS & INPUT
' ============================================
package "1. Stakeholders & Input" #E3F2FD {
  actor "Product Owner" as PO #4CAF50
  actor "Tech Lead" as TL #2196F3
  actor "Business Stakeholder" as BS #FF9800

  rectangle "Project Vision" as vision #BBDEFB {
    card "Objective" as obj
    card "Background" as bg
    card "Scope" as scope
  }

  PO --> vision
  TL --> vision
  BS --> vision
}

' ============================================
' LAYER 2: REQUIREMENTS & SCOPE
' ============================================
package "2. Requirements & Scope" #E8F5E9 {
  rectangle "In Scope" as inScope #C8E6C9 {
`;

  // Add features dynamically
  features.forEach((f, i) => {
    const cleanFeature = f.replace(/[^a-zA-Z0-9\s]/g, '').trim().slice(0, 25);
    puml += `    card "${cleanFeature}" as f${i + 1}\n`;
  });

  puml += `  }

  rectangle "Out of Scope" as outScope #FFECB3 {
    card "Excluded Items" as excluded
  }

  rectangle "Assumptions" as assumptions #E1F5FE {
    card "Technical Assumptions" as techAssume
    card "Business Assumptions" as bizAssume
  }

  vision --> inScope
  vision --> outScope
  vision --> assumptions
}

' ============================================
' LAYER 3: ARCHITECTURE & DESIGN
' ============================================
package "3. Architecture & Design" #FFF3E0 {
  rectangle "System Architecture" as sysArch #FFE0B2 {
    component "Frontend\\n(React SPA)" as frontend #42A5F5
    component "API Gateway" as api #66BB6A
    component "Services Layer" as services #FFA726
`;

  if (dataStores) {
    puml += `    database "Database" as db #7E57C2
    database "Cache" as cache #EC407A
`;
  } else {
    puml += `    database "Data Store" as db #7E57C2
`;
  }

  puml += `  }

  frontend --> api : REST/GraphQL
  api --> services : Business Logic
  services --> db : Persist
`;

  if (dataStores) {
    puml += `  services --> cache : Cache
`;
  }

  puml += `
  rectangle "External Integrations" as external #FFCDD2 {
    cloud "Third-party APIs" as thirdParty
    cloud "Auth Provider" as auth
  }

  services --> thirdParty
  services --> auth

  inScope --> sysArch
}

' ============================================
' LAYER 4: TEAM & EXECUTION
' ============================================
package "4. Team & Execution" #F3E5F5 {
  rectangle "Team Structure" as teamStruct #E1BEE7 {
`;

  // Add team members dynamically
  teams.forEach((t, i) => {
    const cleanTeam = t.replace(/[^a-zA-Z0-9\s\-]/g, '').trim().slice(0, 30);
    puml += `    card "${cleanTeam}" as tm${i + 1}\n`;
  });

  puml += `  }

  rectangle "Environments" as envs #D1C4E9 {
    node "Development" as dev
    node "Staging" as staging
    node "Production" as prod
  }

  dev --> staging : Promote
  staging --> prod : Deploy

  rectangle "CI/CD Pipeline" as cicd #B39DDB {
    card "Build" as build
    card "Test" as test
    card "Deploy" as deploy
  }

  build --> test
  test --> deploy
  deploy --> dev

  sysArch --> teamStruct : Implement
  teamStruct --> envs
}

' ============================================
' LAYER 5: QUALITY & COMPLIANCE
' ============================================
package "5. Quality & Compliance" #FFEBEE {
`;

  if (hasNFRs) {
    puml += `  rectangle "NFRs" as nfrs #FFCDD2 {
    card "Performance" as perf
    card "Scalability" as scale
    card "Security" as sec
    card "Availability" as avail
  }
`;
  }

  puml += `
  rectangle "Security Controls" as security #EF9A9A {
    card "Authentication" as authn
    card "Authorization" as authz
    card "Encryption" as encrypt
    card "Audit Logs" as audit
  }

  envs --> security : Secure
`;

  if (hasNFRs) {
    puml += `  envs --> nfrs : Validate
`;
  }

  puml += `}

' ============================================
' LAYER 6: RISKS & DEPENDENCIES
' ============================================
package "6. Risks & Dependencies" #FBE9E7 {
  rectangle "Dependencies" as deps #FFCCBC {
    card "Internal Teams" as intDeps
    card "External Vendors" as extDeps
  }

  rectangle "Risks" as riskBox #FFAB91 {
`;

  if (risks.length > 0) {
    risks.forEach((r, i) => {
      const cleanRisk = r.replace(/[^a-zA-Z0-9\s]/g, '').trim().slice(0, 25);
      puml += `    card "${cleanRisk}" as risk${i + 1} #FF8A65\n`;
    });
  } else {
    puml += `    card "Resource Risk" as risk1 #FF8A65
    card "Timeline Risk" as risk2 #FF8A65
`;
  }

  puml += `  }

  rectangle "Mitigations" as mitigations #A5D6A7 {
    card "Contingency Plans" as contingency
  }

  riskBox --> mitigations : Mitigate
  deps --> riskBox : May cause
}

' ============================================
' LAYER 7: DELIVERABLES & OUTCOMES
' ============================================
package "7. Deliverables & Outcomes" #E8EAF6 {
  rectangle "Deliverables" as deliv #C5CAE9 {
`;

  deliverables.forEach((d, i) => {
    const cleanDeliv = d.replace(/[^a-zA-Z0-9\s]/g, '').trim().slice(0, 30);
    puml += `    artifact "${cleanDeliv}" as del${i + 1}\n`;
  });

  puml += `  }

  rectangle "Definition of Done" as dod #9FA8DA {
    card "Code Complete" as cc
    card "Tests Pass" as tp
    card "Deployed" as dep
    card "Approved" as app
  }

  cc --> tp
  tp --> dep
  dep --> app

  rectangle "Approvals" as approvals #7986CB {
    card "Technical Sign-off" as techApp
    card "Business Sign-off" as bizApp
  }

  security --> deliv : Secure Delivery
  deliv --> dod : Validate
  dod --> approvals : Submit
}

' ============================================
' FLOW CONNECTIONS (Epic Narrative)
' ============================================
vision -[#2196F3,bold]-> inScope : <size:10>Defines</size>
inScope -[#4CAF50,bold]-> sysArch : <size:10>Architected</size>
sysArch -[#FF9800,bold]-> teamStruct : <size:10>Built by</size>
teamStruct -[#9C27B0,bold]-> security : <size:10>Secured</size>
security -[#F44336,bold]-> deps : <size:10>Managed</size>
deps -[#3F51B5,bold]-> deliv : <size:10>Produces</size>
deliv -[#009688,bold]-> approvals : <size:10>Approved</size>

legend right
  |<#E3F2FD> Stakeholders & Input |
  |<#E8F5E9> Requirements & Scope |
  |<#FFF3E0> Architecture & Design |
  |<#F3E5F5> Team & Execution |
  |<#FFEBEE> Quality & Compliance |
  |<#FBE9E7> Risks & Dependencies |
  |<#E8EAF6> Deliverables & Outcomes |
endlegend

@enduml`;

  return puml;
}

// Export for use in components
export { refineInput, generateEpic, generateMultilayerDiagram };
