/**
 * Conditional MSAL Authentication Provider
 *
 * React 19 compatible authentication provider that:
 * - When MSAL_AUTH_ENABLED is true: Wraps app with MsalProvider and handles Azure AD auth
 * - When MSAL_AUTH_ENABLED is false: Bypasses all auth, renders children directly
 * - When MSAL_AUTH_MOCK is true: Uses mock auth for local testing
 *
 * IMPORTANT: This implementation has been reviewed and fixed for:
 * - Infinite loop prevention (no accounts in useEffect deps)
 * - Memory leak prevention (isMounted guard)
 * - Race condition prevention (consolidated state updates)
 * - StrictMode compatibility (initialization guard)
 */

import React, { createContext, useContext, useEffect, useState, useCallback, useRef } from 'react';
import { MSAL_AUTH_ENABLED, msalConfig, loginRequest, shouldUseMsalAuth } from './authConfig';
import { MockAuthProvider, MOCK_AUTH_ENABLED, useMockAuth } from './MockAuthProvider';
import type { AuthContextType, AuthenticatedUser, AuthProviderProps } from './types';

// ===========================================
// CONDITIONAL MSAL IMPORTS
// Only import MSAL when auth is enabled to enable tree-shaking
// ===========================================

let PublicClientApplication: any = null;
let MsalProvider: any = null;
let useMsal: any = null;
let useIsAuthenticated: any = null;
let InteractionStatus: any = null;

// Dynamic import MSAL only when needed
if (MSAL_AUTH_ENABLED) {
  try {
    const msalBrowser = require('@azure/msal-browser');
    const msalReact = require('@azure/msal-react');

    PublicClientApplication = msalBrowser.PublicClientApplication;
    InteractionStatus = msalBrowser.InteractionStatus;
    MsalProvider = msalReact.MsalProvider;
    useMsal = msalReact.useMsal;
    useIsAuthenticated = msalReact.useIsAuthenticated;
  } catch (e) {
    console.error('[Auth] Failed to load MSAL packages. Make sure @azure/msal-browser and @azure/msal-react are installed.');
    console.error(e);
  }
}

// ===========================================
// AUTH CONTEXT
// ===========================================

const defaultAuthContext: AuthContextType = {
  user: null,
  isAuthenticated: !MSAL_AUTH_ENABLED, // Always "authenticated" when auth disabled
  isLoading: false,
  error: null,
  login: async () => {},
  logout: async () => {},
};

const AuthContext = createContext<AuthContextType>(defaultAuthContext);

// Internal hook for real MSAL auth context (not exported - use useAuth instead)
const useRealAuthContext = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// ===========================================
// MSAL AUTH CONTENT (Internal component)
// Only used when MSAL is enabled
// ===========================================

const MsalAuthContent: React.FC<AuthProviderProps> = ({ children }) => {
  const { instance, inProgress } = useMsal();
  const isAuthenticated = useIsAuthenticated();
  const [user, setUser] = useState<AuthenticatedUser | null>(null);
  const [isInitialized, setIsInitialized] = useState(false);
  const [authError, setAuthError] = useState<Error | null>(null);

  // Guard against double initialization in StrictMode
  const isInitializing = useRef(false);

  // Single initialization effect - NO accounts in dependencies to prevent infinite loop
  useEffect(() => {
    // Prevent double initialization in StrictMode
    if (isInitializing.current || isInitialized) {
      return;
    }
    isInitializing.current = true;

    let isMounted = true;

    const initializeAuth = async () => {
      try {
        // Handle any redirect response from Azure AD
        const response = await instance.handleRedirectPromise();

        if (!isMounted) return;

        let activeAccount = response?.account;

        // If no redirect response, check for existing accounts
        if (!activeAccount) {
          activeAccount = instance.getActiveAccount();
          if (!activeAccount) {
            const allAccounts = instance.getAllAccounts();
            if (allAccounts.length > 0) {
              activeAccount = allAccounts[0];
            }
          }
        }

        // Set active account and update user state together (prevent race condition)
        if (activeAccount) {
          instance.setActiveAccount(activeAccount);
          setUser({
            name: activeAccount.name || 'Unknown User',
            email: activeAccount.username || '',
            username: activeAccount.username?.split('@')[0] || '',
            tenantId: activeAccount.tenantId,
            objectId: activeAccount.localAccountId,
          });
        } else {
          setUser(null);
        }

        setAuthError(null);
      } catch (error) {
        console.error('[Auth] Redirect handling error:', error);
        if (isMounted) {
          setAuthError(error instanceof Error ? error : new Error(String(error)));
          setUser(null);
        }
      } finally {
        if (isMounted) {
          setIsInitialized(true);
        }
      }
    };

    initializeAuth();

    // Cleanup function to prevent state updates after unmount
    return () => {
      isMounted = false;
    };
  }, [instance, isInitialized]); // NO accounts dependency - prevents infinite loop

  // Login handler
  const login = useCallback(async () => {
    try {
      setAuthError(null);
      await instance.loginRedirect(loginRequest);
    } catch (error) {
      console.error('[Auth] Login failed:', error);
      setAuthError(error instanceof Error ? error : new Error(String(error)));
      throw error;
    }
  }, [instance]);

  // Logout handler
  const logout = useCallback(async () => {
    try {
      setUser(null);
      await instance.logoutRedirect({
        postLogoutRedirectUri: window.location.origin,
      });
    } catch (error) {
      console.error('[Auth] Logout failed:', error);
      throw error;
    }
  }, [instance]);

  // Get access token for API calls
  const getAccessToken = useCallback(async (): Promise<string | null> => {
    try {
      const account = instance.getActiveAccount();
      if (!account) return null;

      const response = await instance.acquireTokenSilent({
        ...loginRequest,
        account,
      });
      return response.accessToken;
    } catch (error) {
      console.error('[Auth] Token acquisition failed:', error);
      return null;
    }
  }, [instance]);

  const isLoading = !isInitialized || inProgress !== InteractionStatus.None;

  const authContextValue: AuthContextType = {
    user,
    isAuthenticated,
    isLoading,
    error: authError,
    login,
    logout,
    getAccessToken,
  };

  return (
    <AuthContext.Provider value={authContextValue}>
      {children}
    </AuthContext.Provider>
  );
};

// ===========================================
// MSAL INSTANCE (Singleton)
// ===========================================

let msalInstance: any = null;

const getMsalInstance = () => {
  if (!msalInstance && PublicClientApplication) {
    msalInstance = new PublicClientApplication(msalConfig);
  }
  return msalInstance;
};

// ===========================================
// AUTH PROVIDER (Main export)
// ===========================================

/**
 * Authentication Provider Component
 *
 * Priority:
 * 1. MOCK_AUTH_ENABLED (VITE_MSAL_AUTH_MOCK=true) - Use mock auth for local testing
 * 2. MSAL_AUTH_ENABLED (VITE_MSAL_AUTH_ENABLED=true) - Use real Azure AD auth
 * 3. Neither enabled - Bypass auth entirely (always authenticated)
 */
export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  // Priority 1: Mock auth mode for local testing
  if (MOCK_AUTH_ENABLED) {
    console.log('[Auth] Using MOCK authentication mode for local testing');
    return <MockAuthProvider>{children}</MockAuthProvider>;
  }

  // Priority 2: Real MSAL auth disabled - bypass entirely
  if (!shouldUseMsalAuth()) {
    const bypassAuthContext: AuthContextType = {
      user: null,
      isAuthenticated: true, // Always "authenticated" when auth is bypassed
      isLoading: false,
      error: null,
      login: async () => {
        console.log('[Auth] Authentication is disabled - login skipped');
      },
      logout: async () => {
        console.log('[Auth] Authentication is disabled - logout skipped');
      },
    };

    return (
      <AuthContext.Provider value={bypassAuthContext}>
        {children}
      </AuthContext.Provider>
    );
  }

  // Priority 3: Real MSAL auth - check if packages loaded successfully
  if (!MsalProvider || !PublicClientApplication) {
    console.error('[Auth] MSAL packages not available. Install with: npm install @azure/msal-browser @azure/msal-react');
    return (
      <div style={{ padding: '20px', color: 'red', fontFamily: 'sans-serif' }}>
        <h2>Authentication Error</h2>
        <p>MSAL packages not installed.</p>
        <code style={{ background: '#f5f5f5', padding: '8px', display: 'block', marginTop: '8px' }}>
          npm install @azure/msal-browser @azure/msal-react
        </code>
      </div>
    );
  }

  const instance = getMsalInstance();

  return (
    <MsalProvider instance={instance}>
      <MsalAuthContent>{children}</MsalAuthContent>
    </MsalProvider>
  );
};

// ===========================================
// UNIFIED useAuth HOOK
// Works with both Mock and Real auth providers
// ===========================================

/**
 * Hook to access authentication context
 * Works with Mock, Real MSAL, and Bypass modes
 */
export const useAuth = (): AuthContextType => {
  // Try mock auth context first (when MOCK_AUTH_ENABLED)
  if (MOCK_AUTH_ENABLED) {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    return useMockAuth();
  }

  // Use regular auth context
  // eslint-disable-next-line react-hooks/rules-of-hooks
  return useRealAuthContext();
};
