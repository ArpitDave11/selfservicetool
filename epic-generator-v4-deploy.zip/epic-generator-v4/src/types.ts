// Epic Generator Types & Constants

export interface StageField {
  name: string;
  label: string;
  placeholder: string;
  type: 'text' | 'textarea';
  required: boolean;
}

export interface Stage {
  id: string;
  title: string;
  description: string;
  fields: StageField[];
  populatesSections: number[];
}

export interface RefinedData {
  [key: string]: {
    original: string;
    refined: string;
    diagramNode: string;
  };
}

export interface EpicState {
  currentStage: number;
  data: RefinedData;
  diagramNodes: string[];
  generatedEpic: string | null;
}

// Chat/Feedback Types
export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  // For AI follow-up questions
  questionType?: 'section-select' | 'text-input' | 'confirm';
  options?: string[];  // For dropdown options
  selectedValue?: string;  // User's answer
  isAnswered?: boolean;  // Whether this question has been answered
}

export interface ChatState {
  messages: ChatMessage[];
  isOpen: boolean;
  isProcessing: boolean;
  pendingSection?: number;  // Section being modified
  pendingFeedback?: string;  // Original feedback to apply
}

// AI Refinement Types
export interface SectionFeedback {
  sectionNum: number;           // 1-17
  sectionTitle: string;         // e.g., "Objective", "Scope"
  score: number;                // 0-10 for this section
  status: 'strong' | 'adequate' | 'weak' | 'missing';
  issues: string[];             // Specific problems found
  suggestions: string[];        // How to improve
  refinedContent?: string;      // AI-improved version (optional)
}

export interface EpicQualityReport {
  overallScore: number;         // 0-10
  summary: string;              // One paragraph overall assessment
  sections: SectionFeedback[];  // Feedback for each section
  criticalIssues: string[];     // Must-fix problems
  strengthAreas: string[];      // What's done well
  missingRequired: string[];    // Required info that's missing
}

export interface RefinementState {
  isRefining: boolean;
  progress: { current: number; total: number; section: string };
  report: EpicQualityReport | null;
  showReport: boolean;
}

// 6 Input Stages
export const STAGES: Stage[] = [
  {
    id: 'project',
    title: 'Project',
    description: 'Project name and background context',
    fields: [
      { name: 'projectName', label: 'Project Name', placeholder: 'Enter project name', type: 'text', required: true },
      { name: 'background', label: 'Background & Context', placeholder: 'Why does this project exist? What problem does it solve?', type: 'textarea', required: true },
    ],
    populatesSections: [1, 2],
  },
  {
    id: 'objective_scope',
    title: 'Objective & Scope',
    description: 'Define the goal and boundaries',
    fields: [
      { name: 'objective', label: 'Objective', placeholder: 'What is the main goal of this project?', type: 'textarea', required: true },
      { name: 'inScope', label: 'In Scope', placeholder: 'What is included in this project?', type: 'textarea', required: true },
      { name: 'outOfScope', label: 'Out of Scope', placeholder: 'What is explicitly excluded?', type: 'textarea', required: false },
    ],
    populatesSections: [1, 3],
  },
  {
    id: 'architecture',
    title: 'Architecture',
    description: 'System design and data stores',
    fields: [
      { name: 'assumptions', label: 'Assumptions', placeholder: 'What assumptions are we making?', type: 'textarea', required: false },
      { name: 'architectureOverview', label: 'Architecture Overview', placeholder: 'Describe the high-level system architecture', type: 'textarea', required: true },
      { name: 'dataStores', label: 'Data Stores & Services', placeholder: 'What databases, APIs, and services will be used?', type: 'textarea', required: true },
    ],
    populatesSections: [4, 5, 6, 10],
  },
  {
    id: 'features',
    title: 'Features',
    description: 'Key features, user stories, and requirements',
    fields: [
      { name: 'features', label: 'Key Features', placeholder: 'List the main features', type: 'textarea', required: true },
      { name: 'userStories', label: 'User Stories', placeholder: 'As a [user], I want [feature] so that [benefit]', type: 'textarea', required: false },
      { name: 'nfrs', label: 'Non-Functional Requirements', placeholder: 'Performance, scalability, security requirements', type: 'textarea', required: false },
      { name: 'deliverables', label: 'Deliverables', placeholder: 'What will be delivered?', type: 'textarea', required: true },
    ],
    populatesSections: [11, 12, 14],
  },
  {
    id: 'team_env',
    title: 'Team & Environment',
    description: 'Team structure, environments, and security',
    fields: [
      { name: 'teams', label: 'Team & Roles', placeholder: 'Who is involved and what are their roles?', type: 'textarea', required: true },
      { name: 'environments', label: 'Environments & CI/CD', placeholder: 'Dev, Staging, Prod environments and deployment strategy', type: 'textarea', required: true },
      { name: 'security', label: 'Data Security & Access', placeholder: 'Security requirements and access controls', type: 'textarea', required: false },
    ],
    populatesSections: [7, 8, 9],
  },
  {
    id: 'delivery',
    title: 'Delivery',
    description: 'Dependencies, risks, and completion criteria',
    fields: [
      { name: 'dependencies', label: 'Dependencies', placeholder: 'What does this project depend on?', type: 'textarea', required: false },
      { name: 'risks', label: 'Risks', placeholder: 'What are the potential risks?', type: 'textarea', required: false },
      { name: 'nextSteps', label: 'Next Steps', placeholder: 'Immediate actions to take', type: 'textarea', required: true },
      { name: 'dod', label: 'Definition of Done', placeholder: 'When is this project considered complete?', type: 'textarea', required: true },
      { name: 'approvers', label: 'Approvers', placeholder: 'Who needs to sign off?', type: 'textarea', required: false },
    ],
    populatesSections: [13, 15, 16, 17],
  },
];

// 17 Epic Sections Template
export const EPIC_SECTIONS = [
  { num: 1, title: 'Objective', dataKeys: ['objective'] },
  { num: 2, title: 'Background & Context', dataKeys: ['background'] },
  { num: 3, title: 'Scope', dataKeys: ['inScope', 'outOfScope'], subsections: ['In Scope', 'Out of Scope'] },
  { num: 4, title: 'Assumptions', dataKeys: ['assumptions'] },
  { num: 5, title: 'High-Level Architecture Overview', dataKeys: ['architectureOverview'], hasDiagram: true },
  { num: 6, title: 'Architecture Diagrams', dataKeys: [], isReference: true },
  { num: 7, title: 'Team & Roles', dataKeys: ['teams'], isTable: true },
  { num: 8, title: 'Environments & CI/CD Strategy', dataKeys: ['environments'] },
  { num: 9, title: 'Data Security & Access Controls', dataKeys: ['security'] },
  { num: 10, title: 'Data Stores, Services & Interfaces', dataKeys: ['dataStores'] },
  { num: 11, title: 'Key Features & User Stories', dataKeys: ['features', 'userStories'] },
  { num: 12, title: 'Non-Functional Requirements (NFRs)', dataKeys: ['nfrs'] },
  { num: 13, title: 'Dependencies & Risks', dataKeys: ['dependencies', 'risks'], subsections: ['Dependencies', 'Risks'] },
  { num: 14, title: 'Deliverables', dataKeys: ['deliverables'] },
  { num: 15, title: 'Next Steps', dataKeys: ['nextSteps'] },
  { num: 16, title: 'Definition of Done (DoD)', dataKeys: ['dod'] },
  { num: 17, title: 'Approvals & Sign-Offs', dataKeys: ['approvers'], isTable: true },
];
