// Configuration for Epic Generator
// OpenAI + Azure OpenAI + GitLab Integration

// ===========================================
// AI PROVIDER TYPE
// ===========================================
export type AIProvider = 'none' | 'openai' | 'azure';

// ===========================================
// MODEL FAMILY DETECTION
// ===========================================
// Model family detection - GPT-5 has different limits than GPT-4
export type ModelFamily = 'gpt-4' | 'gpt-5' | 'gpt-3.5' | 'unknown';

// ===========================================
// OPENAI CONFIGURATION (Direct API)
// ===========================================
export interface OpenAIConfig {
  enabled: boolean;
  apiKey: string;            // sk-... API key from OpenAI
  model: string;             // e.g., "gpt-4o", "gpt-4-turbo", "gpt-3.5-turbo"
  organizationId?: string;   // Optional organization ID
  maxTokens: number;
  temperature: number;
  baseUrl?: string;          // Optional custom base URL (for proxies)
}

// ===========================================
// AZURE OPENAI CONFIGURATION
// ===========================================
export interface AzureOpenAIConfig {
  enabled: boolean;
  endpoint: string;        // e.g., "https://your-resource.openai.azure.com"
  deploymentName: string;  // Your deployment name
  apiKey: string;
  apiVersion: string;      // e.g., "2024-02-15-preview"
  maxTokens: number;
  temperature: number;
  modelFamily?: ModelFamily;  // Auto-detected or user-specified
}

// ===========================================
// GITLAB CONFIGURATION
// ===========================================
export interface GitLabConfig {
  enabled: boolean;
  baseUrl: string;           // e.g., "https://gitlab.com" or self-hosted
  projectId: string;         // Legacy: Project ID for file operations (kept for compatibility)
  accessToken: string;       // Personal Access Token with api scope
  branch: string;            // Legacy: Target branch for commits
  epicFilePath: string;      // Legacy: Path where epic.md will be saved
  rootGroupId: string;       // Root group ID for epic operations
  selectedPodId: string;     // Legacy: Selected pod (subgroup) ID
  selectedEpicId: string;    // Legacy: Selected epic ID
  // Epic-focused configuration
  crewLabelPrefix: string;   // Label prefix for crew-level epics (e.g., "crew::")
  podLabelPrefix: string;    // Label prefix for pod-level epics (e.g., "pod::")
}

// ===========================================
// GITLAB EPIC TYPES
// ===========================================
export interface GitLabEpic {
  id: number;
  iid: number;
  group_id: number;
  title: string;
  description: string;
  state: 'opened' | 'closed';
  confidential: boolean;
  author: {
    id: number;
    username: string;
    name: string;
  };
  labels: string[];
  start_date: string | null;
  due_date: string | null;
  created_at: string;
  updated_at: string;
  closed_at: string | null;
  web_url: string;
  parent?: {
    id: number;
    iid: number;
    title: string;
  };
  epicLevel?: 'crew' | 'pod' | 'unknown';
}

export interface GitLabEpicListResult {
  success: boolean;
  data?: GitLabEpic[];
  totalCount?: number;
  error?: string;
}

export interface GitLabEpicResult {
  success: boolean;
  data?: GitLabEpic;
  error?: string;
}

export interface GitLabLabel {
  id: number;
  name: string;
  color: string;
  text_color: string;
  description: string | null;
}

export interface GitLabLabelResult {
  success: boolean;
  data?: GitLabLabel[];
  error?: string;
}

export interface GitLabEpicChild {
  id: number;
  iid: number;
  title: string;
  type: 'epic' | 'issue';
  state: string;
  web_url: string;
}

export interface GitLabEpicChildrenResult {
  success: boolean;
  epics?: GitLabEpicChild[];
  issues?: GitLabEpicChild[];
  error?: string;
}

export interface GitLabCreateEpicParams {
  title: string;
  description?: string;
  labels?: string[];
  confidential?: boolean;
  start_date_fixed?: string;
  due_date_fixed?: string;
  parent_id?: number;
}

export interface GitLabUpdateEpicParams {
  title?: string;
  description?: string;
  labels?: string[];
  state_event?: 'close' | 'reopen';
  add_labels?: string[];
  remove_labels?: string[];
}

export interface GitLabEpicSearchParams {
  search?: string;
  labels?: string[];
  state?: 'opened' | 'closed' | 'all';
  author_id?: number;
  order_by?: 'created_at' | 'updated_at' | 'title';
  sort?: 'asc' | 'desc';
  per_page?: number;
  page?: number;
  include_descendant_groups?: boolean;
}

// ===========================================
// APP CONFIG
// ===========================================
export interface AppConfig {
  aiProvider: AIProvider;    // Which AI provider to use
  openAI: OpenAIConfig;      // OpenAI direct API config
  azureOpenAI: AzureOpenAIConfig;
  gitlab: GitLabConfig;
}

// Default configuration
export const DEFAULT_CONFIG: AppConfig = {
  aiProvider: 'none',
  openAI: {
    enabled: false,
    apiKey: '',
    model: 'gpt-4o',
    organizationId: '',
    maxTokens: 4096,
    temperature: 0.7,
    baseUrl: 'https://api.openai.com/v1',
  },
  azureOpenAI: {
    enabled: false,
    endpoint: '',
    deploymentName: '',
    apiKey: '',
    apiVersion: '2024-02-15-preview',
    maxTokens: 4096,
    temperature: 0.7,
  },
  gitlab: {
    enabled: false,
    baseUrl: 'http://devcloud.ubs.net',
    projectId: '',
    accessToken: '',
    branch: 'main',
    epicFilePath: 'docs/epics/',
    rootGroupId: '557797',
    selectedPodId: '',
    selectedEpicId: '',
    crewLabelPrefix: 'crew::',
    podLabelPrefix: 'pod::',
  },
};

// Available OpenAI models
export const OPENAI_MODELS = [
  { id: 'gpt-4o', name: 'GPT-4o (Recommended)', family: 'gpt-4' as ModelFamily },
  { id: 'gpt-4o-mini', name: 'GPT-4o Mini (Fast & Cheap)', family: 'gpt-4' as ModelFamily },
  { id: 'gpt-4-turbo', name: 'GPT-4 Turbo', family: 'gpt-4' as ModelFamily },
  { id: 'gpt-4', name: 'GPT-4', family: 'gpt-4' as ModelFamily },
  { id: 'gpt-3.5-turbo', name: 'GPT-3.5 Turbo (Budget)', family: 'gpt-3.5' as ModelFamily },
  { id: 'o1-preview', name: 'o1 Preview (Reasoning)', family: 'gpt-5' as ModelFamily },
  { id: 'o1-mini', name: 'o1 Mini (Fast Reasoning)', family: 'gpt-5' as ModelFamily },
];

// Available API versions for Azure OpenAI
export const AZURE_API_VERSIONS = [
  '2024-12-01-preview',  // Latest for GPT-5
  '2024-10-01-preview',
  '2024-08-01-preview',
  '2024-06-01',
  '2024-05-01-preview',
  '2024-02-15-preview',
  '2023-12-01-preview',
  '2023-05-15',
];

// Model family limits - different models have different capabilities
export const MODEL_LIMITS: Record<ModelFamily, { maxTokens: number; maxTemperature: number; defaultTokens: number }> = {
  'gpt-4': {
    maxTokens: 128000,      // GPT-4 Turbo supports up to 128K
    maxTemperature: 2.0,
    defaultTokens: 4096,
  },
  'gpt-3.5': {
    maxTokens: 16384,       // GPT-3.5 Turbo supports up to 16K
    maxTemperature: 2.0,
    defaultTokens: 4096,
  },
  'gpt-5': {
    maxTokens: 16384,       // GPT-5/o1 has lower max_completion_tokens
    maxTemperature: 1.0,    // GPT-5/o1 temperature must be <= 1.0
    defaultTokens: 4096,
  },
  'unknown': {
    maxTokens: 4096,        // Safe default
    maxTemperature: 1.0,    // Safe default
    defaultTokens: 2048,
  },
};

// Detect model family from deployment name or model ID
export function detectModelFamily(modelName: string): ModelFamily {
  const name = modelName.toLowerCase();

  // GPT-5 / o1 / o3 series (reasoning models)
  if (name.includes('gpt-5') || name.includes('gpt5') || name.includes('o1') || name.includes('o3')) {
    return 'gpt-5';
  }

  // GPT-4 series
  if (name.includes('gpt-4') || name.includes('gpt4')) {
    return 'gpt-4';
  }

  // GPT-3.5 series
  if (name.includes('gpt-3.5') || name.includes('gpt3.5') || name.includes('gpt-35')) {
    return 'gpt-3.5';
  }

  // Turbo without version number - assume GPT-4
  if (name.includes('turbo')) {
    return 'gpt-4';
  }

  return 'unknown';
}

// Get model family for OpenAI model
export function getOpenAIModelFamily(modelId: string): ModelFamily {
  const model = OPENAI_MODELS.find(m => m.id === modelId);
  return model?.family || detectModelFamily(modelId);
}

// Get safe parameters for Azure OpenAI model
export function getSafeModelParams(config: AzureOpenAIConfig): { maxTokens: number; temperature: number } {
  const family = config.modelFamily || detectModelFamily(config.deploymentName);
  const limits = MODEL_LIMITS[family];

  return {
    maxTokens: Math.min(config.maxTokens || limits.defaultTokens, limits.maxTokens),
    temperature: Math.min(config.temperature || 0.7, limits.maxTemperature),
  };
}

// Get safe parameters for OpenAI model
export function getSafeOpenAIModelParams(config: OpenAIConfig): { maxTokens: number; temperature: number } {
  const family = getOpenAIModelFamily(config.model);
  const limits = MODEL_LIMITS[family];

  return {
    maxTokens: Math.min(config.maxTokens || limits.defaultTokens, limits.maxTokens),
    temperature: Math.min(config.temperature || 0.7, limits.maxTemperature),
  };
}

// ===========================================
// CONFIG STORAGE (localStorage)
// ===========================================
const CONFIG_STORAGE_KEY = 'epic-generator-config';

export function loadConfig(): AppConfig {
  try {
    const stored = localStorage.getItem(CONFIG_STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);

      // Determine AI provider based on what's enabled (migration from old config)
      let aiProvider: AIProvider = parsed.aiProvider || 'none';
      if (!parsed.aiProvider) {
        // Migrate from old config format
        if (parsed.openAI?.enabled) {
          aiProvider = 'openai';
        } else if (parsed.azureOpenAI?.enabled) {
          aiProvider = 'azure';
        }
      }

      // Merge with defaults to handle new fields
      return {
        aiProvider,
        openAI: { ...DEFAULT_CONFIG.openAI, ...parsed.openAI },
        azureOpenAI: { ...DEFAULT_CONFIG.azureOpenAI, ...parsed.azureOpenAI },
        gitlab: { ...DEFAULT_CONFIG.gitlab, ...parsed.gitlab },
      };
    }
  } catch (e) {
    console.error('Failed to load config:', e);
  }
  return DEFAULT_CONFIG;
}

export function saveConfig(config: AppConfig): void {
  try {
    localStorage.setItem(CONFIG_STORAGE_KEY, JSON.stringify(config));
  } catch (e) {
    console.error('Failed to save config:', e);
  }
}

// ===========================================
// AZURE OPENAI API CALLS
// ===========================================
export async function callAzureOpenAI(
  config: AzureOpenAIConfig,
  systemPrompt: string,
  userPrompt: string
): Promise<string> {
  if (!config.enabled) {
    // Return mock response when Azure is not configured
    await new Promise(resolve => setTimeout(resolve, 300));
    return userPrompt; // Just return the input as-is in mock mode
  }

  if (!config.endpoint || !config.apiKey || !config.deploymentName) {
    throw new Error('Azure OpenAI is not fully configured. Please check Settings.');
  }

  // Get safe parameters based on model family
  const safeParams = getSafeModelParams(config);
  const modelFamily = config.modelFamily || detectModelFamily(config.deploymentName);

  const url = `${config.endpoint}/openai/deployments/${config.deploymentName}/chat/completions?api-version=${config.apiVersion}`;

  // Build request body - GPT-5/o1 models use different parameter names
  const isGpt5Family = modelFamily === 'gpt-5';

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const requestBody: Record<string, any> = {
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userPrompt },
    ],
  };

  // GPT-5/o1 models use max_completion_tokens instead of max_tokens
  // and have stricter temperature limits
  if (isGpt5Family) {
    requestBody.max_completion_tokens = safeParams.maxTokens;
    // Some o1 models don't support temperature at all, but if they do, it must be <= 1.0
    if (safeParams.temperature <= 1.0) {
      requestBody.temperature = safeParams.temperature;
    }
  } else {
    requestBody.max_tokens = safeParams.maxTokens;
    requestBody.temperature = safeParams.temperature;
  }

  console.log(`[Azure OpenAI] Model family: ${modelFamily}, max_tokens: ${safeParams.maxTokens}, temperature: ${safeParams.temperature}`);

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'api-key': config.apiKey,
    },
    body: JSON.stringify(requestBody),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: { message: response.statusText } }));
    const errorMessage = error.error?.message || response.statusText;

    // Provide helpful error messages for common issues
    if (errorMessage.includes('max_tokens') || errorMessage.includes('max_completion_tokens')) {
      throw new Error(`Token limit error: ${errorMessage}. Try reducing Max Tokens in Settings or the model may have stricter limits.`);
    }
    if (errorMessage.includes('temperature')) {
      throw new Error(`Temperature error: ${errorMessage}. GPT-5/o1 models require temperature <= 1.0. Adjust in Settings.`);
    }

    throw new Error(`Azure OpenAI error: ${errorMessage}`);
  }

  const data = await response.json();
  return data.choices[0].message.content;
}

// Test Azure OpenAI connection
export async function testAzureOpenAI(config: AzureOpenAIConfig): Promise<{ success: boolean; error?: string }> {
  if (!config.endpoint || !config.apiKey || !config.deploymentName) {
    return { success: false, error: 'Endpoint, API Key, and Deployment Name are required' };
  }

  try {
    const result = await callAzureOpenAI(
      { ...config, enabled: true },
      'You are a helpful assistant.',
      'Say "Connection successful" in exactly those words.'
    );

    if (result.toLowerCase().includes('connection successful')) {
      return { success: true };
    }
    return { success: true }; // Any response means it worked
  } catch (e) {
    return { success: false, error: e instanceof Error ? e.message : 'Connection failed' };
  }
}

// ===========================================
// OPENAI DIRECT API CALLS
// ===========================================
export async function callOpenAI(
  config: OpenAIConfig,
  systemPrompt: string,
  userPrompt: string
): Promise<string> {
  if (!config.enabled) {
    // Return mock response when OpenAI is not configured
    await new Promise(resolve => setTimeout(resolve, 300));
    return userPrompt; // Just return the input as-is in mock mode
  }

  if (!config.apiKey) {
    throw new Error('OpenAI API key is not configured. Please check Settings.');
  }

  // Get safe parameters based on model family
  const safeParams = getSafeOpenAIModelParams(config);
  const modelFamily = getOpenAIModelFamily(config.model);

  const baseUrl = config.baseUrl || 'https://api.openai.com/v1';
  const url = `${baseUrl}/chat/completions`;

  // Build request body - o1 models use different parameter names
  const isO1Family = modelFamily === 'gpt-5';

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const requestBody: Record<string, any> = {
    model: config.model,
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userPrompt },
    ],
  };

  // o1 models use max_completion_tokens instead of max_tokens
  // and have stricter temperature limits (some don't support temperature at all)
  if (isO1Family) {
    requestBody.max_completion_tokens = safeParams.maxTokens;
    // o1 models may not support temperature - only add if <= 1.0
    if (safeParams.temperature <= 1.0) {
      requestBody.temperature = safeParams.temperature;
    }
  } else {
    requestBody.max_tokens = safeParams.maxTokens;
    requestBody.temperature = safeParams.temperature;
  }

  console.log(`[OpenAI] Model: ${config.model}, family: ${modelFamily}, max_tokens: ${safeParams.maxTokens}, temperature: ${safeParams.temperature}`);

  // Build headers
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${config.apiKey}`,
  };

  // Add organization ID if provided
  if (config.organizationId) {
    headers['OpenAI-Organization'] = config.organizationId;
  }

  const response = await fetch(url, {
    method: 'POST',
    headers,
    body: JSON.stringify(requestBody),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: { message: response.statusText } }));
    const errorMessage = error.error?.message || response.statusText;

    // Provide helpful error messages for common issues
    if (errorMessage.includes('max_tokens') || errorMessage.includes('max_completion_tokens')) {
      throw new Error(`Token limit error: ${errorMessage}. Try reducing Max Tokens in Settings.`);
    }
    if (errorMessage.includes('temperature')) {
      throw new Error(`Temperature error: ${errorMessage}. o1 models require temperature <= 1.0.`);
    }
    if (errorMessage.includes('invalid_api_key') || errorMessage.includes('Incorrect API key')) {
      throw new Error('Invalid API key. Please check your OpenAI API key in Settings.');
    }
    if (errorMessage.includes('quota') || errorMessage.includes('rate_limit')) {
      throw new Error('Rate limit or quota exceeded. Please wait and try again.');
    }

    throw new Error(`OpenAI error: ${errorMessage}`);
  }

  const data = await response.json();
  return data.choices[0].message.content;
}

// Test OpenAI connection
export async function testOpenAI(config: OpenAIConfig): Promise<{ success: boolean; error?: string; model?: string }> {
  if (!config.apiKey) {
    return { success: false, error: 'API Key is required' };
  }

  try {
    const result = await callOpenAI(
      { ...config, enabled: true },
      'You are a helpful assistant.',
      'Say "Connection successful" in exactly those words.'
    );

    if (result.toLowerCase().includes('connection successful')) {
      return { success: true, model: config.model };
    }
    return { success: true, model: config.model }; // Any response means it worked
  } catch (e) {
    return { success: false, error: e instanceof Error ? e.message : 'Connection failed' };
  }
}

// ===========================================
// UNIFIED AI CALL - Uses OpenAI, Azure OpenAI, or mock
// ===========================================
export async function callAI(
  config: AppConfig,
  systemPrompt: string,
  userPrompt: string
): Promise<string> {
  // Check which AI provider is active
  if (config.aiProvider === 'openai' && config.openAI.enabled) {
    return callOpenAI(config.openAI, systemPrompt, userPrompt);
  }

  if (config.aiProvider === 'azure' && config.azureOpenAI.enabled) {
    return callAzureOpenAI(config.azureOpenAI, systemPrompt, userPrompt);
  }

  // Fallback: Check individual enabled flags for backwards compatibility
  if (config.openAI.enabled) {
    return callOpenAI(config.openAI, systemPrompt, userPrompt);
  }

  if (config.azureOpenAI.enabled) {
    return callAzureOpenAI(config.azureOpenAI, systemPrompt, userPrompt);
  }

  // Mock mode - return input as-is
  await new Promise(resolve => setTimeout(resolve, 300));
  return userPrompt;
}

// Check if any AI provider is enabled
export function isAIEnabled(config: AppConfig): boolean {
  return (
    (config.aiProvider === 'openai' && config.openAI.enabled) ||
    (config.aiProvider === 'azure' && config.azureOpenAI.enabled) ||
    config.openAI.enabled ||
    config.azureOpenAI.enabled
  );
}

// Get the active AI provider name for display
export function getActiveAIProvider(config: AppConfig): string {
  if (config.aiProvider === 'openai' && config.openAI.enabled) {
    return `OpenAI (${config.openAI.model})`;
  }
  if (config.aiProvider === 'azure' && config.azureOpenAI.enabled) {
    return `Azure OpenAI (${config.azureOpenAI.deploymentName})`;
  }
  if (config.openAI.enabled) {
    return `OpenAI (${config.openAI.model})`;
  }
  if (config.azureOpenAI.enabled) {
    return `Azure OpenAI (${config.azureOpenAI.deploymentName})`;
  }
  return 'None';
}

// ===========================================
// GITLAB API CALLS
// ===========================================

// Build the API base URL - use Vite proxy in dev to bypass CORS
function getGitLabApiUrl(config: GitLabConfig): string {
  // In development, use the Vite proxy
  if (import.meta.env.DEV) {
    return '/gitlab-api';
  }
  // In production, use the configured base URL directly
  return `${config.baseUrl}/api/v4`;
}

export interface GitLabPublishResult {
  success: boolean;
  url?: string;
  error?: string;
}

// Result type for group/subgroup fetching
export interface GitLabGroupResult {
  success: boolean;
  data?: Array<{ id: number; name: string; path: string }>;
  error?: string;
}

// Result type for epics (combined subgroups + projects) - Legacy
export interface GitLabLegacyEpicResult {
  success: boolean;
  data?: Array<{ id: number; name: string; path: string; type: 'subgroup' | 'project' }>;
  error?: string;
}

// Fetch subgroups (Pods) for a given group ID
export async function fetchGitLabSubgroups(
  config: GitLabConfig,
  groupId: string
): Promise<GitLabGroupResult> {
  if (!config.accessToken) {
    return { success: false, error: 'Access token is required' };
  }

  const apiUrl = getGitLabApiUrl(config);
  const url = `${apiUrl}/groups/${groupId}/subgroups?per_page=100&page=1`;

  console.log('[GitLab API] Fetching subgroups from:', url);

  try {
    const response = await fetch(url, {
      headers: {
        'PRIVATE-TOKEN': config.accessToken,
      },
    });

    if (!response.ok) {
      return { success: false, error: `Failed: ${response.status} ${response.statusText}` };
    }

    const data = await response.json();
    return {
      success: true,
      data: data.map((item: { id: number; name: string; full_path: string }) => ({
        id: item.id,
        name: item.name,
        path: item.full_path,
      })),
    };
  } catch (e) {
    console.error('[GitLab API] Error fetching subgroups:', e);
    return { success: false, error: e instanceof Error ? e.message : 'Connection failed' };
  }
}

// Fetch BOTH subgroups AND projects within a group (Legacy navigation)
// This combines child groups and projects into a single list
export async function fetchGitLabLegacyEpics(
  config: GitLabConfig,
  groupId: string
): Promise<GitLabLegacyEpicResult> {
  if (!config.accessToken) {
    return { success: false, error: 'Access token is required' };
  }

  const apiUrl = getGitLabApiUrl(config);

  console.log('[GitLab API] Fetching epics (subgroups + projects) from group:', groupId);

  try {
    // Fetch both subgroups and projects in parallel
    const [subgroupsRes, projectsRes] = await Promise.all([
      fetch(`${apiUrl}/groups/${groupId}/subgroups?per_page=100&page=1`, {
        headers: { 'PRIVATE-TOKEN': config.accessToken },
      }),
      fetch(`${apiUrl}/groups/${groupId}/projects?per_page=100&page=1`, {
        headers: { 'PRIVATE-TOKEN': config.accessToken },
      }),
    ]);

    console.log('[GitLab API] Subgroups response:', subgroupsRes.status);
    console.log('[GitLab API] Projects response:', projectsRes.status);

    const results: Array<{ id: number; name: string; path: string; type: 'subgroup' | 'project' }> = [];

    if (subgroupsRes.ok) {
      const subgroups = await subgroupsRes.json();
      subgroups.forEach((item: { id: number; name: string; full_path: string }) => {
        results.push({
          id: item.id,
          name: `📁 ${item.name}`,  // Folder icon for subgroups
          path: item.full_path,
          type: 'subgroup',
        });
      });
    }

    if (projectsRes.ok) {
      const projects = await projectsRes.json();
      projects.forEach((item: { id: number; name: string; path_with_namespace: string }) => {
        results.push({
          id: item.id,
          name: `📄 ${item.name}`,  // Document icon for projects
          path: item.path_with_namespace,
          type: 'project',
        });
      });
    }

    return { success: true, data: results };
  } catch (e) {
    console.error('[GitLab API] Error fetching epics:', e);
    return { success: false, error: e instanceof Error ? e.message : 'Connection failed' };
  }
}

export async function publishToGitLab(
  config: GitLabConfig,
  fileName: string,
  content: string,
  commitMessage: string
): Promise<GitLabPublishResult> {
  if (!config.enabled) {
    return { success: false, error: 'GitLab integration is not enabled' };
  }

  if (!config.accessToken || !config.projectId) {
    return { success: false, error: 'GitLab access token and project ID are required' };
  }

  const apiUrl = getGitLabApiUrl(config);
  const filePath = `${config.epicFilePath}${fileName}`.replace(/\/+/g, '/');
  const encodedPath = encodeURIComponent(filePath);
  const encodedProjectId = encodeURIComponent(config.projectId);

  console.log('[GitLab API] Publishing to:', `${apiUrl}/projects/${encodedProjectId}/repository/files/${encodedPath}`);

  try {
    // Check if file exists
    const checkResponse = await fetch(
      `${apiUrl}/projects/${encodedProjectId}/repository/files/${encodedPath}?ref=${config.branch}`,
      {
        headers: {
          'PRIVATE-TOKEN': config.accessToken,
        },
      }
    );

    const fileExists = checkResponse.ok;

    // Create or update file
    const method = fileExists ? 'PUT' : 'POST';
    const response = await fetch(
      `${apiUrl}/projects/${encodedProjectId}/repository/files/${encodedPath}`,
      {
        method,
        headers: {
          'Content-Type': 'application/json',
          'PRIVATE-TOKEN': config.accessToken,
        },
        body: JSON.stringify({
          branch: config.branch,
          content: content,
          commit_message: commitMessage,
          encoding: 'text',
        }),
      }
    );

    if (!response.ok) {
      const error = await response.json();
      return { success: false, error: error.message || response.statusText };
    }

    const fileUrl = `${config.baseUrl}/${config.projectId}/-/blob/${config.branch}/${filePath}`;

    return { success: true, url: fileUrl };
  } catch (e) {
    return { success: false, error: e instanceof Error ? e.message : 'Unknown error' };
  }
}

// Test GitLab connection
export async function testGitLabConnection(config: GitLabConfig): Promise<{ success: boolean; error?: string; projectName?: string }> {
  if (!config.accessToken || !config.projectId) {
    return { success: false, error: 'Access token and project ID are required' };
  }

  const apiUrl = getGitLabApiUrl(config);
  const encodedProjectId = encodeURIComponent(config.projectId);
  const url = `${apiUrl}/projects/${encodedProjectId}`;

  console.log('[GitLab API] Testing connection:', url);

  try {
    const response = await fetch(url, {
      headers: {
        'PRIVATE-TOKEN': config.accessToken,
      },
    });

    if (!response.ok) {
      return { success: false, error: `Failed to connect: ${response.status} ${response.statusText}` };
    }

    const data = await response.json();
    return { success: true, projectName: data.name_with_namespace };
  } catch (e) {
    console.error('[GitLab API] Connection test failed:', e);
    return { success: false, error: e instanceof Error ? e.message : 'Connection failed' };
  }
}

// ===========================================
// NEW GITLAB API FUNCTIONS (Phases 2-7)
// ===========================================

// ===== PHASE 2: Repository Tree Types & Function =====
export interface GitLabFile {
  name: string;
  path: string;
  type: 'blob' | 'tree';  // blob = file, tree = folder
  mode: string;
}

export interface GitLabTreeResult {
  success: boolean;
  data?: GitLabFile[];
  error?: string;
}

// Fetch repository tree (list files and folders)
// API: GET /projects/:id/repository/tree
export async function fetchGitLabRepositoryTree(
  config: GitLabConfig,
  path: string = ''
): Promise<GitLabTreeResult> {
  // Validate inputs
  if (!config.accessToken) {
    return { success: false, error: 'Access token is required' };
  }
  if (!config.projectId) {
    return { success: false, error: 'Project ID is required' };
  }

  const apiUrl = getGitLabApiUrl(config);
  const encodedProjectId = encodeURIComponent(config.projectId);

  // Build URL with query params
  const params = new URLSearchParams({
    ref: config.branch || 'main',
    per_page: '100'
  });
  if (path) {
    params.append('path', path);
  }

  const url = `${apiUrl}/projects/${encodedProjectId}/repository/tree?${params.toString()}`;
  console.log('[GitLab API] Fetching tree:', url);

  try {
    const response = await fetch(url, {
      headers: { 'PRIVATE-TOKEN': config.accessToken }
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('[GitLab API] Tree fetch failed:', response.status, errorText);

      if (response.status === 404) {
        return { success: false, error: 'Repository or path not found. Check project ID and branch.' };
      }
      return { success: false, error: `Failed: ${response.status} ${response.statusText}` };
    }

    const data = await response.json();
    console.log('[GitLab API] Tree fetched:', data.length, 'items');

    return {
      success: true,
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      data: data.map((item: any) => ({
        name: item.name,
        path: item.path,
        type: item.type,
        mode: item.mode
      }))
    };
  } catch (e) {
    console.error('[GitLab API] Tree fetch error:', e);
    return { success: false, error: e instanceof Error ? e.message : 'Network error' };
  }
}

// ===== PHASE 3: File Content Types & Function =====
export interface GitLabFileResult {
  success: boolean;
  content?: string;
  fileName?: string;
  filePath?: string;
  size?: number;
  error?: string;
}

// Fetch file content from GitLab
// API: GET /projects/:id/repository/files/:file_path
export async function fetchGitLabFileContent(
  config: GitLabConfig,
  filePath: string
): Promise<GitLabFileResult> {
  // Validate inputs
  if (!config.accessToken) {
    return { success: false, error: 'Access token is required' };
  }
  if (!config.projectId) {
    return { success: false, error: 'Project ID is required' };
  }
  if (!filePath) {
    return { success: false, error: 'File path is required' };
  }

  const apiUrl = getGitLabApiUrl(config);
  const encodedProjectId = encodeURIComponent(config.projectId);
  const encodedFilePath = encodeURIComponent(filePath);
  const encodedRef = encodeURIComponent(config.branch || 'main');

  const url = `${apiUrl}/projects/${encodedProjectId}/repository/files/${encodedFilePath}?ref=${encodedRef}`;
  console.log('[GitLab API] Fetching file:', url);

  try {
    const response = await fetch(url, {
      headers: { 'PRIVATE-TOKEN': config.accessToken }
    });

    if (!response.ok) {
      console.error('[GitLab API] File fetch failed:', response.status);

      if (response.status === 404) {
        return { success: false, error: 'File not found' };
      }
      return { success: false, error: `Failed: ${response.status} ${response.statusText}` };
    }

    const data = await response.json();

    // Decode base64 content
    let content: string;
    try {
      // Standard base64 decode
      content = atob(data.content);
    } catch {
      // Handle UTF-8 content that was base64 encoded
      try {
        const binaryString = atob(data.content);
        const bytes = new Uint8Array(binaryString.length);
        for (let i = 0; i < binaryString.length; i++) {
          bytes[i] = binaryString.charCodeAt(i);
        }
        content = new TextDecoder('utf-8').decode(bytes);
      } catch {
        return { success: false, error: 'Failed to decode file content' };
      }
    }

    console.log('[GitLab API] File fetched:', data.file_name, data.size, 'bytes');

    return {
      success: true,
      content,
      fileName: data.file_name,
      filePath: data.file_path,
      size: data.size
    };
  } catch (e) {
    console.error('[GitLab API] File fetch error:', e);
    return { success: false, error: e instanceof Error ? e.message : 'Network error' };
  }
}

// ===== PHASE 4: Branches Types & Function =====
export interface GitLabBranch {
  name: string;
  default: boolean;
  protected: boolean;
}

export interface GitLabBranchResult {
  success: boolean;
  data?: GitLabBranch[];
  defaultBranch?: string;
  error?: string;
}

// Fetch branches from GitLab project
// API: GET /projects/:id/repository/branches
export async function fetchGitLabBranches(
  config: GitLabConfig
): Promise<GitLabBranchResult> {
  if (!config.accessToken) {
    return { success: false, error: 'Access token is required' };
  }
  if (!config.projectId) {
    return { success: false, error: 'Project ID is required' };
  }

  const apiUrl = getGitLabApiUrl(config);
  const encodedProjectId = encodeURIComponent(config.projectId);
  const url = `${apiUrl}/projects/${encodedProjectId}/repository/branches?per_page=100`;

  console.log('[GitLab API] Fetching branches:', url);

  try {
    const response = await fetch(url, {
      headers: { 'PRIVATE-TOKEN': config.accessToken }
    });

    if (!response.ok) {
      return { success: false, error: `Failed: ${response.status} ${response.statusText}` };
    }

    const data = await response.json();
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const branches = data.map((b: any) => ({
      name: b.name,
      default: b.default,
      protected: b.protected
    }));

    const defaultBranch = branches.find((b: GitLabBranch) => b.default)?.name;

    console.log('[GitLab API] Branches fetched:', branches.length, 'Default:', defaultBranch);

    return {
      success: true,
      data: branches,
      defaultBranch
    };
  } catch (e) {
    console.error('[GitLab API] Branches fetch error:', e);
    return { success: false, error: e instanceof Error ? e.message : 'Network error' };
  }
}

// ===== PHASE 5: Merge Request Types & Function =====
export interface GitLabMRResult {
  success: boolean;
  mrUrl?: string;
  mrIid?: number;
  error?: string;
}

// Create a Merge Request in GitLab
// API: POST /projects/:id/merge_requests
export async function createGitLabMergeRequest(
  config: GitLabConfig,
  sourceBranch: string,
  targetBranch: string,
  title: string,
  description: string = ''
): Promise<GitLabMRResult> {
  if (!config.accessToken) {
    return { success: false, error: 'Access token is required' };
  }
  if (!config.projectId) {
    return { success: false, error: 'Project ID is required' };
  }
  if (!sourceBranch || !targetBranch || !title) {
    return { success: false, error: 'Source branch, target branch, and title are required' };
  }

  const apiUrl = getGitLabApiUrl(config);
  const encodedProjectId = encodeURIComponent(config.projectId);
  const url = `${apiUrl}/projects/${encodedProjectId}/merge_requests`;

  console.log('[GitLab API] Creating MR:', sourceBranch, '→', targetBranch);

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'PRIVATE-TOKEN': config.accessToken
      },
      body: JSON.stringify({
        source_branch: sourceBranch,
        target_branch: targetBranch,
        title: title,
        description: description || 'Created via Epic Generator',
        remove_source_branch: true
      })
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      console.error('[GitLab API] MR creation failed:', response.status, errorData);

      // Handle specific errors
      if (errorData.message?.includes('already exists')) {
        return { success: false, error: 'A merge request already exists for this branch' };
      }
      if (errorData.message?.includes('source branch')) {
        return { success: false, error: 'Source branch not found' };
      }

      return { success: false, error: errorData.message || `Failed: ${response.status}` };
    }

    const data = await response.json();
    console.log('[GitLab API] MR created:', data.iid, data.web_url);

    return {
      success: true,
      mrUrl: data.web_url,
      mrIid: data.iid
    };
  } catch (e) {
    console.error('[GitLab API] MR creation error:', e);
    return { success: false, error: e instanceof Error ? e.message : 'Network error' };
  }
}

// ===== PHASE 6: Commit to Branch Function =====
// Create branch + commit file in ONE atomic operation using Commits API
// API: POST /projects/:id/repository/commits
export async function commitToGitLabBranch(
  config: GitLabConfig,
  branchName: string,
  startBranch: string,
  filePath: string,
  content: string,
  commitMessage: string,
  action: 'create' | 'update' = 'create'
): Promise<{ success: boolean; commitUrl?: string; error?: string }> {
  if (!config.accessToken) {
    return { success: false, error: 'Access token is required' };
  }
  if (!config.projectId) {
    return { success: false, error: 'Project ID is required' };
  }

  const apiUrl = getGitLabApiUrl(config);
  const encodedProjectId = encodeURIComponent(config.projectId);
  const url = `${apiUrl}/projects/${encodedProjectId}/repository/commits`;

  console.log('[GitLab API] Committing to branch:', branchName, 'from:', startBranch);
  console.log('[GitLab API] File:', filePath, 'Action:', action);

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'PRIVATE-TOKEN': config.accessToken
      },
      body: JSON.stringify({
        branch: branchName,
        start_branch: startBranch,
        commit_message: commitMessage,
        actions: [{
          action: action,
          file_path: filePath,
          content: content
        }]
      })
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      console.error('[GitLab API] Commit failed:', response.status, errorData);

      // Handle specific errors
      if (errorData.message?.includes('already exists') && action === 'create') {
        return { success: false, error: 'File already exists. Use update action instead.' };
      }
      if (errorData.message?.includes('does not exist') && action === 'update') {
        return { success: false, error: 'File does not exist. Use create action instead.' };
      }

      return { success: false, error: errorData.message || `Failed: ${response.status}` };
    }

    const data = await response.json();
    console.log('[GitLab API] Commit successful:', data.short_id);

    return {
      success: true,
      commitUrl: data.web_url
    };
  } catch (e) {
    console.error('[GitLab API] Commit error:', e);
    return { success: false, error: e instanceof Error ? e.message : 'Network error' };
  }
}

// ===== PHASE 7: Complete MR Workflow Function =====
// Create branch → Commit file → Create MR in one convenient call
export async function publishWithMergeRequest(
  config: GitLabConfig,
  fileName: string,
  content: string,
  commitMessage: string,
  mrTitle: string,
  mrDescription: string = ''
): Promise<{
  success: boolean;
  fileUrl?: string;
  mrUrl?: string;
  branchName?: string;
  error?: string;
}> {
  // 1. Generate unique branch name
  const timestamp = Date.now();
  const safeName = fileName
    .replace(/\.[^.]+$/, '')           // Remove extension
    .replace(/[^a-z0-9]/gi, '-')       // Replace special chars
    .replace(/-+/g, '-')               // Collapse multiple dashes
    .toLowerCase()
    .substring(0, 30);                 // Limit length
  const branchName = `epic/${safeName}-${timestamp}`;

  // 2. Build file path
  const filePath = `${config.epicFilePath}${fileName}`.replace(/\/+/g, '/');

  console.log('[MR Workflow] Starting...');
  console.log('[MR Workflow] Branch:', branchName);
  console.log('[MR Workflow] File:', filePath);

  // 3. Create branch and commit file
  const commitResult = await commitToGitLabBranch(
    config,
    branchName,
    config.branch,        // Create from target branch
    filePath,
    content,
    commitMessage,
    'create'
  );

  if (!commitResult.success) {
    // If file exists, try update instead
    if (commitResult.error?.includes('already exists')) {
      console.log('[MR Workflow] File exists, trying update...');
      const updateResult = await commitToGitLabBranch(
        config,
        branchName,
        config.branch,
        filePath,
        content,
        commitMessage,
        'update'
      );

      if (!updateResult.success) {
        return { success: false, error: `Commit failed: ${updateResult.error}` };
      }
    } else {
      return { success: false, error: `Commit failed: ${commitResult.error}` };
    }
  }

  console.log('[MR Workflow] Commit successful, creating MR...');

  // 4. Create Merge Request
  const mrResult = await createGitLabMergeRequest(
    config,
    branchName,
    config.branch,
    mrTitle,
    mrDescription || `Automated update via Epic Generator\n\n**File:** \`${filePath}\``
  );

  if (!mrResult.success) {
    // Commit succeeded but MR failed - still partially successful
    const fileUrl = `${config.baseUrl}/${config.projectId}/-/blob/${branchName}/${filePath}`;
    return {
      success: true,
      fileUrl,
      branchName,
      error: `File committed but MR failed: ${mrResult.error}`
    };
  }

  console.log('[MR Workflow] Complete! MR:', mrResult.mrUrl);

  const fileUrl = `${config.baseUrl}/${config.projectId}/-/blob/${branchName}/${filePath}`;
  return {
    success: true,
    fileUrl,
    mrUrl: mrResult.mrUrl,
    branchName
  };
}

// ===========================================
// GITLAB EPIC MANAGEMENT API FUNCTIONS
// ===========================================

// Helper to determine epic level from labels
function determineEpicLevel(
  labels: string[],
  config: GitLabConfig
): 'crew' | 'pod' | 'unknown' {
  const crewPrefix = config.crewLabelPrefix || 'crew::';
  const podPrefix = config.podLabelPrefix || 'pod::';

  for (const label of labels) {
    if (label.startsWith(crewPrefix)) return 'crew';
    if (label.startsWith(podPrefix)) return 'pod';
  }
  return 'unknown';
}

// Fetch epics from a GitLab group with search/filter support
export async function fetchGroupEpics(
  config: GitLabConfig,
  params: GitLabEpicSearchParams = {}
): Promise<GitLabEpicListResult> {
  if (!config.accessToken) {
    return { success: false, error: 'Access token is required' };
  }
  if (!config.rootGroupId) {
    return { success: false, error: 'Group ID is required' };
  }

  const apiUrl = getGitLabApiUrl(config);
  const queryParams = new URLSearchParams();

  if (params.search) queryParams.append('search', params.search);
  if (params.state) queryParams.append('state', params.state);
  if (params.labels?.length) queryParams.append('labels', params.labels.join(','));
  if (params.author_id) queryParams.append('author_id', String(params.author_id));
  if (params.order_by) queryParams.append('order_by', params.order_by);
  if (params.sort) queryParams.append('sort', params.sort);
  if (params.per_page) queryParams.append('per_page', String(params.per_page));
  if (params.page) queryParams.append('page', String(params.page));
  if (params.include_descendant_groups) queryParams.append('include_descendant_groups', 'true');

  const url = `${apiUrl}/groups/${config.rootGroupId}/epics?${queryParams.toString()}`;
  console.log('[GitLab Epic API] Fetching epics:', url);

  try {
    const response = await fetch(url, {
      headers: { 'PRIVATE-TOKEN': config.accessToken }
    });

    if (!response.ok) {
      return { success: false, error: `Failed: ${response.status} ${response.statusText}` };
    }

    const data = await response.json();
    const totalCount = parseInt(response.headers.get('x-total') || '0', 10);

    // Determine epic level based on labels
    const epicsWithLevel = data.map((epic: GitLabEpic) => ({
      ...epic,
      epicLevel: determineEpicLevel(epic.labels || [], config)
    }));

    return { success: true, data: epicsWithLevel, totalCount };
  } catch (e) {
    console.error('[GitLab Epic API] Error fetching epics:', e);
    return { success: false, error: e instanceof Error ? e.message : 'Network error' };
  }
}

// Fetch a single epic's details
export async function fetchEpicDetails(
  config: GitLabConfig,
  epicIid: number
): Promise<GitLabEpicResult> {
  if (!config.accessToken || !config.rootGroupId) {
    return { success: false, error: 'Access token and group ID are required' };
  }

  const apiUrl = getGitLabApiUrl(config);
  const url = `${apiUrl}/groups/${config.rootGroupId}/epics/${epicIid}`;

  console.log('[GitLab Epic API] Fetching epic details:', url);

  try {
    const response = await fetch(url, {
      headers: { 'PRIVATE-TOKEN': config.accessToken }
    });

    if (!response.ok) {
      if (response.status === 404) {
        return { success: false, error: 'Epic not found' };
      }
      return { success: false, error: `Failed: ${response.status}` };
    }

    const data = await response.json();
    return {
      success: true,
      data: {
        ...data,
        epicLevel: determineEpicLevel(data.labels || [], config)
      }
    };
  } catch (e) {
    console.error('[GitLab Epic API] Error fetching epic details:', e);
    return { success: false, error: e instanceof Error ? e.message : 'Network error' };
  }
}

// Fetch child epics and issues for an epic
export async function fetchEpicChildren(
  config: GitLabConfig,
  epicIid: number
): Promise<GitLabEpicChildrenResult> {
  if (!config.accessToken || !config.rootGroupId) {
    return { success: false, error: 'Access token and group ID are required' };
  }

  const apiUrl = getGitLabApiUrl(config);

  console.log('[GitLab Epic API] Fetching epic children for iid:', epicIid);

  try {
    // Fetch child epics and issues in parallel
    const [epicsRes, issuesRes] = await Promise.all([
      fetch(`${apiUrl}/groups/${config.rootGroupId}/epics/${epicIid}/epics`, {
        headers: { 'PRIVATE-TOKEN': config.accessToken }
      }),
      fetch(`${apiUrl}/groups/${config.rootGroupId}/epics/${epicIid}/issues`, {
        headers: { 'PRIVATE-TOKEN': config.accessToken }
      })
    ]);

    const childEpics: GitLabEpicChild[] = [];
    const childIssues: GitLabEpicChild[] = [];

    if (epicsRes.ok) {
      const epicsData = await epicsRes.json();
      epicsData.forEach((e: { id: number; iid: number; title: string; state: string; web_url: string }) => {
        childEpics.push({
          id: e.id,
          iid: e.iid,
          title: e.title,
          type: 'epic',
          state: e.state,
          web_url: e.web_url
        });
      });
    }

    if (issuesRes.ok) {
      const issuesData = await issuesRes.json();
      issuesData.forEach((i: { id: number; iid: number; title: string; state: string; web_url: string }) => {
        childIssues.push({
          id: i.id,
          iid: i.iid,
          title: i.title,
          type: 'issue',
          state: i.state,
          web_url: i.web_url
        });
      });
    }

    return { success: true, epics: childEpics, issues: childIssues };
  } catch (e) {
    console.error('[GitLab Epic API] Error fetching epic children:', e);
    return { success: false, error: e instanceof Error ? e.message : 'Network error' };
  }
}

// Create a new GitLab epic
export async function createGitLabEpic(
  config: GitLabConfig,
  params: GitLabCreateEpicParams
): Promise<GitLabEpicResult> {
  if (!config.accessToken || !config.rootGroupId) {
    return { success: false, error: 'Access token and group ID are required' };
  }
  if (!params.title) {
    return { success: false, error: 'Epic title is required' };
  }

  const apiUrl = getGitLabApiUrl(config);
  const url = `${apiUrl}/groups/${config.rootGroupId}/epics`;

  console.log('[GitLab Epic API] Creating epic:', params.title);

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'PRIVATE-TOKEN': config.accessToken
      },
      body: JSON.stringify({
        title: params.title,
        description: params.description || '',
        labels: params.labels?.join(',') || '',
        confidential: params.confidential || false,
        start_date_fixed: params.start_date_fixed,
        due_date_fixed: params.due_date_fixed,
        parent_id: params.parent_id
      })
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      return { success: false, error: errorData.message || `Failed: ${response.status}` };
    }

    const data = await response.json();
    console.log('[GitLab Epic API] Epic created:', data.iid, data.web_url);

    return {
      success: true,
      data: {
        ...data,
        epicLevel: determineEpicLevel(data.labels || [], config)
      }
    };
  } catch (e) {
    console.error('[GitLab Epic API] Error creating epic:', e);
    return { success: false, error: e instanceof Error ? e.message : 'Network error' };
  }
}

// Update an existing GitLab epic (non-destructive label handling)
export async function updateGitLabEpic(
  config: GitLabConfig,
  epicIid: number,
  params: GitLabUpdateEpicParams
): Promise<GitLabEpicResult> {
  if (!config.accessToken || !config.rootGroupId) {
    return { success: false, error: 'Access token and group ID are required' };
  }

  const apiUrl = getGitLabApiUrl(config);
  const url = `${apiUrl}/groups/${config.rootGroupId}/epics/${epicIid}`;

  // Build update payload - only include non-undefined fields
  const payload: Record<string, unknown> = {};
  if (params.title !== undefined) payload.title = params.title;
  if (params.description !== undefined) payload.description = params.description;
  if (params.state_event) payload.state_event = params.state_event;

  // Non-destructive label handling
  if (params.add_labels?.length) payload.add_labels = params.add_labels.join(',');
  if (params.remove_labels?.length) payload.remove_labels = params.remove_labels.join(',');
  // Full labels replacement (use carefully)
  if (params.labels !== undefined) payload.labels = params.labels.join(',');

  console.log('[GitLab Epic API] Updating epic:', epicIid, payload);

  try {
    const response = await fetch(url, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'PRIVATE-TOKEN': config.accessToken
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      return { success: false, error: errorData.message || `Failed: ${response.status}` };
    }

    const data = await response.json();
    console.log('[GitLab Epic API] Epic updated:', data.iid);

    return {
      success: true,
      data: {
        ...data,
        epicLevel: determineEpicLevel(data.labels || [], config)
      }
    };
  } catch (e) {
    console.error('[GitLab Epic API] Error updating epic:', e);
    return { success: false, error: e instanceof Error ? e.message : 'Network error' };
  }
}

// Fetch available labels for a group
export async function fetchGroupLabels(
  config: GitLabConfig
): Promise<GitLabLabelResult> {
  if (!config.accessToken || !config.rootGroupId) {
    return { success: false, error: 'Access token and group ID are required' };
  }

  const apiUrl = getGitLabApiUrl(config);
  const url = `${apiUrl}/groups/${config.rootGroupId}/labels?per_page=100`;

  console.log('[GitLab Epic API] Fetching labels:', url);

  try {
    const response = await fetch(url, {
      headers: { 'PRIVATE-TOKEN': config.accessToken }
    });

    if (!response.ok) {
      return { success: false, error: `Failed: ${response.status}` };
    }

    const data = await response.json();
    return {
      success: true,
      data: data.map((label: { id: number; name: string; color: string; text_color: string; description: string | null }) => ({
        id: label.id,
        name: label.name,
        color: label.color,
        text_color: label.text_color,
        description: label.description
      }))
    };
  } catch (e) {
    console.error('[GitLab Epic API] Error fetching labels:', e);
    return { success: false, error: e instanceof Error ? e.message : 'Network error' };
  }
}
