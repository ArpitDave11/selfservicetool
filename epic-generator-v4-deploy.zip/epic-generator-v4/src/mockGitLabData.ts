/**
 * Mock GitLab Data for Local Testing
 *
 * This file contains realistic mock data that mirrors actual GitLab API responses.
 * Used for end-to-end testing without requiring GitLab connectivity.
 *
 * To enable: Set MOCK_GITLAB_ENABLED = true in this file
 */

import type {
  GitLabEpic,
  GitLabLabel,
  GitLabEpicChild,
  GitLabEpicListResult,
  GitLabEpicResult,
  GitLabLabelResult,
  GitLabEpicChildrenResult,
  GitLabEpicSearchParams,
  GitLabCreateEpicParams,
  GitLabUpdateEpicParams,
  GitLabConfig
} from './config';

// ===========================================
// MOCK MODE TOGGLE - Set to true for local testing
// ===========================================
export const MOCK_GITLAB_ENABLED = false;

// ===========================================
// MOCK EPICS DATA (Realistic GitLab API format)
// ===========================================
export const mockEpics: GitLabEpic[] = [
  {
    id: 12345678,
    iid: 101,
    group_id: 557797,
    title: 'Platform Modernization Initiative Q1 2025',
    description: `# Platform Modernization Initiative

## 1. Executive Summary
This epic captures the comprehensive effort to modernize our core platform infrastructure, improving scalability, maintainability, and developer experience.

## 2. Business Context
- **Problem Statement**: Current platform has accumulated technical debt limiting feature velocity
- **Strategic Alignment**: Supports company goal of 2x feature delivery speed by Q3 2025
- **Key Stakeholders**: Engineering, Product, Infrastructure teams

## 3. Technical Scope

### 3.1 Core Infrastructure
- Migrate to containerized microservices architecture
- Implement service mesh for inter-service communication
- Upgrade to PostgreSQL 16 with connection pooling

### 3.2 API Layer
- Implement GraphQL gateway for unified API access
- Add rate limiting and circuit breaker patterns
- Enhance API documentation with OpenAPI 3.1

### 3.3 Observability
- Deploy distributed tracing with Jaeger
- Implement structured logging with correlation IDs
- Create SLO dashboards in Grafana

## 4. Success Metrics
| Metric | Current | Target |
|--------|---------|--------|
| API Latency (p99) | 450ms | <200ms |
| Deployment Frequency | Weekly | Daily |
| Change Failure Rate | 15% | <5% |
| MTTR | 4 hours | <30 min |

## 5. Timeline
- **Phase 1** (Jan-Feb): Infrastructure setup
- **Phase 2** (Mar-Apr): Migration execution
- **Phase 3** (May): Validation and optimization

## 6. Dependencies
- Cloud infrastructure budget approval
- DevOps team capacity allocation
- Security review completion

## 7. Risks & Mitigations
| Risk | Impact | Mitigation |
|------|--------|------------|
| Data migration complexity | High | Incremental migration with rollback capability |
| Team learning curve | Medium | Training sessions and pair programming |
| Service disruption | High | Blue-green deployment strategy |
`,
    state: 'opened',
    confidential: false,
    author: {
      id: 1001,
      username: 'john.smith',
      name: 'John Smith'
    },
    labels: ['crew::platform', 'epic-generator', 'priority::high', 'Q1-2025'],
    start_date: '2025-01-01',
    due_date: '2025-05-31',
    created_at: '2024-12-15T10:30:00Z',
    updated_at: '2025-01-14T15:45:00Z',
    closed_at: null,
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/101',
    epicLevel: 'crew'
  },
  {
    id: 12345679,
    iid: 102,
    group_id: 557797,
    title: 'User Authentication Service Refactor',
    description: `# User Authentication Service Refactor

## Overview
Modernize the authentication service to support OAuth 2.0, SAML, and passwordless authentication methods.

## Objectives
1. Implement OAuth 2.0 / OIDC provider
2. Add SAML 2.0 integration for enterprise SSO
3. Support WebAuthn for passwordless login
4. Enhance session management with refresh tokens

## Technical Requirements

### Authentication Methods
- OAuth 2.0 Authorization Code Flow with PKCE
- SAML 2.0 Service Provider implementation
- WebAuthn/FIDO2 for biometric authentication
- Magic link email authentication

### Security Enhancements
- JWT token rotation with sliding window
- Device fingerprinting for anomaly detection
- Rate limiting per user and IP
- Audit logging for all auth events

### Integration Points
- Identity Provider federation
- User directory synchronization
- Multi-tenant support

## Acceptance Criteria
- [ ] All existing auth flows continue working
- [ ] New OAuth clients can be registered via API
- [ ] SAML metadata can be imported/exported
- [ ] WebAuthn registration flow complete
- [ ] 99.99% auth service availability

## Dependencies
- Platform Modernization Epic (parent)
- Security team approval
- Compliance review for PII handling
`,
    state: 'opened',
    confidential: false,
    author: {
      id: 1002,
      username: 'jane.doe',
      name: 'Jane Doe'
    },
    labels: ['pod::auth', 'epic-generator', 'security', 'priority::high'],
    start_date: '2025-01-15',
    due_date: '2025-03-31',
    created_at: '2025-01-05T09:00:00Z',
    updated_at: '2025-01-13T11:20:00Z',
    closed_at: null,
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/102',
    parent: {
      id: 12345678,
      iid: 101,
      title: 'Platform Modernization Initiative Q1 2025'
    },
    epicLevel: 'pod'
  },
  {
    id: 12345680,
    iid: 103,
    group_id: 557797,
    title: 'Data Pipeline Optimization',
    description: `# Data Pipeline Optimization

## Summary
Optimize existing data pipelines for better performance, reliability, and cost efficiency.

## Current State
- Batch processing taking 6+ hours
- High failure rate on large datasets
- Limited real-time capabilities

## Target State
- Batch processing < 2 hours
- 99.9% pipeline success rate
- Near real-time data availability

## Implementation Plan

### Phase 1: Assessment
- Profile existing pipelines
- Identify bottlenecks
- Document data dependencies

### Phase 2: Optimization
- Implement incremental processing
- Add data partitioning
- Optimize queries and transformations

### Phase 3: Monitoring
- Pipeline health dashboards
- Automated alerting
- Data quality checks

## Success Metrics
- Processing time reduction: 70%
- Cost reduction: 40%
- Data freshness: < 15 minutes
`,
    state: 'opened',
    confidential: false,
    author: {
      id: 1003,
      username: 'bob.wilson',
      name: 'Bob Wilson'
    },
    labels: ['pod::data', 'epic-generator', 'performance'],
    start_date: '2025-02-01',
    due_date: '2025-04-30',
    created_at: '2025-01-10T14:00:00Z',
    updated_at: '2025-01-12T09:30:00Z',
    closed_at: null,
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/103',
    parent: {
      id: 12345678,
      iid: 101,
      title: 'Platform Modernization Initiative Q1 2025'
    },
    epicLevel: 'pod'
  },
  {
    id: 12345681,
    iid: 104,
    group_id: 557797,
    title: 'Mobile App Redesign',
    description: `# Mobile App Redesign

## Vision
Create a modern, intuitive mobile experience that increases user engagement by 50%.

## Key Features
1. New navigation paradigm
2. Offline-first architecture
3. Biometric authentication
4. Push notification enhancements
5. Dark mode support

## Design Principles
- Mobile-first approach
- Accessibility (WCAG 2.1 AA)
- Performance budget: <3s initial load
- Gesture-based interactions

## Technical Stack
- React Native 0.73+
- TypeScript
- Redux Toolkit
- React Query for caching

## Timeline
Q1 2025: Design and prototyping
Q2 2025: Development
Q3 2025: Testing and launch
`,
    state: 'opened',
    confidential: false,
    author: {
      id: 1004,
      username: 'sarah.chen',
      name: 'Sarah Chen'
    },
    labels: ['crew::mobile', 'epic-generator', 'ux', 'priority::medium'],
    start_date: '2025-01-01',
    due_date: '2025-09-30',
    created_at: '2024-12-01T08:00:00Z',
    updated_at: '2025-01-11T16:00:00Z',
    closed_at: null,
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/104',
    epicLevel: 'crew'
  },
  {
    id: 12345682,
    iid: 105,
    group_id: 557797,
    title: 'Legacy API Migration (Completed)',
    description: `# Legacy API Migration

## Summary
Successfully migrated all v1 API endpoints to v2 with improved performance and security.

## Achievements
- Migrated 47 endpoints
- Zero downtime deployment
- 35% latency improvement
- All clients updated

## Lessons Learned
- Gradual rollout was key to success
- Client communication essential
- Monitoring prevented issues
`,
    state: 'closed',
    confidential: false,
    author: {
      id: 1001,
      username: 'john.smith',
      name: 'John Smith'
    },
    labels: ['crew::platform', 'epic-generator', 'migration', 'completed'],
    start_date: '2024-06-01',
    due_date: '2024-11-30',
    created_at: '2024-05-15T10:00:00Z',
    updated_at: '2024-12-01T12:00:00Z',
    closed_at: '2024-12-01T12:00:00Z',
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/105',
    epicLevel: 'crew'
  },
  {
    id: 12345683,
    iid: 106,
    group_id: 557797,
    title: 'Infrastructure Cost Optimization',
    description: `# Infrastructure Cost Optimization

## Objective
Reduce cloud infrastructure costs by 30% while maintaining performance and reliability.

## Focus Areas

### Compute Optimization
- Right-size EC2 instances
- Implement auto-scaling policies
- Use spot instances for batch workloads

### Storage Optimization
- Implement data lifecycle policies
- Move cold data to cheaper tiers
- Deduplicate redundant storage

### Network Optimization
- Optimize data transfer
- Use CDN effectively
- Reduce cross-region traffic

## Expected Savings
| Category | Current | Target | Savings |
|----------|---------|--------|---------|
| Compute | $50k/mo | $35k/mo | $15k/mo |
| Storage | $20k/mo | $14k/mo | $6k/mo |
| Network | $10k/mo | $7k/mo | $3k/mo |
| **Total** | **$80k/mo** | **$56k/mo** | **$24k/mo** |
`,
    state: 'opened',
    confidential: false,
    author: {
      id: 1005,
      username: 'mike.johnson',
      name: 'Mike Johnson'
    },
    labels: ['pod::infra', 'epic-generator', 'cost-optimization'],
    start_date: '2025-01-15',
    due_date: '2025-06-30',
    created_at: '2025-01-08T11:00:00Z',
    updated_at: '2025-01-14T10:00:00Z',
    closed_at: null,
    web_url: 'https://gitlab.example.com/groups/engineering/-/epics/106',
    parent: {
      id: 12345678,
      iid: 101,
      title: 'Platform Modernization Initiative Q1 2025'
    },
    epicLevel: 'pod'
  }
];

// ===========================================
// MOCK LABELS DATA
// ===========================================
export const mockLabels: GitLabLabel[] = [
  { id: 1, name: 'crew::platform', color: '#428BCA', text_color: '#FFFFFF', description: 'Platform team epics' },
  { id: 2, name: 'crew::mobile', color: '#44AD8E', text_color: '#FFFFFF', description: 'Mobile team epics' },
  { id: 3, name: 'pod::auth', color: '#D10069', text_color: '#FFFFFF', description: 'Authentication pod' },
  { id: 4, name: 'pod::data', color: '#FA7035', text_color: '#FFFFFF', description: 'Data pipeline pod' },
  { id: 5, name: 'pod::infra', color: '#6B4FBB', text_color: '#FFFFFF', description: 'Infrastructure pod' },
  { id: 6, name: 'epic-generator', color: '#F0AD4E', text_color: '#333333', description: 'Generated by Epic Generator' },
  { id: 7, name: 'priority::high', color: '#CC0000', text_color: '#FFFFFF', description: 'High priority' },
  { id: 8, name: 'priority::medium', color: '#FFCC00', text_color: '#333333', description: 'Medium priority' },
  { id: 9, name: 'priority::low', color: '#009900', text_color: '#FFFFFF', description: 'Low priority' },
  { id: 10, name: 'security', color: '#FF0000', text_color: '#FFFFFF', description: 'Security related' },
  { id: 11, name: 'performance', color: '#0066CC', text_color: '#FFFFFF', description: 'Performance related' },
  { id: 12, name: 'ux', color: '#FF69B4', text_color: '#333333', description: 'User experience' },
  { id: 13, name: 'Q1-2025', color: '#808080', text_color: '#FFFFFF', description: 'Q1 2025 milestone' },
  { id: 14, name: 'completed', color: '#00CC00', text_color: '#FFFFFF', description: 'Work completed' },
];

// ===========================================
// MOCK CHILD EPICS DATA
// ===========================================
export const mockEpicChildren: Record<number, { epics: GitLabEpicChild[], issues: GitLabEpicChild[] }> = {
  101: {
    epics: [
      { id: 12345679, iid: 102, title: 'User Authentication Service Refactor', type: 'epic', state: 'opened', web_url: 'https://gitlab.example.com/groups/engineering/-/epics/102' },
      { id: 12345680, iid: 103, title: 'Data Pipeline Optimization', type: 'epic', state: 'opened', web_url: 'https://gitlab.example.com/groups/engineering/-/epics/103' },
      { id: 12345683, iid: 106, title: 'Infrastructure Cost Optimization', type: 'epic', state: 'opened', web_url: 'https://gitlab.example.com/groups/engineering/-/epics/106' },
    ],
    issues: [
      { id: 9001, iid: 501, title: 'Set up CI/CD pipeline for new architecture', type: 'issue', state: 'closed', web_url: 'https://gitlab.example.com/engineering/platform/-/issues/501' },
      { id: 9002, iid: 502, title: 'Create architecture decision records (ADRs)', type: 'issue', state: 'closed', web_url: 'https://gitlab.example.com/engineering/platform/-/issues/502' },
      { id: 9003, iid: 503, title: 'Define API versioning strategy', type: 'issue', state: 'opened', web_url: 'https://gitlab.example.com/engineering/platform/-/issues/503' },
    ]
  },
  102: {
    epics: [],
    issues: [
      { id: 9101, iid: 601, title: 'Implement OAuth 2.0 authorization server', type: 'issue', state: 'opened', web_url: 'https://gitlab.example.com/engineering/auth/-/issues/601' },
      { id: 9102, iid: 602, title: 'Add SAML 2.0 IdP integration', type: 'issue', state: 'opened', web_url: 'https://gitlab.example.com/engineering/auth/-/issues/602' },
      { id: 9103, iid: 603, title: 'Implement WebAuthn registration', type: 'issue', state: 'opened', web_url: 'https://gitlab.example.com/engineering/auth/-/issues/603' },
      { id: 9104, iid: 604, title: 'Add rate limiting middleware', type: 'issue', state: 'closed', web_url: 'https://gitlab.example.com/engineering/auth/-/issues/604' },
    ]
  },
  104: {
    epics: [],
    issues: [
      { id: 9201, iid: 701, title: 'Design new navigation system', type: 'issue', state: 'closed', web_url: 'https://gitlab.example.com/engineering/mobile/-/issues/701' },
      { id: 9202, iid: 702, title: 'Implement offline storage layer', type: 'issue', state: 'opened', web_url: 'https://gitlab.example.com/engineering/mobile/-/issues/702' },
      { id: 9203, iid: 703, title: 'Add biometric authentication', type: 'issue', state: 'opened', web_url: 'https://gitlab.example.com/engineering/mobile/-/issues/703' },
    ]
  }
};

// ===========================================
// MOCK API FUNCTIONS
// ===========================================

// Simulate network delay
const simulateDelay = (ms: number = 500) => new Promise(resolve => setTimeout(resolve, ms));

// Mock: Fetch group epics
export async function mockFetchGroupEpics(
  config: GitLabConfig,
  params: GitLabEpicSearchParams = {}
): Promise<GitLabEpicListResult> {
  await simulateDelay(300);

  let results = [...mockEpics];

  // Apply search filter
  if (params.search) {
    const searchLower = params.search.toLowerCase();
    results = results.filter(e =>
      e.title.toLowerCase().includes(searchLower) ||
      e.description.toLowerCase().includes(searchLower)
    );
  }

  // Apply state filter
  if (params.state && params.state !== 'all') {
    results = results.filter(e => e.state === params.state);
  }

  // Apply label filter
  if (params.labels && params.labels.length > 0) {
    results = results.filter(e =>
      params.labels!.some(label => e.labels.includes(label))
    );
  }

  // Apply sorting
  const orderBy = params.order_by || 'updated_at';
  const sortDir = params.sort || 'desc';
  results.sort((a, b) => {
    const aVal = a[orderBy as keyof GitLabEpic] as string;
    const bVal = b[orderBy as keyof GitLabEpic] as string;
    const comparison = aVal < bVal ? -1 : aVal > bVal ? 1 : 0;
    return sortDir === 'desc' ? -comparison : comparison;
  });

  // Apply pagination
  const page = params.page || 1;
  const perPage = params.per_page || 20;
  const start = (page - 1) * perPage;
  const paginatedResults = results.slice(start, start + perPage);

  // Determine epic level based on labels
  const crewPrefix = config.crewLabelPrefix || 'crew::';
  const podPrefix = config.podLabelPrefix || 'pod::';

  const epicsWithLevel = paginatedResults.map(epic => ({
    ...epic,
    epicLevel: epic.labels.some(l => l.startsWith(crewPrefix)) ? 'crew' as const :
               epic.labels.some(l => l.startsWith(podPrefix)) ? 'pod' as const : 'unknown' as const
  }));

  console.log('[Mock GitLab] Fetched epics:', epicsWithLevel.length, 'of', results.length);

  return {
    success: true,
    data: epicsWithLevel,
    totalCount: results.length
  };
}

// Mock: Fetch epic details
export async function mockFetchEpicDetails(
  config: GitLabConfig,
  epicIid: number
): Promise<GitLabEpicResult> {
  await simulateDelay(200);

  const epic = mockEpics.find(e => e.iid === epicIid);

  if (!epic) {
    return { success: false, error: 'Epic not found' };
  }

  const crewPrefix = config.crewLabelPrefix || 'crew::';
  const podPrefix = config.podLabelPrefix || 'pod::';

  console.log('[Mock GitLab] Fetched epic details:', epic.iid, epic.title);

  return {
    success: true,
    data: {
      ...epic,
      epicLevel: epic.labels.some(l => l.startsWith(crewPrefix)) ? 'crew' as const :
                 epic.labels.some(l => l.startsWith(podPrefix)) ? 'pod' as const : 'unknown' as const
    }
  };
}

// Mock: Fetch epic children
export async function mockFetchEpicChildren(
  _config: GitLabConfig,
  epicIid: number
): Promise<GitLabEpicChildrenResult> {
  await simulateDelay(250);

  const children = mockEpicChildren[epicIid];

  if (!children) {
    return { success: true, epics: [], issues: [] };
  }

  console.log('[Mock GitLab] Fetched children for epic', epicIid, ':', children.epics.length, 'epics,', children.issues.length, 'issues');

  return {
    success: true,
    epics: children.epics,
    issues: children.issues
  };
}

// Mock: Create epic
export async function mockCreateGitLabEpic(
  config: GitLabConfig,
  params: GitLabCreateEpicParams
): Promise<GitLabEpicResult> {
  await simulateDelay(400);

  if (!params.title) {
    return { success: false, error: 'Title is required' };
  }

  const crewPrefix = config.crewLabelPrefix || 'crew::';
  const podPrefix = config.podLabelPrefix || 'pod::';

  const newEpic: GitLabEpic = {
    id: Date.now(),
    iid: 200 + Math.floor(Math.random() * 100),
    group_id: parseInt(config.rootGroupId) || 557797,
    title: params.title,
    description: params.description || '',
    state: 'opened',
    confidential: params.confidential || false,
    author: {
      id: 1001,
      username: 'current.user',
      name: 'Current User'
    },
    labels: params.labels || [],
    start_date: params.start_date_fixed || null,
    due_date: params.due_date_fixed || null,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    closed_at: null,
    web_url: `https://gitlab.example.com/groups/engineering/-/epics/${Date.now()}`,
    parent: params.parent_id ? {
      id: params.parent_id,
      iid: mockEpics.find(e => e.id === params.parent_id)?.iid || 0,
      title: mockEpics.find(e => e.id === params.parent_id)?.title || ''
    } : undefined,
    epicLevel: (params.labels || []).some(l => l.startsWith(crewPrefix)) ? 'crew' :
               (params.labels || []).some(l => l.startsWith(podPrefix)) ? 'pod' : 'unknown'
  };

  // Add to mock data for this session
  mockEpics.unshift(newEpic);

  console.log('[Mock GitLab] Created epic:', newEpic.iid, newEpic.title);

  return {
    success: true,
    data: newEpic
  };
}

// Mock: Update epic
export async function mockUpdateGitLabEpic(
  config: GitLabConfig,
  epicIid: number,
  params: GitLabUpdateEpicParams
): Promise<GitLabEpicResult> {
  await simulateDelay(300);

  const epicIndex = mockEpics.findIndex(e => e.iid === epicIid);

  if (epicIndex === -1) {
    return { success: false, error: 'Epic not found' };
  }

  const epic = mockEpics[epicIndex];

  // Update fields
  if (params.title !== undefined) epic.title = params.title;
  if (params.description !== undefined) epic.description = params.description;
  if (params.state_event === 'close') epic.state = 'closed';
  if (params.state_event === 'reopen') epic.state = 'opened';

  // Handle labels (non-destructive)
  if (params.add_labels) {
    params.add_labels.forEach(label => {
      if (!epic.labels.includes(label)) epic.labels.push(label);
    });
  }
  if (params.remove_labels) {
    epic.labels = epic.labels.filter(l => !params.remove_labels!.includes(l));
  }
  if (params.labels !== undefined) {
    epic.labels = params.labels;
  }

  epic.updated_at = new Date().toISOString();

  const crewPrefix = config.crewLabelPrefix || 'crew::';
  const podPrefix = config.podLabelPrefix || 'pod::';

  epic.epicLevel = epic.labels.some(l => l.startsWith(crewPrefix)) ? 'crew' :
                   epic.labels.some(l => l.startsWith(podPrefix)) ? 'pod' : 'unknown';

  console.log('[Mock GitLab] Updated epic:', epic.iid, epic.title);

  return {
    success: true,
    data: epic
  };
}

// Mock: Fetch labels
export async function mockFetchGroupLabels(
  _config: GitLabConfig
): Promise<GitLabLabelResult> {
  await simulateDelay(200);

  console.log('[Mock GitLab] Fetched labels:', mockLabels.length);

  return {
    success: true,
    data: mockLabels
  };
}

// ===========================================
// MOCK API WRAPPER
// ===========================================
// These functions decide whether to use mock or real API

export function shouldUseMockGitLab(): boolean {
  return MOCK_GITLAB_ENABLED;
}
