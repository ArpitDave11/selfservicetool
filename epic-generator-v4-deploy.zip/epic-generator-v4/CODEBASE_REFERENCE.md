# EPIC GENERATOR - COMPLETE CODEBASE REFERENCE DOCUMENT

> **Last Updated**: 2026-01-15
> **Version**: 1.1.0
> **Purpose**: In-depth reference for understanding, maintaining, and extending the Epic Generator application

---

## TABLE OF CONTENTS

1. [Project Overview](#1-project-overview)
2. [Architecture Overview](#2-architecture-overview)
3. [File-by-File Deep Dive](#3-file-by-file-deep-dive)
4. [Data Flow](#4-data-flow)
5. [Key Algorithms](#5-key-algorithms)
6. [Integration Points](#6-integration-points)
7. [User Interface Details](#7-user-interface-details)
8. [Error Handling](#8-error-handling)
9. [Storage](#9-storage)
10. [Security Considerations](#10-security-considerations)
11. [Mock GitLab System](#11-mock-gitlab-system)
12. [Testing](#12-testing)
13. [Appendix E: Known Issues & Fixes](#appendix-e-known-issues--fixes)

---

## 1. PROJECT OVERVIEW

### 1.1 What is this Application?

**FRAME** (Feature Requirements & Architecture Management Engine) is an **AI-powered technical documentation tool** that generates comprehensive 17-section Epic documents for software projects. It's a **React + TypeScript SPA** branded for UBS internal use.

### 1.2 Core Value Proposition

| Feature | Description |
|---------|-------------|
| **6-Stage Wizard Input** | Guides users through structured data collection |
| **17-Section Epic Output** | Generates professional technical design documents |
| **AI Assistance** | OpenAI or Azure OpenAI for suggestions, refinements, and diagram generation |
| **GitLab Integration** | Direct publishing to enterprise GitLab repositories |
| **Visual Blueprints** | Auto-generated Mermaid architecture diagrams |

### 1.3 Key Capabilities

- **Dual-mode AI Suggestions**: "Refine" (uses user keywords) vs "Auto" (generates from scratch)
- **Typewriter Effect**: Animated text population for AI suggestions
- **Live Markdown Preview**: Side-by-side editor and rendered preview
- **Intelligent Diagram Selection**: AI chooses best diagram type based on content
- **Chat-based Feedback**: Natural language epic modifications
- **Export Options**: Markdown, Mermaid code, SVG, PNG
- **Hierarchical GitLab Selection**: Root Group → Pod → Epic navigation

---

## 2. ARCHITECTURE OVERVIEW

### 2.1 Technology Stack

| Layer | Technology | Version | Purpose |
|-------|------------|---------|---------|
| UI Framework | React | 19.0.0 | Component-based UI |
| Language | TypeScript | 5.6.0 | Type safety |
| Build Tool | Vite | 6.0.0 | Fast dev server & bundling |
| Markdown | react-markdown | 9.0.1 | Markdown parsing |
| GFM Support | remark-gfm | 4.0.0 | GitHub Flavored Markdown |
| Diagrams | Mermaid.js | 11.4.0 | Flowcharts, sequences |
| PlantUML | plantuml-encoder | 1.4.0 | Diagram encoding |
| AI Backend | OpenAI / Azure OpenAI | External | GPT-4/5 integration |
| Version Control | GitLab API | v4 | Repository integration |

### 2.2 Directory Structure

```
epic-generator/
├── index.html              # Entry HTML (loads main.tsx)
├── package.json            # Dependencies & npm scripts
├── package-lock.json       # Locked dependency versions
├── vite.config.js          # Vite config with GitLab proxy
├── vitest.config.ts        # Vitest test configuration
├── tsconfig.json           # TypeScript strict mode config
├── INSTALL.md              # Installation guide
├── CODEBASE_REFERENCE.md   # This file
│
├── public/
│   └── UBS-3821101260.png  # UBS logo asset
│
└── src/
    ├── main.tsx            # React DOM entry point (10 lines)
    ├── App.tsx             # Main component - ALL UI (4,169 lines)
    ├── types.ts            # TypeScript interfaces & constants (146 lines)
    ├── config.ts           # OpenAI + Azure OpenAI + GitLab API (1,668 lines)
    ├── skills.ts           # AI prompts & diagram generation (1,309 lines)
    ├── MarkdownPreview.tsx # Markdown renderer with Mermaid (236 lines)
    ├── mockGitLabData.ts   # Mock GitLab data for local testing (685 lines)
    ├── styles.css          # CSS animations & global styles (400 lines)
    │
    └── test/               # Test directory (Vitest)
        ├── setup.ts        # Test setup and mocks
        ├── testUtils.ts    # Test utilities and mock data
        ├── epicEditor.test.tsx   # Epic Editor component tests
        ├── saveEpic.test.tsx     # Save Epic workflow tests
        ├── loadEpic.test.tsx     # Load Epic workflow tests
        └── gitlabApi.test.ts     # GitLab API integration tests
```

### 2.3 Component Hierarchy

```
App.tsx (Main Container)
├── Header (UBS FRAME branding)
├── Progress Steps (6 stages + Epic)
├── Tab Navigation (Wizard | Epic | Blueprint | Settings)
│
├── Wizard View (renderWizard)
│   ├── Help Banner
│   ├── Stage Fields (with AI suggest buttons)
│   ├── Refined Content Display
│   ├── Navigation Buttons
│   └── Epic Sections Preview
│
├── Epic Editor View (renderEpicEditor)
│   ├── Action Bar
│   ├── Split Screen
│   │   ├── Editor Pane (textarea)
│   │   └── Preview Pane (MarkdownPreview)
│   └── Chat Panel (optional)
│
├── Blueprint View (renderBlueprint)
│   ├── Action Bar
│   ├── Diagram Preview (MermaidBlueprint)
│   ├── Fullscreen Overlay
│   └── Code Editor + Legend
│
├── Settings View (renderSettings)
│   ├── Azure OpenAI Config
│   └── GitLab Config
│
├── Toast Notifications
└── Confetti Animation
```

---

## 3. FILE-BY-FILE DEEP DIVE

### 3.1 `src/types.ts` - Type Definitions & Constants

#### Core Interfaces

```typescript
// Stage field definition - describes each input field
interface StageField {
  name: string;           // Unique identifier (e.g., "projectName")
  label: string;          // Display label for UI
  placeholder: string;    // Input placeholder text
  type: 'text' | 'textarea';  // Input type
  required: boolean;      // Validation requirement
}

// Wizard stage definition - describes each step
interface Stage {
  id: string;                   // Stage identifier (e.g., "project")
  title: string;                // Display title
  description: string;          // Help text shown below title
  fields: StageField[];         // Array of input fields
  populatesSections: number[];  // Which epic sections this stage fills
}

// Refined user input storage - stores both original and AI-refined content
interface RefinedData {
  [key: string]: {
    original: string;     // Raw user input
    refined: string;      // AI-refined content
    diagramNode: string;  // Mermaid node representation
  };
}

// Main application state
interface EpicState {
  currentStage: number;         // Current wizard stage (0-5)
  data: RefinedData;            // All refined field data
  diagramNodes: string[];       // Collected diagram nodes
  generatedEpic: string | null; // Final generated epic markdown
}

// Chat message for feedback system
interface ChatMessage {
  id: string;                   // Unique message ID
  role: 'user' | 'assistant';   // Message sender
  content: string;              // Message content
  timestamp: Date;              // When sent
  questionType?: 'section-select' | 'text-input' | 'confirm';  // For AI questions
  options?: string[];           // Dropdown options if applicable
  selectedValue?: string;       // User's answer
  isAnswered?: boolean;         // Whether question was answered
}

// Chat panel state
interface ChatState {
  messages: ChatMessage[];      // All chat messages
  isOpen: boolean;              // Panel visibility
  isProcessing: boolean;        // AI thinking indicator
  pendingSection?: number;      // Section being modified
  pendingFeedback?: string;     // Original feedback to apply
}
```

#### The 6 Wizard Stages

| Stage | ID | Fields | Populates Sections |
|-------|-----|--------|-------------------|
| 1. Project | `project` | projectName, background | 1, 2 |
| 2. Objective & Scope | `objective_scope` | objective, inScope, outOfScope | 1, 3 |
| 3. Architecture | `architecture` | assumptions, architectureOverview, dataStores | 4, 5, 6, 10 |
| 4. Features | `features` | features, userStories, nfrs, deliverables | 11, 12, 14 |
| 5. Team & Environment | `team_env` | teams, environments, security | 7, 8, 9 |
| 6. Delivery | `delivery` | dependencies, risks, nextSteps, dod, approvers | 13, 15, 16, 17 |

#### The 17 Epic Sections

```typescript
EPIC_SECTIONS = [
  { num: 1,  title: 'Objective',                          dataKeys: ['objective'] },
  { num: 2,  title: 'Background & Context',               dataKeys: ['background'] },
  { num: 3,  title: 'Scope',                              dataKeys: ['inScope', 'outOfScope'], subsections: ['In Scope', 'Out of Scope'] },
  { num: 4,  title: 'Assumptions',                        dataKeys: ['assumptions'] },
  { num: 5,  title: 'High-Level Architecture Overview',   dataKeys: ['architectureOverview'], hasDiagram: true },
  { num: 6,  title: 'Architecture Diagrams',              dataKeys: [], isReference: true },
  { num: 7,  title: 'Team & Roles',                       dataKeys: ['teams'], isTable: true },
  { num: 8,  title: 'Environments & CI/CD Strategy',      dataKeys: ['environments'] },
  { num: 9,  title: 'Data Security & Access Controls',    dataKeys: ['security'] },
  { num: 10, title: 'Data Stores, Services & Interfaces', dataKeys: ['dataStores'] },
  { num: 11, title: 'Key Features & User Stories',        dataKeys: ['features', 'userStories'] },
  { num: 12, title: 'Non-Functional Requirements (NFRs)', dataKeys: ['nfrs'] },
  { num: 13, title: 'Dependencies & Risks',               dataKeys: ['dependencies', 'risks'], subsections: ['Dependencies', 'Risks'] },
  { num: 14, title: 'Deliverables',                       dataKeys: ['deliverables'] },
  { num: 15, title: 'Next Steps',                         dataKeys: ['nextSteps'] },
  { num: 16, title: 'Definition of Done (DoD)',           dataKeys: ['dod'] },
  { num: 17, title: 'Approvals & Sign-Offs',              dataKeys: ['approvers'], isTable: true },
]
```

---

### 3.2 `src/config.ts` - Configuration & API Integration

#### AI Provider Type

```typescript
type AIProvider = 'none' | 'openai' | 'azure';

// Main App Config
interface AppConfig {
  aiProvider: AIProvider;      // Which AI provider to use
  openAI: OpenAIConfig;        // OpenAI direct API config
  azureOpenAI: AzureOpenAIConfig;
  gitlab: GitLabConfig;
}
```

#### OpenAI Configuration Interface (NEW)

```typescript
interface OpenAIConfig {
  enabled: boolean;           // Toggle OpenAI features
  apiKey: string;             // "sk-..." API key from OpenAI
  model: string;              // "gpt-4o", "gpt-4-turbo", "gpt-3.5-turbo"
  organizationId?: string;    // Optional organization ID
  maxTokens: number;          // Default: 4096
  temperature: number;        // Default: 0.7
  baseUrl?: string;           // Optional custom base URL (for proxies)
}

// Available OpenAI Models
OPENAI_MODELS = [
  { id: 'gpt-4o', name: 'GPT-4o (Recommended)', family: 'gpt-4' },
  { id: 'gpt-4o-mini', name: 'GPT-4o Mini (Fast & Cheap)', family: 'gpt-4' },
  { id: 'gpt-4-turbo', name: 'GPT-4 Turbo', family: 'gpt-4' },
  { id: 'gpt-4', name: 'GPT-4', family: 'gpt-4' },
  { id: 'gpt-3.5-turbo', name: 'GPT-3.5 Turbo (Budget)', family: 'gpt-3.5' },
  { id: 'o1-preview', name: 'o1 Preview (Reasoning)', family: 'gpt-5' },
  { id: 'o1-mini', name: 'o1 Mini (Fast Reasoning)', family: 'gpt-5' },
]
```

#### Azure OpenAI Configuration Interface

```typescript
interface AzureOpenAIConfig {
  enabled: boolean;           // Toggle AI features
  endpoint: string;           // "https://your-resource.openai.azure.com"
  deploymentName: string;     // "gpt-4o-deployment"
  apiKey: string;             // Azure API key
  apiVersion: string;         // "2024-02-15-preview"
  maxTokens: number;          // Default: 4096
  temperature: number;        // Default: 0.7
  modelFamily?: ModelFamily;  // 'gpt-4' | 'gpt-5' | 'gpt-3.5' | 'unknown'
}
```

#### Model Family Detection & Limits

```typescript
// Auto-detection based on deployment name or model ID
function detectModelFamily(modelName: string): ModelFamily {
  const name = modelName.toLowerCase();
  if (name.includes('gpt-5') || name.includes('o1') || name.includes('o3')) {
    return 'gpt-5';
  }
  if (name.includes('gpt-4')) {
    return 'gpt-4';
  }
  if (name.includes('gpt-3.5')) {
    return 'gpt-3.5';
  }
  return 'unknown';
}

// Model-specific limits
MODEL_LIMITS = {
  'gpt-4': {
    maxTokens: 128000,      // GPT-4 Turbo supports up to 128K
    maxTemperature: 2.0,
    defaultTokens: 4096,
  },
  'gpt-3.5': {
    maxTokens: 16384,       // GPT-3.5 Turbo supports up to 16K
    maxTemperature: 2.0,
    defaultTokens: 4096,
  },
  'gpt-5': {
    maxTokens: 16384,       // GPT-5/o1 has lower max_completion_tokens
    maxTemperature: 1.0,    // Temperature must be <= 1.0
    defaultTokens: 4096,
  },
  'unknown': {
    maxTokens: 4096,        // Safe default
    maxTemperature: 1.0,
    defaultTokens: 2048,
  },
}
```

#### GitLab Configuration Interface

```typescript
interface GitLabConfig {
  enabled: boolean;           // Toggle GitLab features
  baseUrl: string;            // "https://devcloud.ubs.net"
  projectId: string;          // Selected project ID or path
  accessToken: string;        // Personal Access Token (glpat-...)
  branch: string;             // Target branch (default: "main")
  epicFilePath: string;       // Path prefix (default: "docs/epics/")
  rootGroupId: string;        // Root group for hierarchical selection
  selectedPodId: string;      // Selected pod (subgroup)
  selectedEpicId: string;     // Selected epic (project)
}
```

#### GitLab Repository Types (NEW)

```typescript
// File/folder item in repository tree
interface GitLabFile {
  id: string;
  name: string;
  type: 'tree' | 'blob';      // tree = folder, blob = file
  path: string;
  mode: string;
}

// Result from repository tree fetch
interface GitLabTreeResult {
  success: boolean;
  data?: GitLabFile[];
  error?: string;
}

// Result from file content fetch
interface GitLabFileResult {
  success: boolean;
  content?: string;           // Decoded file content
  fileName?: string;
  size?: number;
  error?: string;
}

// Branch information
interface GitLabBranch {
  name: string;
  default: boolean;
  web_url: string;
}

// Result from branches fetch
interface GitLabBranchResult {
  success: boolean;
  branches?: GitLabBranch[];
  defaultBranch?: string;
  error?: string;
}

// Result from MR workflow
interface GitLabMRResult {
  success: boolean;
  branchName?: string;
  commitUrl?: string;
  mrUrl?: string;
  error?: string;
}
```

#### API Functions Reference

| Function | Parameters | Returns | Purpose |
|----------|------------|---------|---------|
| `loadConfig()` | none | `AppConfig` | Load from localStorage |
| `saveConfig()` | `AppConfig` | void | Save to localStorage |
| `callOpenAI()` | `config, systemPrompt, userPrompt` | `string` | Make OpenAI API call |
| `testOpenAI()` | `config` | `{ success, error?, model? }` | Test OpenAI connection |
| `callAzureOpenAI()` | `config, systemPrompt, userPrompt` | `string` | Make Azure API call |
| `testAzureOpenAI()` | `config` | `{ success, error? }` | Test Azure connection |
| `callAI()` | `config, systemPrompt, userPrompt` | `string` | Unified AI call (routes to correct provider) |
| `isAIEnabled()` | `config` | `boolean` | Check if any AI is enabled |
| `getActiveAIProvider()` | `config` | `string` | Get active provider name |
| `fetchGitLabSubgroups()` | `config, groupId` | `GitLabGroupResult` | Get child groups |
| `fetchGitLabEpics()` | `config, groupId` | `GitLabEpicResult` | Get subgroups + projects |
| `publishToGitLab()` | `config, fileName, content, commitMessage` | `GitLabPublishResult` | Create/update file |
| `testGitLabConnection()` | `config` | `{ success, error?, projectName? }` | Test connection |
| `getSafeModelParams()` | `config` | `{ maxTokens, temperature }` | Get safe Azure params |
| `getSafeOpenAIModelParams()` | `config` | `{ maxTokens, temperature }` | Get safe OpenAI params |
| `detectModelFamily()` | `modelName` | `ModelFamily` | Auto-detect model family |
| `getOpenAIModelFamily()` | `modelId` | `ModelFamily` | Get family for OpenAI model |
| `fetchGitLabRepositoryTree()` | `config, path?, ref?` | `GitLabTreeResult` | List files/folders in repo |
| `fetchGitLabFileContent()` | `config, filePath, ref?` | `GitLabFileResult` | Get file content (base64 decoded) |
| `fetchGitLabBranches()` | `config` | `GitLabBranchResult` | List branches + find default |
| `commitToGitLabBranch()` | `config, branchName, filePath, content, commitMessage, startBranch?` | `GitLabMRResult` | Atomic branch creation + file commit |
| `createGitLabMergeRequest()` | `config, sourceBranch, targetBranch, title, description` | `GitLabMRResult` | Create merge request |
| `publishWithMergeRequest()` | `config, fileName, content, commitMessage, mrTitle, mrDescription` | `GitLabMRResult` | Complete MR workflow (branch + commit + MR) |

#### OpenAI API Request

```typescript
// OpenAI API endpoint
POST https://api.openai.com/v1/chat/completions

// Headers
{
  'Content-Type': 'application/json',
  'Authorization': 'Bearer sk-...',
  'OpenAI-Organization': 'org-...'  // Optional
}

// Request body (standard models)
{
  model: 'gpt-4o',
  messages: [...],
  max_tokens: 4096,
  temperature: 0.7,
}

// Request body (o1 models)
{
  model: 'o1-preview',
  messages: [...],
  max_completion_tokens: 4096,  // Different parameter!
  temperature: 0.7,             // Must be <= 1.0
}
```

#### GPT-4 vs GPT-5 Request Differences

```typescript
// GPT-4 request body
{
  messages: [...],
  max_tokens: 4096,        // Standard parameter
  temperature: 0.7,
}

// GPT-5/o1 request body
{
  messages: [...],
  max_completion_tokens: 4096,  // Different parameter name!
  temperature: 0.7,             // Must be <= 1.0
}
```

#### CORS Handling

```typescript
// Development: Use Vite proxy
if (import.meta.env.DEV) {
  return '/gitlab-api';  // Proxied to http://devcloud.ubs.net/api/v4
}
// Production: Direct API calls
return `${config.baseUrl}/api/v4`;
```

---

### 3.3 `src/skills.ts` - AI Skills & Diagram Generation

#### Core AI Functions

**1. Get Suggestion**
```typescript
async function getSuggestion(
  stageId: string,      // Which stage (e.g., "project")
  fieldName: string,    // Which field (e.g., "projectName")
  context: Record<string, string>,  // All collected data
  mode: 'with-context' | 'auto'     // Suggestion mode
): Promise<SuggestionResult>
```

- **`mode='with-context'`**: Uses user's keywords to tailor suggestions
- **`mode='auto'`**: Generates from scratch using only project context

**2. Run Skill**
```typescript
async function runSkill(
  skill: 'refine' | 'generate',
  params: {
    stageId?: string;
    fieldName?: string;
    input?: string;
    context?: Record<string, string>;
    data?: RefinedData;
    projectName?: string;
  }
): Promise<RefineResult | GenerateResult>
```

- **`skill='refine'`**: Enhances single field input
- **`skill='generate'`**: Creates full 17-section epic

**3. Generate Intelligent Blueprint**
```typescript
async function generateIntelligentBlueprint(
  data: RefinedData,
  projectName: string
): Promise<{ diagram: string; type: DiagramType; reasoning: string }>
```

#### Field-Specific System Prompts

Each field has tailored AI prompts:

```typescript
fieldPrompts = {
  project: {
    projectName: 'Generate a professional project name (2-4 words, no quotes).',
    background: 'Write a project background section explaining why this initiative exists.',
  },
  objective_scope: {
    objective: 'Write a clear, measurable project objective with success criteria.',
    inScope: 'List items that are IN SCOPE for this project. Use bullet points.',
    outOfScope: 'List items that are OUT OF SCOPE for this project.',
  },
  architecture: {
    assumptions: 'List technical and business assumptions.',
    architectureOverview: 'Describe the high-level system architecture.',
    dataStores: 'Describe databases, caching, and data flow.',
  },
  // ... more fields
}
```

#### Diagram Types & Selection

| Type | Best For | Mermaid Syntax | Score Factors |
|------|----------|----------------|---------------|
| `c4-container` | System architecture | `flowchart LR` + subgraphs | componentCount >= 3, hasArchitecture |
| `sequence` | User flows | `sequenceDiagram` | hasUserStories + hasWorkflows |
| `deployment` | Infrastructure | `flowchart LR` + environments | hasDeploymentDetails |
| `component` | Internal structure | `flowchart LR` + layers | hasDataStores + componentCount >= 2 |
| `multilayer` | Full epic overview | 7-layer architecture | Default fallback |

#### Context Analysis Algorithm

```typescript
function analyzeEpicContext(data: RefinedData): DiagramContext {
  return {
    hasArchitecture: archText.length > 50,
    hasFeatures: featureLines.length > 0,
    hasUserStories: storiesText.length > 50,
    hasDataStores: dataText.length > 30,
    hasEnvironments: envsText.length > 30,
    hasDeploymentDetails: envsText.includes('kubernetes') || envsText.includes('docker'),
    hasWorkflows: storiesText.includes('when') || storiesText.includes('then'),
    featureCount: featureLines.length,
    componentCount: uniqueComponentMatches.size,
    integrationCount: uniqueIntegrationMatches.size,
  };
}
```

#### Chat/Feedback AI Functions

| Function | Purpose | Returns |
|----------|---------|---------|
| `analyzeUserFeedback()` | Determine target section from feedback | `{ needsClarification, suggestedSection?, followUpQuestion? }` |
| `processFeedback()` | Generate updated section content | `{ updatedSection, explanation }` |
| `fixMermaidDiagram()` | AI-powered syntax error correction | Fixed Mermaid code string |

---

### 3.4 `src/MarkdownPreview.tsx` - Markdown Renderer

#### Features

- **GitHub-flavored Markdown (GFM)** via `remark-gfm`
- **Task list rendering** (`- [ ]` and `- [x]` checkboxes)
- **Tables** with proper styling
- **Code blocks** with language detection
- **Mermaid diagram embedding** via `MermaidDiagram` component

#### Mermaid Integration

```typescript
// Inside code block renderer
if (language === 'mermaid') {
  return <MermaidDiagram chart={String(children).trim()} />;
}
```

#### MermaidDiagram Component

```typescript
function MermaidDiagram({ chart }: { chart: string }) {
  const [svg, setSvg] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const renderDiagram = async () => {
      try {
        const id = `mermaid-${Math.random().toString(36).substr(2, 9)}`;
        const { svg } = await mermaid.render(id, chart);
        setSvg(svg);
        setError(null);
      } catch (err) {
        setError('Diagram rendering error');
      }
    };
    renderDiagram();
  }, [chart]);

  if (error) return <ErrorDisplay />;
  return <div dangerouslySetInnerHTML={{ __html: svg }} />;
}
```

#### Styling Reference

```typescript
styles = {
  h1: { fontSize: '2em', borderBottom: '1px solid #d0d7de', paddingBottom: '0.3em' },
  h2: { fontSize: '1.5em', borderBottom: '1px solid #d0d7de', paddingBottom: '0.3em' },
  h3: { fontSize: '1.25em', fontWeight: '600' },
  table: { borderCollapse: 'collapse', width: '100%' },
  th: { border: '1px solid #d0d7de', backgroundColor: '#f6f8fa', fontWeight: '600' },
  td: { border: '1px solid #d0d7de', padding: '8px 12px' },
  code: { backgroundColor: 'rgba(175, 184, 193, 0.2)', borderRadius: '6px' },
  blockquote: { borderLeft: '4px solid #d0d7de', color: '#57606a' },
}
```

---

### 3.5 `src/App.tsx` - Main Application Component (3,123 lines)

#### State Management

**Core State:**
```typescript
const [state, setState] = useState<EpicState>(initialState);
const [formData, setFormData] = useState<Record<string, string>>({});
const [editingRefined, setEditingRefined] = useState<Record<string, boolean>>({});
const [loadingSuggestion, setLoadingSuggestion] = useState<Record<string, boolean>>({});
const [alternatives, setAlternatives] = useState<Record<string, string[]>>({});
```

**UI State:**
```typescript
const [activeTab, setActiveTab] = useState<'wizard' | 'epic' | 'blueprint' | 'settings'>('wizard');
const [isRefining, setIsRefining] = useState(false);
const [isGenerating, setIsGenerating] = useState(false);
const [editableEpic, setEditableEpic] = useState<string>('');
const [blueprintCode, setBlueprintCode] = useState<string>('');
const [blueprintType, setBlueprintType] = useState<string>('');
const [blueprintReasoning, setBlueprintReasoning] = useState<string>('');
const [blueprintZoom, setBlueprintZoom] = useState<number>(100);
const [blueprintFullscreen, setBlueprintFullscreen] = useState(false);
const [blueprintSvg, setBlueprintSvg] = useState<string>('');
```

**Config State:**
```typescript
const [config, setConfig] = useState<AppConfig>(DEFAULT_CONFIG);
const [isPublishing, setIsPublishing] = useState(false);
const [publishStatus, setPublishStatus] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
const [gitlabTestStatus, setGitlabTestStatus] = useState<{ testing: boolean; result?: string } | null>(null);
const [azureTestStatus, setAzureTestStatus] = useState<{ testing: boolean; result?: string } | null>(null);
const [pods, setPods] = useState<Array<{ id: number; name: string; path: string }>>([]);
const [epics, setEpics] = useState<Array<{ id: number; name: string; path: string; type: 'subgroup' | 'project' }>>([]);
```

**GitLab Advanced State (NEW):**
```typescript
const [branches, setBranches] = useState<GitLabBranch[]>([]);                    // Available branches
const [navigationStack, setNavigationStack] = useState<Array<{                   // Navigation breadcrumb
  id: string; name: string; type: string
}>>([]);
const [publishMode, setPublishMode] = useState<'direct' | 'mr'>('direct');       // Publish mode toggle
const [repositoryFiles, setRepositoryFiles] = useState<GitLabFile[]>([]);        // Current folder contents
const [currentRepoPath, setCurrentRepoPath] = useState<string>('');              // Current browsing path
const [loadingRepoFiles, setLoadingRepoFiles] = useState(false);                 // Loading state
const [selectedProjectName, setSelectedProjectName] = useState<string>('');       // Selected project display name
```

**Toast & Effects:**
```typescript
const [toasts, setToasts] = useState<Toast[]>([]);
const [showConfetti, setShowConfetti] = useState(false);
const [generationProgress, setGenerationProgress] = useState({ current: 0, total: 17, section: '' });
const [typingField, setTypingField] = useState<string | null>(null);
```

**Chat State:**
```typescript
const [chatState, setChatState] = useState<ChatState>({
  messages: [],
  isOpen: false,
  isProcessing: false,
});
const [chatInput, setChatInput] = useState('');
```

#### Key Functions Reference

**Navigation:**
| Function | Purpose |
|----------|---------|
| `nextStage()` | Refine current stage + advance or generate epic |
| `prevStage()` | Go back, restore previous form data |
| `resetWizard()` | Clear everything, start fresh |

**AI Integration:**
| Function | Purpose |
|----------|---------|
| `handleGetSuggestion(fieldName, mode)` | Get AI suggestion with typewriter effect |
| `refineStage()` | Refine all fields in current stage |
| `generateEpic()` | Generate 17-section epic + blueprint |
| `regenerateBlueprint()` | Regenerate diagram with AI analysis |
| `handleRequestDiagramFix()` | AI-powered Mermaid syntax fix |

**Chat Functions:**
| Function | Purpose |
|----------|---------|
| `toggleChat()` | Open/close chat panel |
| `addChatMessage()` | Add message to chat |
| `handleSendChatMessage()` | Process user feedback |
| `handleSectionSelect()` | User selects section to update |
| `handleConfirmSection()` | User confirms/rejects AI suggestion |
| `replaceSection()` | Replace section in epic markdown |

**Export Functions:**
| Function | Purpose |
|----------|---------|
| `exportAsSVG()` | Download diagram as SVG |
| `exportAsPNG()` | Download diagram as PNG (2x scale) |
| Copy markdown, Mermaid code | Clipboard operations |

**GitLab Functions:**
| Function | Purpose |
|----------|---------|
| `handlePublishToGitLab()` | Push epic to GitLab (supports direct commit or MR mode) |
| `handleFetchPods()` | Load pods from root group |
| `handlePodSelect()` | Select pod, load child items |
| `handleEpicSelect()` | Navigate subgroups or select project (distinguishes by web_url) |
| `handleNavigateBack()` | Navigate back in subgroup hierarchy |
| `handleBrowseFiles()` | Browse repository files at given path |
| `handleLoadFile()` | Load file content into editor |
| `handleBrowseParent()` | Navigate to parent folder |

#### Inline UI Components

**Toast System:**
```typescript
interface Toast {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  title: string;
  message?: string;
  duration?: number;  // Default: 3000ms
  exiting?: boolean;
}
```

**Confetti Component:**
- 50 colored pieces (#3b82f6, #8b5cf6, #10b981, #f59e0b, #ef4444, #ec4899)
- Random positions and delays
- 3-second fall animation

**MermaidBlueprint Component:**
- Zoom support (25-200%)
- AI auto-fix on render errors
- SVG export callback

#### Render Functions

**`renderWizard()`** - Lines 915-1105
- Help banner (Refine vs Auto explanation)
- Stage title and description
- Field inputs with dual-mode suggest buttons
- Refined content display (editable)
- Alternative suggestions chips
- Navigation buttons
- Epic sections preview grid

**`renderEpicEditor()`** - Lines 2510-2923
- Action bar (Copy, Download, Push to GitLab, Start Over, AI Feedback)
- Split screen: Editor (textarea) | Preview (MarkdownPreview)
- Chat panel with messages and input

**`renderBlueprint()`** - Lines 1345-1845
- Action bar (Regenerate, Copy Mermaid, Download .mmd, Open Editor, SVG, PNG)
- Live diagram preview with zoom controls
- Fullscreen overlay
- Split: Mermaid code editor | Diagram guide legend
- AI reasoning display

**`renderSettings()`** - Lines 1847-2480
- Two-column layout: Azure OpenAI | GitLab
- Toggle switches with visual feedback
- Form fields with validation
- Test connection buttons
- Model family detection and parameters
- GitLab hierarchical selection with breadcrumb navigation
- Branch selector dropdown (fetched from GitLab)
- **Repository Browser** (NEW): Browse files/folders, click to navigate or load
- **Publish Mode Toggle** (NEW): Direct Commit vs Merge Request mode
- Quick status footer

---

### 3.6 `src/styles.css` - Animations & Global Styles

#### Keyframe Animations

| Animation | Purpose | Duration | CSS Class |
|-----------|---------|----------|-----------|
| `shimmer` | Skeleton loading | 1.5s | `.skeleton` |
| `spin` | Loading spinner | 1s | - |
| `slideInRight` | Toast entrance | 0.3s | `.toast` |
| `slideOutRight` | Toast exit | 0.3s | `.toast-exit` |
| `progressShrink` | Toast countdown | Variable | `.toast-progress` |
| `confettiFall` | Celebration pieces | 3s | `.confetti-piece` |
| `progressPulse` | Section name pulse | 1.5s | `.progress-section-name` |
| `blink` | Typewriter cursor | 1s | `.typewriter-cursor` |
| `pulse` | Chat thinking | 1s | - |
| `fadeIn` | Chat message | 0.3s | `.chat-message` |

#### Global Styles

```css
/* Background gradient */
body {
  background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 50%, #e2e8f0 100%);
  background-attachment: fixed;
}

/* Smooth transitions for all interactive elements */
button, input, textarea, select, [role="button"] {
  transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
}

/* Focus accessibility */
button:focus-visible, input:focus-visible, textarea:focus-visible {
  outline: 2px solid #3b82f6;
  outline-offset: 2px;
}
```

#### Component Styles

```css
/* Toast notifications */
.toast {
  min-width: 280px;
  max-width: 400px;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(12px);
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
  border-radius: 10px;
}

/* Progress bar */
.progress-bar-fill {
  background: linear-gradient(90deg, #3b82f6, #8b5cf6, #10b981);
  background-size: 200% 100%;
  animation: shimmer 2s ease-in-out infinite;
}

/* Chat scrollbar */
.chat-messages::-webkit-scrollbar {
  width: 6px;
}
.chat-messages::-webkit-scrollbar-thumb {
  background: #d1d5db;
  border-radius: 3px;
}
```

---

### 3.7 Configuration Files

#### `vite.config.js`

```javascript
export default defineConfig({
  plugins: [react()],
  server: {
    port: 3002,
    proxy: {
      '/gitlab-api': {
        target: 'https://devcloud.ubs.net',  // HTTPS for secure connections
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/gitlab-api/, '/api/v4'),
        secure: false,
        // Proxy logging for debugging
        configure: (proxy, options) => {
          proxy.on('error', (err, req, res) => {
            console.log('[Proxy Error]', err.message);
          });
          proxy.on('proxyReq', (proxyReq, req, res) => {
            console.log('[Proxy Request]', req.method, req.url);
          });
          proxy.on('proxyRes', (proxyRes, req, res) => {
            console.log('[Proxy Response]', proxyRes.statusCode, req.url);
          });
        }
      }
    }
  }
})
```

#### `tsconfig.json`

```json
{
  "compilerOptions": {
    "target": "ES2020",
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "module": "ESNext",
    "moduleResolution": "bundler",
    "jsx": "react-jsx",
    "strict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noFallthroughCasesInSwitch": true,
    "skipLibCheck": true,
    "isolatedModules": true,
    "noEmit": true
  },
  "include": ["src"]
}
```

#### `package.json`

```json
{
  "name": "epic-generator",
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite --port 3002",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "mermaid": "^11.4.0",
    "plantuml-encoder": "^1.4.0",
    "react": "^19.0.0",
    "react-dom": "^19.0.0",
    "react-markdown": "^9.0.1",
    "remark-gfm": "^4.0.0"
  },
  "devDependencies": {
    "@types/react": "^19.0.0",
    "@types/react-dom": "^19.0.0",
    "@vitejs/plugin-react": "^4.3.0",
    "typescript": "^5.6.0",
    "vite": "^6.0.0"
  }
}
```

---

## 4. DATA FLOW

### 4.1 Wizard → Epic Flow

```
┌─────────────────┐
│   User Input    │
│   (formData)    │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  refineStage()  │──► runSkill('refine') per field
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│   state.data    │  { original, refined, diagramNode }
│    updated      │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│   nextStage()   │──► Advance or generateEpic()
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ runSkill        │──► Builds 17-section markdown
│ ('generate')    │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ generateIntelli │──► Creates Mermaid diagram
│ gentBlueprint() │
└────────┬────────┘
         │
         ▼
┌─────────────────────────────────────┐
│ state.generatedEpic                 │
│ editableEpic                        │
│ blueprintCode + Type + Reasoning    │
└─────────────────────────────────────┘
```

### 4.2 AI Suggestion Flow

```
┌─────────────────────┐
│ User clicks button  │
│ "Refine" or "Auto"  │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ handleGetSuggestion │
│ (fieldName, mode)   │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│  getSuggestion()    │──► Build prompt from context + field prompts
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│     callAI()        │──► callAzureOpenAI() or mock
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ typewriterEffect()  │──► Animated field population
└─────────────────────┘
```

### 4.3 Chat Feedback Flow

```
┌─────────────────────┐
│  User types feedback│
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│handleSendChatMessage│
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│analyzeUserFeedback()│──► Determine target section
└──────────┬──────────┘
           │
     ┌─────┴─────┐
     │           │
     ▼           ▼
┌─────────┐  ┌─────────┐
│Needs    │  │Confident│
│Clarify  │  │Section  │
└────┬────┘  └────┬────┘
     │            │
     ▼            ▼
┌─────────┐  ┌─────────┐
│Ask      │  │Confirm  │
│Follow-up│  │with user│
└─────────┘  └────┬────┘
                  │
                  ▼
         ┌─────────────────┐
         │handleSectionSel-│
         │ect() or Confirm │
         └────────┬────────┘
                  │
                  ▼
         ┌─────────────────┐
         │processFeedback()│──► AI generates updated section
         └────────┬────────┘
                  │
                  ▼
         ┌─────────────────┐
         │replaceSection() │──► Update editableEpic
         └─────────────────┘
```

### 4.4 GitLab Publishing Flow

**Direct Commit Mode:**
```
┌─────────────────────┐
│User clicks "Push to │
│GitLab" (Direct Mode)│
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│handlePublishToGitLab│
│  publishMode='direct'│
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ publishToGitLab()   │
│ (config, fileName,  │
│  content, message)  │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ Check if file exists│──► GET /repository/files/{path}
└──────────┬──────────┘
           │
     ┌─────┴─────┐
     │           │
     ▼           ▼
┌─────────┐  ┌─────────┐
│Exists   │  │Not Found│
│PUT      │  │POST     │
└────┬────┘  └────┬────┘
     │            │
     └─────┬──────┘
           │
           ▼
┌─────────────────────┐
│ Return { success,   │
│   url }             │
└─────────────────────┘
```

**Merge Request Mode (NEW):**
```
┌─────────────────────┐
│User clicks "Create  │
│MR" (MR Mode)        │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│handlePublishToGitLab│
│  publishMode='mr'   │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│publishWithMergeRequ-│
│est() - Orchestrator │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ commitToGitLabBranch│──► POST /repository/commits
│ (creates branch +   │    { branch, start_branch,
│  commits file)      │      actions: [...] }
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│createGitLabMerge-   │──► POST /merge_requests
│Request()            │    { source_branch,
│                     │      target_branch, title }
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ Return { success,   │
│   branchName, mrUrl}│
└─────────────────────┘
```

### 4.5 File Browser Flow (NEW)

```
┌─────────────────────┐
│User clicks "Browse  │
│Files" in Settings   │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│  handleBrowseFiles  │
│  (path = '')        │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│fetchGitLabRepository│──► GET /repository/tree?path=
│Tree()               │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│ setRepositoryFiles  │
│ (files + folders)   │
└──────────┬──────────┘
           │
     ┌─────┴─────┐
     │           │
     ▼           ▼
┌─────────┐  ┌─────────┐
│Click    │  │Click    │
│Folder   │  │File     │
│(tree)   │  │(blob)   │
└────┬────┘  └────┬────┘
     │            │
     ▼            ▼
┌─────────┐  ┌─────────┐
│handleBro│  │handleLo-│
│wseFiles │  │adFile() │
│(path)   │  │         │
└─────────┘  └────┬────┘
                  │
                  ▼
         ┌─────────────────┐
         │fetchGitLabFile- │──► GET /repository/files/{path}
         │Content()        │    (base64 decode)
         └────────┬────────┘
                  │
                  ▼
         ┌─────────────────┐
         │setEditableEpic  │──► Load content into editor
         │(content)        │
         └─────────────────┘
```

---

## 5. KEY ALGORITHMS

### 5.1 Section Replacement Algorithm

```typescript
function replaceSection(epic: string, sectionNum: number, newContent: string): string {
  const sectionInfo = EPIC_SECTIONS[sectionNum - 1];
  if (!sectionInfo) return epic;

  // Escape special regex characters in section title
  const escapedTitle = sectionInfo.title.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Match section header and content until next section or end
  const sectionRegex = new RegExp(
    `(## ${sectionNum}\\. ${escapedTitle}[\\s\\S]*?)(?=## \\d+\\.|$)`,
    'i'
  );

  return epic.replace(sectionRegex, newContent + '\n\n');
}
```

### 5.2 Diagram Type Selection Algorithm

```typescript
function selectBestDiagramType(context: DiagramContext): DiagramType {
  const scores: Record<string, number> = {
    'c4-container': 2,  // Default baseline
    'component': 0,
    'sequence': 0,
    'deployment': 0,
  };

  // Score based on available data
  if (context.hasArchitecture && context.componentCount >= 3) {
    scores['c4-container'] += 5;
    scores['component'] += 4;
  }

  if (context.hasUserStories && context.hasWorkflows) {
    scores['sequence'] += 5;
  }

  if (context.hasDeploymentDetails && context.hasEnvironments) {
    scores['deployment'] += 5;
  }

  if (context.hasDataStores && context.componentCount >= 2) {
    scores['component'] += 2;
  }

  if (context.integrationCount >= 2) {
    scores['c4-container'] += 3;
    scores['sequence'] += 2;
  }

  // Return highest scoring type
  return Object.entries(scores).reduce((a, b) =>
    a[1] > b[1] ? a : b
  )[0] as DiagramType;
}
```

### 5.3 Safe Model Parameters Algorithm

```typescript
function getSafeModelParams(config: AzureOpenAIConfig): { maxTokens: number; temperature: number } {
  const family = config.modelFamily || detectModelFamily(config.deploymentName);
  const limits = MODEL_LIMITS[family];

  return {
    maxTokens: Math.min(config.maxTokens || limits.defaultTokens, limits.maxTokens),
    temperature: Math.min(config.temperature || 0.7, limits.maxTemperature),
  };
}
```

### 5.4 Typewriter Effect Algorithm

```typescript
const typewriterEffect = useCallback((fieldName: string, text: string, speed = 15) => {
  setTypingField(fieldName);
  let index = 0;
  setFormData(prev => ({ ...prev, [fieldName]: '' }));

  const typeInterval = setInterval(() => {
    if (index < text.length) {
      setFormData(prev => ({
        ...prev,
        [fieldName]: text.slice(0, index + 1),
      }));
      index++;
    } else {
      clearInterval(typeInterval);
      setTypingField(null);
    }
  }, speed);

  return () => clearInterval(typeInterval);
}, []);
```

### 5.5 Component Extraction Algorithm

```typescript
function extractComponents(archText: string): string[] {
  const components: string[] = [];
  const lines = archText.split('\n');

  for (const line of lines) {
    // Look for bold items like **Component Name**
    const boldMatches = line.match(/\*\*([^*]+)\*\*/g);
    if (boldMatches) {
      boldMatches.forEach(m => {
        const cleaned = m.replace(/\*\*/g, '').trim();
        if (cleaned.length > 2 && cleaned.length < 40) {
          components.push(cleaned);
        }
      });
    }

    // Look for list items
    const listMatch = line.match(/^[-•*]\s*(.+?)(?:\s*[-:]|$)/);
    if (listMatch && listMatch[1].length > 2 && listMatch[1].length < 40) {
      components.push(listMatch[1].trim());
    }
  }

  return [...new Set(components)].slice(0, 8);
}
```

---

## 6. INTEGRATION POINTS

### 6.1 OpenAI API (Direct)

**Endpoint:**
```
POST https://api.openai.com/v1/chat/completions
```

**Headers:**
```
Content-Type: application/json
Authorization: Bearer sk-...
OpenAI-Organization: org-...  (optional)
```

**Request Body:**
```json
{
  "model": "gpt-4o",
  "messages": [
    { "role": "system", "content": "..." },
    { "role": "user", "content": "..." }
  ],
  "max_tokens": 4096,
  "temperature": 0.7
}
```

**Available Models:**
- `gpt-4o` (Recommended)
- `gpt-4o-mini` (Fast & Cheap)
- `gpt-4-turbo`
- `gpt-4`
- `gpt-3.5-turbo` (Budget)
- `o1-preview` (Reasoning)
- `o1-mini` (Fast Reasoning)

**Response:**
```json
{
  "choices": [
    {
      "message": {
        "content": "AI response here"
      }
    }
  ]
}
```

### 6.2 Azure OpenAI API

**Endpoint Format:**
```
{endpoint}/openai/deployments/{deployment}/chat/completions?api-version={version}
```

**Headers:**
```
Content-Type: application/json
api-key: {apiKey}
```

**Request Body (GPT-4):**
```json
{
  "messages": [
    { "role": "system", "content": "..." },
    { "role": "user", "content": "..." }
  ],
  "max_tokens": 4096,
  "temperature": 0.7
}
```

**Request Body (GPT-5/o1):**
```json
{
  "messages": [
    { "role": "system", "content": "..." },
    { "role": "user", "content": "..." }
  ],
  "max_completion_tokens": 4096,
  "temperature": 0.7
}
```

**Response:**
```json
{
  "choices": [
    {
      "message": {
        "content": "AI response here"
      }
    }
  ]
}
```

### 6.3 GitLab API v4

**Base URL:**
- Development: `/gitlab-api` (proxied)
- Production: `{baseUrl}/api/v4`

**Authentication:**
```
PRIVATE-TOKEN: {accessToken}
```

**Endpoints Used:**

| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | `/groups/{id}/subgroups` | List child groups (pods) |
| GET | `/groups/{id}/projects` | List projects in group |
| GET | `/projects/{id}` | Get project details |
| GET | `/projects/{id}/repository/files/{path}?ref={branch}` | Check if file exists / get content |
| POST | `/projects/{id}/repository/files/{path}` | Create new file |
| PUT | `/projects/{id}/repository/files/{path}` | Update existing file |
| GET | `/projects/{id}/repository/tree?path={path}&ref={branch}` | List files/folders in repository |
| GET | `/projects/{id}/repository/branches` | List all branches |
| POST | `/projects/{id}/repository/commits` | Create branch + commit atomically |
| POST | `/projects/{id}/merge_requests` | Create merge request |

**File Create/Update Body:**
```json
{
  "branch": "main",
  "content": "file content here",
  "commit_message": "Add epic: Project Name",
  "encoding": "text"
}
```

**Commits API Body (for atomic branch + commit):**
```json
{
  "branch": "epic/feature-name-1234567890",
  "commit_message": "Add epic: Project Name",
  "start_branch": "main",
  "actions": [
    {
      "action": "create",
      "file_path": "docs/epics/project-name-epic.md",
      "content": "# Epic content here..."
    }
  ]
}
```

**Merge Request Body:**
```json
{
  "source_branch": "epic/feature-name-1234567890",
  "target_branch": "main",
  "title": "Epic: Project Name",
  "description": "This MR adds the epic documentation..."
}
```

### 6.4 Mermaid.js

**Initialization:**
```typescript
mermaid.initialize({
  startOnLoad: false,
  theme: 'default',
  securityLevel: 'loose',
  fontFamily: 'system-ui, -apple-system, sans-serif',
  flowchart: {
    useMaxWidth: true,
    htmlLabels: true,
    curve: 'basis',
  },
});
```

**Rendering:**
```typescript
const { svg } = await mermaid.render(uniqueId, mermaidCode);
// svg contains the rendered SVG string
```

**Supported Diagram Types:**
- `flowchart LR` / `flowchart TB` - Flow diagrams
- `sequenceDiagram` - Sequence diagrams
- `graph TD` / `graph LR` - Basic graphs

---

## 7. USER INTERFACE DETAILS

### 7.1 Color Palette

| Element | Color | Hex Code |
|---------|-------|----------|
| Primary Blue | Gradient | `#3b82f6 → #2563eb` |
| Secondary Purple | Gradient | `#8b5cf6 → #7c3aed` |
| Success Green | Gradient | `#10b981 → #059669` |
| GitLab Orange | Gradient | `#fc6d26 → #e24329` |
| Error Red | Solid | `#ef4444` |
| Warning Yellow | Solid | `#f59e0b` |
| Text Primary | Dark | `#1a1a2e` |
| Text Secondary | Gray | `#6b7280` |
| Background | Light gradient | `#f8fafc → #f1f5f9 → #e2e8f0` |

### 7.2 Glass Morphism Effect

```css
.card {
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  border: 1px solid rgba(255, 255, 255, 0.3);
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.08);
  border-radius: 12px;
}
```

### 7.3 Interactive States

| State | Effect |
|-------|--------|
| Button hover | `filter: brightness(0.98)` |
| Card hover | `transform: translateY(-2px)` |
| Focus visible | `outline: 2px solid #3b82f6; outline-offset: 2px` |
| Loading | Shimmer animation + disabled cursor |
| Active tab | White background + shadow |

### 7.4 Responsive Considerations

- Max container width: `1400px`
- Split screen layout: `1fr 1fr` grid
- Minimum height: `600px` for editor views
- Chat panel: Fixed `340px` width when open

---

## 8. ERROR HANDLING

### 8.1 Azure OpenAI Errors

| Error Type | Detection | User Feedback |
|------------|-----------|---------------|
| Token limit | Message contains "max_tokens" | "Try reducing Max Tokens in Settings" |
| Temperature | Message contains "temperature" | "GPT-5/o1 models require temperature <= 1.0" |
| Auth failure | Response not OK | Display error message |
| Network | Catch block | "Connection failed" |

### 8.2 GitLab Errors

| Error Type | Detection | User Feedback |
|------------|-----------|---------------|
| Auth failure | Response 401/403 | "Failed to connect: {status}" |
| Not found | Response 404 | Handle as "file doesn't exist" |
| Network | Catch block | "Connection failed" |

### 8.3 Mermaid Errors

| Error Type | Detection | Recovery |
|------------|-----------|----------|
| Syntax error | Render throws | Attempt AI fix via `fixMermaidDiagram()` |
| AI fix fails | Fix throws | Show error + manual edit option |
| Invalid start | No valid diagram type | Fall back to C4 container diagram |

### 8.4 Error Display Patterns

```typescript
// Toast notification
showToast('error', 'Title', 'Detailed message');

// Inline status
setPublishStatus({ type: 'error', message: 'Error details' });

// Test result
setGitlabTestStatus({ testing: false, result: 'Error: message' });
```

---

## 9. STORAGE

### 9.1 localStorage Schema

**Key:** `epic-generator-config`

**Value Structure:**
```typescript
{
  aiProvider: 'none' | 'openai' | 'azure',   // Which AI provider to use
  openAI: {
    enabled: boolean,
    apiKey: string,
    model: string,
    organizationId?: string,
    maxTokens: number,
    temperature: number,
    baseUrl?: string
  },
  azureOpenAI: {
    enabled: boolean,
    endpoint: string,
    deploymentName: string,
    apiKey: string,
    apiVersion: string,
    maxTokens: number,
    temperature: number,
    modelFamily?: string
  },
  gitlab: {
    enabled: boolean,
    baseUrl: string,
    projectId: string,
    accessToken: string,
    branch: string,
    epicFilePath: string,
    rootGroupId: string,
    selectedPodId: string,
    selectedEpicId: string
  }
}
```

### 9.2 Storage Operations

```typescript
// Load with defaults merge + migration from old format
function loadConfig(): AppConfig {
  const stored = localStorage.getItem('epic-generator-config');
  if (stored) {
    const parsed = JSON.parse(stored);

    // Determine AI provider (migration from old config)
    let aiProvider = parsed.aiProvider || 'none';
    if (!parsed.aiProvider) {
      if (parsed.openAI?.enabled) aiProvider = 'openai';
      else if (parsed.azureOpenAI?.enabled) aiProvider = 'azure';
    }

    return {
      aiProvider,
      openAI: { ...DEFAULT_CONFIG.openAI, ...parsed.openAI },
      azureOpenAI: { ...DEFAULT_CONFIG.azureOpenAI, ...parsed.azureOpenAI },
      gitlab: { ...DEFAULT_CONFIG.gitlab, ...parsed.gitlab },
    };
  }
  return DEFAULT_CONFIG;
}

// Save
function saveConfig(config: AppConfig): void {
  localStorage.setItem('epic-generator-config', JSON.stringify(config));
}
```

### 9.3 Data Persistence Behavior

| Data Type | Persistence | Location |
|-----------|-------------|----------|
| Configuration | Survives refresh | localStorage |
| Epic content | Session only | React state |
| Blueprint code | Session only | React state |
| Chat history | Session only | React state |
| Form inputs | Session only | React state |

---

## 10. SECURITY CONSIDERATIONS

### 10.1 Credential Storage

| Credential | Storage | Risk Level |
|------------|---------|------------|
| OpenAI API Key | localStorage | Medium - Client-side only |
| Azure API Key | localStorage | Medium - Client-side only |
| GitLab Token | localStorage | Medium - Client-side only |

**Mitigation:** All credentials stay in user's browser. No server-side storage.

### 10.2 API Security

| Aspect | Implementation |
|--------|----------------|
| OpenAI Auth | `Authorization: Bearer` header |
| Azure Auth | `api-key` header |
| GitLab Auth | `PRIVATE-TOKEN` header |
| HTTPS | Required for production |
| CORS | Vite proxy in development only |

### 10.3 Content Security

| Concern | Handling |
|---------|----------|
| XSS in Markdown | react-markdown sanitizes by default |
| Mermaid injection | `securityLevel: 'loose'` for features |
| User input | No server storage, client-only processing |

### 10.4 Token Scope Requirements

**GitLab Personal Access Token:**
- Required scope: `api`
- Allows: Read/write repository files
- Does not require: Admin, sudo

### 10.5 Best Practices

1. Never commit `.env` files with credentials
2. Use separate tokens for development/production
3. Rotate tokens periodically
4. Monitor GitLab audit logs for unusual activity

---

## 11. MOCK GITLAB SYSTEM

### 11.1 Purpose

The Mock GitLab system allows end-to-end testing of GitLab functionality without requiring an actual GitLab connection. This is useful for:
- Local development without VPN/network access
- Demo environments
- Testing UI flows before connecting to production GitLab

### 11.2 Configuration

**File:** `src/mockGitLabData.ts`

```typescript
// Toggle mock mode (set to true for local testing)
export const MOCK_GITLAB_ENABLED = true;

// Check function used throughout the app
export function shouldUseMockGitLab(): boolean {
  return MOCK_GITLAB_ENABLED;
}
```

### 11.3 Mock Data Included

| Data Type | Count | Description |
|-----------|-------|-------------|
| Mock Epics | 6 | Full epics with titles, descriptions, labels |
| Mock Labels | 14 | crew::, pod::, priority::, and other labels |
| Mock Children | 4 | Child epics and issues for hierarchy testing |

### 11.4 Mock API Functions

| Function | Purpose |
|----------|---------|
| `mockFetchGroupEpics()` | Returns filtered/paginated mock epics |
| `mockFetchEpicDetails()` | Returns single epic by IID |
| `mockFetchEpicChildren()` | Returns child epics/issues |
| `mockCreateGitLabEpic()` | Simulates epic creation |
| `mockUpdateGitLabEpic()` | Simulates epic update |
| `mockFetchGroupLabels()` | Returns available labels |

### 11.5 Visual Indicator

When mock mode is enabled, a yellow "MOCK MODE" badge appears in the Epic Editor header.

### 11.6 Default Landing Page

When mock mode is enabled, the application defaults to the **Epic Editor** tab instead of the Wizard tab, allowing immediate testing of GitLab-related features.

---

## 12. TESTING

### 12.1 Test Framework

- **Framework**: Vitest 4.0.17
- **DOM**: jsdom 27.4.0
- **React Testing**: @testing-library/react

### 12.2 Test Files

| File | Tests | Description |
|------|-------|-------------|
| `gitlabApi.test.ts` | 21 | GitLab API integration tests |
| `epicEditor.test.tsx` | 11 | Epic Editor tab visibility and empty state |
| `saveEpic.test.tsx` | 16 | Save Epic workflow (level selection, labels) |
| `loadEpic.test.tsx` | 15 | Load Epic modal and search functionality |
| **Total** | **63** | |

### 12.3 Test Commands

```bash
npm test           # Run tests in watch mode
npm run test:run   # Run tests once
npm run test:ui    # Open Vitest UI
```

### 12.4 Test Configuration

**File:** `vitest.config.ts`

```typescript
import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  test: {
    environment: 'jsdom',
    setupFiles: ['./src/test/setup.ts'],
    globals: true,
  },
});
```

### 12.5 Test Utilities

**File:** `src/test/testUtils.ts`

Contains mock data factories:
- `mockCrewEpic` - Sample crew-level epic
- `mockPodEpic` - Sample pod-level epic
- `mockClosedEpic` - Sample closed epic
- `mockEpics` - Array of all mock epics
- `mockLabels` - Array of mock labels

---

## APPENDIX A: QUICK REFERENCE

### File Locations for Common Tasks

| Task | File | Function/Location |
|------|------|-------------------|
| Add new wizard stage | `types.ts` | Add to `STAGES` array |
| Add new epic section | `types.ts` | Add to `EPIC_SECTIONS` array |
| Modify AI prompts | `skills.ts` | `getSystemPromptForField()` |
| Change diagram logic | `skills.ts` | `generateIntelligentBlueprint()` |
| Update UI styling | `App.tsx` | `styles` object |
| Add animation | `styles.css` | Add `@keyframes` |
| Modify API calls | `config.ts` | Respective API functions |
| Add GitLab API endpoint | `config.ts` | Add new function with fetch |
| Modify file browser | `App.tsx` | `handleBrowseFiles()`, `handleLoadFile()` |
| Change publish behavior | `App.tsx` | `handlePublishToGitLab()` |
| Add new publish mode | `config.ts` | `publishWithMergeRequest()` or similar |

### State Update Patterns

```typescript
// Update nested config
updateConfig({
  ...config,
  azureOpenAI: { ...config.azureOpenAI, enabled: true }
});

// Update single field in form
setFormData(prev => ({ ...prev, [fieldName]: value }));

// Update refined data
setState(prev => ({
  ...prev,
  data: {
    ...prev.data,
    [fieldName]: { original, refined, diagramNode }
  }
}));
```

### Common Debugging Points

1. **AI not responding:** Check `config.azureOpenAI.enabled` and credentials
2. **GitLab push fails:** Verify token scope and project ID
3. **Diagram not rendering:** Check Mermaid syntax in browser console
4. **Toast not showing:** Verify `showToast` is being called
5. **404 on GitLab API:** Check if ID is project vs group (groups return 404 on `/projects/{id}`)
6. **File browser empty:** Ensure projectId is set (not groupId), check console for proxy logs
7. **MR creation fails:** Check branch name format, verify permissions on target repo
8. **Proxy not working:** Check Vite server terminal for `[Proxy Request]` and `[Proxy Response]` logs

---

## APPENDIX B: DEVELOPMENT COMMANDS

```bash
# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview

# Type checking (via Vite)
npm run build  # Will fail on type errors
```

---

## APPENDIX C: FUTURE ENHANCEMENT AREAS

1. **Backend Storage**: Add server-side epic storage
2. **Collaboration**: Real-time multi-user editing
3. **Templates**: Pre-built epic templates by project type
4. **Version History**: Track epic revisions
5. **Export Formats**: PDF, Confluence, Jira integration
6. **Custom Sections**: User-defined epic sections
7. **Approval Workflow**: Built-in approval tracking

---

## APPENDIX D: RECENT UPDATES (2026-01-15)

### Mock GitLab System & Testing (2026-01-15)

**New Features Added:**

1. **Mock GitLab Data System**
   - New file: `src/mockGitLabData.ts` (685 lines)
   - Toggle: `MOCK_GITLAB_ENABLED = true` for local testing
   - 6 realistic mock epics with full markdown descriptions
   - 14 mock labels (crew::, pod::, priority::, etc.)
   - Mock API functions mirroring real GitLab API

2. **Default Landing Page Change**
   - Epic Editor is now the default tab (was Wizard)
   - Allows immediate access to GitLab features in mock mode

3. **Visual Mock Mode Indicator**
   - Yellow "MOCK MODE" badge in Epic Editor header
   - Buttons show "(Mock)" suffix when in mock mode

4. **Test Suite**
   - Framework: Vitest with jsdom
   - 63 tests across 4 test files
   - Test utilities with mock data factories

**New Files:**
- `src/mockGitLabData.ts` - Mock GitLab data and functions
- `vitest.config.ts` - Test configuration
- `src/test/setup.ts` - Test setup
- `src/test/testUtils.ts` - Test utilities
- `src/test/gitlabApi.test.ts` - API tests
- `src/test/epicEditor.test.tsx` - Editor tests
- `src/test/saveEpic.test.tsx` - Save workflow tests
- `src/test/loadEpic.test.tsx` - Load workflow tests

---

### GitLab Integration Enhancements (2026-01-10)

### GitLab Integration Enhancements

**New Features Added:**

1. **Subgroup vs Project Detection**
   - `handleEpicSelect()` now distinguishes between subgroups and projects using `web_url`
   - Subgroups (containing `/groups/` in URL) allow drill-down navigation
   - Projects set the `projectId` for API operations

2. **Navigation Stack & Breadcrumbs**
   - Added navigation history for browsing through subgroup hierarchy
   - Back button to navigate up the tree
   - Visual breadcrumb showing current location

3. **Branch Selector**
   - Fetches available branches from GitLab API
   - Dropdown to select target branch for commits
   - Identifies and highlights default branch

4. **Repository File Browser**
   - Browse files and folders in the selected project
   - Click folders to navigate deeper
   - Click files to load content into the Epic Editor
   - Back button to navigate to parent folder

5. **Publish Mode Toggle**
   - **Direct Commit**: Push directly to selected branch
   - **Merge Request**: Create new branch + commit + MR for code review
   - Visual toggle in Settings panel
   - Dynamic button text reflects selected mode

6. **Vite Proxy Improvements**
   - Changed to HTTPS for secure connections
   - Added request/response logging for debugging
   - Console shows `[Proxy Request]`, `[Proxy Response]`, and `[Proxy Error]`

**New Functions in config.ts:**
- `fetchGitLabRepositoryTree()` - Lists files/folders
- `fetchGitLabFileContent()` - Gets file content (base64 decoded)
- `fetchGitLabBranches()` - Lists branches
- `commitToGitLabBranch()` - Atomic branch + commit via Commits API
- `createGitLabMergeRequest()` - Creates MR
- `publishWithMergeRequest()` - Complete MR workflow

**New Types:**
- `GitLabFile`, `GitLabTreeResult`, `GitLabFileResult`
- `GitLabBranch`, `GitLabBranchResult`, `GitLabMRResult`

---

## APPENDIX E: KNOWN ISSUES & FIXES

### E.1 Blueprint Not Rendering - Code Restoration (FIXED 2026-01-10)

**Problem:** Epic Blueprint stopped rendering after multiple attempted "fixes" to handle AI-generated Mermaid syntax errors.

**Symptom:** Blueprint shows blank or error state. Console shows various parse errors.

**Root Cause:** Over-engineering. Multiple regex "fixes" in `validateMermaidDiagram()` and changes to `MermaidBlueprint` component broke the working code.

**What Went Wrong:**
1. Added complex regex patterns to "fix" AI-generated Mermaid that actually corrupted valid diagrams
2. Added SVG error content detection that threw errors on valid diagrams
3. Changed state management from `useState` to `useRef` unnecessarily
4. Added `onSvgReady` prop that wasn't in the original

**Fix Applied - RESTORED TO WORKING VERSION:**

**1. Restored `MermaidBlueprint` component (src/App.tsx:1129-1200):**
```typescript
// Simple, working version - no over-engineering
const MermaidBlueprint = ({
  code,
  zoom = 100,
  onRequestFix
}: {
  code: string;
  zoom?: number;
  onRequestFix?: (failedCode: string, errorMessage: string) => Promise<string | null>;
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [svg, setSvg] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [isFixing, setIsFixing] = useState(false);
  const [hasAttemptedFix, setHasAttemptedFix] = useState(false);

  useEffect(() => {
    setHasAttemptedFix(false);
  }, [code]);

  useEffect(() => {
    if (!code || !containerRef.current) return;

    const renderDiagram = async () => {
      try {
        setError(null);
        setIsFixing(false);
        const id = `mermaid-blueprint-${Date.now()}`;
        const { svg: renderedSvg } = await mermaid.render(id, code);
        setSvg(renderedSvg);  // No SVG error checking - trust Mermaid
      } catch (err) {
        // ... error handling with AI fix attempt
      }
    };

    renderDiagram();
  }, [code, onRequestFix, hasAttemptedFix]);  // State in deps is OK here
  // ...
};
```

**2. Restored `validateMermaidDiagram` (src/skills.ts:1015-1029):**
```typescript
// Simple validation - just clean up and check start
function validateMermaidDiagram(mermaid: string, data: RefinedData, projectName: string): string {
  mermaid = mermaid.replace(/```mermaid\s*/gi, '').replace(/```\s*/g, '').trim();

  const validStarts = ['flowchart', 'sequenceDiagram', 'graph', 'stateDiagram', 'classDiagram'];
  const hasValidStart = validStarts.some(start => mermaid.toLowerCase().startsWith(start.toLowerCase()));

  if (!hasValidStart) {
    console.warn('AI generated invalid Mermaid syntax. Falling back to rule-based diagram.');
    return generateC4ContainerDiagram(data, projectName);
  }

  return mermaid;
}
```

**3. Re-enabled AI diagram generation (src/skills.ts:872-880):**
```typescript
// Use AI to generate the diagram (Azure OpenAI is always enabled)
if (currentConfig) {
  try {
    const result = await generateAIPoweredBlueprint(data, projectName);
    return result;
  } catch (error) {
    console.error('AI blueprint generation failed, falling back to rule-based:', error);
  }
}
```

**Lesson Learned:**
- The original code was WORKING
- Adding "fixes" for edge cases broke the main functionality
- Keep it simple - complex regex patterns to "fix" AI output often cause more problems
- If AI generates bad Mermaid, the fallback to rule-based generation handles it
- Don't add SVG content inspection - trust Mermaid's render result

**Prevention Checklist:**
- [ ] Before "fixing" code, verify the fix doesn't break working functionality
- [ ] Test with actual usage after every change
- [ ] Keep a backup of working code (epic-generator_OLD was the reference)
- [ ] Prefer simple fallbacks over complex correction logic

**Related Files:**
- `src/skills.ts:1015-1029` - Simple validateMermaidDiagram
- `src/skills.ts:867-880` - AI generation enabled
- `src/App.tsx:1129-1200` - MermaidBlueprint component

---

*This document should be updated whenever significant changes are made to the codebase.*
