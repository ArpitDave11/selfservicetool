# Claude Code Context

## Project Overview

**Epic Generator v4** (FRAME - Feature Requirements & Architecture Management Engine) is an AI-powered technical documentation web application that generates comprehensive 17-section technical design documents through a guided 6-stage wizard interface.

## Tech Stack

- **Framework**: React 19.0.0 with TypeScript 5.6.0
- **Build Tool**: Vite 6.0.0
- **Markdown**: react-markdown + remark-gfm
- **Diagrams**: Mermaid.js 11.4.0, PlantUML encoder
- **AI Integration**: OpenAI / Azure OpenAI APIs
- **Version Control**: GitLab API v4

## Key Files

| File | Purpose |
|------|---------|
| `src/App.tsx` | Main component with all UI and business logic (4,169 lines) |
| `src/types.ts` | TypeScript interfaces, Stage/Section constants |
| `src/config.ts` | API configuration, GitLab integration, localStorage persistence (1,668 lines) |
| `src/skills.ts` | AI prompts, diagram generation, suggestion/refinement logic (1,309 lines) |
| `src/MarkdownPreview.tsx` | Markdown renderer with Mermaid diagram support |
| `src/mockGitLabData.ts` | Mock GitLab data for local testing without API (685 lines) |
| `src/styles.css` | Animations, toast notifications, glass morphism styles |
| `vite.config.js` | Dev server (port 3002), GitLab API proxy configuration |
| `vitest.config.ts` | Test configuration for Vitest |
| `src/test/*` | Test files (63 tests across 4 files) |

## Development Commands

```bash
npm install          # Install dependencies
npm run dev          # Start dev server on port 3002
npm run build        # Production build to dist/
npm run preview      # Preview production build
npm test             # Run tests in watch mode
npm run test:run     # Run tests once
npm run test:ui      # Open Vitest UI
```

## Architecture Notes

### Application Flow
```
Wizard (6 stages) → AI Suggestions → Epic Generation (17 sections) → Export/GitLab
```

### State Management
- Uses React useState hooks (no external state library)
- Settings persisted to localStorage
- Draft data maintained in component state

### AI Integration Modes
1. **Mock** - No API calls, demo data (default)
2. **Azure OpenAI** - Enterprise Azure-hosted models
3. **OpenAI** - Direct API with sk-... keys

### Main UI Tabs
- **Wizard** - 6-stage guided input form
- **Epic Editor** - Markdown editor with live preview
- **Blueprint** - Architecture diagram generation
- **Settings** - API and GitLab configuration

## Code Conventions

- TypeScript strict mode enabled
- All interfaces defined in `types.ts`
- AI prompts centralized in `skills.ts`
- Configuration logic isolated in `config.ts`
- CSS uses BEM-like naming with animations in `styles.css`

## Important Patterns

### Adding New Wizard Fields
1. Update `STAGES` array in `types.ts`
2. Add field rendering in `renderWizard()` in `App.tsx`
3. Add AI prompt in `skills.ts` if suggestion support needed

### Adding New Epic Sections
1. Update `EPIC_SECTIONS` array in `types.ts`
2. Modify epic generation logic in `App.tsx`
3. Update AI prompts in `skills.ts`

### GitLab Integration
- Proxy configured in `vite.config.js` for `/gitlab-api/*` routes
- Connection testing via `config.ts` functions
- Supports branches, merge requests, hierarchical project selection

## Testing Locally

1. Run `npm run dev`
2. Open `http://localhost:3002`
3. Configure AI provider in Settings tab (optional)
4. Use Mock mode for development without API keys

## Common Tasks

### Modify AI Behavior
Edit prompts in `src/skills.ts` - each field has specific system prompts for professional content generation.

### Update Styling
Main styles in `src/styles.css`. Component uses inline styles with CSS variables for theming.

### Add New Export Format
Modify export handlers in `App.tsx` near the download/copy functionality.

## Mock GitLab Mode

For development without GitLab connectivity:

1. **Enable Mock Mode**: Set `MOCK_GITLAB_ENABLED = true` in `src/mockGitLabData.ts`
2. **Default Tab**: Epic Editor (not Wizard) when mock mode is on
3. **Visual Indicator**: Yellow "MOCK MODE" badge appears in header
4. **Mock Data**: 6 realistic epics, 14 labels, child epic/issue hierarchy

Mock functions mirror real GitLab API:
- `mockFetchGroupEpics()` - Search/filter epics
- `mockFetchEpicDetails()` - Get single epic
- `mockCreateGitLabEpic()` - Simulate creation
- `mockUpdateGitLabEpic()` - Simulate updates

## AI Features (Epic Editor)

### AI Critique Button (Orange ★)
Analyzes epic quality and provides honest feedback:
- **Score**: 0-10 with color coding (green/yellow/red)
- **Section Breakdown**: Per-section scores and status
- **Critical Issues**: Must-fix problems highlighted
- **Suggestions**: Specific improvements for weak sections
- **Apply Suggestions**: One-click to improve weak sections

**Implementation**:
- `analyzeAndRefineEpic()` in `skills.ts` - AI analysis function
- `EpicQualityReport` type in `types.ts` - Report structure
- Report modal in `App.tsx` - UI display

### Refine Button (Purple ⊕) - PLANNED
Intelligent refinement using wizard skills:
1. **Parses** loaded epic → extracts into 6 wizard stage fields
2. **Refines** each field using `runSkill('refine', ...)`
3. **Regenerates** improved epic from refined data
4. **Flags** missing sections that need more content

**Data Flow**:
```
Epic Markdown → parseEpicToStageData() → RefinedData
→ refineInput() per field → generateEpic() → Improved Epic
```

---

## Testing

**Framework**: Vitest 4.0.17 with jsdom

**Test Files** (63 tests total):
- `gitlabApi.test.ts` - GitLab API integration
- `epicEditor.test.tsx` - Epic Editor component
- `saveEpic.test.tsx` - Save Epic workflow
- `loadEpic.test.tsx` - Load Epic modal

**Run Tests**:
```bash
npm test           # Watch mode
npm run test:run   # Single run
npm run test:ui    # Visual UI
```
