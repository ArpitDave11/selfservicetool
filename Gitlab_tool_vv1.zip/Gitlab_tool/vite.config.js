// import { createRequire } from "node:module";
import { resolve } from "node:path";
import tailwindcss from "@tailwindcss/vite";
import { TanStackRouterVite } from "@tanstack/router-plugin/vite";
import viteReact from "@vitejs/plugin-react";
import { defineConfig } from "vite";
import svgr from "vite-plugin-svgr";
import { creaoPlugins } from "./config/vite/creao-plugin.mjs";

function azureProxyPlugin() {
	return {
		name: "azure-openai-proxy",
		configureServer(server) {
			server.middlewares.use("/api/azure/chat", async (req, res) => {
				if (req.method !== "POST") {
					res.statusCode = 405;
					res.end("Method Not Allowed");
					return;
				}

				const endpoint = process.env.AZURE_OPENAI_ENDPOINT;
				const deployment = process.env.AZURE_OPENAI_DEPLOYMENT;
				const apiKey = process.env.AZURE_OPENAI_API_KEY;
				const apiVersion =
					process.env.AZURE_OPENAI_API_VERSION || "2024-08-01-preview";

				if (!endpoint || !deployment || !apiKey) {
					res.statusCode = 500;
					res.setHeader("Content-Type", "application/json");
					res.end(
						JSON.stringify({
							error:
								"Missing Azure OpenAI configuration (AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_DEPLOYMENT, AZURE_OPENAI_API_KEY)",
						}),
					);
					return;
				}

				const body = await new Promise((resolve) => {
					let data = "";
					req.on("data", (chunk) => {
						data += chunk;
					});
					req.on("end", () => resolve(data));
				});

				let payload;
				try {
					payload = body ? JSON.parse(body) : {};
				} catch (error) {
					res.statusCode = 400;
					res.setHeader("Content-Type", "application/json");
					res.end(JSON.stringify({ error: "Invalid JSON payload" }));
					return;
				}

				const messages = Array.isArray(payload?.messages) ? payload.messages : [];
				if (messages.length === 0) {
					res.statusCode = 400;
					res.setHeader("Content-Type", "application/json");
					res.end(JSON.stringify({ error: "messages array is required" }));
					return;
				}

				const targetUrl = `${endpoint.replace(/\/+$/, "")}/openai/deployments/${deployment}/chat/completions?api-version=${apiVersion}`;

				try {
					const azureResponse = await fetch(targetUrl, {
						method: "POST",
						headers: {
							"Content-Type": "application/json",
							"api-key": apiKey,
						},
						body: JSON.stringify({
							messages,
							temperature: payload.temperature ?? 0.4,
							max_tokens: payload.max_tokens ?? 800,
							stream: false,
						}),
					});

					const data = await azureResponse.json();

					if (!azureResponse.ok) {
						res.statusCode = azureResponse.status;
						res.setHeader("Content-Type", "application/json");
						res.end(
							JSON.stringify({
								error: data?.error || "Azure OpenAI request failed",
							}),
						);
						return;
					}

					const message =
						data?.choices?.[0]?.message?.content ||
						data?.choices?.[0]?.message ||
						"";

					res.statusCode = 200;
					res.setHeader("Content-Type", "application/json");
					res.end(
						JSON.stringify({
							message,
							raw: data,
						}),
					);
				} catch (error) {
					console.error("[azure-openai-proxy] error", error);
					res.statusCode = 500;
					res.setHeader("Content-Type", "application/json");
					res.end(JSON.stringify({ error: "Failed to call Azure OpenAI" }));
				}
			});
		},
	};
}

// https://vitejs.dev/config/
export default defineConfig({
	base: process.env.TENANT_ID ? `/${process.env.TENANT_ID}/` : "/",
	define: {
		"import.meta.env.TENANT_ID": JSON.stringify(process.env.TENANT_ID || ""),
	},
	plugins: [
		...creaoPlugins(),
		azureProxyPlugin(),
		TanStackRouterVite({
			autoCodeSplitting: false, // affects pick-n-edit feature. disabled for now.
		}),
		viteReact({
			jsxRuntime: "automatic",
		}),
		svgr(),
		tailwindcss(),
	],
	test: {
		globals: true,
		environment: "jsdom",
	},
	resolve: {
		alias: {
			"@": resolve(__dirname, "./src"),
		},
	},
	server: {
		host: "0.0.0.0",
		port: 3000,
		allowedHosts: true, // respond to *any* Host header
		watch: {
			usePolling: true,
			interval: 300, // ms; tune if CPU gets high
		},
	},
	build: {
		chunkSizeWarningLimit: 1500,
	},
});
