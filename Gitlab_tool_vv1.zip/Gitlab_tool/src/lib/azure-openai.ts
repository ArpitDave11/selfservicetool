export type AzureChatMessage = {
	role: "system" | "user" | "assistant";
	content: string;
};

export interface AzureChatOptions {
	temperature?: number;
	maxTokens?: number;
}

export interface AzureChatResult<T = unknown> {
	message: string;
	raw: T;
}

const AZURE_PROXY_PATH = import.meta.env.VITE_AZURE_PROXY_PATH || "/api/azure/chat";

export async function runAzureChat<T = unknown>(
	messages: AzureChatMessage[],
	options: AzureChatOptions = {},
): Promise<AzureChatResult<T>> {
	const response = await fetch(AZURE_PROXY_PATH, {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
		},
		body: JSON.stringify({
			messages,
			temperature: options.temperature ?? 0.3,
			max_tokens: options.maxTokens ?? 800,
		}),
	});

	if (!response.ok) {
		const errorText = await response.text();
		throw new Error(
			`Azure proxy request failed (${response.status}): ${errorText}`,
		);
	}

	const data = (await response.json()) as { message?: string } & T;
	const message =
		typeof data?.message === "string"
			? data.message.trim()
			: // @ts-expect-error raw Azure format fallback
				data?.choices?.[0]?.message?.content?.trim?.() || "";

	return {
		message,
		raw: data,
	};
}
