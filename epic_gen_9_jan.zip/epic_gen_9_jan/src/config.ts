// Configuration for Epic Generator
// Azure OpenAI + GitLab Integration

// ===========================================
// AZURE OPENAI CONFIGURATION
// ===========================================

// Model family detection - GPT-5 has different limits than GPT-4
export type ModelFamily = 'gpt-4' | 'gpt-5' | 'unknown';

export interface AzureOpenAIConfig {
  enabled: boolean;
  endpoint: string;        // e.g., "https://your-resource.openai.azure.com"
  deploymentName: string;  // Your deployment name
  apiKey: string;
  apiVersion: string;      // e.g., "2024-02-15-preview"
  maxTokens: number;
  temperature: number;
  modelFamily?: ModelFamily;  // Auto-detected or user-specified
}

export interface GitLabConfig {
  enabled: boolean;
  baseUrl: string;           // e.g., "https://gitlab.com" or self-hosted
  projectId: string;         // Project ID or path (e.g., "group/project")
  accessToken: string;       // Personal Access Token with api scope
  branch: string;            // Target branch for commits
  epicFilePath: string;      // Path where epic.md will be saved
  // Hierarchical selection for enterprise GitLab
  rootGroupId: string;       // Root group ID for fetching pods (e.g., "557797")
  selectedPodId: string;     // Selected pod (subgroup) ID
  selectedEpicId: string;    // Selected epic (project/subgroup) ID
}

export interface AppConfig {
  azureOpenAI: AzureOpenAIConfig;
  gitlab: GitLabConfig;
}

// Default configuration
export const DEFAULT_CONFIG: AppConfig = {
  azureOpenAI: {
    enabled: false,
    endpoint: '',
    deploymentName: '',
    apiKey: '',
    apiVersion: '2024-02-15-preview',
    maxTokens: 4096,
    temperature: 0.7,
  },
  gitlab: {
    enabled: false,
    baseUrl: 'http://devcloud.ubs.net',
    projectId: '',
    accessToken: '',
    branch: 'main',
    epicFilePath: 'docs/epics/',
    rootGroupId: '557797',
    selectedPodId: '',
    selectedEpicId: '',
  },
};

// Available API versions for Azure OpenAI
export const AZURE_API_VERSIONS = [
  '2024-12-01-preview',  // Latest for GPT-5
  '2024-10-01-preview',
  '2024-08-01-preview',
  '2024-06-01',
  '2024-05-01-preview',
  '2024-02-15-preview',
  '2023-12-01-preview',
  '2023-05-15',
];

// Model family limits - GPT-5 has stricter limits
export const MODEL_LIMITS: Record<ModelFamily, { maxTokens: number; maxTemperature: number; defaultTokens: number }> = {
  'gpt-4': {
    maxTokens: 128000,      // GPT-4 Turbo supports up to 128K
    maxTemperature: 2.0,
    defaultTokens: 4096,
  },
  'gpt-5': {
    maxTokens: 16384,       // GPT-5 has lower max_completion_tokens
    maxTemperature: 1.0,    // GPT-5 temperature must be <= 1.0
    defaultTokens: 4096,
  },
  'unknown': {
    maxTokens: 4096,        // Safe default
    maxTemperature: 1.0,    // Safe default
    defaultTokens: 2048,
  },
};

// Detect model family from deployment name
export function detectModelFamily(deploymentName: string): ModelFamily {
  const name = deploymentName.toLowerCase();
  if (name.includes('gpt-5') || name.includes('gpt5') || name.includes('o1') || name.includes('o3')) {
    return 'gpt-5';
  }
  if (name.includes('gpt-4') || name.includes('gpt4') || name.includes('turbo')) {
    return 'gpt-4';
  }
  return 'unknown';
}

// Get safe parameters for the model
export function getSafeModelParams(config: AzureOpenAIConfig): { maxTokens: number; temperature: number } {
  const family = config.modelFamily || detectModelFamily(config.deploymentName);
  const limits = MODEL_LIMITS[family];

  return {
    maxTokens: Math.min(config.maxTokens || limits.defaultTokens, limits.maxTokens),
    temperature: Math.min(config.temperature || 0.7, limits.maxTemperature),
  };
}

// ===========================================
// CONFIG STORAGE (localStorage)
// ===========================================
const CONFIG_STORAGE_KEY = 'epic-generator-config';

export function loadConfig(): AppConfig {
  try {
    const stored = localStorage.getItem(CONFIG_STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      // Merge with defaults to handle new fields
      return {
        azureOpenAI: { ...DEFAULT_CONFIG.azureOpenAI, ...parsed.azureOpenAI },
        gitlab: { ...DEFAULT_CONFIG.gitlab, ...parsed.gitlab },
      };
    }
  } catch (e) {
    console.error('Failed to load config:', e);
  }
  return DEFAULT_CONFIG;
}

export function saveConfig(config: AppConfig): void {
  try {
    localStorage.setItem(CONFIG_STORAGE_KEY, JSON.stringify(config));
  } catch (e) {
    console.error('Failed to save config:', e);
  }
}

// ===========================================
// AZURE OPENAI API CALLS
// ===========================================
export async function callAzureOpenAI(
  config: AzureOpenAIConfig,
  systemPrompt: string,
  userPrompt: string
): Promise<string> {
  if (!config.enabled) {
    // Return mock response when Azure is not configured
    await new Promise(resolve => setTimeout(resolve, 300));
    return userPrompt; // Just return the input as-is in mock mode
  }

  if (!config.endpoint || !config.apiKey || !config.deploymentName) {
    throw new Error('Azure OpenAI is not fully configured. Please check Settings.');
  }

  // Get safe parameters based on model family
  const safeParams = getSafeModelParams(config);
  const modelFamily = config.modelFamily || detectModelFamily(config.deploymentName);

  const url = `${config.endpoint}/openai/deployments/${config.deploymentName}/chat/completions?api-version=${config.apiVersion}`;

  // Build request body - GPT-5/o1 models use different parameter names
  const isGpt5Family = modelFamily === 'gpt-5';

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const requestBody: Record<string, any> = {
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userPrompt },
    ],
  };

  // GPT-5/o1 models use max_completion_tokens instead of max_tokens
  // and have stricter temperature limits
  if (isGpt5Family) {
    requestBody.max_completion_tokens = safeParams.maxTokens;
    // Some o1 models don't support temperature at all, but if they do, it must be <= 1.0
    if (safeParams.temperature <= 1.0) {
      requestBody.temperature = safeParams.temperature;
    }
  } else {
    requestBody.max_tokens = safeParams.maxTokens;
    requestBody.temperature = safeParams.temperature;
  }

  console.log(`[Azure OpenAI] Model family: ${modelFamily}, max_tokens: ${safeParams.maxTokens}, temperature: ${safeParams.temperature}`);

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'api-key': config.apiKey,
    },
    body: JSON.stringify(requestBody),
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: { message: response.statusText } }));
    const errorMessage = error.error?.message || response.statusText;

    // Provide helpful error messages for common issues
    if (errorMessage.includes('max_tokens') || errorMessage.includes('max_completion_tokens')) {
      throw new Error(`Token limit error: ${errorMessage}. Try reducing Max Tokens in Settings or the model may have stricter limits.`);
    }
    if (errorMessage.includes('temperature')) {
      throw new Error(`Temperature error: ${errorMessage}. GPT-5/o1 models require temperature <= 1.0. Adjust in Settings.`);
    }

    throw new Error(`Azure OpenAI error: ${errorMessage}`);
  }

  const data = await response.json();
  return data.choices[0].message.content;
}

// Test Azure OpenAI connection
export async function testAzureOpenAI(config: AzureOpenAIConfig): Promise<{ success: boolean; error?: string }> {
  if (!config.endpoint || !config.apiKey || !config.deploymentName) {
    return { success: false, error: 'Endpoint, API Key, and Deployment Name are required' };
  }

  try {
    const result = await callAzureOpenAI(
      { ...config, enabled: true },
      'You are a helpful assistant.',
      'Say "Connection successful" in exactly those words.'
    );

    if (result.toLowerCase().includes('connection successful')) {
      return { success: true };
    }
    return { success: true }; // Any response means it worked
  } catch (e) {
    return { success: false, error: e instanceof Error ? e.message : 'Connection failed' };
  }
}

// ===========================================
// UNIFIED AI CALL - Uses Azure OpenAI or mock
// ===========================================
export async function callAI(
  config: AppConfig,
  systemPrompt: string,
  userPrompt: string
): Promise<string> {
  if (config.azureOpenAI.enabled) {
    return callAzureOpenAI(config.azureOpenAI, systemPrompt, userPrompt);
  }
  // Mock mode - return input as-is
  await new Promise(resolve => setTimeout(resolve, 300));
  return userPrompt;
}

// ===========================================
// GITLAB API CALLS
// ===========================================

// Build the API base URL - use Vite proxy in dev to bypass CORS
function getGitLabApiUrl(config: GitLabConfig): string {
  // In development, use the Vite proxy
  if (import.meta.env.DEV) {
    return '/gitlab-api';
  }
  // In production, use the configured base URL directly
  return `${config.baseUrl}/api/v4`;
}

export interface GitLabPublishResult {
  success: boolean;
  url?: string;
  error?: string;
}

// Result type for group/subgroup fetching
export interface GitLabGroupResult {
  success: boolean;
  data?: Array<{ id: number; name: string; path: string }>;
  error?: string;
}

// Result type for epics (combined subgroups + projects)
export interface GitLabEpicResult {
  success: boolean;
  data?: Array<{ id: number; name: string; path: string; type: 'subgroup' | 'project' }>;
  error?: string;
}

// Fetch subgroups (Pods) for a given group ID
export async function fetchGitLabSubgroups(
  config: GitLabConfig,
  groupId: string
): Promise<GitLabGroupResult> {
  if (!config.accessToken) {
    return { success: false, error: 'Access token is required' };
  }

  const apiUrl = getGitLabApiUrl(config);
  const url = `${apiUrl}/groups/${groupId}/subgroups?per_page=100&page=1`;

  console.log('[GitLab API] Fetching subgroups from:', url);

  try {
    const response = await fetch(url, {
      headers: {
        'PRIVATE-TOKEN': config.accessToken,
      },
    });

    if (!response.ok) {
      return { success: false, error: `Failed: ${response.status} ${response.statusText}` };
    }

    const data = await response.json();
    return {
      success: true,
      data: data.map((item: { id: number; name: string; full_path: string }) => ({
        id: item.id,
        name: item.name,
        path: item.full_path,
      })),
    };
  } catch (e) {
    console.error('[GitLab API] Error fetching subgroups:', e);
    return { success: false, error: e instanceof Error ? e.message : 'Connection failed' };
  }
}

// Fetch BOTH subgroups AND projects within a group (Epics)
// This combines child groups and projects into a single list
export async function fetchGitLabEpics(
  config: GitLabConfig,
  groupId: string
): Promise<GitLabEpicResult> {
  if (!config.accessToken) {
    return { success: false, error: 'Access token is required' };
  }

  const apiUrl = getGitLabApiUrl(config);

  console.log('[GitLab API] Fetching epics (subgroups + projects) from group:', groupId);

  try {
    // Fetch both subgroups and projects in parallel
    const [subgroupsRes, projectsRes] = await Promise.all([
      fetch(`${apiUrl}/groups/${groupId}/subgroups?per_page=100&page=1`, {
        headers: { 'PRIVATE-TOKEN': config.accessToken },
      }),
      fetch(`${apiUrl}/groups/${groupId}/projects?per_page=100&page=1`, {
        headers: { 'PRIVATE-TOKEN': config.accessToken },
      }),
    ]);

    console.log('[GitLab API] Subgroups response:', subgroupsRes.status);
    console.log('[GitLab API] Projects response:', projectsRes.status);

    const results: Array<{ id: number; name: string; path: string; type: 'subgroup' | 'project' }> = [];

    if (subgroupsRes.ok) {
      const subgroups = await subgroupsRes.json();
      subgroups.forEach((item: { id: number; name: string; full_path: string }) => {
        results.push({
          id: item.id,
          name: `📁 ${item.name}`,  // Folder icon for subgroups
          path: item.full_path,
          type: 'subgroup',
        });
      });
    }

    if (projectsRes.ok) {
      const projects = await projectsRes.json();
      projects.forEach((item: { id: number; name: string; path_with_namespace: string }) => {
        results.push({
          id: item.id,
          name: `📄 ${item.name}`,  // Document icon for projects
          path: item.path_with_namespace,
          type: 'project',
        });
      });
    }

    return { success: true, data: results };
  } catch (e) {
    console.error('[GitLab API] Error fetching epics:', e);
    return { success: false, error: e instanceof Error ? e.message : 'Connection failed' };
  }
}

export async function publishToGitLab(
  config: GitLabConfig,
  fileName: string,
  content: string,
  commitMessage: string
): Promise<GitLabPublishResult> {
  if (!config.enabled) {
    return { success: false, error: 'GitLab integration is not enabled' };
  }

  if (!config.accessToken || !config.projectId) {
    return { success: false, error: 'GitLab access token and project ID are required' };
  }

  const apiUrl = getGitLabApiUrl(config);
  const filePath = `${config.epicFilePath}${fileName}`.replace(/\/+/g, '/');
  const encodedPath = encodeURIComponent(filePath);
  const encodedProjectId = encodeURIComponent(config.projectId);

  console.log('[GitLab API] Publishing to:', `${apiUrl}/projects/${encodedProjectId}/repository/files/${encodedPath}`);

  try {
    // Check if file exists
    const checkResponse = await fetch(
      `${apiUrl}/projects/${encodedProjectId}/repository/files/${encodedPath}?ref=${config.branch}`,
      {
        headers: {
          'PRIVATE-TOKEN': config.accessToken,
        },
      }
    );

    const fileExists = checkResponse.ok;

    // Create or update file
    const method = fileExists ? 'PUT' : 'POST';
    const response = await fetch(
      `${apiUrl}/projects/${encodedProjectId}/repository/files/${encodedPath}`,
      {
        method,
        headers: {
          'Content-Type': 'application/json',
          'PRIVATE-TOKEN': config.accessToken,
        },
        body: JSON.stringify({
          branch: config.branch,
          content: content,
          commit_message: commitMessage,
          encoding: 'text',
        }),
      }
    );

    if (!response.ok) {
      const error = await response.json();
      return { success: false, error: error.message || response.statusText };
    }

    const fileUrl = `${config.baseUrl}/${config.projectId}/-/blob/${config.branch}/${filePath}`;

    return { success: true, url: fileUrl };
  } catch (e) {
    return { success: false, error: e instanceof Error ? e.message : 'Unknown error' };
  }
}

// Test GitLab connection
export async function testGitLabConnection(config: GitLabConfig): Promise<{ success: boolean; error?: string; projectName?: string }> {
  if (!config.accessToken || !config.projectId) {
    return { success: false, error: 'Access token and project ID are required' };
  }

  const apiUrl = getGitLabApiUrl(config);
  const encodedProjectId = encodeURIComponent(config.projectId);
  const url = `${apiUrl}/projects/${encodedProjectId}`;

  console.log('[GitLab API] Testing connection:', url);

  try {
    const response = await fetch(url, {
      headers: {
        'PRIVATE-TOKEN': config.accessToken,
      },
    });

    if (!response.ok) {
      return { success: false, error: `Failed to connect: ${response.status} ${response.statusText}` };
    }

    const data = await response.json();
    return { success: true, projectName: data.name_with_namespace };
  } catch (e) {
    console.error('[GitLab API] Connection test failed:', e);
    return { success: false, error: e instanceof Error ? e.message : 'Connection failed' };
  }
}
