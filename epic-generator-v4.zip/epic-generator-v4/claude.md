# Claude Code Context

## Project Overview

**Epic Generator v4** (FRAME - Feature Requirements & Architecture Management Engine) is an AI-powered technical documentation web application that generates comprehensive 17-section technical design documents through a guided 6-stage wizard interface.

## Tech Stack

- **Framework**: React 19.0.0 with TypeScript 5.6.0
- **Build Tool**: Vite 6.0.0
- **Markdown**: react-markdown + remark-gfm
- **Diagrams**: Mermaid.js 11.4.0, PlantUML encoder
- **AI Integration**: OpenAI / Azure OpenAI APIs
- **Version Control**: GitLab API v4

## Key Files

| File | Purpose |
|------|---------|
| `src/App.tsx` | Main component with all UI and business logic (4,100+ lines) |
| `src/types.ts` | TypeScript interfaces, Stage/Section constants |
| `src/config.ts` | API configuration, GitLab integration, localStorage persistence |
| `src/skills.ts` | AI prompts, diagram generation, suggestion/refinement logic |
| `src/MarkdownPreview.tsx` | Markdown renderer with Mermaid diagram support |
| `src/styles.css` | Animations, toast notifications, glass morphism styles |
| `vite.config.js` | Dev server (port 3002), GitLab API proxy configuration |

## Development Commands

```bash
npm install          # Install dependencies
npm run dev          # Start dev server on port 3002
npm run build        # Production build to dist/
npm run preview      # Preview production build
```

## Architecture Notes

### Application Flow
```
Wizard (6 stages) → AI Suggestions → Epic Generation (17 sections) → Export/GitLab
```

### State Management
- Uses React useState hooks (no external state library)
- Settings persisted to localStorage
- Draft data maintained in component state

### AI Integration Modes
1. **Mock** - No API calls, demo data (default)
2. **Azure OpenAI** - Enterprise Azure-hosted models
3. **OpenAI** - Direct API with sk-... keys

### Main UI Tabs
- **Wizard** - 6-stage guided input form
- **Epic Editor** - Markdown editor with live preview
- **Blueprint** - Architecture diagram generation
- **Settings** - API and GitLab configuration

## Code Conventions

- TypeScript strict mode enabled
- All interfaces defined in `types.ts`
- AI prompts centralized in `skills.ts`
- Configuration logic isolated in `config.ts`
- CSS uses BEM-like naming with animations in `styles.css`

## Important Patterns

### Adding New Wizard Fields
1. Update `STAGES` array in `types.ts`
2. Add field rendering in `renderWizard()` in `App.tsx`
3. Add AI prompt in `skills.ts` if suggestion support needed

### Adding New Epic Sections
1. Update `EPIC_SECTIONS` array in `types.ts`
2. Modify epic generation logic in `App.tsx`
3. Update AI prompts in `skills.ts`

### GitLab Integration
- Proxy configured in `vite.config.js` for `/gitlab-api/*` routes
- Connection testing via `config.ts` functions
- Supports branches, merge requests, hierarchical project selection

## Testing Locally

1. Run `npm run dev`
2. Open `http://localhost:3002`
3. Configure AI provider in Settings tab (optional)
4. Use Mock mode for development without API keys

## Common Tasks

### Modify AI Behavior
Edit prompts in `src/skills.ts` - each field has specific system prompts for professional content generation.

### Update Styling
Main styles in `src/styles.css`. Component uses inline styles with CSS variables for theming.

### Add New Export Format
Modify export handlers in `App.tsx` near the download/copy functionality.
