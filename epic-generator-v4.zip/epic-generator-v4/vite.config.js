import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3002,
    proxy: {
      // Proxy GitLab API requests to bypass CORS
      // All requests to /gitlab-api/* are forwarded to GitLab's /api/v4/*
      '/gitlab-api': {
        target: 'https://devcloud.ubs.net',  // HTTPS for security
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/gitlab-api/, '/api/v4'),
        secure: false,  // Allow self-signed certificates
        // Logging for debugging proxy issues
        configure: (proxy, options) => {
          proxy.on('error', (err, req, res) => {
            console.log('[Proxy Error]', err.message);
          });
          proxy.on('proxyReq', (proxyReq, req, res) => {
            console.log('[Proxy Request]', req.method, req.url, '→', options.target + req.url.replace('/gitlab-api', '/api/v4'));
          });
          proxy.on('proxyRes', (proxyRes, req, res) => {
            console.log('[Proxy Response]', proxyRes.statusCode, req.url);
          });
        }
      }
    }
  }
})
