/**
 * Load Epic Tests
 *
 * Tests for:
 * 1. Load Epic modal functionality
 * 2. Search and filter epics
 * 3. Loading epic into editor
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import React, { useState } from 'react';
import { mockCrewEpic, mockPodEpic, mockClosedEpic, mockEpics } from './testUtils';
import type { GitLabEpic } from '../config';

describe('Load Epic Modal', () => {
  // Component simulating the load epic modal
  const LoadEpicModal = ({
    isOpen,
    onClose,
    onSearch,
    onLoadEpic,
    searchResults,
    isLoading
  }: {
    isOpen: boolean;
    onClose: () => void;
    onSearch: (term: string, state: 'opened' | 'closed' | 'all') => void;
    onLoadEpic: (epicIid: number) => void;
    searchResults: GitLabEpic[];
    isLoading: boolean;
  }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [filterState, setFilterState] = useState<'opened' | 'closed' | 'all'>('opened');

    if (!isOpen) return null;

    return (
      <div data-testid="load-epic-modal">
        <h3>Load Epic from GitLab</h3>

        <div data-testid="search-controls">
          <input
            data-testid="search-input"
            type="text"
            placeholder="Search epics..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && onSearch(searchTerm, filterState)}
          />
          <select
            data-testid="state-filter"
            value={filterState}
            onChange={(e) => setFilterState(e.target.value as 'opened' | 'closed' | 'all')}
          >
            <option value="opened">Open</option>
            <option value="closed">Closed</option>
            <option value="all">All</option>
          </select>
          <button
            data-testid="search-btn"
            onClick={() => onSearch(searchTerm, filterState)}
            disabled={isLoading}
          >
            {isLoading ? 'Searching...' : 'Search'}
          </button>
        </div>

        <div data-testid="epic-list">
          {searchResults.length === 0 ? (
            <div data-testid="empty-results">
              Search for epics to load into the editor
            </div>
          ) : (
            searchResults.map(epic => (
              <div
                key={epic.id}
                data-testid={`epic-item-${epic.iid}`}
                onClick={() => onLoadEpic(epic.iid)}
                style={{ cursor: 'pointer' }}
              >
                <span data-testid={`epic-level-${epic.iid}`}>
                  {epic.epicLevel === 'crew' ? 'CREW' : epic.epicLevel === 'pod' ? 'POD' : 'EPIC'}
                </span>
                <span data-testid={`epic-title-${epic.iid}`}>{epic.title}</span>
                <span data-testid={`epic-state-${epic.iid}`}>{epic.state}</span>
              </div>
            ))
          )}
        </div>

        <button data-testid="cancel-btn" onClick={onClose}>
          Cancel
        </button>
      </div>
    );
  };

  it('should not render when closed', () => {
    render(
      <LoadEpicModal
        isOpen={false}
        onClose={vi.fn()}
        onSearch={vi.fn()}
        onLoadEpic={vi.fn()}
        searchResults={[]}
        isLoading={false}
      />
    );

    expect(screen.queryByTestId('load-epic-modal')).not.toBeInTheDocument();
  });

  it('should render search controls when open', () => {
    render(
      <LoadEpicModal
        isOpen={true}
        onClose={vi.fn()}
        onSearch={vi.fn()}
        onLoadEpic={vi.fn()}
        searchResults={[]}
        isLoading={false}
      />
    );

    expect(screen.getByTestId('search-input')).toBeInTheDocument();
    expect(screen.getByTestId('state-filter')).toBeInTheDocument();
    expect(screen.getByTestId('search-btn')).toBeInTheDocument();
  });

  it('should show empty state when no results', () => {
    render(
      <LoadEpicModal
        isOpen={true}
        onClose={vi.fn()}
        onSearch={vi.fn()}
        onLoadEpic={vi.fn()}
        searchResults={[]}
        isLoading={false}
      />
    );

    expect(screen.getByTestId('empty-results')).toBeInTheDocument();
  });

  it('should disable search button while loading', () => {
    render(
      <LoadEpicModal
        isOpen={true}
        onClose={vi.fn()}
        onSearch={vi.fn()}
        onLoadEpic={vi.fn()}
        searchResults={[]}
        isLoading={true}
      />
    );

    expect(screen.getByTestId('search-btn')).toBeDisabled();
    expect(screen.getByTestId('search-btn')).toHaveTextContent('Searching...');
  });

  it('should close modal when cancel clicked', () => {
    const onClose = vi.fn();

    render(
      <LoadEpicModal
        isOpen={true}
        onClose={onClose}
        onSearch={vi.fn()}
        onLoadEpic={vi.fn()}
        searchResults={[]}
        isLoading={false}
      />
    );

    fireEvent.click(screen.getByTestId('cancel-btn'));
    expect(onClose).toHaveBeenCalled();
  });
});

describe('Load Epic - Search Functionality', () => {
  const LoadEpicModal = ({
    onSearch,
    searchResults
  }: {
    onSearch: (term: string, state: 'opened' | 'closed' | 'all') => void;
    searchResults: GitLabEpic[];
  }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [filterState, setFilterState] = useState<'opened' | 'closed' | 'all'>('opened');

    return (
      <div>
        <input
          data-testid="search-input"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && onSearch(searchTerm, filterState)}
        />
        <select
          data-testid="state-filter"
          value={filterState}
          onChange={(e) => setFilterState(e.target.value as 'opened' | 'closed' | 'all')}
        >
          <option value="opened">Open</option>
          <option value="closed">Closed</option>
          <option value="all">All</option>
        </select>
        <button data-testid="search-btn" onClick={() => onSearch(searchTerm, filterState)}>
          Search
        </button>
        <div data-testid="results-count">{searchResults.length} results</div>
      </div>
    );
  };

  it('should call onSearch with search term and filter state', () => {
    const onSearch = vi.fn();

    render(<LoadEpicModal onSearch={onSearch} searchResults={[]} />);

    // Type search term
    fireEvent.change(screen.getByTestId('search-input'), {
      target: { value: 'authentication' }
    });

    // Click search
    fireEvent.click(screen.getByTestId('search-btn'));

    expect(onSearch).toHaveBeenCalledWith('authentication', 'opened');
  });

  it('should trigger search on Enter key', () => {
    const onSearch = vi.fn();

    render(<LoadEpicModal onSearch={onSearch} searchResults={[]} />);

    const input = screen.getByTestId('search-input');
    fireEvent.change(input, { target: { value: 'test' } });
    fireEvent.keyDown(input, { key: 'Enter' });

    expect(onSearch).toHaveBeenCalledWith('test', 'opened');
  });

  it('should search with different filter states', () => {
    const onSearch = vi.fn();

    render(<LoadEpicModal onSearch={onSearch} searchResults={[]} />);

    // Change filter to closed
    fireEvent.change(screen.getByTestId('state-filter'), {
      target: { value: 'closed' }
    });

    fireEvent.click(screen.getByTestId('search-btn'));

    expect(onSearch).toHaveBeenCalledWith('', 'closed');
  });
});

describe('Load Epic - Result Display', () => {
  const EpicList = ({
    epics,
    onLoadEpic
  }: {
    epics: GitLabEpic[];
    onLoadEpic: (iid: number) => void;
  }) => (
    <div data-testid="epic-list">
      {epics.map(epic => (
        <div
          key={epic.id}
          data-testid={`epic-${epic.iid}`}
          onClick={() => onLoadEpic(epic.iid)}
        >
          <span data-testid={`level-${epic.iid}`}>{epic.epicLevel}</span>
          <span data-testid={`title-${epic.iid}`}>{epic.title}</span>
          <span data-testid={`state-${epic.iid}`}>{epic.state}</span>
          <span data-testid={`updated-${epic.iid}`}>
            {new Date(epic.updated_at).toLocaleDateString()}
          </span>
        </div>
      ))}
    </div>
  );

  it('should display epic level badge correctly', () => {
    render(<EpicList epics={mockEpics} onLoadEpic={vi.fn()} />);

    expect(screen.getByTestId(`level-${mockCrewEpic.iid}`)).toHaveTextContent('crew');
    expect(screen.getByTestId(`level-${mockPodEpic.iid}`)).toHaveTextContent('pod');
  });

  it('should display epic title', () => {
    render(<EpicList epics={mockEpics} onLoadEpic={vi.fn()} />);

    expect(screen.getByTestId(`title-${mockCrewEpic.iid}`)).toHaveTextContent(mockCrewEpic.title);
    expect(screen.getByTestId(`title-${mockPodEpic.iid}`)).toHaveTextContent(mockPodEpic.title);
  });

  it('should display epic state', () => {
    render(<EpicList epics={mockEpics} onLoadEpic={vi.fn()} />);

    expect(screen.getByTestId(`state-${mockCrewEpic.iid}`)).toHaveTextContent('opened');
    expect(screen.getByTestId(`state-${mockClosedEpic.iid}`)).toHaveTextContent('closed');
  });

  it('should call onLoadEpic when epic clicked', () => {
    const onLoadEpic = vi.fn();

    render(<EpicList epics={mockEpics} onLoadEpic={onLoadEpic} />);

    fireEvent.click(screen.getByTestId(`epic-${mockCrewEpic.iid}`));

    expect(onLoadEpic).toHaveBeenCalledWith(mockCrewEpic.iid);
  });
});

describe('Load Epic - Into Editor', () => {
  // Test the load into editor handler
  const loadEpicHandler = async (
    epicIid: number,
    fetchFn: (iid: number) => Promise<{ success: boolean; data?: GitLabEpic; error?: string }>,
    setEditableEpic: (content: string) => void,
    setActiveTab: (tab: string) => void,
    closeModal: () => void,
    showToast: (type: string, title: string, message: string) => void
  ) => {
    const result = await fetchFn(epicIid);

    if (result.success && result.data) {
      setEditableEpic(result.data.description || '');
      closeModal();
      setActiveTab('epic');
      showToast('success', 'Epic Loaded', `Loaded: ${result.data.title}`);
      return { success: true };
    } else {
      showToast('error', 'Failed to Load', result.error || 'Unknown error');
      return { success: false };
    }
  };

  it('should set editable epic content on successful load', async () => {
    const fetchFn = vi.fn().mockResolvedValue({
      success: true,
      data: mockCrewEpic
    });
    const setEditableEpic = vi.fn();
    const setActiveTab = vi.fn();
    const closeModal = vi.fn();
    const showToast = vi.fn();

    await loadEpicHandler(
      mockCrewEpic.iid,
      fetchFn,
      setEditableEpic,
      setActiveTab,
      closeModal,
      showToast
    );

    expect(setEditableEpic).toHaveBeenCalledWith(mockCrewEpic.description);
  });

  it('should switch to epic tab on successful load', async () => {
    const fetchFn = vi.fn().mockResolvedValue({
      success: true,
      data: mockCrewEpic
    });
    const setEditableEpic = vi.fn();
    const setActiveTab = vi.fn();
    const closeModal = vi.fn();
    const showToast = vi.fn();

    await loadEpicHandler(
      mockCrewEpic.iid,
      fetchFn,
      setEditableEpic,
      setActiveTab,
      closeModal,
      showToast
    );

    expect(setActiveTab).toHaveBeenCalledWith('epic');
  });

  it('should close modal on successful load', async () => {
    const fetchFn = vi.fn().mockResolvedValue({
      success: true,
      data: mockCrewEpic
    });
    const setEditableEpic = vi.fn();
    const setActiveTab = vi.fn();
    const closeModal = vi.fn();
    const showToast = vi.fn();

    await loadEpicHandler(
      mockCrewEpic.iid,
      fetchFn,
      setEditableEpic,
      setActiveTab,
      closeModal,
      showToast
    );

    expect(closeModal).toHaveBeenCalled();
  });

  it('should show success toast on load', async () => {
    const fetchFn = vi.fn().mockResolvedValue({
      success: true,
      data: mockCrewEpic
    });
    const setEditableEpic = vi.fn();
    const setActiveTab = vi.fn();
    const closeModal = vi.fn();
    const showToast = vi.fn();

    await loadEpicHandler(
      mockCrewEpic.iid,
      fetchFn,
      setEditableEpic,
      setActiveTab,
      closeModal,
      showToast
    );

    expect(showToast).toHaveBeenCalledWith(
      'success',
      'Epic Loaded',
      `Loaded: ${mockCrewEpic.title}`
    );
  });

  it('should show error toast on failed load', async () => {
    const fetchFn = vi.fn().mockResolvedValue({
      success: false,
      error: 'Epic not found'
    });
    const setEditableEpic = vi.fn();
    const setActiveTab = vi.fn();
    const closeModal = vi.fn();
    const showToast = vi.fn();

    await loadEpicHandler(
      999,
      fetchFn,
      setEditableEpic,
      setActiveTab,
      closeModal,
      showToast
    );

    expect(showToast).toHaveBeenCalledWith(
      'error',
      'Failed to Load',
      'Epic not found'
    );
    expect(setEditableEpic).not.toHaveBeenCalled();
    expect(closeModal).not.toHaveBeenCalled();
  });

  it('should handle empty description', async () => {
    const epicWithNoDesc = { ...mockCrewEpic, description: '' };
    const fetchFn = vi.fn().mockResolvedValue({
      success: true,
      data: epicWithNoDesc
    });
    const setEditableEpic = vi.fn();
    const setActiveTab = vi.fn();
    const closeModal = vi.fn();
    const showToast = vi.fn();

    await loadEpicHandler(
      epicWithNoDesc.iid,
      fetchFn,
      setEditableEpic,
      setActiveTab,
      closeModal,
      showToast
    );

    expect(setEditableEpic).toHaveBeenCalledWith('');
  });
});
