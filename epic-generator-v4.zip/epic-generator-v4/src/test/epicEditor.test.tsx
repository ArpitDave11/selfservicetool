/**
 * Epic Editor Tests
 *
 * Tests for:
 * 1. Epic Editor tab always visible
 * 2. Empty state when no epic is loaded
 * 3. Full editor when epic content exists
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import React from 'react';

// Since App.tsx is a large monolithic component, we'll test the logic separately
// and create focused unit tests for the specific features

describe('Epic Editor Tab Visibility', () => {
  // Test the tab visibility logic
  const TabNavigation = ({
    hasEpic,
    activeTab,
    setActiveTab
  }: {
    hasEpic: boolean;
    activeTab: string;
    setActiveTab: (tab: string) => void;
  }) => (
    <div data-testid="tabs">
      <button
        data-testid="wizard-tab"
        onClick={() => setActiveTab('wizard')}
        className={activeTab === 'wizard' ? 'active' : ''}
      >
        Wizard
      </button>
      {/* Epic Editor tab is always visible */}
      <button
        data-testid="epic-tab"
        onClick={() => setActiveTab('epic')}
        className={activeTab === 'epic' ? 'active' : ''}
      >
        Epic Editor
      </button>
      {/* Blueprint tab is conditional */}
      {hasEpic && (
        <button
          data-testid="blueprint-tab"
          onClick={() => setActiveTab('blueprint')}
          className={activeTab === 'blueprint' ? 'active' : ''}
        >
          Blueprint
        </button>
      )}
      <button
        data-testid="settings-tab"
        onClick={() => setActiveTab('settings')}
        className={activeTab === 'settings' ? 'active' : ''}
      >
        Settings
      </button>
    </div>
  );

  it('should always show Epic Editor tab even when no epic exists', () => {
    const setActiveTab = vi.fn();
    render(
      <TabNavigation
        hasEpic={false}
        activeTab="wizard"
        setActiveTab={setActiveTab}
      />
    );

    // Epic Editor tab should be visible
    expect(screen.getByTestId('epic-tab')).toBeInTheDocument();

    // Blueprint tab should NOT be visible when hasEpic is false
    expect(screen.queryByTestId('blueprint-tab')).not.toBeInTheDocument();
  });

  it('should show both Epic Editor and Blueprint tabs when epic exists', () => {
    const setActiveTab = vi.fn();
    render(
      <TabNavigation
        hasEpic={true}
        activeTab="wizard"
        setActiveTab={setActiveTab}
      />
    );

    // Both tabs should be visible
    expect(screen.getByTestId('epic-tab')).toBeInTheDocument();
    expect(screen.getByTestId('blueprint-tab')).toBeInTheDocument();
  });

  it('should switch to Epic Editor tab when clicked', () => {
    const setActiveTab = vi.fn();
    render(
      <TabNavigation
        hasEpic={false}
        activeTab="wizard"
        setActiveTab={setActiveTab}
      />
    );

    fireEvent.click(screen.getByTestId('epic-tab'));
    expect(setActiveTab).toHaveBeenCalledWith('epic');
  });
});

describe('Epic Editor Empty State', () => {
  // Test empty state component
  const EmptyState = ({
    editableEpic,
    gitlabEnabled,
    onGoToWizard,
    onLoadFromGitLab
  }: {
    editableEpic: string;
    gitlabEnabled: boolean;
    onGoToWizard: () => void;
    onLoadFromGitLab: () => void;
  }) => {
    if (editableEpic) {
      return <div data-testid="editor-content">Editor with content</div>;
    }

    return (
      <div data-testid="empty-state">
        <h2>No Epic Loaded</h2>
        <p>Generate a new epic using the Wizard, or load an existing one from GitLab.</p>
        <button data-testid="go-to-wizard" onClick={onGoToWizard}>
          Go to Wizard
        </button>
        <button
          data-testid="load-from-gitlab"
          onClick={onLoadFromGitLab}
          disabled={!gitlabEnabled}
        >
          Load from GitLab
        </button>
      </div>
    );
  };

  it('should show empty state when no epic content', () => {
    const onGoToWizard = vi.fn();
    const onLoadFromGitLab = vi.fn();

    render(
      <EmptyState
        editableEpic=""
        gitlabEnabled={true}
        onGoToWizard={onGoToWizard}
        onLoadFromGitLab={onLoadFromGitLab}
      />
    );

    expect(screen.getByTestId('empty-state')).toBeInTheDocument();
    expect(screen.getByText('No Epic Loaded')).toBeInTheDocument();
    expect(screen.getByTestId('go-to-wizard')).toBeInTheDocument();
    expect(screen.getByTestId('load-from-gitlab')).toBeInTheDocument();
  });

  it('should show editor content when epic exists', () => {
    const onGoToWizard = vi.fn();
    const onLoadFromGitLab = vi.fn();

    render(
      <EmptyState
        editableEpic="# Test Epic Content"
        gitlabEnabled={true}
        onGoToWizard={onGoToWizard}
        onLoadFromGitLab={onLoadFromGitLab}
      />
    );

    expect(screen.getByTestId('editor-content')).toBeInTheDocument();
    expect(screen.queryByTestId('empty-state')).not.toBeInTheDocument();
  });

  it('should call onGoToWizard when wizard button clicked', () => {
    const onGoToWizard = vi.fn();
    const onLoadFromGitLab = vi.fn();

    render(
      <EmptyState
        editableEpic=""
        gitlabEnabled={true}
        onGoToWizard={onGoToWizard}
        onLoadFromGitLab={onLoadFromGitLab}
      />
    );

    fireEvent.click(screen.getByTestId('go-to-wizard'));
    expect(onGoToWizard).toHaveBeenCalled();
  });

  it('should disable Load from GitLab button when GitLab not enabled', () => {
    const onGoToWizard = vi.fn();
    const onLoadFromGitLab = vi.fn();

    render(
      <EmptyState
        editableEpic=""
        gitlabEnabled={false}
        onGoToWizard={onGoToWizard}
        onLoadFromGitLab={onLoadFromGitLab}
      />
    );

    const loadButton = screen.getByTestId('load-from-gitlab');
    expect(loadButton).toBeDisabled();
  });

  it('should call onLoadFromGitLab when load button clicked and GitLab enabled', () => {
    const onGoToWizard = vi.fn();
    const onLoadFromGitLab = vi.fn();

    render(
      <EmptyState
        editableEpic=""
        gitlabEnabled={true}
        onGoToWizard={onGoToWizard}
        onLoadFromGitLab={onLoadFromGitLab}
      />
    );

    fireEvent.click(screen.getByTestId('load-from-gitlab'));
    expect(onLoadFromGitLab).toHaveBeenCalled();
  });
});
