/**
 * GitLab API Integration Tests
 *
 * Tests for:
 * 1. Epic fetch/search API
 * 2. Epic create API
 * 3. Epic update API
 * 4. Label fetch API
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import { mockCrewEpic, mockPodEpic, mockEpics, mockLabels } from './testUtils';

describe('GitLab API - Epic Search', () => {
  // Simulated fetchGroupEpics function logic
  const fetchGroupEpics = async (
    config: { enabled: boolean; url: string; accessToken: string; rootGroupId: string },
    params: {
      search?: string;
      state?: 'opened' | 'closed' | 'all';
      labels?: string[];
      per_page?: number;
      page?: number;
    }
  ) => {
    if (!config.enabled || !config.accessToken || !config.rootGroupId) {
      return { success: false, error: 'GitLab not configured' };
    }

    // Simulate filtering
    let results = [...mockEpics];

    if (params.search) {
      const searchLower = params.search.toLowerCase();
      results = results.filter(e => e.title.toLowerCase().includes(searchLower));
    }

    if (params.state && params.state !== 'all') {
      results = results.filter(e => e.state === params.state);
    }

    if (params.labels && params.labels.length > 0) {
      results = results.filter(e =>
        params.labels!.some(label => e.labels.includes(label))
      );
    }

    // Pagination simulation
    const page = params.page || 1;
    const perPage = params.per_page || 20;
    const start = (page - 1) * perPage;
    const paginatedResults = results.slice(start, start + perPage);

    return {
      success: true,
      data: paginatedResults,
      totalCount: results.length
    };
  };

  it('should return error when GitLab not enabled', async () => {
    const result = await fetchGroupEpics(
      { enabled: false, url: '', accessToken: '', rootGroupId: '' },
      {}
    );

    expect(result.success).toBe(false);
    expect(result.error).toBe('GitLab not configured');
  });

  it('should return all epics when no filters', async () => {
    const result = await fetchGroupEpics(
      { enabled: true, url: 'https://gitlab.com', accessToken: 'token', rootGroupId: '123' },
      {}
    );

    expect(result.success).toBe(true);
    expect(result.data).toHaveLength(mockEpics.length);
  });

  it('should filter epics by search term', async () => {
    const result = await fetchGroupEpics(
      { enabled: true, url: 'https://gitlab.com', accessToken: 'token', rootGroupId: '123' },
      { search: 'Platform' }
    );

    expect(result.success).toBe(true);
    expect(result.data).toHaveLength(1);
    expect(result.data![0].title).toContain('Platform');
  });

  it('should filter epics by state', async () => {
    const result = await fetchGroupEpics(
      { enabled: true, url: 'https://gitlab.com', accessToken: 'token', rootGroupId: '123' },
      { state: 'closed' }
    );

    expect(result.success).toBe(true);
    expect(result.data!.every(e => e.state === 'closed')).toBe(true);
  });

  it('should return all states when filter is "all"', async () => {
    const result = await fetchGroupEpics(
      { enabled: true, url: 'https://gitlab.com', accessToken: 'token', rootGroupId: '123' },
      { state: 'all' }
    );

    expect(result.success).toBe(true);
    expect(result.data).toHaveLength(mockEpics.length);
  });

  it('should filter epics by labels', async () => {
    const result = await fetchGroupEpics(
      { enabled: true, url: 'https://gitlab.com', accessToken: 'token', rootGroupId: '123' },
      { labels: ['crew::platform'] }
    );

    expect(result.success).toBe(true);
    expect(result.data!.every(e => e.labels.includes('crew::platform'))).toBe(true);
  });
});

describe('GitLab API - Epic Details', () => {
  const fetchEpicDetails = async (
    config: { enabled: boolean; accessToken: string; rootGroupId: string },
    epicIid: number
  ) => {
    if (!config.enabled || !config.accessToken || !config.rootGroupId) {
      return { success: false, error: 'GitLab not configured' };
    }

    const epic = mockEpics.find(e => e.iid === epicIid);
    if (!epic) {
      return { success: false, error: 'Epic not found' };
    }

    return { success: true, data: epic };
  };

  it('should return epic details by IID', async () => {
    const result = await fetchEpicDetails(
      { enabled: true, accessToken: 'token', rootGroupId: '123' },
      mockCrewEpic.iid
    );

    expect(result.success).toBe(true);
    expect(result.data!.iid).toBe(mockCrewEpic.iid);
    expect(result.data!.title).toBe(mockCrewEpic.title);
  });

  it('should return error for non-existent epic', async () => {
    const result = await fetchEpicDetails(
      { enabled: true, accessToken: 'token', rootGroupId: '123' },
      99999
    );

    expect(result.success).toBe(false);
    expect(result.error).toBe('Epic not found');
  });
});

describe('GitLab API - Create Epic', () => {
  const createGitLabEpic = async (
    config: { enabled: boolean; accessToken: string; rootGroupId: string },
    params: {
      title: string;
      description?: string;
      labels?: string[];
      parent_id?: number;
    }
  ) => {
    if (!config.enabled || !config.accessToken || !config.rootGroupId) {
      return { success: false, error: 'GitLab not configured' };
    }

    if (!params.title) {
      return { success: false, error: 'Title is required' };
    }

    // Simulate epic creation
    const newEpic = {
      id: Date.now(),
      iid: Math.floor(Math.random() * 1000) + 200,
      group_id: parseInt(config.rootGroupId),
      title: params.title,
      description: params.description || '',
      state: 'opened' as const,
      labels: params.labels || [],
      start_date: null,
      due_date: null,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      web_url: `https://gitlab.com/groups/test/-/epics/${Date.now()}`,
      parent: params.parent_id ? { id: params.parent_id, iid: 0, title: '' } : undefined,
      epicLevel: params.labels?.some(l => l.startsWith('crew::')) ? 'crew' as const : 'pod' as const
    };

    return { success: true, data: newEpic };
  };

  it('should create epic with required fields', async () => {
    const result = await createGitLabEpic(
      { enabled: true, accessToken: 'token', rootGroupId: '123' },
      { title: 'New Test Epic' }
    );

    expect(result.success).toBe(true);
    expect(result.data!.title).toBe('New Test Epic');
    expect(result.data!.web_url).toBeDefined();
  });

  it('should create epic with all fields', async () => {
    const result = await createGitLabEpic(
      { enabled: true, accessToken: 'token', rootGroupId: '123' },
      {
        title: 'Full Epic',
        description: '# Epic Description',
        labels: ['crew::test', 'epic-generator'],
        parent_id: undefined
      }
    );

    expect(result.success).toBe(true);
    expect(result.data!.description).toBe('# Epic Description');
    expect(result.data!.labels).toContain('crew::test');
  });

  it('should fail when title is missing', async () => {
    const result = await createGitLabEpic(
      { enabled: true, accessToken: 'token', rootGroupId: '123' },
      { title: '' }
    );

    expect(result.success).toBe(false);
    expect(result.error).toBe('Title is required');
  });

  it('should include parent_id for pod epics', async () => {
    const result = await createGitLabEpic(
      { enabled: true, accessToken: 'token', rootGroupId: '123' },
      {
        title: 'Pod Epic',
        labels: ['pod::test'],
        parent_id: mockCrewEpic.id
      }
    );

    expect(result.success).toBe(true);
    expect(result.data!.parent).toBeDefined();
    expect(result.data!.parent!.id).toBe(mockCrewEpic.id);
  });
});

describe('GitLab API - Update Epic', () => {
  const updateGitLabEpic = async (
    config: { enabled: boolean; accessToken: string; rootGroupId: string },
    epicIid: number,
    params: {
      title?: string;
      description?: string;
    }
  ) => {
    if (!config.enabled || !config.accessToken || !config.rootGroupId) {
      return { success: false, error: 'GitLab not configured' };
    }

    const existingEpic = mockEpics.find(e => e.iid === epicIid);
    if (!existingEpic) {
      return { success: false, error: 'Epic not found' };
    }

    // Simulate update
    const updatedEpic = {
      ...existingEpic,
      title: params.title ?? existingEpic.title,
      description: params.description ?? existingEpic.description,
      updated_at: new Date().toISOString()
    };

    return { success: true, data: updatedEpic };
  };

  it('should update epic title', async () => {
    const result = await updateGitLabEpic(
      { enabled: true, accessToken: 'token', rootGroupId: '123' },
      mockCrewEpic.iid,
      { title: 'Updated Title' }
    );

    expect(result.success).toBe(true);
    expect(result.data!.title).toBe('Updated Title');
  });

  it('should update epic description', async () => {
    const result = await updateGitLabEpic(
      { enabled: true, accessToken: 'token', rootGroupId: '123' },
      mockCrewEpic.iid,
      { description: '# Updated Description' }
    );

    expect(result.success).toBe(true);
    expect(result.data!.description).toBe('# Updated Description');
  });

  it('should preserve unchanged fields', async () => {
    const result = await updateGitLabEpic(
      { enabled: true, accessToken: 'token', rootGroupId: '123' },
      mockCrewEpic.iid,
      { title: 'New Title' }
    );

    expect(result.success).toBe(true);
    expect(result.data!.description).toBe(mockCrewEpic.description);
    expect(result.data!.labels).toEqual(mockCrewEpic.labels);
  });

  it('should fail for non-existent epic', async () => {
    const result = await updateGitLabEpic(
      { enabled: true, accessToken: 'token', rootGroupId: '123' },
      99999,
      { title: 'Test' }
    );

    expect(result.success).toBe(false);
    expect(result.error).toBe('Epic not found');
  });
});

describe('GitLab API - Fetch Labels', () => {
  const fetchGroupLabels = async (
    config: { enabled: boolean; accessToken: string; rootGroupId: string }
  ) => {
    if (!config.enabled || !config.accessToken || !config.rootGroupId) {
      return { success: false, error: 'GitLab not configured' };
    }

    return { success: true, data: mockLabels };
  };

  it('should return group labels', async () => {
    const result = await fetchGroupLabels({
      enabled: true,
      accessToken: 'token',
      rootGroupId: '123'
    });

    expect(result.success).toBe(true);
    expect(result.data).toHaveLength(mockLabels.length);
  });

  it('should return error when not configured', async () => {
    const result = await fetchGroupLabels({
      enabled: false,
      accessToken: '',
      rootGroupId: ''
    });

    expect(result.success).toBe(false);
    expect(result.error).toBe('GitLab not configured');
  });
});

describe('Epic Level Detection', () => {
  const determineEpicLevel = (
    labels: string[],
    crewPrefix: string = 'crew::',
    podPrefix: string = 'pod::'
  ): 'crew' | 'pod' | 'unknown' => {
    if (labels.some(l => l.startsWith(crewPrefix))) return 'crew';
    if (labels.some(l => l.startsWith(podPrefix))) return 'pod';
    return 'unknown';
  };

  it('should detect crew level from labels', () => {
    const level = determineEpicLevel(['crew::platform', 'epic-generator']);
    expect(level).toBe('crew');
  });

  it('should detect pod level from labels', () => {
    const level = determineEpicLevel(['pod::auth', 'epic-generator']);
    expect(level).toBe('pod');
  });

  it('should return unknown when no level label', () => {
    const level = determineEpicLevel(['some-label', 'epic-generator']);
    expect(level).toBe('unknown');
  });

  it('should handle custom prefixes', () => {
    const level = determineEpicLevel(
      ['team::platform'],
      'team::',
      'squad::'
    );
    expect(level).toBe('crew');
  });
});
