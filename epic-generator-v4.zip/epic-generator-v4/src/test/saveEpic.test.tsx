/**
 * Save Epic Workflow Tests
 *
 * Tests for:
 * 1. Crew/Pod level selection
 * 2. Parent epic requirement for Pod level
 * 3. Epic creation with proper labels
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import React, { useState } from 'react';
import { mockCrewEpic, mockPodEpic, mockEpics } from './testUtils';
import type { GitLabEpic } from '../config';

describe('Save Epic - Level Selection', () => {
  // Component simulating the publish modal
  const PublishModal = ({
    gitlabEpics,
    onPublish,
    onCancel
  }: {
    gitlabEpics: GitLabEpic[];
    onPublish: (level: 'crew' | 'pod', parentId: number | null) => void;
    onCancel: () => void;
  }) => {
    const [level, setLevel] = useState<'crew' | 'pod'>('pod');
    const [parentId, setParentId] = useState<number | null>(null);

    const crewEpics = gitlabEpics.filter(e => e.epicLevel === 'crew');
    const canPublish = level === 'crew' || (level === 'pod' && parentId !== null);

    return (
      <div data-testid="publish-modal">
        <h3>Publish as GitLab Epic</h3>

        {/* Level Selection */}
        <div data-testid="level-selection">
          <button
            data-testid="crew-level-btn"
            onClick={() => setLevel('crew')}
            className={level === 'crew' ? 'selected' : ''}
          >
            Crew Level
          </button>
          <button
            data-testid="pod-level-btn"
            onClick={() => setLevel('pod')}
            className={level === 'pod' ? 'selected' : ''}
          >
            Pod Level
          </button>
        </div>

        {/* Parent Selection (required for Pod) */}
        {level === 'pod' && (
          <div data-testid="parent-selection">
            <label>
              Parent Crew Epic <span data-testid="required-indicator">*</span>
            </label>
            <select
              data-testid="parent-select"
              value={parentId || ''}
              onChange={(e) => setParentId(e.target.value ? Number(e.target.value) : null)}
            >
              <option value="">Select a parent crew epic...</option>
              {crewEpics.map(epic => (
                <option key={epic.id} value={epic.id}>{epic.title}</option>
              ))}
            </select>
            {crewEpics.length === 0 && (
              <div data-testid="no-crew-warning">
                No crew-level epics found. Create a Crew Level epic first.
              </div>
            )}
          </div>
        )}

        {/* Actions */}
        <button data-testid="cancel-btn" onClick={onCancel}>
          Cancel
        </button>
        <button
          data-testid="publish-btn"
          disabled={!canPublish}
          onClick={() => onPublish(level, parentId)}
        >
          Create Epic
        </button>
      </div>
    );
  };

  it('should default to Pod level selection', () => {
    const onPublish = vi.fn();
    const onCancel = vi.fn();

    render(
      <PublishModal
        gitlabEpics={mockEpics}
        onPublish={onPublish}
        onCancel={onCancel}
      />
    );

    const podBtn = screen.getByTestId('pod-level-btn');
    expect(podBtn).toHaveClass('selected');
  });

  it('should switch to Crew level when selected', () => {
    const onPublish = vi.fn();
    const onCancel = vi.fn();

    render(
      <PublishModal
        gitlabEpics={mockEpics}
        onPublish={onPublish}
        onCancel={onCancel}
      />
    );

    fireEvent.click(screen.getByTestId('crew-level-btn'));

    expect(screen.getByTestId('crew-level-btn')).toHaveClass('selected');
    // Parent selection should not be visible for crew level
    expect(screen.queryByTestId('parent-selection')).not.toBeInTheDocument();
  });

  it('should show parent selection only for Pod level', () => {
    const onPublish = vi.fn();
    const onCancel = vi.fn();

    render(
      <PublishModal
        gitlabEpics={mockEpics}
        onPublish={onPublish}
        onCancel={onCancel}
      />
    );

    // Pod is default, parent selection should be visible
    expect(screen.getByTestId('parent-selection')).toBeInTheDocument();
    expect(screen.getByTestId('required-indicator')).toBeInTheDocument();

    // Switch to crew
    fireEvent.click(screen.getByTestId('crew-level-btn'));
    expect(screen.queryByTestId('parent-selection')).not.toBeInTheDocument();

    // Switch back to pod
    fireEvent.click(screen.getByTestId('pod-level-btn'));
    expect(screen.getByTestId('parent-selection')).toBeInTheDocument();
  });
});

describe('Save Epic - Parent Requirement', () => {
  const PublishModal = ({
    gitlabEpics,
    onPublish
  }: {
    gitlabEpics: GitLabEpic[];
    onPublish: (level: 'crew' | 'pod', parentId: number | null) => void;
  }) => {
    const [level, setLevel] = useState<'crew' | 'pod'>('pod');
    const [parentId, setParentId] = useState<number | null>(null);

    const crewEpics = gitlabEpics.filter(e => e.epicLevel === 'crew');
    const canPublish = level === 'crew' || (level === 'pod' && parentId !== null);

    return (
      <div>
        <button data-testid="crew-btn" onClick={() => setLevel('crew')}>Crew</button>
        <button data-testid="pod-btn" onClick={() => setLevel('pod')}>Pod</button>

        {level === 'pod' && (
          <select
            data-testid="parent-select"
            value={parentId || ''}
            onChange={(e) => setParentId(e.target.value ? Number(e.target.value) : null)}
          >
            <option value="">Select...</option>
            {crewEpics.map(epic => (
              <option key={epic.id} value={epic.id}>{epic.title}</option>
            ))}
          </select>
        )}

        <button
          data-testid="publish-btn"
          disabled={!canPublish}
          onClick={() => onPublish(level, parentId)}
        >
          Publish
        </button>
      </div>
    );
  };

  it('should disable publish button when Pod level has no parent selected', () => {
    const onPublish = vi.fn();

    render(<PublishModal gitlabEpics={mockEpics} onPublish={onPublish} />);

    // Pod is default, no parent selected
    expect(screen.getByTestId('publish-btn')).toBeDisabled();
  });

  it('should enable publish button when Pod level has parent selected', () => {
    const onPublish = vi.fn();

    render(<PublishModal gitlabEpics={mockEpics} onPublish={onPublish} />);

    // Select a parent
    fireEvent.change(screen.getByTestId('parent-select'), {
      target: { value: mockCrewEpic.id.toString() }
    });

    expect(screen.getByTestId('publish-btn')).not.toBeDisabled();
  });

  it('should enable publish button immediately for Crew level', () => {
    const onPublish = vi.fn();

    render(<PublishModal gitlabEpics={mockEpics} onPublish={onPublish} />);

    // Switch to crew
    fireEvent.click(screen.getByTestId('crew-btn'));

    expect(screen.getByTestId('publish-btn')).not.toBeDisabled();
  });

  it('should call onPublish with correct params when publishing crew epic', () => {
    const onPublish = vi.fn();

    render(<PublishModal gitlabEpics={mockEpics} onPublish={onPublish} />);

    fireEvent.click(screen.getByTestId('crew-btn'));
    fireEvent.click(screen.getByTestId('publish-btn'));

    expect(onPublish).toHaveBeenCalledWith('crew', null);
  });

  it('should call onPublish with parent ID when publishing pod epic', () => {
    const onPublish = vi.fn();

    render(<PublishModal gitlabEpics={mockEpics} onPublish={onPublish} />);

    // Select parent
    fireEvent.change(screen.getByTestId('parent-select'), {
      target: { value: mockCrewEpic.id.toString() }
    });

    fireEvent.click(screen.getByTestId('publish-btn'));

    expect(onPublish).toHaveBeenCalledWith('pod', mockCrewEpic.id);
  });
});

describe('Save Epic - Label Generation', () => {
  // Test label generation logic
  const generateLabels = (
    level: 'crew' | 'pod',
    projectName: string,
    crewPrefix: string = 'crew::',
    podPrefix: string = 'pod::'
  ): string[] => {
    const safeName = projectName.toLowerCase().replace(/\s+/g, '-');
    const levelLabel = level === 'crew'
      ? `${crewPrefix}${safeName}`
      : `${podPrefix}${safeName}`;

    return [levelLabel, 'epic-generator'];
  };

  it('should generate crew label for crew level epic', () => {
    const labels = generateLabels('crew', 'Platform Modernization');

    expect(labels).toContain('crew::platform-modernization');
    expect(labels).toContain('epic-generator');
    expect(labels).not.toContain('pod::platform-modernization');
  });

  it('should generate pod label for pod level epic', () => {
    const labels = generateLabels('pod', 'User Authentication');

    expect(labels).toContain('pod::user-authentication');
    expect(labels).toContain('epic-generator');
    expect(labels).not.toContain('crew::user-authentication');
  });

  it('should handle special characters in project name', () => {
    const labels = generateLabels('crew', 'My Project (v2.0)');

    expect(labels[0]).toBe('crew::my-project-(v2.0)');
  });

  it('should handle multiple spaces in project name', () => {
    const labels = generateLabels('pod', 'My    Spaced   Project');

    expect(labels[0]).toBe('pod::my-spaced-project');
  });
});

describe('Save Epic - API Integration', () => {
  // Test the create epic handler logic
  const createEpicHandler = async (
    config: { enabled: boolean; rootGroupId: string },
    projectName: string,
    level: 'crew' | 'pod',
    parentId: number | null,
    createFn: (params: {
      title: string;
      description: string;
      labels: string[];
      parent_id?: number;
    }) => Promise<{ success: boolean; data?: { web_url: string }; error?: string }>
  ) => {
    if (!config.enabled || !config.rootGroupId) {
      return { success: false, error: 'GitLab not configured' };
    }

    const safeName = projectName.toLowerCase().replace(/\s+/g, '-');
    const levelLabel = level === 'crew' ? `crew::${safeName}` : `pod::${safeName}`;

    const params = {
      title: projectName,
      description: '# Generated Epic Content',
      labels: [levelLabel, 'epic-generator'],
      parent_id: parentId || undefined
    };

    return createFn(params);
  };

  it('should return error when GitLab not configured', async () => {
    const createFn = vi.fn();

    const result = await createEpicHandler(
      { enabled: false, rootGroupId: '' },
      'Test Epic',
      'crew',
      null,
      createFn
    );

    expect(result.success).toBe(false);
    expect(result.error).toBe('GitLab not configured');
    expect(createFn).not.toHaveBeenCalled();
  });

  it('should call create function with correct params for crew epic', async () => {
    const createFn = vi.fn().mockResolvedValue({
      success: true,
      data: { web_url: 'https://gitlab.com/test' }
    });

    await createEpicHandler(
      { enabled: true, rootGroupId: '123' },
      'My Crew Epic',
      'crew',
      null,
      createFn
    );

    expect(createFn).toHaveBeenCalledWith({
      title: 'My Crew Epic',
      description: '# Generated Epic Content',
      labels: ['crew::my-crew-epic', 'epic-generator'],
      parent_id: undefined
    });
  });

  it('should call create function with parent_id for pod epic', async () => {
    const createFn = vi.fn().mockResolvedValue({
      success: true,
      data: { web_url: 'https://gitlab.com/test' }
    });

    await createEpicHandler(
      { enabled: true, rootGroupId: '123' },
      'My Pod Epic',
      'pod',
      42,
      createFn
    );

    expect(createFn).toHaveBeenCalledWith({
      title: 'My Pod Epic',
      description: '# Generated Epic Content',
      labels: ['pod::my-pod-epic', 'epic-generator'],
      parent_id: 42
    });
  });
});
