// Epic Generator Skills & Prompts

import { EPIC_SECTIONS, type RefinedData } from './types';
import { type AppConfig, callAI } from './config';

// Skill Types
export interface RefineResult {
  refined: string;
  diagramNode: string;
  suggestions?: string[];
}

export interface GenerateResult {
  epic: string;
  diagram: string;
}

export interface SuggestionResult {
  suggestion: string;
  alternatives?: string[];
}

// Store config reference for AI calls
let currentConfig: AppConfig | null = null;

export function setConfig(config: AppConfig) {
  currentConfig = config;
}

// Get AI suggestion for a field using Azure OpenAI
// mode: 'with-context' uses user's keywords to tailor suggestion
// mode: 'auto' generates from scratch using project context
export async function getSuggestion(
  stageId: string,
  fieldName: string,
  context: Record<string, string>,
  mode: 'with-context' | 'auto' = 'auto'
): Promise<SuggestionResult> {
  if (!currentConfig) {
    throw new Error('Azure OpenAI is not configured. Please check Settings.');
  }

  const userHint = context['_userHint'];
  const systemPrompt = getSystemPromptForField(stageId, fieldName);
  const userPrompt = buildUserPrompt(stageId, fieldName, context, userHint, mode);

  const aiResponse = await callAI(currentConfig, systemPrompt, userPrompt);

  return {
    suggestion: aiResponse.trim(),
    alternatives: [],
  };
}

// Get system prompt for a specific field
function getSystemPromptForField(stageId: string, fieldName: string): string {
  const basePrompt = `You are an expert technical writer helping to create comprehensive software project epics.
Provide concise, professional content suitable for a technical design document.
Be specific and actionable. Use bullet points or numbered lists where appropriate.
Do not include any preamble or explanation - just provide the content directly.`;

  const fieldPrompts: Record<string, Record<string, string>> = {
    project: {
      projectName: `${basePrompt}\nGenerate a professional project name (2-4 words, no quotes).`,
      background: `${basePrompt}\nWrite a project background section explaining why this initiative exists and its business context.`,
    },
    objective_scope: {
      objective: `${basePrompt}\nWrite a clear, measurable project objective with success criteria.`,
      inScope: `${basePrompt}\nList items that are IN SCOPE for this project. Use bullet points, one item per line.`,
      outOfScope: `${basePrompt}\nList items that are OUT OF SCOPE for this project. Use bullet points, one item per line.`,
    },
    architecture: {
      assumptions: `${basePrompt}\nList technical and business assumptions for this project. Use bullet points.`,
      architectureOverview: `${basePrompt}\nDescribe the high-level system architecture including components, technologies, and how they interact.`,
      dataStores: `${basePrompt}\nDescribe the data stores, databases, caching layers, and data flow for this system.`,
    },
    features: {
      features: `${basePrompt}\nList the key features for this project. Use numbered list format.`,
      userStories: `${basePrompt}\nWrite user stories in the format "As a [role], I want [feature] so that [benefit]".`,
      nfrs: `${basePrompt}\nDefine non-functional requirements including performance, scalability, security, and availability targets.`,
      deliverables: `${basePrompt}\nList project deliverables. Use bullet points.`,
    },
    team_env: {
      teams: `${basePrompt}\nDefine team roles and responsibilities. Format: Role - Responsibility`,
      environments: `${basePrompt}\nDescribe the environment strategy (dev, staging, prod) and CI/CD approach.`,
      security: `${basePrompt}\nDefine security controls including authentication, authorization, encryption, and compliance requirements.`,
    },
    delivery: {
      dependencies: `${basePrompt}\nList project dependencies (teams, systems, third parties). Use bullet points.`,
      risks: `${basePrompt}\nIdentify project risks with mitigations. Format: Risk: [description] | Mitigation: [approach]`,
      nextSteps: `${basePrompt}\nList immediate next steps to kick off this project. Use numbered list.`,
      dod: `${basePrompt}\nDefine the Definition of Done criteria for this project. Use bullet points.`,
      approvers: `${basePrompt}\nList required approvers with their roles. Format: Name/Role - Type of approval`,
    },
  };

  return fieldPrompts[stageId]?.[fieldName] || basePrompt;
}

// Build user prompt based on context
function buildUserPrompt(
  _stageId: string,
  fieldName: string,
  context: Record<string, string>,
  userHint: string | undefined,
  mode: 'with-context' | 'auto'
): string {
  let prompt = '';

  // Add project context if available
  if (context.projectName) {
    prompt += `Project: ${context.projectName}\n`;
  }
  if (context.objective) {
    prompt += `Objective: ${context.objective}\n`;
  }
  if (context.background) {
    prompt += `Background: ${context.background}\n`;
  }

  // Add user hint if in with-context mode
  if (mode === 'with-context' && userHint) {
    prompt += `\nUser's keywords/ideas to incorporate: ${userHint}\n`;
    prompt += `\nBased on these keywords, generate appropriate content for the "${fieldName}" field.`;
  } else {
    prompt += `\nGenerate content for the "${fieldName}" field based on the project context above.`;
  }

  // Add field-specific guidance
  const fieldGuidance: Record<string, string> = {
    projectName: 'Generate a professional, concise project name.',
    background: 'Write 2-3 paragraphs explaining the business context and need.',
    objective: 'Write a clear objective with measurable success criteria.',
    inScope: 'List 5-8 items that are in scope.',
    outOfScope: 'List 3-5 items explicitly out of scope.',
    assumptions: 'List 4-6 key assumptions.',
    architectureOverview: 'Describe the architecture in 2-3 paragraphs with key components.',
    dataStores: 'Describe databases, caching, and data flow.',
    features: 'List 5-8 key features.',
    userStories: 'Write 3-5 user stories.',
    nfrs: 'Define performance, scalability, security, and availability requirements.',
    deliverables: 'List 5-7 project deliverables.',
    teams: 'Define 5-7 team roles.',
    environments: 'Describe dev, staging, and production environments.',
    security: 'Define authentication, authorization, and encryption approach.',
    dependencies: 'List 4-6 dependencies.',
    risks: 'Identify 3-5 risks with mitigations.',
    nextSteps: 'List 4-6 immediate next steps.',
    dod: 'Define 5-7 Definition of Done criteria.',
    approvers: 'List 3-5 required approvers.',
  };

  if (fieldGuidance[fieldName]) {
    prompt += `\n${fieldGuidance[fieldName]}`;
  }

  return prompt;
}

// Small delay for UI feedback
const mockDelay = () => new Promise(resolve => setTimeout(resolve, 300));

// Refine Skill - Enhances user input at each stage
async function refineInput(
  stageId: string,
  fieldName: string,
  userInput: string,
  _context: Record<string, string>
): Promise<RefineResult> {
  await mockDelay();

  // Mock refinement based on stage and field
  const refinements: Record<string, Record<string, (input: string) => RefineResult>> = {
    project: {
      projectName: (input) => ({
        refined: input,
        diagramNode: `Project["${input}"]`,
      }),
      background: (input) => ({
        refined: `**Context:** ${input}\n\n**Business Need:** This initiative addresses key organizational requirements and strategic objectives.`,
        diagramNode: `Context["Background & Context"]`,
      }),
    },
    objective_scope: {
      objective: (input) => ({
        refined: `**Primary Goal:** ${input}\n\n**Success Metrics:** Measurable outcomes will be defined during implementation.`,
        diagramNode: `Objective["${input.slice(0, 30)}..."]`,
      }),
      inScope: (input) => ({
        refined: input.split('\n').map(line => line.trim()).filter(Boolean).map(line => `- ${line}`).join('\n'),
        diagramNode: `Scope["In Scope Items"]`,
      }),
      outOfScope: (input) => ({
        refined: input ? input.split('\n').map(line => line.trim()).filter(Boolean).map(line => `- ${line}`).join('\n') : '- To be determined based on project constraints',
        diagramNode: `OutScope["Out of Scope"]`,
      }),
    },
    architecture: {
      assumptions: (input) => ({
        refined: input ? input.split('\n').map(line => line.trim()).filter(Boolean).map(line => `- ${line}`).join('\n') : '- Standard infrastructure availability\n- Team availability for implementation',
        diagramNode: `Assumptions["Assumptions"]`,
      }),
      architectureOverview: (input) => ({
        refined: `**System Architecture:**\n\n${input}\n\n**Key Components:** The system follows a modular architecture pattern enabling scalability and maintainability.`,
        diagramNode: `Architecture["System Architecture"]`,
      }),
      dataStores: (input) => ({
        refined: `**Data Layer:**\n\n${input}\n\n**Integration Points:** APIs and services will follow RESTful conventions with appropriate authentication.`,
        diagramNode: `DataStores["Data & Services"]`,
      }),
    },
    features: {
      features: (input) => ({
        refined: input.split('\n').map(line => line.trim()).filter(Boolean).map((line, i) => `${i + 1}. **${line}**`).join('\n'),
        diagramNode: `Features["Key Features"]`,
      }),
      userStories: (input) => ({
        refined: input || 'User stories to be elaborated during sprint planning.',
        diagramNode: `Stories["User Stories"]`,
      }),
      nfrs: (input) => ({
        refined: input ? `**Performance & Quality Requirements:**\n\n${input}` : '- Performance: Response time < 2s\n- Availability: 99.9% uptime\n- Security: Industry standard encryption',
        diagramNode: `NFRs["NFRs"]`,
      }),
      deliverables: (input) => ({
        refined: input.split('\n').map(line => line.trim()).filter(Boolean).map(line => `- [ ] ${line}`).join('\n'),
        diagramNode: `Deliverables["Deliverables"]`,
      }),
    },
    team_env: {
      teams: (input) => ({
        refined: input,
        diagramNode: `Team["Team Structure"]`,
      }),
      environments: (input) => ({
        refined: `**Environment Strategy:**\n\n${input}\n\n**Deployment:** CI/CD pipeline with automated testing and staged rollouts.`,
        diagramNode: `Environments["Environments"]`,
      }),
      security: (input) => ({
        refined: input ? `**Security Controls:**\n\n${input}` : '- Role-based access control (RBAC)\n- Data encryption at rest and in transit\n- Audit logging enabled',
        diagramNode: `Security["Security"]`,
      }),
    },
    delivery: {
      dependencies: (input) => ({
        refined: input ? input.split('\n').map(line => line.trim()).filter(Boolean).map(line => `- ${line}`).join('\n') : '- No critical external dependencies identified',
        diagramNode: `Dependencies["Dependencies"]`,
      }),
      risks: (input) => ({
        refined: input ? input.split('\n').map(line => line.trim()).filter(Boolean).map(line => `- **Risk:** ${line}`).join('\n') : '- Resource availability\n- Timeline constraints',
        diagramNode: `Risks["Risks"]`,
      }),
      nextSteps: (input) => ({
        refined: input.split('\n').map(line => line.trim()).filter(Boolean).map((line, i) => `${i + 1}. ${line}`).join('\n'),
        diagramNode: `NextSteps["Next Steps"]`,
      }),
      dod: (input) => ({
        refined: input.split('\n').map(line => line.trim()).filter(Boolean).map(line => `- [ ] ${line}`).join('\n'),
        diagramNode: `DoD["Definition of Done"]`,
      }),
      approvers: (input) => ({
        refined: input || 'Project stakeholders and technical leads',
        diagramNode: `Approvers["Approvers"]`,
      }),
    },
  };

  const stageRefinements = refinements[stageId];
  if (stageRefinements && stageRefinements[fieldName]) {
    return stageRefinements[fieldName](userInput);
  }

  // Default refinement
  return {
    refined: userInput,
    diagramNode: `Node_${fieldName}["${fieldName}"]`,
  };
}

// Generate Epic Skill - Creates full 17-section epic
async function generateEpic(data: RefinedData, projectName: string): Promise<GenerateResult> {
  await mockDelay();

  // Build the epic document
  let epic = `# Technical Design Epic: ${projectName}\n\n`;
  epic += `*Generated on ${new Date().toLocaleDateString()}*\n\n---\n\n`;

  // Generate each section
  for (const section of EPIC_SECTIONS) {
    epic += `## ${section.num}. ${section.title}\n\n`;

    if (section.subsections) {
      // Handle sections with subsections (Scope, Dependencies & Risks)
      section.dataKeys.forEach((key, idx) => {
        const subsectionTitle = section.subsections![idx];
        const content = data[key]?.refined || '_To be defined_';
        epic += `### ${section.num}.${idx + 1} ${subsectionTitle}\n\n${content}\n\n`;
      });
    } else if (section.isTable && section.dataKeys[0] === 'teams') {
      // Team & Roles table
      epic += `| Role | Responsibility |\n|------|----------------|\n`;
      const teamData = data['teams']?.refined || 'Team structure to be defined';
      teamData.split('\n').filter(Boolean).forEach(line => {
        epic += `| ${line} | TBD |\n`;
      });
      epic += '\n';
    } else if (section.isTable && section.dataKeys[0] === 'approvers') {
      // Approvals table
      epic += `| Approver | Role | Status |\n|----------|------|--------|\n`;
      const approverData = data['approvers']?.refined || 'Stakeholders';
      approverData.split('\n').filter(Boolean).forEach(line => {
        epic += `| ${line.trim()} | Stakeholder | Pending |\n`;
      });
      epic += '\n';
    } else if (section.hasDiagram) {
      // Architecture overview - no embedded diagram (Blueprint tab has the visual)
      const content = data[section.dataKeys[0]]?.refined || '_Architecture details to be defined_';
      epic += `${content}\n\n`;
    } else if (section.isReference) {
      // Architecture diagrams reference - point to Blueprint tab
      epic += `> **Note:** Visual architecture diagrams are available in the **Blueprint** tab.\n\n`;
    } else {
      // Standard section
      const content = section.dataKeys
        .map(key => data[key]?.refined)
        .filter(Boolean)
        .join('\n\n') || '_To be defined_';
      epic += `${content}\n\n`;
    }
  }

  // Generate the multilayer summary diagram
  const diagram = generateMultilayerDiagram(data, projectName);

  return { epic, diagram };
}

// Generate architecture diagram from refined data
function generateArchitectureDiagram(data: RefinedData): string {
  const hasDataStores = data['dataStores']?.refined;
  const hasFeatures = data['features']?.refined;

  let diagram = 'graph TD\n';
  diagram += '    User[User/Client] --> API[API Gateway]\n';
  diagram += '    API --> Services[Service Layer]\n';

  if (hasFeatures) {
    diagram += '    Services --> Features[Feature Modules]\n';
  }

  if (hasDataStores) {
    diagram += '    Services --> DB[(Database)]\n';
    diagram += '    Services --> Cache[(Cache)]\n';
  } else {
    diagram += '    Services --> DB[(Data Store)]\n';
  }

  diagram += '    Services --> External[External Services]\n';

  return diagram;
}

// Generate multilayer diagram showing the full flow
function generateMultilayerDiagram(_data: RefinedData, projectName: string): string {
  let diagram = 'graph TD\n';

  // Input Layer
  diagram += '    subgraph Input["Input Layer"]\n';
  diagram += '        I1[Project Info]\n';
  diagram += '        I2[Objective & Scope]\n';
  diagram += '        I3[Architecture]\n';
  diagram += '        I4[Features]\n';
  diagram += '        I5[Team & Env]\n';
  diagram += '        I6[Delivery]\n';
  diagram += '    end\n\n';

  // Refinement Layer
  diagram += '    subgraph Refine["AI Refinement Layer"]\n';
  diagram += '        R1[Refined Background]\n';
  diagram += '        R2[Refined Scope]\n';
  diagram += '        R3[Refined Architecture]\n';
  diagram += '        R4[Refined Features]\n';
  diagram += '        R5[Refined Team]\n';
  diagram += '        R6[Refined Delivery]\n';
  diagram += '    end\n\n';

  // Connections
  diagram += '    I1 --> R1\n';
  diagram += '    I2 --> R2\n';
  diagram += '    I3 --> R3\n';
  diagram += '    I4 --> R4\n';
  diagram += '    I5 --> R5\n';
  diagram += '    I6 --> R6\n\n';

  // Epic Document
  diagram += `    subgraph Epic["${projectName} Epic"]\n`;
  diagram += '        E[17-Section Document]\n';
  diagram += '    end\n\n';

  diagram += '    R1 --> E\n';
  diagram += '    R2 --> E\n';
  diagram += '    R3 --> E\n';
  diagram += '    R4 --> E\n';
  diagram += '    R5 --> E\n';
  diagram += '    R6 --> E\n';

  return diagram;
}

// Main skill runner
export async function runSkill(
  skill: 'refine' | 'generate',
  params: {
    stageId?: string;
    fieldName?: string;
    input?: string;
    context?: Record<string, string>;
    data?: RefinedData;
    projectName?: string;
  }
): Promise<RefineResult | GenerateResult> {
  if (skill === 'refine') {
    return refineInput(
      params.stageId!,
      params.fieldName!,
      params.input!,
      params.context || {}
    );
  } else {
    return generateEpic(params.data!, params.projectName!);
  }
}

// ===========================================
// INTELLIGENT PLANTUML GENERATION
// ===========================================

// Diagram types that can be generated based on context
type DiagramType =
  | 'c4-container'      // Best for system architecture overview
  | 'component'         // Best for internal component structure
  | 'sequence'          // Best for user flows and interactions
  | 'deployment';       // Best for infrastructure and environments

interface DiagramContext {
  hasArchitecture: boolean;
  hasFeatures: boolean;
  hasUserStories: boolean;
  hasDataStores: boolean;
  hasEnvironments: boolean;
  hasDeploymentDetails: boolean;
  hasWorkflows: boolean;
  featureCount: number;
  componentCount: number;
  integrationCount: number;
}

// Analyze epic data to understand what type of diagram would be most valuable
function analyzeEpicContext(data: RefinedData): DiagramContext {
  const archText = (data['architectureOverview']?.original || '').toLowerCase();
  const featuresText = data['features']?.original || '';
  const storiesText = data['userStories']?.original || '';
  const dataText = data['dataStores']?.original || '';
  const envsText = data['environments']?.original || '';

  // Count meaningful items
  const featureLines = featuresText.split('\n').filter(l => l.trim().length > 3);
  const componentMatches = archText.match(/\b(service|component|module|layer|api|database|cache|queue|gateway)\b/gi) || [];
  const integrationMatches = archText.match(/\b(integration|external|third-party|api|webhook|oauth|sso)\b/gi) || [];

  return {
    hasArchitecture: archText.length > 50,
    hasFeatures: featureLines.length > 0,
    hasUserStories: storiesText.length > 50,
    hasDataStores: dataText.length > 30,
    hasEnvironments: envsText.length > 30,
    hasDeploymentDetails: envsText.toLowerCase().includes('deploy') || envsText.toLowerCase().includes('kubernetes') || envsText.toLowerCase().includes('docker'),
    hasWorkflows: storiesText.toLowerCase().includes('when') || storiesText.toLowerCase().includes('then') || archText.includes('flow'),
    featureCount: featureLines.length,
    componentCount: new Set(componentMatches.map(m => m.toLowerCase())).size,
    integrationCount: new Set(integrationMatches.map(m => m.toLowerCase())).size,
  };
}

// Intelligently select the best diagram type based on context
function selectBestDiagramType(context: DiagramContext): DiagramType {
  // Priority scoring for diagram types that support horizontal layout
  const scores: Record<string, number> = {
    'c4-container': 2, // Default baseline score
    'component': 0,
    'sequence': 0,
    'deployment': 0,
  };

  // Score based on available data
  if (context.hasArchitecture && context.componentCount >= 3) {
    scores['c4-container'] += 5;
    scores['component'] += 4;
  }

  if (context.hasUserStories && context.hasWorkflows) {
    scores['sequence'] += 5;
  }

  if (context.hasDeploymentDetails && context.hasEnvironments) {
    scores['deployment'] += 5;
  }

  if (context.hasDataStores && context.componentCount >= 2) {
    scores['component'] += 2;
  }

  if (context.integrationCount >= 2) {
    scores['c4-container'] += 3;
    scores['sequence'] += 2;
  }

  // C4 is a good default for architecture-focused epics
  if (context.hasArchitecture) {
    scores['c4-container'] += 2;
  }

  // Find highest scoring type (only from our supported horizontal types)
  let bestType: DiagramType = 'c4-container';
  let highestScore = 0;

  for (const [type, score] of Object.entries(scores)) {
    if (score > highestScore) {
      highestScore = score;
      bestType = type as DiagramType;
    }
  }

  return bestType;
}

// Extract meaningful components from architecture text
function extractComponents(archText: string): string[] {
  const components: string[] = [];
  const lines = archText.split('\n');

  for (const line of lines) {
    // Look for bold items like **Component Name**
    const boldMatches = line.match(/\*\*([^*]+)\*\*/g);
    if (boldMatches) {
      boldMatches.forEach(m => {
        const cleaned = m.replace(/\*\*/g, '').trim();
        if (cleaned.length > 2 && cleaned.length < 40) {
          components.push(cleaned);
        }
      });
    }

    // Look for list items
    const listMatch = line.match(/^[-•*]\s*(.+?)(?:\s*[-:]|$)/);
    if (listMatch && listMatch[1].length > 2 && listMatch[1].length < 40) {
      components.push(listMatch[1].trim());
    }
  }

  return [...new Set(components)].slice(0, 8);
}

// Extract user stories for sequence diagrams
function extractUserFlows(storiesText: string): { actor: string; action: string; target: string }[] {
  const flows: { actor: string; action: string; target: string }[] = [];
  const lines = storiesText.split('\n');

  for (const line of lines) {
    // Parse "As a [role], I want [action] so that [benefit]"
    const storyMatch = line.match(/as\s+(?:a|an)\s+(\w+).*?(?:I want|I need|I can)\s+(.+?)(?:\s+so that|\s+in order|$)/i);
    if (storyMatch) {
      flows.push({
        actor: storyMatch[1].charAt(0).toUpperCase() + storyMatch[1].slice(1),
        action: storyMatch[2].trim().slice(0, 50),
        target: 'System',
      });
    }
  }

  return flows.slice(0, 6);
}

// Generate C4-style Container diagram using Mermaid - great for system overview
function generateC4ContainerDiagram(data: RefinedData, projectName: string): string {
  const arch = data['architectureOverview']?.original || '';
  const dataStores = data['dataStores']?.original || '';

  const components = extractComponents(arch);
  const hasDB = dataStores.toLowerCase().includes('database') || dataStores.toLowerCase().includes('postgres') || dataStores.toLowerCase().includes('mysql') || dataStores.toLowerCase().includes('warehouse');
  const hasCache = dataStores.toLowerCase().includes('cache') || dataStores.toLowerCase().includes('redis') || dataStores.toLowerCase().includes('memcache');
  const hasQueue = dataStores.toLowerCase().includes('queue') || dataStores.toLowerCase().includes('kafka') || dataStores.toLowerCase().includes('rabbit') || dataStores.toLowerCase().includes('streaming');
  const hasNoSQL = dataStores.toLowerCase().includes('nosql') || dataStores.toLowerCase().includes('mongodb') || dataStores.toLowerCase().includes('cassandra');
  const hasFrontend = arch.toLowerCase().includes('frontend') || arch.toLowerCase().includes('react') || arch.toLowerCase().includes('ui') || arch.toLowerCase().includes('user interface');
  const hasAPI = arch.toLowerCase().includes('api') || arch.toLowerCase().includes('gateway') || arch.toLowerCase().includes('rest');
  const hasAnalytics = arch.toLowerCase().includes('analytics') || arch.toLowerCase().includes('machine learning') || arch.toLowerCase().includes('ml');
  const hasExternal = arch.toLowerCase().includes('external') || arch.toLowerCase().includes('third-party') || arch.toLowerCase().includes('integration');

  // Sanitize project name for Mermaid
  const safeProjectName = projectName.replace(/[^a-zA-Z0-9\s]/g, '').trim() || 'System';

  let mermaid = `flowchart LR\n`;

  // User
  mermaid += `    U((User))\n`;

  // Frontend
  if (hasFrontend) {
    mermaid += `    subgraph Frontend["Frontend"]\n`;
    mermaid += `        WA[Web App]\n`;
    mermaid += `    end\n`;
  }

  // Backend
  mermaid += `    subgraph Backend["Backend Services"]\n`;
  if (hasAPI) {
    mermaid += `        API[API Gateway]\n`;
  }
  if (components.length > 0) {
    components.slice(0, 3).forEach((comp, i) => {
      const safeComp = comp.replace(/[^a-zA-Z0-9\s]/g, '').trim().slice(0, 15) || `Service${i}`;
      mermaid += `        SVC${i}[${safeComp}]\n`;
    });
  } else {
    mermaid += `        SVC0[Services]\n`;
  }
  if (hasAnalytics) {
    mermaid += `        ANA[Analytics]\n`;
  }
  mermaid += `    end\n`;

  // Data layer - always include at least a database
  mermaid += `    subgraph Data["Data Layer"]\n`;
  if (hasDB || (!hasCache && !hasQueue && !hasNoSQL)) {
    mermaid += `        DB[(Database)]\n`;
  }
  if (hasCache) {
    mermaid += `        CACHE[(Cache)]\n`;
  }
  if (hasQueue) {
    mermaid += `        QUEUE[(Queue)]\n`;
  }
  if (hasNoSQL) {
    mermaid += `        NOSQL[(NoSQL)]\n`;
  }
  mermaid += `    end\n`;

  if (hasExternal) {
    mermaid += `    EXT{{External API}}\n`;
  }

  // Connections
  if (hasFrontend) {
    mermaid += `    U --> WA\n`;
    if (hasAPI) {
      mermaid += `    WA --> API\n`;
    } else {
      mermaid += `    WA --> SVC0\n`;
    }
  } else if (hasAPI) {
    mermaid += `    U --> API\n`;
  } else {
    mermaid += `    U --> SVC0\n`;
  }

  if (hasAPI) {
    mermaid += `    API --> SVC0\n`;
    if (hasAnalytics) {
      mermaid += `    API --> ANA\n`;
    }
  }

  // Service connections to data - always connect to DB since we always have it
  mermaid += `    SVC0 --> DB\n`;
  if (hasAnalytics) {
    mermaid += `    ANA --> DB\n`;
  }
  if (hasCache) {
    mermaid += `    SVC0 --> CACHE\n`;
  }
  if (hasQueue) {
    mermaid += `    SVC0 --> QUEUE\n`;
  }
  if (hasNoSQL) {
    mermaid += `    SVC0 --> NOSQL\n`;
  }
  if (hasExternal) {
    mermaid += `    SVC0 --> EXT\n`;
  }

  return mermaid;
}

// Generate Sequence diagram using Mermaid - great for user flows
function generateSequenceDiagram(data: RefinedData, projectName: string): string {
  const stories = data['userStories']?.original || '';
  const flows = extractUserFlows(stories);

  let mermaid = `sequenceDiagram
    autonumber
    participant U as User
    participant UI as Web App
    participant API as API
    participant SVC as Service
    participant DB as Database
`;

  if (flows.length > 0) {
    flows.forEach((flow, index) => {
      // Sanitize the action text
      const safeAction = flow.action.replace(/[^a-zA-Z0-9\s]/g, '').trim().slice(0, 30);
      const shortAction = safeAction.slice(0, 20);

      if (index > 0) mermaid += `\n`;
      mermaid += `    Note over U,DB: ${safeAction}\n`;
      mermaid += `    U->>+UI: ${shortAction}\n`;
      mermaid += `    UI->>+API: Request\n`;
      mermaid += `    API->>+SVC: Process\n`;
      mermaid += `    SVC->>+DB: Query\n`;
      mermaid += `    DB-->>-SVC: Result\n`;
      mermaid += `    SVC-->>-API: Response\n`;
      mermaid += `    API-->>-UI: Data\n`;
      mermaid += `    UI-->>-U: Display\n`;
    });
  } else {
    // Generic flow based on common patterns
    mermaid += `    Note over U,DB: Main Application Flow\n`;
    mermaid += `    U->>+UI: Access Application\n`;
    mermaid += `    UI->>+API: Request Data\n`;
    mermaid += `    API->>+SVC: Process Request\n`;
    mermaid += `    SVC->>+DB: Query Data\n`;
    mermaid += `    DB-->>-SVC: Return Results\n`;
    mermaid += `    SVC-->>-API: Send Response\n`;
    mermaid += `    API-->>-UI: Return Data\n`;
    mermaid += `    UI-->>-U: Display Results\n`;
  }

  return mermaid;
}

// Generate Deployment diagram using Mermaid - great for infrastructure
function generateDeploymentDiagram(data: RefinedData, projectName: string): string {
  const envs = data['environments']?.original || '';

  const hasK8s = envs.toLowerCase().includes('kubernetes') || envs.toLowerCase().includes('k8s');
  const hasDocker = envs.toLowerCase().includes('docker') || envs.toLowerCase().includes('container');

  let mermaid = `flowchart LR
    subgraph CICD["CI/CD Pipeline"]
        BUILD[Build] --> TEST[Test]
        TEST --> DEPLOY[Deploy]
    end

    subgraph Environments["Environments"]
        DEV[Dev]
        STAGE[Staging]
        PROD[Production]
    end

`;

  if (hasK8s) {
    mermaid += `    subgraph Infra["Infrastructure"]
        K8S[Kubernetes]
        DB[(Database)]
    end

`;
  } else if (hasDocker) {
    mermaid += `    subgraph Infra["Infrastructure"]
        DOCKER[Docker]
        DB[(Database)]
    end

`;
  } else {
    mermaid += `    subgraph Infra["Infrastructure"]
        SERVER[Server]
        DB[(Database)]
    end

`;
  }

  // Connections
  mermaid += `    DEPLOY --> DEV\n`;
  mermaid += `    DEPLOY --> STAGE\n`;
  mermaid += `    DEPLOY --> PROD\n`;

  if (hasK8s) {
    mermaid += `    PROD --> K8S\n`;
    mermaid += `    K8S --> DB\n`;
  } else if (hasDocker) {
    mermaid += `    PROD --> DOCKER\n`;
    mermaid += `    DOCKER --> DB\n`;
  } else {
    mermaid += `    PROD --> SERVER\n`;
    mermaid += `    SERVER --> DB\n`;
  }

  return mermaid;
}

// Generate Component diagram using Mermaid - for internal structure
function generateComponentDiagram(data: RefinedData, projectName: string): string {
  const arch = data['architectureOverview']?.original || '';
  const features = data['features']?.original || '';
  const components = extractComponents(arch);
  const featureList = features.split('\n').filter(l => l.trim().length > 3).slice(0, 4);

  let mermaid = `flowchart LR
    subgraph Presentation["Presentation Layer"]
        UI[User Interface]
    end

    subgraph API["API Layer"]
        GW[API Gateway]
    end

    subgraph Services["Service Layer"]
`;

  // Add components from architecture or features
  const compIds: string[] = [];
  if (components.length > 0) {
    components.slice(0, 3).forEach((comp, i) => {
      const safeComp = comp.replace(/[^a-zA-Z0-9\s]/g, '').trim().slice(0, 15) || `Service${i}`;
      compIds.push(`COMP${i}`);
      mermaid += `        COMP${i}[${safeComp}]\n`;
    });
  } else if (featureList.length > 0) {
    featureList.slice(0, 3).forEach((feat, i) => {
      const cleanFeat = feat.replace(/^[\d.\-*]+\s*/, '').replace(/[^a-zA-Z0-9\s]/g, '').trim().slice(0, 15) || `Feature${i}`;
      compIds.push(`COMP${i}`);
      mermaid += `        COMP${i}[${cleanFeat}]\n`;
    });
  } else {
    compIds.push('COMP0');
    mermaid += `        COMP0[Service]\n`;
  }

  mermaid += `    end

    subgraph Data["Data Layer"]
        DB[(Database)]
    end

`;

  // Connections
  mermaid += `    UI --> GW\n`;

  if (compIds.length > 0) {
    mermaid += `    GW --> ${compIds[0]}\n`;
    // Chain components
    for (let i = 0; i < compIds.length - 1; i++) {
      mermaid += `    ${compIds[i]} --> ${compIds[i + 1]}\n`;
    }
    mermaid += `    ${compIds[compIds.length - 1]} --> DB\n`;
  } else {
    mermaid += `    GW --> DB\n`;
  }

  return mermaid;
}

// Main intelligent blueprint generator
export async function generateIntelligentBlueprint(data: RefinedData, projectName: string): Promise<{ diagram: string; type: DiagramType; reasoning: string }> {
  // Add small delay so UI shows loading state
  await mockDelay();

  // Use AI to generate the diagram (Azure OpenAI is always enabled)
  if (currentConfig) {
    try {
      const result = await generateAIPoweredBlueprint(data, projectName);
      return result;
    } catch (error) {
      console.error('AI blueprint generation failed, falling back to rule-based:', error);
    }
  }

  // Rule-based generation (fallback if AI fails)
  const context = analyzeEpicContext(data);
  const diagramType = selectBestDiagramType(context);

  let diagram: string;
  let reasoning: string;

  switch (diagramType) {
    case 'c4-container':
      diagram = generateC4ContainerDiagram(data, projectName);
      reasoning = `Selected C4 Container diagram because the epic has ${context.componentCount} architectural components and focuses on system structure.`;
      break;
    case 'sequence':
      diagram = generateSequenceDiagram(data, projectName);
      reasoning = `Selected Sequence diagram because the epic contains user stories with clear interaction flows.`;
      break;
    case 'deployment':
      diagram = generateDeploymentDiagram(data, projectName);
      reasoning = `Selected Deployment diagram because the epic details deployment environments and infrastructure.`;
      break;
    case 'component':
      diagram = generateComponentDiagram(data, projectName);
      reasoning = `Selected Component diagram to show the internal structure and feature modules.`;
      break;
    default:
      diagram = generateC4ContainerDiagram(data, projectName);
      reasoning = `Selected C4 Container as the default architecture overview diagram.`;
  }

  return { diagram, type: diagramType, reasoning };
}

// AI-powered blueprint generation using Mermaid
async function generateAIPoweredBlueprint(data: RefinedData, projectName: string): Promise<{ diagram: string; type: DiagramType; reasoning: string }> {
  const systemPrompt = `You are an expert software architect who creates Mermaid.js diagrams.
Analyze the epic information and generate the most appropriate Mermaid diagram.

Choose the best diagram type based on the content:
- Architecture: Use flowchart LR with subgraphs for system architecture
- Sequence: Use sequenceDiagram for user flows and interactions
- Deployment: Use flowchart LR with subgraphs for infrastructure
- Component: Use flowchart LR with subgraphs for internal structure

CRITICAL RULES - YOU MUST FOLLOW THESE EXACTLY:
1. Use ONLY valid Mermaid.js syntax
2. For flowcharts: Use "flowchart LR" for left-to-right layout
3. For sequences: Use "sequenceDiagram"
4. Use subgraphs to group related components
5. Node syntax: A[Label] for rectangles, A((Label)) for circles, A[(Label)] for databases, A{{Label}} for hexagons
6. Arrow syntax: --> for solid arrows, -.-> for dotted arrows
7. Use ONLY the actual names, components, and details from the provided epic
8. Keep the diagram focused and readable (max 15 nodes)
9. Do NOT include any markdown code fence markers

MERMAID NODE SYNTAX - CRITICAL (MUST FOLLOW):
10. NODE NAMES: Every node MUST use ID[Label] format. NEVER use bare text after arrows.
    WRONG: A --> Integration Layer
    CORRECT: A --> IL[Integration Layer]
11. NODE IDs: Use short alphanumeric IDs (2-4 chars). Labels with spaces go in brackets.
    WRONG: UserInterface --> Backend Service
    CORRECT: UI[User Interface] --> BS[Backend Service]
12. SPACES IN LABELS: Any label with spaces MUST be inside square brackets with an ID prefix.
    WRONG: --> My Service
    CORRECT: --> MS[My Service]
13. ARROW TARGETS: The right side of every arrow must be EITHER:
    - A previously defined node ID: A --> B
    - A new node definition: A --> B[Label Text]
    NEVER: A --> Some Text With Spaces (THIS WILL CAUSE PARSE ERRORS)

Example flowchart:
flowchart LR
    subgraph Frontend
        UI[Web App]
    end
    subgraph Backend
        API[API Gateway]
        SVC[Service]
    end
    subgraph Data
        DB[(Database)]
    end
    UI --> API
    API --> SVC
    SVC --> DB

Example sequence:
sequenceDiagram
    participant U as User
    participant UI as Web App
    participant API as API
    participant DB as Database
    U->>UI: Request
    UI->>API: Process
    API->>DB: Query
    DB-->>API: Result
    API-->>UI: Response
    UI-->>U: Display

Return your response in this exact format:
TYPE: [architecture|sequence|deployment|component]
REASONING: [one sentence explaining why this type was chosen]
DIAGRAM:
[Mermaid code - just the diagram, no code fences]`;

  const epicSummary = buildEpicSummary(data, projectName);

  const response = await callAI(currentConfig!, systemPrompt, epicSummary);

  // Parse AI response
  const typeMatch = response.match(/TYPE:\s*(\S+)/i);
  const reasoningMatch = response.match(/REASONING:\s*(.+?)(?=DIAGRAM:|$)/is);
  // Match Mermaid diagram - look for flowchart or sequenceDiagram
  const diagramMatch = response.match(/(flowchart\s+(?:LR|TB|TD|RL|BT)[\s\S]*?)(?=TYPE:|REASONING:|$)|(sequenceDiagram[\s\S]*?)(?=TYPE:|REASONING:|$)/i);

  const type = (typeMatch?.[1]?.toLowerCase().replace('-', '_') as DiagramType) || 'c4-container';
  const reasoning = reasoningMatch?.[1]?.trim() || 'AI-generated based on epic content.';
  let diagram = (diagramMatch?.[1] || diagramMatch?.[2] || '').trim();

  // Validate the diagram
  if (diagram) {
    diagram = validateMermaidDiagram(diagram, data, projectName);
  } else {
    diagram = generateC4ContainerDiagram(data, projectName);
  }

  return { diagram, type, reasoning };
}

// Validate Mermaid diagram and fix common issues
function validateMermaidDiagram(mermaid: string, data: RefinedData, projectName: string): string {
  // Remove any code fence markers that might have been included
  mermaid = mermaid.replace(/```mermaid\s*/gi, '').replace(/```\s*/g, '').trim();

  // Check if it starts with a valid Mermaid diagram type
  const validStarts = ['flowchart', 'sequenceDiagram', 'graph', 'stateDiagram', 'classDiagram'];
  const hasValidStart = validStarts.some(start => mermaid.toLowerCase().startsWith(start.toLowerCase()));

  if (!hasValidStart) {
    console.warn('AI generated invalid Mermaid syntax. Falling back to rule-based diagram.');
    return generateC4ContainerDiagram(data, projectName);
  }

  return mermaid;
}

// Build a summary of the epic for AI consumption
function buildEpicSummary(data: RefinedData, projectName: string): string {
  let summary = `Project: ${projectName}\n\n`;

  if (data['objective']?.original) {
    summary += `OBJECTIVE:\n${data['objective'].original}\n\n`;
  }
  if (data['architectureOverview']?.original) {
    summary += `ARCHITECTURE:\n${data['architectureOverview'].original}\n\n`;
  }
  if (data['features']?.original) {
    summary += `FEATURES:\n${data['features'].original}\n\n`;
  }
  if (data['userStories']?.original) {
    summary += `USER STORIES:\n${data['userStories'].original}\n\n`;
  }
  if (data['dataStores']?.original) {
    summary += `DATA STORES:\n${data['dataStores'].original}\n\n`;
  }
  if (data['teams']?.original) {
    summary += `TEAMS:\n${data['teams'].original}\n\n`;
  }
  if (data['environments']?.original) {
    summary += `ENVIRONMENTS:\n${data['environments'].original}\n\n`;
  }

  return summary;
}

// Generate Mermaid Blueprint - Multilayer Epic Overview Diagram (renamed from PlantUML)
export function generatePlantUMLBlueprint(data: RefinedData, projectName: string): string {
  // Extract key data for the diagram
  const features = data['features']?.original?.split('\n').filter(Boolean).slice(0, 4) || ['Feature 1', 'Feature 2'];
  const teams = data['teams']?.original?.split('\n').filter(Boolean).slice(0, 3) || ['Team'];
  const hasDataStores = data['dataStores']?.original ? true : false;
  const deliverables = data['deliverables']?.original?.split('\n').filter(Boolean).slice(0, 3) || ['Deliverable'];

  // Sanitize function
  const sanitize = (s: string) => s.replace(/[^a-zA-Z0-9\s]/g, '').trim().slice(0, 20);

  let mermaid = `flowchart TB
    subgraph Stakeholders["1. Stakeholders"]
        PO((Product Owner))
        TL((Tech Lead))
        BIZ((Business))
    end

    subgraph Requirements["2. Requirements"]
`;

  // Add features
  features.forEach((f, i) => {
    mermaid += `        F${i}[${sanitize(f)}]\n`;
  });

  mermaid += `    end

    subgraph Architecture["3. Architecture"]
        UI[Frontend]
        API[API Gateway]
        SVC[Services]
`;

  if (hasDataStores) {
    mermaid += `        DB[(Database)]
        CACHE[(Cache)]
    end
`;
  } else {
    mermaid += `        DB[(Database)]
    end
`;
  }

  mermaid += `
    subgraph Team["4. Team & Execution"]
`;

  teams.forEach((t, i) => {
    mermaid += `        TM${i}[${sanitize(t)}]\n`;
  });

  mermaid += `        subgraph Pipeline["CI/CD"]
            BUILD[Build] --> TEST[Test] --> DEPLOY[Deploy]
        end
    end

    subgraph Environments["5. Environments"]
        DEV[Development]
        STG[Staging]
        PROD[Production]
    end

    subgraph Deliverables["6. Deliverables"]
`;

  deliverables.forEach((d, i) => {
    mermaid += `        D${i}[${sanitize(d)}]\n`;
  });

  mermaid += `    end

    %% Connections
    PO --> Requirements
    TL --> Requirements
    BIZ --> Requirements

    Requirements --> Architecture
    UI --> API
    API --> SVC
    SVC --> DB
`;

  if (hasDataStores) {
    mermaid += `    SVC --> CACHE
`;
  }

  mermaid += `
    Architecture --> Team
    Team --> Pipeline
    DEPLOY --> DEV
    DEV --> STG
    STG --> PROD

    PROD --> Deliverables
`;

  return mermaid;
}

// ===========================================
// EPIC FEEDBACK CHAT FUNCTIONS
// ===========================================

// Analyze user feedback to determine which section they want to modify
export async function analyzeUserFeedback(
  feedback: string,
  epicSections: string[]
): Promise<{ needsClarification: boolean; suggestedSection?: number; followUpQuestion?: string }> {
  if (!currentConfig) {
    throw new Error('Azure OpenAI is not configured. Please check Settings.');
  }

  const systemPrompt = `You are an assistant helping users modify their epic document.
Analyze the user's feedback to determine which section they want to modify.

Available sections:
${epicSections.map((s, i) => `${i + 1}. ${s}`).join('\n')}

Based on the user's feedback:
1. Can you confidently identify which section(s) the user is referring to?
2. Do you need more information to make the change?

Return a JSON object (no markdown, just raw JSON):
{
  "needsClarification": boolean,
  "suggestedSection": number or null (1-17),
  "followUpQuestion": "question to ask user" or null
}

If the feedback clearly mentions a specific section (by name or number), set needsClarification to false and suggestedSection to that section number.
If the feedback is vague or could apply to multiple sections, set needsClarification to true and ask a clarifying question.`;

  const userPrompt = `User feedback: "${feedback}"

Return JSON only:`;

  const response = await callAI(currentConfig, systemPrompt, userPrompt);

  // Clean up response and parse JSON
  let cleanResponse = response.trim();
  // Remove markdown code fences if present
  cleanResponse = cleanResponse.replace(/```json\s*/gi, '').replace(/```\s*/g, '').trim();

  try {
    return JSON.parse(cleanResponse);
  } catch {
    // If parsing fails, ask for clarification
    return {
      needsClarification: true,
      suggestedSection: undefined,
      followUpQuestion: 'Which section would you like me to update?'
    };
  }
}

// Process user feedback and generate updated section content
export async function processFeedback(
  feedback: string,
  currentEpic: string,
  targetSection: number,
  additionalContext?: string
): Promise<{ updatedSection: string; explanation: string }> {
  if (!currentConfig) {
    throw new Error('Azure OpenAI is not configured. Please check Settings.');
  }

  const sectionTitle = EPIC_SECTIONS[targetSection - 1]?.title || `Section ${targetSection}`;

  const systemPrompt = `You are an expert technical writer helping to modify an epic document.
The user wants to modify section "${sectionTitle}" of their epic document.

RULES:
1. Only modify the specified section - do not touch other sections
2. Return the updated section content in markdown format
3. Preserve the section header format: "## ${targetSection}. ${sectionTitle}"
4. Keep the same style and tone as the rest of the document
5. Be concise but thorough
6. If the section has subsections, preserve them
7. Do not add unnecessary fluff - make meaningful improvements based on the feedback

Return a JSON object (no markdown, just raw JSON):
{
  "updatedSection": "## ${targetSection}. ${sectionTitle}\\n\\n[updated content here]",
  "explanation": "Brief 1-2 sentence explanation of changes made"
}`;

  const userPrompt = `CURRENT EPIC DOCUMENT:
${currentEpic}

USER FEEDBACK: ${feedback}
${additionalContext ? `\nADDITIONAL CONTEXT: ${additionalContext}` : ''}

TARGET SECTION: ${targetSection}. ${sectionTitle}

Return JSON only:`;

  const response = await callAI(currentConfig, systemPrompt, userPrompt);

  // Clean up response and parse JSON
  let cleanResponse = response.trim();
  cleanResponse = cleanResponse.replace(/```json\s*/gi, '').replace(/```\s*/g, '').trim();

  try {
    return JSON.parse(cleanResponse);
  } catch {
    // If parsing fails, return a generic error response
    throw new Error('Failed to parse AI response. Please try again.');
  }
}

// Fix Mermaid diagram syntax errors using AI
export async function fixMermaidDiagram(
  failedCode: string,
  errorMessage: string
): Promise<string> {
  if (!currentConfig) {
    throw new Error('Config not set. Cannot fix diagram without AI.');
  }

  const systemPrompt = `You are a Mermaid.js syntax expert.
A diagram failed to render with the following error. Fix the syntax while keeping the EXACT same structure, nodes, and connections.

RULES:
1. Return ONLY the fixed Mermaid code - no explanations, no markdown
2. Keep the same diagram type (flowchart/sequence/etc)
3. DO NOT simplify or remove any nodes/connections - only fix syntax errors
4. Ensure all node IDs are valid (alphanumeric, underscores allowed, no spaces or special chars)
5. Ensure all labels are properly quoted with double quotes if they contain special characters
6. Fix any invalid arrow syntax or subgraph definitions
7. Ensure subgraphs have proper opening and closing
8. Do NOT include markdown code fences like \`\`\`mermaid or \`\`\``;

  const userPrompt = `ERROR MESSAGE:
${errorMessage}

FAILED MERMAID CODE:
${failedCode}

Return ONLY the fixed Mermaid code:`;

  const response = await callAI(currentConfig, systemPrompt, userPrompt);

  // Clean up response - remove any code fences
  let fixed = response
    .replace(/```mermaid\s*/gi, '')
    .replace(/```\s*/g, '')
    .trim();

  return fixed;
}

