# Dynamic Template Architecture Design

> **A comprehensive blueprint-driven architecture for the Epic Generator v4 wizard system, enabling variable stages, dynamic field types, and configurable output sections.**

---

## Table of Contents

1. [Meta & Progress Log](#meta)
2. [Discovery Phase](#iteration-1---2026-01-24) (Iterations 1-3)
   - STAGES and EPIC_SECTIONS analysis
   - renderWizard() patterns
   - AI integration patterns
3. [Pattern Extraction Phase](#iteration-4---2026-01-24) (Iterations 4-5)
   - Field type enumeration
   - Validation rules
   - AI prompt registry
   - Render type specifications
4. [Blueprint Schema Design](#iteration-6---2026-01-24) (Iterations 6-7)
   - Complete TypeScript schema
   - Blueprint loader
   - Technical Architect template example
5. [Architecture Design](#iteration-8---2026-01-24) (Iterations 8-9)
   - Dynamic wizard renderer
   - Blueprint context provider
   - State management
   - Template selector UI
   - Migration plan
6. [Implementation Planning](#iteration-10---2026-01-24) (Iterations 10-11)
   - Prioritized task list
   - Testing strategy
   - MVP definition
   - API migration guide
7. [Architecture Refinement](#iteration-12---2026-01-24) (Iterations 12-14)
   - Data flow diagrams
   - Edge case analysis
   - AI prompt templates
   - Performance optimization
   - Extensibility patterns
8. [Finalization](#iteration-15---2026-01-24) (Iterations 15-18)
   - Test matrix
   - CI/CD integration
   - Risk assessment
   - Executive summary
   - Quick-start guide
   - Implementation checklist
   - Known limitations
9. [Final Summary](#final-summary---iteration-19)

---

## Document Statistics

| Metric | Value |
|--------|-------|
| Iterations completed | 19/20 |
| Source files analyzed | 4 (types.ts, App.tsx, skills.ts, config.ts) |
| Lines of code reviewed | ~7,500 |
| Blueprint interfaces defined | 25+ |
| Implementation tasks identified | 48 |
| Test cases documented | 80+ |
| Estimated implementation hours | 207 (MVP: 72) |

---

## Meta
- Last Updated: 2026-01-24 - Iteration 20 (FINAL)
- Current Iteration: 20/20
- Current Phase: COMPLETE
- Completion Status: 100%

## Progress Log

### Iteration 1 - 2026-01-24
**Files Analyzed:**
- `src/types.ts` (174 lines) - COMPLETE
- `src/App.tsx` (lines 1-500, 1175-1575) - PARTIAL (renderWizard function analyzed)
- `src/skills.ts` (lines 1-1000) - PARTIAL (field prompts and AI integration patterns)
- `src/config.ts` (lines 1-300) - PARTIAL (configuration interfaces)

**Key Findings:**

#### 1. STAGES Array Structure (types.ts:83-152)
The current system defines 6 hardcoded stages:

```typescript
export interface Stage {
  id: string;           // Unique identifier (e.g., 'project', 'objective_scope')
  title: string;        // Display title
  description: string;  // Stage description
  fields: StageField[]; // Array of input fields
  populatesSections: number[];  // Which of 17 epic sections this populates
}

export interface StageField {
  name: string;         // Field identifier
  label: string;        // Display label
  placeholder: string;  // Input placeholder text
  type: 'text' | 'textarea';  // Only 2 field types currently
  required: boolean;
}
```

**Current Stages:**
1. `project` - projectName, background
2. `objective_scope` - objective, inScope, outOfScope
3. `architecture` - assumptions, architectureOverview, dataStores
4. `features` - features, userStories, nfrs, deliverables
5. `team_env` - teams, environments, security
6. `delivery` - dependencies, risks, nextSteps, dod, approvers

**Total: 19 fields across 6 stages**

#### 2. EPIC_SECTIONS Array Structure (types.ts:155-173)
17 output sections with metadata:

```typescript
interface EpicSection {
  num: number;              // Section number (1-17)
  title: string;           // Section title
  dataKeys: string[];      // Which field(s) populate this section
  subsections?: string[];  // For sections with sub-parts
  isTable?: boolean;       // Render as table (teams, approvers)
  hasDiagram?: boolean;    // Architecture overview
  isReference?: boolean;   // Architecture diagrams (embed mermaid)
}
```

#### 3. renderWizard() Function Pattern (App.tsx:1175-1368)
The wizard rendering follows a consistent pattern:
- Iterates over `currentStage.fields` using `.map()`
- For each field:
  - Renders label with required indicator
  - Shows Refine/Auto suggestion buttons
  - Renders text input OR textarea based on `field.type`
  - Shows alternative suggestions if available
  - Shows "AI Refined" section if content was refined
- Navigation: Previous/Next buttons with stage validation
- Section preview showing 17 EPIC_SECTIONS with populated indicators

#### 4. AI Integration Pattern (skills.ts:56-98)
Field-specific prompts are defined in a nested structure:

```typescript
const fieldPrompts: Record<string, Record<string, string>> = {
  [stageId]: {
    [fieldName]: 'System prompt for this field...',
  }
}
```

**AI Skill Types:**
- `refine` - Enhances user input with AI
- `generate` - Creates full 17-section epic
- `getSuggestion` - Gets AI suggestion for a field (with-context or auto mode)

#### 5. State Management Pattern (App.tsx)
Uses React useState with this shape:

```typescript
interface EpicState {
  currentStage: number;    // 0-based stage index
  data: RefinedData;       // Field data with original/refined values
  diagramNodes: string[];  // Mermaid diagram nodes
  generatedEpic: string | null;  // Final markdown
}

interface RefinedData {
  [fieldName: string]: {
    original: string;
    refined: string;
    diagramNode: string;
  };
}
```

**Decisions Made:**
1. The architecture is fundamentally loop-based over STAGES array - good foundation for dynamic templates
2. Field types are limited (text/textarea only) - needs expansion for flexibility
3. AI prompts are hardcoded per field - needs extraction to blueprint configuration
4. populatesSections creates mapping between input stages and output sections

**Open Questions:**
1. How is stage validation performed? (Need to analyze further)
2. Are there dependencies between fields? (Cross-field validation)
3. How are blueprints/diagrams generated from data? (Need deeper skills.ts analysis)
4. What's the epic generation flow in detail?

**Next Steps:**
- Continue reading App.tsx to find state management handlers (handleFieldChange, nextStage, etc.)
- Complete skills.ts analysis for diagram generation
- Analyze how EPIC_SECTIONS drives epic output generation
- Document all hardcoded stage/field references

---

## Architecture Design (Cumulative)

### Current Architecture Overview

```mermaid
flowchart TD
    subgraph Input["Wizard Input Layer"]
        S1[Stage 1: Project]
        S2[Stage 2: Objective & Scope]
        S3[Stage 3: Architecture]
        S4[Stage 4: Features]
        S5[Stage 5: Team & Env]
        S6[Stage 6: Delivery]
    end

    subgraph AI["AI Processing"]
        REF[Refine Skill]
        SUG[Suggestion Skill]
    end

    subgraph Output["Epic Output Layer"]
        GEN[Generate Epic]
        SEC[17 Sections]
    end

    S1 --> REF
    S2 --> REF
    S3 --> REF
    S4 --> REF
    S5 --> REF
    S6 --> REF

    REF --> GEN
    SUG --> REF
    GEN --> SEC
```

### Key Hardcoded Dependencies Identified

| Location | Hardcoded Element | Lines | Impact |
|----------|-------------------|-------|--------|
| types.ts | STAGES array | 83-152 | Defines all 6 wizard stages |
| types.ts | EPIC_SECTIONS array | 155-173 | Defines all 17 output sections |
| skills.ts | fieldPrompts object | 62-95 | AI prompts per stage/field |
| skills.ts | refinements object | 173-266 | Mock refinement logic per field |
| skills.ts | fieldGuidance object | 130-151 | Generation guidance per field |
| App.tsx | renderWizard() | 1175-1368 | Field rendering (partially dynamic) |

### Field Type Analysis

Current field types: `'text' | 'textarea'`

Fields by type:
- **text (1):** projectName
- **textarea (18):** All other fields

**Observation:** The system is essentially all textareas except project name. A dynamic system should support more field types.

---

## Self-Critique (Iteration 1)

**Positive:**
- Successfully identified core data structures (Stage, StageField, EpicSection)
- Found the key hardcoded arrays (STAGES, EPIC_SECTIONS, fieldPrompts)
- Understood the basic rendering loop in renderWizard()

**Concerns:**
- Haven't yet seen the full state management flow
- The populatesSections mapping is interesting but need to understand how it's used in generation
- Limited field types may constrain what dynamic templates can express

**Questions for Next Iteration:**
1. How does nextStage() handle validation and state updates?
2. How does generateEpic() use EPIC_SECTIONS to build the markdown?
3. What other UI components would need to become dynamic?

---

## Blueprint Schema (Draft v0.1)

Based on initial findings, here's an early draft of what a Blueprint schema might look like:

```typescript
interface WizardBlueprint {
  id: string;
  name: string;
  version: string;
  description: string;

  // Wizard stages configuration
  stages: BlueprintStage[];

  // Output sections configuration
  outputSections: BlueprintSection[];

  // AI configuration per field
  aiPrompts: Record<string, BlueprintFieldPrompt>;

  // Validation rules
  validations?: BlueprintValidation[];
}

interface BlueprintStage {
  id: string;
  title: string;
  description: string;
  fields: BlueprintField[];
  populatesOutputSections: string[];  // Reference by section ID, not number
}

interface BlueprintField {
  name: string;
  label: string;
  placeholder: string;
  type: FieldType;  // Expanded types
  required: boolean;
  defaultValue?: string;
  validation?: FieldValidation;
  aiEnabled?: boolean;
}

type FieldType =
  | 'text'
  | 'textarea'
  | 'select'
  | 'multi-select'
  | 'date'
  | 'number'
  | 'checkbox'
  | 'rich-text';

interface BlueprintSection {
  id: string;
  num: number;
  title: string;
  dataKeys: string[];
  renderType: 'text' | 'table' | 'list' | 'diagram' | 'reference';
  subsections?: string[];
  tableColumns?: string[];
}
```

**Note:** This is a preliminary schema that will be refined as more code is analyzed.

---

---

### Iteration 2 - 2026-01-24
**Files Analyzed:**
- `src/App.tsx` (lines 630-830, 942-1141) - State management, handlers, epic generation
- `src/skills.ts` (lines 1000-1300) - AI blueprint generation with extensive prompt engineering

**Key Findings:**

#### 6. State Management Deep Dive (App.tsx:630-740)

The application maintains extensive state using React hooks:

```typescript
// Core wizard state
const [state, setState] = useState<EpicState>(initialState);
const [formData, setFormData] = useState<Record<string, string>>({});
const [editingRefined, setEditingRefined] = useState<Record<string, boolean>>({});
const [loadingSuggestion, setLoadingSuggestion] = useState<Record<string, boolean>>({});
const [alternatives, setAlternatives] = useState<Record<string, string[]>>({});

// Generation state
const [isRefining, setIsRefining] = useState(false);
const [isGenerating, setIsGenerating] = useState(false);
const [generationProgress, setGenerationProgress] = useState({ current: 0, total: 17, section: '' });

// UI state
const [activeTab, setActiveTab] = useState<'wizard' | 'epic' | 'blueprint' | 'settings'>('epic');
const [editableEpic, setEditableEpic] = useState<string>('');
const [blueprintCode, setBlueprintCode] = useState<string>('');
```

**Key Insight:** State is spread across many useState hooks. A dynamic system would need a more consolidated state model.

#### 7. Handler Functions Analysis (App.tsx:942-1083)

**handleFieldChange (line 942):**
```typescript
const handleFieldChange = (fieldName: string, value: string) => {
  setFormData(prev => ({ ...prev, [fieldName]: value }));
};
```
Simple key-value update - already dynamic, no hardcoding.

**handleGetSuggestion (line 987):**
- Takes `fieldName` and `mode` ('with-context' | 'auto')
- Builds context from all form data
- Calls `getSuggestion(currentStage.id, fieldName, context, mode)`
- Uses typewriter effect for visual appeal
- **Dependency:** References `currentStage.id` - stage ID needed for AI prompt selection

**nextStage (line 1055):**
```typescript
const nextStage = async () => {
  await refineStage();  // Refine all fields in current stage
  if (isLastStage) {
    generateEpic();
  } else {
    setState(prev => ({ ...prev, currentStage: prev.currentStage + 1 }));
    setFormData({});
    setAlternatives({});
    setEditingRefined({});
  }
};
```
- Automatic refinement on stage transition
- Last stage triggers epic generation
- Clears form data for next stage

**prevStage (line 1068):**
- Decrements stage counter
- Restores formData from `state.data[field.name].original` for previous stage fields
- **Hardcoded:** Uses `STAGES[state.currentStage - 1].fields` to get field list

#### 8. refineStage Function (App.tsx:1015-1052)

```typescript
const refineStage = useCallback(async () => {
  for (const field of currentStage.fields) {
    const input = formData[field.name] || '';
    if (input.trim()) {
      const result = await runSkill('refine', {
        stageId: currentStage.id,
        fieldName: field.name,
        input,
        context,
      }) as RefineResult;

      newData[field.name] = {
        original: input,
        refined: result.refined,
        diagramNode: result.diagramNode,
      };
    }
  }
}, [currentStage, formData, state.data, state.diagramNodes, getContext]);
```

**Key Pattern:** Iterates over `currentStage.fields` - this is already dynamic based on the stage definition.

#### 9. generateEpic Function (App.tsx:1086-1141)

```typescript
const generateEpic = async () => {
  // Progress animation through 17 sections
  const sections = [
    'Objective', 'Background & Context', 'Scope', 'Assumptions',
    'Architecture Overview', 'Architecture Diagrams', 'Team & Roles',
    'Environments & CI/CD', 'Data Security', 'Data Stores & Services',
    'Key Features', 'Non-Functional Requirements', 'Dependencies & Risks',
    'Deliverables', 'Next Steps', 'Definition of Done', 'Approvals'
  ];

  // Animate progress
  for (let i = 0; i < sections.length; i++) {
    setGenerationProgress({ current: i + 1, total: 17, section: sections[i] });
  }

  // Generate Blueprint first
  const blueprintResult = await generateIntelligentBlueprint(state.data, projectName);

  // Generate Epic with blueprint
  const result = await runSkill('generate', {
    data: state.data,
    projectName,
    blueprintCode: generatedBlueprintCode,
  }) as GenerateResult;
};
```

**Hardcoded Elements:**
1. `sections` array (line 1091-1097) - hardcoded section names for progress display
2. `total: 17` - hardcoded section count

#### 10. getPopulatedSections Function (App.tsx:1161-1170)

```typescript
const getPopulatedSections = () => {
  const populated = new Set<number>();
  STAGES.slice(0, state.currentStage + 1).forEach(stage => {
    const hasData = stage.fields.some(f => state.data[f.name]?.refined);
    if (hasData) {
      stage.populatesSections.forEach(s => populated.add(s));
    }
  });
  return populated;
};
```

**Key Insight:** Uses `populatesSections` from stage definition to track which output sections have data. This is a critical mapping that must be preserved in dynamic templates.

#### 11. AI Blueprint Generation (skills.ts:1032-1300)

The AI blueprint generation includes an extensive system prompt with:

1. **Intelligent Diagram Type Selection** (lines 1043-1082)
   - 18 diagram types based on content patterns
   - Decision heuristics for type selection

2. **Semantic Color System** (lines 1096-1158)
   - Colorblind-safe palette (Okabe-Ito)
   - Domain-specific color overrides (finance, health, ecommerce, etc.)
   - WCAG 2.1 accessibility requirements

3. **Mermaid Syntax Rules** (lines 1160-1210)
   - Node ID format requirements
   - Special character restrictions
   - Subgraph naming rules
   - Strict command ordering

4. **Node Shapes by Semantic Role** (lines 1212-1225)
   - Services/APIs: Rectangle `ID[Label]`
   - Databases: Cylinder `ID[(Label)]`
   - External APIs: Hexagon `ID{{Label}}`
   - Decisions: Diamond `ID{Label}`

5. **Arrow Semantics** (lines 1228-1277)
   - Line styles for sync/async flows
   - Color coding by flow type
   - Label conventions

**Key Insight:** This is essentially a "mini-blueprint" for diagram generation. The dynamic system should allow customizing these rules per template.

**Decisions Made:**
1. State management is mostly dynamic - fields are accessed by name, not hardcoded
2. The STAGES array is the single source of truth for wizard structure
3. populatesSections mapping is critical for output generation
4. AI prompt engineering is extensive and domain-specific - needs to be extractable

**Open Questions:**
1. How does skills.ts generateEpic() build markdown from EPIC_SECTIONS?
2. Are there any field-name specific behaviors outside of AI prompts?
3. How would validation rules be expressed in a blueprint?

---

## Updated Hardcoded Dependencies

| Location | Hardcoded Element | Lines | Dynamic? | Migration Effort |
|----------|-------------------|-------|----------|------------------|
| types.ts | STAGES array | 83-152 | No | High - core data structure |
| types.ts | EPIC_SECTIONS array | 155-173 | No | High - output template |
| skills.ts | fieldPrompts | 62-95 | No | Medium - extract to config |
| skills.ts | refinements | 173-266 | No | Medium - extract to config |
| skills.ts | fieldGuidance | 130-151 | No | Medium - extract to config |
| skills.ts | AI diagram prompts | 1032-1300 | No | Low - template-level config |
| App.tsx | sections array | 1091-1097 | No | Low - derive from config |
| App.tsx | Progress total: 17 | 1101 | No | Low - derive from config |

---

### Iteration 3 - 2026-01-24
**Files Analyzed:**
- `src/skills.ts` (lines 280-400, 2186-2340) - Epic generation and reverse parsing
- Comprehensive grep for hardcoded field names across all files

**Key Findings:**

#### 12. generateEpic Function Analysis (skills.ts:280-343)

The epic generation follows a clear pattern iterating over EPIC_SECTIONS:

```typescript
async function generateEpic(data: RefinedData, projectName: string, blueprintCode?: string): Promise<GenerateResult> {
  let epic = `# Technical Design Epic: ${projectName}\n\n`;
  epic += `*Generated on ${new Date().toLocaleDateString()}*\n\n---\n\n`;

  for (const section of EPIC_SECTIONS) {
    epic += `## ${section.num}. ${section.title}\n\n`;

    if (section.subsections) {
      // Handle sections with subsections (Scope, Dependencies & Risks)
      section.dataKeys.forEach((key, idx) => {
        const subsectionTitle = section.subsections![idx];
        const content = data[key]?.refined || '_To be defined_';
        epic += `### ${section.num}.${idx + 1} ${subsectionTitle}\n\n${content}\n\n`;
      });
    } else if (section.isTable && section.dataKeys[0] === 'teams') {
      // Team & Roles table - HARDCODED FIELD CHECK
      epic += `| Role | Responsibility |\n|------|----------------|\n`;
      const teamData = data['teams']?.refined || 'Team structure to be defined';
      // ... table generation
    } else if (section.isTable && section.dataKeys[0] === 'approvers') {
      // Approvals table - HARDCODED FIELD CHECK
      epic += `| Approver | Role | Status |\n|----------|------|--------|\n`;
      // ... table generation
    } else if (section.hasDiagram) {
      // Architecture overview
      const content = data[section.dataKeys[0]]?.refined || '_Architecture details to be defined_';
    } else if (section.isReference) {
      // Embed mermaid diagram
      if (blueprintCode) {
        epic += '```mermaid\n' + blueprintCode + '\n```\n\n';
      }
    } else {
      // Standard section - fully dynamic
      const content = section.dataKeys
        .map(key => data[key]?.refined)
        .filter(Boolean)
        .join('\n\n') || '_To be defined_';
    }
  }
  return { epic, diagram };
}
```

**Critical Observation:** The section rendering has special cases for:
1. `isTable` sections with specific field checks ('teams', 'approvers')
2. `hasDiagram` sections
3. `isReference` sections
4. `subsections` handling

These render types should be configurable in the blueprint.

#### 13. parseEpicToStageData Function (skills.ts:2186-2314)

This function reverse-parses an epic back into wizard data:

```typescript
export function parseEpicToStageData(epicMarkdown: string): {
  data: RefinedData;
  missingFields: string[];
  projectName: string;
}
```

**Key Logic:**
1. Extracts project name from title
2. Iterates over EPIC_SECTIONS
3. For each section, extracts content and maps to dataKeys
4. Handles subsections with regex parsing
5. Has special handling for section 11 (Features & User Stories) - **HARDCODED**

**Hardcoded Field References Found in skills.ts:**

| Line | Field Name | Context |
|------|-----------|---------|
| 299, 302 | 'teams' | Table generation check and data access |
| 307, 310 | 'approvers' | Table generation check and data access |
| 347-348 | 'dataStores', 'features' | Architecture diagram generation |
| 508-511 | 'architectureOverview', 'features', 'userStories', 'dataStores' | Context analysis for diagram type |
| 634-635 | 'architectureOverview', 'dataStores' | C4 container diagram |
| 780 | 'userStories' | Sequence diagram |
| 907-908 | 'architectureOverview', 'features' | Component diagram |
| 1880-1896 | 'objective', 'architectureOverview', 'features', 'userStories', 'dataStores', 'teams' | AI summary generation |
| 2271-2300 | 'features', 'userStories' | Section 11 parsing special case |

**Critical Finding:** App.tsx has NO hardcoded field names (confirmed via grep) - all field access is dynamic through the stage configuration. However, skills.ts has significant hardcoding for diagram generation and special rendering cases.

#### 14. Render Type Categories

Based on analysis, sections fall into these render categories:

| Category | Example Sections | Current Handling | Blueprint Approach |
|----------|-----------------|------------------|-------------------|
| Standard Text | Objective, Assumptions, Next Steps | Dynamic via dataKeys | `renderType: 'text'` |
| With Subsections | Scope (In/Out), Dependencies & Risks | subsections array | `renderType: 'subsections'` |
| Table | Team & Roles, Approvers | isTable + hardcoded field check | `renderType: 'table', tableConfig: {...}` |
| Diagram | Architecture Overview | hasDiagram flag | `renderType: 'diagram'` |
| Reference | Architecture Diagrams | isReference flag | `renderType: 'embed'` |
| Multi-Key | Features & User Stories | Multiple dataKeys | `renderType: 'composite'` |

#### 15. Discovery Phase Summary

**What is Already Dynamic:**
1. renderWizard() iterates over stage.fields
2. handleFieldChange uses fieldName dynamically
3. refineStage processes currentStage.fields
4. generateEpic iterates over EPIC_SECTIONS
5. Most state management uses fieldName keys

**What Needs to Be Made Dynamic:**
1. STAGES array itself (load from blueprint)
2. EPIC_SECTIONS array (load from blueprint)
3. AI prompts in skills.ts (fieldPrompts, fieldGuidance, refinements)
4. Table rendering logic (remove hardcoded 'teams'/'approvers' checks)
5. Diagram generation field references
6. parseEpicToStageData special cases

**Decisions Made:**
1. Discovery phase is complete - we have a full picture of hardcoded dependencies
2. The architecture is more dynamic than expected - only skills.ts needs significant refactoring
3. Blueprint schema needs to include render type configurations for output sections
4. AI prompts need a registry pattern to support dynamic field-to-prompt mapping

---

## Discovery Phase Complete - Findings Summary

### Architecture Readiness Assessment

| Component | Current State | Dynamic Readiness | Effort |
|-----------|--------------|-------------------|--------|
| Wizard Renderer | Loop-based | HIGH | Low |
| State Management | Dynamic keys | HIGH | Low |
| Stage Navigation | STAGES.length | MEDIUM | Low |
| Epic Generation | Loop over EPIC_SECTIONS | MEDIUM | Medium |
| AI Prompts | Hardcoded per field | LOW | High |
| Table Rendering | Hardcoded field checks | LOW | Medium |
| Diagram Generation | Hardcoded field access | LOW | High |
| Epic Parsing | Hardcoded special cases | LOW | High |

### Key Patterns to Extract

1. **Stage Pattern:**
   - id, title, description, fields[], populatesSections[]

2. **Field Pattern:**
   - name, label, placeholder, type, required
   - NEW: aiPrompt, validation, defaultValue

3. **Section Pattern:**
   - num, title, dataKeys[], renderType
   - NEW: tableConfig, diagramConfig, subsections

4. **AI Prompt Pattern:**
   - systemPrompt, userPromptTemplate, fieldGuidance

---

### Iteration 4 - 2026-01-24
**Focus:** Pattern Extraction Phase - Field Types, Validation, AI Prompts, Render Types

**Files Analyzed:**
- `src/types.ts` - Complete re-analysis for pattern extraction
- `src/skills.ts` (lines 56-155) - AI prompt structures

---

## Pattern Extraction - Complete Analysis

### 1. Field Type Enumeration

**Current Types (from types.ts:7):**
```typescript
type: 'text' | 'textarea'
```

**Proposed Extended Types for Dynamic Templates:**
```typescript
type FieldType =
  // Text-based inputs
  | 'text'           // Single line text (e.g., projectName)
  | 'textarea'       // Multi-line text (most fields)
  | 'markdown'       // Rich markdown editor

  // Selection inputs
  | 'select'         // Single selection dropdown
  | 'multi-select'   // Multiple selection (tags)
  | 'radio'          // Radio button group
  | 'checkbox'       // Single checkbox (boolean)
  | 'checkbox-group' // Multiple checkboxes

  // Structured inputs
  | 'table-input'    // Tabular data entry (teams, approvers)
  | 'list-input'     // Dynamic list with add/remove
  | 'key-value'      // Key-value pairs

  // Date/Time inputs
  | 'date'           // Date picker
  | 'date-range'     // Start and end dates

  // Numeric inputs
  | 'number'         // Numeric input
  | 'range'          // Slider/range input

  // File inputs
  | 'file'           // File upload
  | 'image'          // Image upload

  // Special inputs
  | 'hidden'         // Hidden field with computed value
  | 'computed';      // Derived from other fields
```

**Field Type Usage Analysis:**

| Field Name | Current Type | Suggested Type | Reason |
|------------|--------------|----------------|--------|
| projectName | text | text | Short single line, correct |
| background | textarea | markdown | Could benefit from formatting |
| objective | textarea | textarea | OK |
| inScope | textarea | list-input | Better UX for list items |
| outOfScope | textarea | list-input | Better UX for list items |
| assumptions | textarea | list-input | Better UX for list items |
| architectureOverview | textarea | markdown | Technical content needs formatting |
| dataStores | textarea | textarea | OK |
| features | textarea | list-input | Numbered list input |
| userStories | textarea | table-input | Structured "As a / I want / So that" |
| nfrs | textarea | list-input | NFRs are typically listed |
| deliverables | textarea | list-input | Checklist format |
| teams | textarea | table-input | Role / Responsibility table |
| environments | textarea | textarea | OK |
| security | textarea | list-input | Security controls as list |
| dependencies | textarea | list-input | Dependencies as list |
| risks | textarea | table-input | Risk / Mitigation pairs |
| nextSteps | textarea | list-input | Numbered steps |
| dod | textarea | checkbox-group | DoD as checklist |
| approvers | textarea | table-input | Name / Role / Status table |

### 2. Validation Rule Patterns

**Current Validation (implicit in types.ts):**
```typescript
required: boolean  // Only validation currently
```

**Proposed Validation Schema:**
```typescript
interface FieldValidation {
  // Basic validators
  required?: boolean;
  minLength?: number;
  maxLength?: number;
  pattern?: string;        // Regex pattern
  patternMessage?: string; // Custom error message for pattern

  // Type-specific validators
  min?: number;            // For number fields
  max?: number;            // For number fields
  minItems?: number;       // For list/multi-select
  maxItems?: number;       // For list/multi-select

  // Custom validators
  custom?: {
    validator: string;     // Name of validator function
    params?: Record<string, unknown>;
    message: string;
  }[];

  // Cross-field validation
  dependsOn?: {
    field: string;         // Field this depends on
    condition: 'equals' | 'notEquals' | 'filled' | 'empty';
    value?: string;
    requiredIf?: boolean;  // Make required based on condition
    visibleIf?: boolean;   // Show/hide based on condition
  };
}
```

**Validation Rules Needed Based on Current Fields:**

| Field | Validation Rules |
|-------|------------------|
| projectName | required, minLength: 2, maxLength: 100 |
| background | required, minLength: 50 |
| objective | required, minLength: 20 |
| inScope | required, minItems: 1 |
| outOfScope | optional |
| assumptions | optional |
| architectureOverview | required, minLength: 50 |
| dataStores | required |
| features | required, minItems: 1 |
| userStories | optional |
| nfrs | optional |
| deliverables | required, minItems: 1 |
| teams | required, minItems: 1 |
| environments | required |
| security | optional |
| dependencies | optional |
| risks | optional |
| nextSteps | required, minItems: 1 |
| dod | required, minItems: 1 |
| approvers | optional |

### 3. AI Prompt Registry Structure

**Current Pattern (skills.ts:62-95):**
- Nested object: `fieldPrompts[stageId][fieldName]`
- Base prompt shared across all fields
- Field-specific suffix added to base prompt
- Separate `fieldGuidance` object for generation hints

**Proposed AI Prompt Configuration:**
```typescript
interface AIPromptConfig {
  // Base configuration (template-level)
  baseSystemPrompt: string;
  contextFields: string[];  // Fields to include in context
  defaultTemperature: number;
  defaultMaxTokens: number;

  // Per-field configuration
  fields: Record<string, FieldAIConfig>;
}

interface FieldAIConfig {
  // Suggestion prompts
  suggestion?: {
    systemPromptSuffix: string;   // Added to base system prompt
    guidance: string;             // Generation guidance (e.g., "List 5-8 items")
    format?: 'prose' | 'bullets' | 'numbered' | 'table';
    contextFields?: string[];     // Additional fields to include in context
  };

  // Refinement prompts
  refinement?: {
    systemPromptSuffix: string;
    transformationRules: string;  // How to transform user input
    outputFormat: string;         // Expected output format
  };

  // Options for disabled AI
  aiEnabled?: boolean;           // Default true
  fallbackBehavior?: 'skip' | 'copy-original' | 'use-default';
  defaultValue?: string;         // Used if AI disabled and no user input
}
```

**Extracted AI Prompt Patterns:**

| Field | System Prompt Suffix | Guidance | Format |
|-------|---------------------|----------|--------|
| projectName | Generate a professional project name (2-4 words, no quotes) | Generate a professional, concise project name | prose |
| background | Write a project background section explaining why this initiative exists and its business context | Write 2-3 paragraphs explaining the business context and need | prose |
| objective | Write a clear, measurable project objective with success criteria | Write a clear objective with measurable success criteria | prose |
| inScope | List items that are IN SCOPE for this project. Use bullet points, one item per line | List 5-8 items that are in scope | bullets |
| outOfScope | List items that are OUT OF SCOPE for this project. Use bullet points, one item per line | List 3-5 items explicitly out of scope | bullets |
| assumptions | List technical and business assumptions for this project. Use bullet points | List 4-6 key assumptions | bullets |
| architectureOverview | Describe the high-level system architecture including components, technologies, and how they interact | Describe the architecture in 2-3 paragraphs with key components | prose |
| dataStores | Describe the data stores, databases, caching layers, and data flow for this system | Describe databases, caching, and data flow | prose |
| features | List the key features for this project. Use numbered list format | List 5-8 key features | numbered |
| userStories | Write user stories in the format "As a [role], I want [feature] so that [benefit]" | Write 3-5 user stories | structured |
| nfrs | Define non-functional requirements including performance, scalability, security, and availability targets | Define performance, scalability, security, and availability requirements | bullets |
| deliverables | List project deliverables. Use bullet points | List 5-7 project deliverables | bullets |
| teams | Define team roles and responsibilities. Format: Role - Responsibility | Define 5-7 team roles | table |
| environments | Describe the environment strategy (dev, staging, prod) and CI/CD approach | Describe dev, staging, and production environments | prose |
| security | Define security controls including authentication, authorization, encryption, and compliance requirements | Define authentication, authorization, and encryption approach | bullets |
| dependencies | List project dependencies (teams, systems, third parties). Use bullet points | List 4-6 dependencies | bullets |
| risks | Identify project risks with mitigations. Format: Risk: [description] Mitigation: [approach] | Identify 3-5 risks with mitigations | table |
| nextSteps | List immediate next steps to kick off this project. Use numbered list | List 4-6 immediate next steps | numbered |
| dod | Define the Definition of Done criteria for this project. Use bullet points | Define 5-7 Definition of Done criteria | bullets |
| approvers | List required approvers with their roles. Format: Name/Role - Type of approval | List 3-5 required approvers | table |

### 4. Render Type Specifications

**Current Output Section Flags (types.ts:155-173):**
- `subsections?: string[]` - Section has subsections
- `isTable?: boolean` - Render as markdown table
- `hasDiagram?: boolean` - Section includes diagram placeholder
- `isReference?: boolean` - Section embeds external content

**Proposed RenderType Enumeration:**
```typescript
type SectionRenderType =
  | 'text'           // Simple markdown text block
  | 'subsections'    // Section with subsections
  | 'table'          // Markdown table rendering
  | 'list'           // Bulleted or numbered list
  | 'diagram'        // Contains diagram placeholder
  | 'embed'          // Embeds external content (mermaid, etc.)
  | 'composite';     // Multiple data keys merged

interface SectionRenderConfig {
  type: SectionRenderType;

  // For 'table' type
  tableConfig?: {
    columns: { key: string; header: string; width?: string }[];
    defaultRowCount?: number;
    allowDynamicRows?: boolean;
  };

  // For 'subsections' type
  subsectionConfig?: {
    titles: string[];        // Subsection titles
    dataKeyMapping: string[]; // Which dataKey maps to which subsection
    numbered?: boolean;       // Use numbered subsections
  };

  // For 'diagram' type
  diagramConfig?: {
    type: 'mermaid' | 'plantuml' | 'placeholder';
    generatorFunction?: string;  // Name of generator function
    sourceFields?: string[];     // Fields that inform diagram generation
  };

  // For 'embed' type
  embedConfig?: {
    contentType: 'mermaid' | 'markdown' | 'html' | 'image';
    sourceField?: string;    // Field containing content to embed
    fallbackMessage?: string;
  };

  // For 'composite' type
  compositeConfig?: {
    separator: string;       // How to join multiple data keys
    subheaders?: boolean;    // Add subheaders for each data key
  };
}
```

**Section Render Type Mapping:**

| Section | Current Flags | Render Type | Configuration |
|---------|--------------|-------------|---------------|
| 1. Objective | none | text | - |
| 2. Background | none | text | - |
| 3. Scope | subsections | subsections | titles: ['In Scope', 'Out of Scope'] |
| 4. Assumptions | none | list | - |
| 5. Architecture Overview | hasDiagram | diagram | type: placeholder |
| 6. Architecture Diagrams | isReference | embed | contentType: mermaid |
| 7. Team & Roles | isTable | table | columns: [Role, Responsibility] |
| 8. Environments | none | text | - |
| 9. Security | none | list | - |
| 10. Data Stores | none | text | - |
| 11. Features & Stories | multi-key | composite | separator: '\n\n' |
| 12. NFRs | none | list | - |
| 13. Dependencies & Risks | subsections | subsections | titles: ['Dependencies', 'Risks'] |
| 14. Deliverables | none | list | - |
| 15. Next Steps | none | list (numbered) | - |
| 16. DoD | none | list (checkbox) | - |
| 17. Approvers | isTable | table | columns: [Approver, Role, Status] |

---

## Self-Critique (Iteration 4)

**Positive:**
- Comprehensive field type enumeration covering future extensibility
- Validation schema is flexible and supports cross-field dependencies
- AI prompt extraction captures all current patterns
- Render types cover all current output variations

**Concerns:**
- The field type expansion is ambitious - may need phased implementation
- Table configurations assume specific column structures - need more flexibility
- AI prompt registry may become large - consider grouping by template

**Decisions Made:**
1. Field types should be extensible - use union type with string literal fallback
2. Validation should support both simple and complex rules
3. AI prompts should be per-field with template-level defaults
4. Render types should be declarative, not imperative

---

### Iteration 5 - 2026-01-24
**Focus:** Inter-field Dependencies, populatesSections Mapping, Blueprint Schema Consolidation

**Files Analyzed:**
- `src/types.ts` (lines 82-173) - Complete STAGES and EPIC_SECTIONS mapping
- `src/App.tsx` (lines 930-939) - getContext() function
- `src/skills.ts` (context field usage patterns)

---

## Pattern Extraction - Continued

### 5. Inter-Field Dependencies Analysis

**Context Building Pattern (App.tsx:930-939):**
```typescript
const getContext = useCallback(() => {
  const context: Record<string, string> = {};
  // Include current form data
  Object.entries(formData).forEach(([key, value]) => {
    context[key] = value;
  });
  // Include previously refined data
  Object.entries(state.data).forEach(([key, value]) => {
    context[key] = value.original;
  });
  return context;
}, [formData, state.data]);
```

**AI Context Usage (skills.ts:111-118):**
The AI suggestions explicitly use these context fields:
- `context.projectName` - Used in all prompts
- `context.objective` - Used for guidance
- `context.background` - Used for context

**Field Dependency Graph:**

```mermaid
graph LR
    subgraph Core["Core Context Fields"]
        PN[projectName]
        OBJ[objective]
        BG[background]
    end

    subgraph Stage1["Stage 1: Project"]
        F_PN[projectName field]
        F_BG[background field]
    end

    subgraph Stage2["Stage 2: Objective"]
        F_OBJ[objective field]
        F_IN[inScope field]
        F_OUT[outOfScope field]
    end

    subgraph Stage3["Stage 3: Architecture"]
        F_ASS[assumptions]
        F_ARCH[architectureOverview]
        F_DS[dataStores]
    end

    subgraph Diagram["Diagram Generation"]
        DIAG[AI Blueprint]
    end

    F_PN --> PN
    F_BG --> BG
    F_OBJ --> OBJ

    PN --> F_OBJ
    PN --> F_ARCH
    PN --> F_DS
    OBJ --> F_ARCH
    BG --> F_OBJ

    F_ARCH --> DIAG
    F_DS --> DIAG
    features --> DIAG
    userStories --> DIAG
```

**Dependency Matrix:**

| Field | Depends On (for AI suggestions) | Informs |
|-------|-------------------------------|---------|
| projectName | - | ALL subsequent fields |
| background | projectName | objective |
| objective | projectName, background | inScope, outOfScope |
| inScope | projectName, objective | - |
| outOfScope | projectName, objective | - |
| assumptions | projectName, objective | - |
| architectureOverview | projectName, objective, background | Diagram generation |
| dataStores | projectName, architectureOverview | Diagram generation |
| features | projectName, objective | Diagram generation |
| userStories | projectName, objective, features | Diagram (sequence) |
| nfrs | projectName, architectureOverview | - |
| deliverables | projectName, features | - |
| teams | projectName | - |
| environments | projectName, architectureOverview | Diagram (deployment) |
| security | projectName, dataStores | - |
| dependencies | projectName, architectureOverview, dataStores | - |
| risks | projectName, dependencies | - |
| nextSteps | projectName, deliverables | - |
| dod | projectName, deliverables | - |
| approvers | projectName | - |

### 6. populatesSections Mapping Analysis

This is a **Stage-to-Sections** mapping that shows which output sections are "lit up" when a stage has data:

**Current Mapping:**

| Stage | populatesSections | Section Names |
|-------|-------------------|---------------|
| project (1) | [1, 2] | Objective, Background |
| objective_scope (2) | [1, 3] | Objective, Scope |
| architecture (3) | [4, 5, 6, 10] | Assumptions, Architecture Overview, Architecture Diagrams, Data Stores |
| features (4) | [11, 12, 14] | Features & Stories, NFRs, Deliverables |
| team_env (5) | [7, 8, 9] | Team, Environments, Security |
| delivery (6) | [13, 15, 16, 17] | Dependencies & Risks, Next Steps, DoD, Approvals |

**Cross-reference with EPIC_SECTIONS dataKeys:**

| Section | dataKeys | Source Stage(s) | populatesSections Includes? |
|---------|----------|-----------------|---------------------------|
| 1. Objective | ['objective'] | objective_scope | project(1,2), objective_scope(1,3) - YES |
| 2. Background | ['background'] | project | project(1,2) - YES |
| 3. Scope | ['inScope', 'outOfScope'] | objective_scope | objective_scope(1,3) - YES |
| 4. Assumptions | ['assumptions'] | architecture | architecture(4,5,6,10) - YES |
| 5. Architecture Overview | ['architectureOverview'] | architecture | architecture(4,5,6,10) - YES |
| 6. Architecture Diagrams | [] | (auto-generated) | architecture(4,5,6,10) - YES |
| 7. Team & Roles | ['teams'] | team_env | team_env(7,8,9) - YES |
| 8. Environments | ['environments'] | team_env | team_env(7,8,9) - YES |
| 9. Security | ['security'] | team_env | team_env(7,8,9) - YES |
| 10. Data Stores | ['dataStores'] | architecture | architecture(4,5,6,10) - YES |
| 11. Features & Stories | ['features', 'userStories'] | features | features(11,12,14) - YES |
| 12. NFRs | ['nfrs'] | features | features(11,12,14) - YES |
| 13. Dependencies & Risks | ['dependencies', 'risks'] | delivery | delivery(13,15,16,17) - YES |
| 14. Deliverables | ['deliverables'] | features | features(11,12,14) - YES |
| 15. Next Steps | ['nextSteps'] | delivery | delivery(13,15,16,17) - YES |
| 16. DoD | ['dod'] | delivery | delivery(13,15,16,17) - YES |
| 17. Approvers | ['approvers'] | delivery | delivery(13,15,16,17) - YES |

**Key Insight:** The `populatesSections` mapping can be AUTO-DERIVED from the `dataKeys` in EPIC_SECTIONS. This redundancy could be eliminated in the blueprint schema.

**Algorithm to derive populatesSections:**
```typescript
function derivePopulatesSections(stages: Stage[], sections: Section[]): void {
  // Build field-to-section mapping
  const fieldToSections = new Map<string, number[]>();
  for (const section of sections) {
    for (const dataKey of section.dataKeys) {
      if (!fieldToSections.has(dataKey)) {
        fieldToSections.set(dataKey, []);
      }
      fieldToSections.get(dataKey)!.push(section.num);
    }
  }

  // Assign populatesSections to each stage
  for (const stage of stages) {
    const sectionSet = new Set<number>();
    for (const field of stage.fields) {
      const sections = fieldToSections.get(field.name) || [];
      sections.forEach(s => sectionSet.add(s));
    }
    stage.populatesSections = Array.from(sectionSet).sort((a, b) => a - b);
  }
}
```

### 7. Diagram Generation Patterns

**Diagram Types and Source Fields (skills.ts analysis):**

| Diagram Type | Generator Function | Source Fields | When Selected |
|--------------|-------------------|---------------|---------------|
| C4 Container | generateC4ContainerDiagram | architectureOverview, dataStores | Default for architecture content |
| Sequence | generateSequenceDiagram | userStories | User flows detected |
| Deployment | generateDeploymentDiagram | environments | Deployment details present |
| Component | generateComponentDiagram | architectureOverview, features | Component structure detected |

**Diagram Type Selection Logic (skills.ts:534-583):**
```typescript
// Score-based selection
const scores = {
  'c4-container': 2,  // Baseline
  'component': 0,
  'sequence': 0,
  'deployment': 0,
};

// Boost scores based on content
if (hasArchitecture && componentCount >= 3) {
  scores['c4-container'] += 5;
  scores['component'] += 4;
}
if (hasUserStories && hasWorkflows) {
  scores['sequence'] += 5;
}
if (hasDeploymentDetails && hasEnvironments) {
  scores['deployment'] += 5;
}
```

**Blueprint Diagram Configuration:**
```typescript
interface BlueprintDiagramConfig {
  // Intelligent type selection
  typeSelection: {
    default: DiagramType;
    rules: DiagramSelectionRule[];
  };

  // Field mappings for each diagram type
  typeConfigs: Record<DiagramType, {
    sourceFields: string[];
    requiredFields?: string[];
    aiPromptOverrides?: string;
  }>;

  // Style configuration
  styling: {
    theme: string;
    colorScheme: 'default' | 'finance' | 'health' | 'tech' | 'custom';
    customColors?: ColorPalette;
  };
}

interface DiagramSelectionRule {
  type: DiagramType;
  condition: {
    hasFields?: string[];
    fieldContains?: { field: string; keywords: string[] };
    minFieldCount?: number;
  };
  scoreBoost: number;
}
```

---

## Pattern Extraction Complete - Summary

### Extracted Patterns Ready for Blueprint Schema:

1. **Field Types** - 20+ types identified, prioritized by current usage
2. **Validation Rules** - Required, length, pattern, cross-field dependencies
3. **AI Prompts** - System prompts, guidance, format per field
4. **Render Types** - 7 render types for output sections
5. **Field Dependencies** - Context building, AI suggestion dependencies
6. **Section Mapping** - Can be auto-derived from dataKeys
7. **Diagram Config** - Type selection rules, source fields, styling

### Pattern Extraction Phase Complete

We now have all the patterns needed to design the complete Blueprint schema.

---

### Iteration 6 - 2026-01-24
**Focus:** Blueprint Schema Design - Complete TypeScript Interface Definition

---

## Blueprint Schema - Complete TypeScript Definition

```typescript
// =============================================================================
// WIZARD BLUEPRINT SCHEMA v1.0
// Dynamic Template Architecture for Epic Generator
// =============================================================================

// -----------------------------------------------------------------------------
// CORE BLUEPRINT INTERFACE
// -----------------------------------------------------------------------------

/**
 * The top-level blueprint configuration that defines an entire wizard template.
 * This schema enables variable number of stages, different field types,
 * and customizable output sections.
 */
export interface WizardBlueprint {
  // Metadata
  id: string;                      // Unique identifier (e.g., 'technical-architect')
  name: string;                    // Display name (e.g., 'Technical Architect Template')
  version: string;                 // Semantic version (e.g., '1.0.0')
  description: string;             // Template description
  author?: string;                 // Template author
  createdAt?: string;              // ISO date string
  updatedAt?: string;              // ISO date string

  // Template Configuration
  config: BlueprintConfig;

  // Wizard Stages
  stages: BlueprintStage[];

  // Output Sections
  outputSections: BlueprintSection[];

  // AI Configuration
  ai: BlueprintAIConfig;

  // Diagram Configuration
  diagrams?: BlueprintDiagramConfig;

  // Custom Styling (optional)
  styling?: BlueprintStyling;
}

// -----------------------------------------------------------------------------
// CONFIGURATION
// -----------------------------------------------------------------------------

export interface BlueprintConfig {
  // Document settings
  documentTitle: string;           // Title template (supports {{projectName}})
  documentSubtitle?: string;       // Subtitle template
  dateFormat?: string;             // Date format for generation timestamp

  // Wizard behavior
  autoSaveEnabled?: boolean;       // Auto-save to localStorage
  autoRefineOnNext?: boolean;      // Auto-refine when moving to next stage (default: true)
  showSectionPreview?: boolean;    // Show section completion preview (default: true)

  // Export settings
  exportFormats?: ('markdown' | 'pdf' | 'html' | 'gitlab')[];
  defaultExportFormat?: string;

  // Context fields - which fields are used for AI context building
  contextFields: string[];         // Fields that form AI context (e.g., ['projectName', 'objective', 'background'])
}

// -----------------------------------------------------------------------------
// STAGES
// -----------------------------------------------------------------------------

export interface BlueprintStage {
  id: string;                      // Unique stage identifier
  title: string;                   // Display title
  description: string;             // Stage description/help text
  icon?: string;                   // Icon identifier or SVG
  color?: string;                  // Stage accent color

  // Fields in this stage
  fields: BlueprintField[];

  // Optional: Explicit section mapping (auto-derived if not provided)
  populatesSections?: string[];    // Section IDs this stage populates

  // Stage-level validation
  validation?: {
    requireAtLeastOne?: string[];  // At least one of these fields must be filled
    customValidator?: string;      // Name of custom validation function
  };

  // Conditional visibility
  visibleIf?: FieldCondition;      // Only show stage if condition met
}

// -----------------------------------------------------------------------------
// FIELDS
// -----------------------------------------------------------------------------

export type FieldType =
  // Text inputs
  | 'text'              // Single line text
  | 'textarea'          // Multi-line text
  | 'markdown'          // Markdown editor with preview
  | 'rich-text'         // WYSIWYG editor

  // Selection inputs
  | 'select'            // Single selection dropdown
  | 'multi-select'      // Multiple selection tags
  | 'radio'             // Radio button group
  | 'checkbox'          // Single boolean checkbox
  | 'checkbox-group'    // Multiple checkboxes

  // Structured inputs
  | 'list'              // Dynamic list with add/remove
  | 'table'             // Table with configurable columns
  | 'key-value'         // Key-value pair list

  // Temporal inputs
  | 'date'              // Date picker
  | 'date-range'        // Start/end date picker
  | 'datetime'          // Date and time picker

  // Numeric inputs
  | 'number'            // Numeric input
  | 'range'             // Slider with min/max
  | 'percentage'        // 0-100 percentage input

  // File inputs
  | 'file'              // File upload
  | 'image'             // Image upload with preview

  // Special types
  | 'hidden'            // Hidden field (not rendered)
  | 'computed'          // Computed from other fields
  | 'divider'           // Visual separator (not a real field)
  | 'heading';          // Section heading (not a real field)

export interface BlueprintField {
  // Identity
  name: string;                    // Unique field identifier
  label: string;                   // Display label
  type: FieldType;                 // Field type

  // Help & Placeholders
  placeholder?: string;            // Input placeholder text
  helpText?: string;               // Help text shown below field
  tooltip?: string;                // Tooltip on hover

  // Validation
  required?: boolean;              // Is field required
  validation?: FieldValidation;    // Detailed validation rules

  // Default value
  defaultValue?: unknown;          // Default value (type depends on field type)

  // AI Configuration
  ai?: FieldAIConfig;              // AI-specific settings

  // Type-specific options
  options?: FieldTypeOptions;      // Options for select, multi-select, etc.

  // Conditional visibility/requirement
  visibleIf?: FieldCondition;      // Show field only if condition met
  requiredIf?: FieldCondition;     // Make required only if condition met
  disabledIf?: FieldCondition;     // Disable if condition met

  // Layout
  width?: 'full' | 'half' | 'third' | 'quarter';
  rows?: number;                   // For textarea: number of rows
}

export interface FieldValidation {
  // String validations
  minLength?: number;
  maxLength?: number;
  pattern?: string;                // Regex pattern
  patternMessage?: string;         // Error message for pattern failure

  // Number validations
  min?: number;
  max?: number;
  step?: number;

  // Array validations (for list, multi-select)
  minItems?: number;
  maxItems?: number;

  // Custom validation
  custom?: {
    validator: string;             // Name of validator function
    params?: Record<string, unknown>;
    message: string;
  }[];
}

export interface FieldCondition {
  field: string;                   // Field to check
  operator: 'equals' | 'notEquals' | 'contains' | 'notContains' |
            'empty' | 'notEmpty' | 'greaterThan' | 'lessThan';
  value?: unknown;                 // Value to compare against
}

export interface FieldTypeOptions {
  // For select, multi-select, radio, checkbox-group
  choices?: { value: string; label: string; }[];

  // For table
  columns?: {
    key: string;
    header: string;
    type?: 'text' | 'select' | 'checkbox';
    width?: string;
    options?: { value: string; label: string; }[];  // For select columns
  }[];
  minRows?: number;
  maxRows?: number;
  addRowLabel?: string;

  // For list
  itemLabel?: string;              // Label for each item (e.g., "Feature")
  allowReorder?: boolean;
  numbered?: boolean;

  // For file/image
  accept?: string;                 // File type filter
  maxSize?: number;                // Max file size in bytes

  // For range
  showValue?: boolean;             // Show current value
  labels?: { min: string; max: string; };
}

// -----------------------------------------------------------------------------
// AI CONFIGURATION
// -----------------------------------------------------------------------------

export interface BlueprintAIConfig {
  // Base configuration
  enabled: boolean;                // Is AI enabled for this template
  baseSystemPrompt: string;        // Base system prompt for all fields
  defaultTemperature?: number;     // Default temperature (0-1)
  defaultMaxTokens?: number;       // Default max tokens

  // Per-field AI configuration
  fields: Record<string, FieldAIConfig>;
}

export interface FieldAIConfig {
  // Enable/disable AI for this field
  enabled?: boolean;               // Default true

  // Suggestion configuration
  suggestion?: {
    systemPromptSuffix: string;    // Added to base system prompt
    guidance: string;              // Generation guidance
    format?: 'prose' | 'bullets' | 'numbered' | 'table' | 'structured';
    contextFields?: string[];      // Additional context fields
    temperature?: number;          // Override temperature
    maxTokens?: number;            // Override max tokens
    examples?: string[];           // Few-shot examples
  };

  // Refinement configuration
  refinement?: {
    systemPromptSuffix?: string;   // Override for refinement
    transformationRules?: string;  // How to transform input
    preserveUserIntent?: boolean;  // Keep user's key points
  };

  // Fallback when AI unavailable
  fallback?: {
    behavior: 'skip' | 'copy-original' | 'use-default';
    defaultValue?: string;
  };
}

// -----------------------------------------------------------------------------
// OUTPUT SECTIONS
// -----------------------------------------------------------------------------

export interface BlueprintSection {
  id: string;                      // Unique section identifier
  num: number;                     // Section number for display
  title: string;                   // Section title

  // Data mapping
  dataKeys: string[];              // Field names that populate this section

  // Render configuration
  render: SectionRenderConfig;

  // Conditional rendering
  visibleIf?: FieldCondition;      // Only show if condition met
  excludeIfEmpty?: boolean;        // Don't render if no data (default: false)
}

export type SectionRenderType =
  | 'text'           // Simple text block
  | 'subsections'    // Section with subsections
  | 'table'          // Markdown table
  | 'list'           // Bulleted or numbered list
  | 'checklist'      // Checkbox list
  | 'diagram'        // Diagram placeholder
  | 'embed'          // Embed content (mermaid, etc.)
  | 'composite'      // Multiple data keys joined
  | 'custom';        // Custom renderer

export interface SectionRenderConfig {
  type: SectionRenderType;

  // For 'subsections'
  subsections?: {
    title: string;
    dataKey: string;
  }[];

  // For 'table'
  table?: {
    columns: { header: string; dataPath?: string; default?: string }[];
    parseMode?: 'lines' | 'delimiter' | 'json';
    delimiter?: string;
  };

  // For 'list'
  list?: {
    style: 'bullet' | 'numbered' | 'checkbox';
    parseMode?: 'lines' | 'delimiter';
    delimiter?: string;
  };

  // For 'embed'
  embed?: {
    type: 'mermaid' | 'markdown' | 'code' | 'image';
    sourceField?: string;          // Field containing content
    language?: string;             // For code blocks
    fallbackMessage?: string;      // Message if no content
  };

  // For 'composite'
  composite?: {
    separator?: string;            // Separator between data keys
    addSubheaders?: boolean;       // Add subheaders for each data key
    subheaderPrefix?: string;      // Prefix for subheaders (e.g., "### ")
  };

  // For 'custom'
  custom?: {
    renderer: string;              // Name of custom renderer function
    props?: Record<string, unknown>;
  };
}

// -----------------------------------------------------------------------------
// DIAGRAM CONFIGURATION
// -----------------------------------------------------------------------------

export interface BlueprintDiagramConfig {
  enabled: boolean;

  // Type selection
  typeSelection: {
    default: DiagramType;
    rules: DiagramSelectionRule[];
  };

  // Type-specific configurations
  types: Record<DiagramType, DiagramTypeConfig>;

  // Styling
  styling: {
    theme: 'default' | 'base' | 'dark' | 'forest' | 'neutral';
    colorScheme: 'default' | 'finance' | 'health' | 'tech' | 'ecommerce' | 'custom';
    customColors?: {
      primary: string;
      secondary: string;
      accent: string;
      background: string;
      text: string;
    };
  };
}

export type DiagramType =
  | 'flowchart'
  | 'sequence'
  | 'class'
  | 'state'
  | 'er'
  | 'gantt'
  | 'pie'
  | 'mindmap'
  | 'c4-container'
  | 'c4-component'
  | 'deployment';

export interface DiagramSelectionRule {
  type: DiagramType;
  condition: {
    hasFields?: string[];                // Fields must be filled
    fieldContains?: {                    // Field must contain keywords
      field: string;
      keywords: string[];
      matchAll?: boolean;
    };
    minFieldCount?: number;              // Minimum filled fields
  };
  scoreBoost: number;                    // Add to type score
}

export interface DiagramTypeConfig {
  sourceFields: string[];                // Fields used for generation
  requiredFields?: string[];             // Must have data to use this type
  aiPromptOverride?: string;             // Custom AI prompt for this type
  maxNodes?: number;                     // Limit node count
  direction?: 'LR' | 'RL' | 'TB' | 'BT'; // Flow direction
}

// -----------------------------------------------------------------------------
// STYLING (OPTIONAL)
// -----------------------------------------------------------------------------

export interface BlueprintStyling {
  // Theme
  primaryColor?: string;
  secondaryColor?: string;
  accentColor?: string;

  // Progress indicator
  progressStyle?: 'dots' | 'bar' | 'steps' | 'none';

  // Card styling
  cardStyle?: 'default' | 'minimal' | 'bordered' | 'elevated';

  // Custom CSS class prefix
  classPrefix?: string;
}
```

---

## Self-Critique (Iteration 6)

**Positive:**
- Comprehensive schema covering all identified patterns
- Strong typing with discriminated unions for render types
- Flexible AI configuration per-field
- Support for conditional visibility/requirement
- Diagram configuration is fully extractable

**Concerns:**
- Schema is large - may need to split into separate files
- Custom renderer/validator functions require runtime loading
- Need to ensure backward compatibility with current hardcoded structure
- Performance implications of loading large blueprint JSON at runtime

**Decisions Made:**
1. Use TypeScript interface as source of truth
2. JSON Schema can be auto-generated from TypeScript
3. Keep optional properties to allow minimal blueprints
4. Support both inline and referenced configurations

---

### Iteration 7 - 2026-01-24
**Focus:** Blueprint Loading Mechanism, Technical Architect Template Example

---

## Blueprint Loading and Validation System

### Loading Architecture

```mermaid
flowchart LR
    subgraph Sources["Blueprint Sources"]
        JSON[JSON File]
        TS[TypeScript Module]
        API[Remote API]
    end

    subgraph Loader["Blueprint Loader"]
        LOAD[loadBlueprint]
        VALID[validateBlueprint]
        TRANS[transformBlueprint]
    end

    subgraph Runtime["Runtime"]
        STORE[BlueprintStore]
        WIZARD[WizardRenderer]
        GEN[EpicGenerator]
    end

    JSON --> LOAD
    TS --> LOAD
    API --> LOAD

    LOAD --> VALID
    VALID --> TRANS
    TRANS --> STORE

    STORE --> WIZARD
    STORE --> GEN
```

### Blueprint Loader Implementation

```typescript
// =============================================================================
// BLUEPRINT LOADER
// =============================================================================

import type { WizardBlueprint, BlueprintStage, BlueprintSection } from './blueprint-schema';

// Blueprint validation result
export interface BlueprintValidationResult {
  valid: boolean;
  errors: BlueprintError[];
  warnings: BlueprintWarning[];
}

export interface BlueprintError {
  path: string;          // JSON path to error (e.g., "stages[0].fields[2].type")
  code: string;          // Error code
  message: string;       // Human-readable message
}

export interface BlueprintWarning {
  path: string;
  code: string;
  message: string;
}

// Blueprint loading options
export interface LoadBlueprintOptions {
  validate?: boolean;           // Validate on load (default: true)
  throwOnError?: boolean;       // Throw on validation error (default: true)
  derivePopulatesSections?: boolean;  // Auto-derive section mappings (default: true)
}

// Blueprint loader class
export class BlueprintLoader {
  private static validators: Map<string, (value: unknown) => boolean> = new Map();
  private static renderers: Map<string, (data: unknown) => string> = new Map();

  /**
   * Load a blueprint from a JSON file path
   */
  static async loadFromFile(path: string, options?: LoadBlueprintOptions): Promise<WizardBlueprint> {
    const response = await fetch(path);
    const json = await response.json();
    return this.load(json, options);
  }

  /**
   * Load a blueprint from a JSON object
   */
  static load(
    blueprint: unknown,
    options: LoadBlueprintOptions = {}
  ): WizardBlueprint {
    const { validate = true, throwOnError = true, derivePopulatesSections = true } = options;

    // Validate if requested
    if (validate) {
      const result = this.validate(blueprint);
      if (!result.valid && throwOnError) {
        throw new BlueprintValidationError(result.errors);
      }
    }

    // Cast to blueprint type
    let bp = blueprint as WizardBlueprint;

    // Apply transformations
    if (derivePopulatesSections) {
      bp = this.derivePopulatesSections(bp);
    }

    // Normalize and set defaults
    bp = this.normalizeBlueprint(bp);

    return bp;
  }

  /**
   * Validate a blueprint against the schema
   */
  static validate(blueprint: unknown): BlueprintValidationResult {
    const errors: BlueprintError[] = [];
    const warnings: BlueprintWarning[] = [];

    // Type guard checks
    if (!blueprint || typeof blueprint !== 'object') {
      errors.push({ path: '', code: 'INVALID_TYPE', message: 'Blueprint must be an object' });
      return { valid: false, errors, warnings };
    }

    const bp = blueprint as Record<string, unknown>;

    // Required fields
    if (!bp.id || typeof bp.id !== 'string') {
      errors.push({ path: 'id', code: 'REQUIRED', message: 'Blueprint id is required' });
    }
    if (!bp.name || typeof bp.name !== 'string') {
      errors.push({ path: 'name', code: 'REQUIRED', message: 'Blueprint name is required' });
    }
    if (!bp.version || typeof bp.version !== 'string') {
      errors.push({ path: 'version', code: 'REQUIRED', message: 'Blueprint version is required' });
    }
    if (!Array.isArray(bp.stages) || bp.stages.length === 0) {
      errors.push({ path: 'stages', code: 'REQUIRED', message: 'Blueprint must have at least one stage' });
    }
    if (!Array.isArray(bp.outputSections) || bp.outputSections.length === 0) {
      errors.push({ path: 'outputSections', code: 'REQUIRED', message: 'Blueprint must have at least one output section' });
    }

    // Validate stages
    if (Array.isArray(bp.stages)) {
      (bp.stages as BlueprintStage[]).forEach((stage, i) => {
        if (!stage.id) {
          errors.push({ path: `stages[${i}].id`, code: 'REQUIRED', message: 'Stage id is required' });
        }
        if (!stage.title) {
          errors.push({ path: `stages[${i}].title`, code: 'REQUIRED', message: 'Stage title is required' });
        }
        if (!Array.isArray(stage.fields) || stage.fields.length === 0) {
          errors.push({ path: `stages[${i}].fields`, code: 'REQUIRED', message: 'Stage must have at least one field' });
        }

        // Validate fields
        stage.fields?.forEach((field, j) => {
          if (!field.name) {
            errors.push({ path: `stages[${i}].fields[${j}].name`, code: 'REQUIRED', message: 'Field name is required' });
          }
          if (!field.type) {
            errors.push({ path: `stages[${i}].fields[${j}].type`, code: 'REQUIRED', message: 'Field type is required' });
          }
        });
      });
    }

    // Validate output sections
    if (Array.isArray(bp.outputSections)) {
      (bp.outputSections as BlueprintSection[]).forEach((section, i) => {
        if (!section.id) {
          errors.push({ path: `outputSections[${i}].id`, code: 'REQUIRED', message: 'Section id is required' });
        }
        if (typeof section.num !== 'number') {
          errors.push({ path: `outputSections[${i}].num`, code: 'REQUIRED', message: 'Section num is required' });
        }
        if (!section.title) {
          errors.push({ path: `outputSections[${i}].title`, code: 'REQUIRED', message: 'Section title is required' });
        }
      });
    }

    // Cross-reference validation: check all dataKeys reference valid fields
    if (Array.isArray(bp.stages) && Array.isArray(bp.outputSections)) {
      const allFields = new Set<string>();
      (bp.stages as BlueprintStage[]).forEach(stage => {
        stage.fields?.forEach(field => allFields.add(field.name));
      });

      (bp.outputSections as BlueprintSection[]).forEach((section, i) => {
        section.dataKeys?.forEach(key => {
          if (!allFields.has(key)) {
            warnings.push({
              path: `outputSections[${i}].dataKeys`,
              code: 'ORPHAN_DATAKEY',
              message: `dataKey "${key}" does not match any field`
            });
          }
        });
      });
    }

    return { valid: errors.length === 0, errors, warnings };
  }

  /**
   * Derive populatesSections from section dataKeys
   */
  private static derivePopulatesSections(blueprint: WizardBlueprint): WizardBlueprint {
    // Build field-to-sections map
    const fieldToSections = new Map<string, string[]>();
    blueprint.outputSections.forEach(section => {
      section.dataKeys.forEach(key => {
        if (!fieldToSections.has(key)) {
          fieldToSections.set(key, []);
        }
        fieldToSections.get(key)!.push(section.id);
      });
    });

    // Assign to stages
    const stages = blueprint.stages.map(stage => {
      if (stage.populatesSections && stage.populatesSections.length > 0) {
        return stage; // Keep explicit mapping
      }

      const sections = new Set<string>();
      stage.fields.forEach(field => {
        const sectionIds = fieldToSections.get(field.name) || [];
        sectionIds.forEach(id => sections.add(id));
      });

      return {
        ...stage,
        populatesSections: Array.from(sections),
      };
    });

    return { ...blueprint, stages };
  }

  /**
   * Normalize blueprint with defaults
   */
  private static normalizeBlueprint(blueprint: WizardBlueprint): WizardBlueprint {
    return {
      ...blueprint,
      config: {
        documentTitle: 'Technical Design Document: {{projectName}}',
        autoSaveEnabled: true,
        autoRefineOnNext: true,
        showSectionPreview: true,
        contextFields: ['projectName', 'objective', 'background'],
        ...blueprint.config,
      },
      ai: {
        enabled: true,
        baseSystemPrompt: 'You are an expert technical writer helping to create comprehensive software project epics.',
        defaultTemperature: 0.7,
        defaultMaxTokens: 4096,
        fields: {},
        ...blueprint.ai,
      },
    };
  }

  /**
   * Register a custom validator function
   */
  static registerValidator(name: string, fn: (value: unknown) => boolean): void {
    this.validators.set(name, fn);
  }

  /**
   * Register a custom section renderer
   */
  static registerRenderer(name: string, fn: (data: unknown) => string): void {
    this.renderers.set(name, fn);
  }
}

// Validation error class
export class BlueprintValidationError extends Error {
  constructor(public errors: BlueprintError[]) {
    super(`Blueprint validation failed: ${errors.map(e => e.message).join(', ')}`);
    this.name = 'BlueprintValidationError';
  }
}
```

---

## Technical Architect Template - Example Blueprint

This is the current 6-stage, 17-section Technical Architect template expressed as a blueprint:

```typescript
// technical-architect.blueprint.ts
import type { WizardBlueprint } from './blueprint-schema';

export const TechnicalArchitectBlueprint: WizardBlueprint = {
  // Metadata
  id: 'technical-architect',
  name: 'Technical Architect Template',
  version: '1.0.0',
  description: 'Comprehensive 17-section technical design document for software projects',
  author: 'Epic Generator Team',

  // Configuration
  config: {
    documentTitle: 'Technical Design Epic: {{projectName}}',
    documentSubtitle: 'Generated on {{date}}',
    dateFormat: 'MMMM D, YYYY',
    autoSaveEnabled: true,
    autoRefineOnNext: true,
    showSectionPreview: true,
    exportFormats: ['markdown', 'gitlab'],
    defaultExportFormat: 'markdown',
    contextFields: ['projectName', 'objective', 'background'],
  },

  // Wizard Stages
  stages: [
    {
      id: 'project',
      title: 'Project',
      description: 'Project name and background context',
      fields: [
        {
          name: 'projectName',
          label: 'Project Name',
          type: 'text',
          placeholder: 'Enter project name',
          required: true,
          validation: { minLength: 2, maxLength: 100 },
          ai: {
            suggestion: {
              systemPromptSuffix: 'Generate a professional project name (2-4 words, no quotes).',
              guidance: 'Generate a professional, concise project name.',
              format: 'prose',
            },
          },
        },
        {
          name: 'background',
          label: 'Background & Context',
          type: 'textarea',
          placeholder: 'Why does this project exist? What problem does it solve?',
          required: true,
          rows: 6,
          ai: {
            suggestion: {
              systemPromptSuffix: 'Write a project background section explaining why this initiative exists and its business context.',
              guidance: 'Write 2-3 paragraphs explaining the business context and need.',
              format: 'prose',
            },
          },
        },
      ],
    },
    {
      id: 'objective_scope',
      title: 'Objective & Scope',
      description: 'Define the goal and boundaries',
      fields: [
        {
          name: 'objective',
          label: 'Objective',
          type: 'textarea',
          placeholder: 'What is the main goal of this project?',
          required: true,
          rows: 4,
          ai: {
            suggestion: {
              systemPromptSuffix: 'Write a clear, measurable project objective with success criteria.',
              guidance: 'Write a clear objective with measurable success criteria.',
              format: 'prose',
            },
          },
        },
        {
          name: 'inScope',
          label: 'In Scope',
          type: 'textarea',
          placeholder: 'What is included in this project?',
          required: true,
          rows: 5,
          ai: {
            suggestion: {
              systemPromptSuffix: 'List items that are IN SCOPE for this project. Use bullet points, one item per line.',
              guidance: 'List 5-8 items that are in scope.',
              format: 'bullets',
            },
          },
        },
        {
          name: 'outOfScope',
          label: 'Out of Scope',
          type: 'textarea',
          placeholder: 'What is explicitly excluded?',
          required: false,
          rows: 4,
          ai: {
            suggestion: {
              systemPromptSuffix: 'List items that are OUT OF SCOPE for this project. Use bullet points, one item per line.',
              guidance: 'List 3-5 items explicitly out of scope.',
              format: 'bullets',
            },
          },
        },
      ],
    },
    {
      id: 'architecture',
      title: 'Architecture',
      description: 'System design and data stores',
      fields: [
        {
          name: 'assumptions',
          label: 'Assumptions',
          type: 'textarea',
          placeholder: 'What assumptions are we making?',
          required: false,
          rows: 4,
          ai: {
            suggestion: {
              systemPromptSuffix: 'List technical and business assumptions for this project. Use bullet points.',
              guidance: 'List 4-6 key assumptions.',
              format: 'bullets',
            },
          },
        },
        {
          name: 'architectureOverview',
          label: 'Architecture Overview',
          type: 'textarea',
          placeholder: 'Describe the high-level system architecture',
          required: true,
          rows: 8,
          ai: {
            suggestion: {
              systemPromptSuffix: 'Describe the high-level system architecture including components, technologies, and how they interact.',
              guidance: 'Describe the architecture in 2-3 paragraphs with key components.',
              format: 'prose',
            },
          },
        },
        {
          name: 'dataStores',
          label: 'Data Stores & Services',
          type: 'textarea',
          placeholder: 'What databases, APIs, and services will be used?',
          required: true,
          rows: 5,
          ai: {
            suggestion: {
              systemPromptSuffix: 'Describe the data stores, databases, caching layers, and data flow for this system.',
              guidance: 'Describe databases, caching, and data flow.',
              format: 'prose',
            },
          },
        },
      ],
    },
    {
      id: 'features',
      title: 'Features',
      description: 'Key features, user stories, and requirements',
      fields: [
        {
          name: 'features',
          label: 'Key Features',
          type: 'textarea',
          placeholder: 'List the main features',
          required: true,
          rows: 6,
          ai: {
            suggestion: {
              systemPromptSuffix: 'List the key features for this project. Use numbered list format.',
              guidance: 'List 5-8 key features.',
              format: 'numbered',
            },
          },
        },
        {
          name: 'userStories',
          label: 'User Stories',
          type: 'textarea',
          placeholder: 'As a [user], I want [feature] so that [benefit]',
          required: false,
          rows: 6,
          ai: {
            suggestion: {
              systemPromptSuffix: 'Write user stories in the format "As a [role], I want [feature] so that [benefit]".',
              guidance: 'Write 3-5 user stories.',
              format: 'structured',
            },
          },
        },
        {
          name: 'nfrs',
          label: 'Non-Functional Requirements',
          type: 'textarea',
          placeholder: 'Performance, scalability, security requirements',
          required: false,
          rows: 4,
          ai: {
            suggestion: {
              systemPromptSuffix: 'Define non-functional requirements including performance, scalability, security, and availability targets.',
              guidance: 'Define performance, scalability, security, and availability requirements.',
              format: 'bullets',
            },
          },
        },
        {
          name: 'deliverables',
          label: 'Deliverables',
          type: 'textarea',
          placeholder: 'What will be delivered?',
          required: true,
          rows: 4,
          ai: {
            suggestion: {
              systemPromptSuffix: 'List project deliverables. Use bullet points.',
              guidance: 'List 5-7 project deliverables.',
              format: 'bullets',
            },
          },
        },
      ],
    },
    {
      id: 'team_env',
      title: 'Team & Environment',
      description: 'Team structure, environments, and security',
      fields: [
        {
          name: 'teams',
          label: 'Team & Roles',
          type: 'textarea',
          placeholder: 'Who is involved and what are their roles?',
          required: true,
          rows: 5,
          ai: {
            suggestion: {
              systemPromptSuffix: 'Define team roles and responsibilities. Format: Role - Responsibility',
              guidance: 'Define 5-7 team roles.',
              format: 'table',
            },
          },
        },
        {
          name: 'environments',
          label: 'Environments & CI/CD',
          type: 'textarea',
          placeholder: 'Dev, Staging, Prod environments and deployment strategy',
          required: true,
          rows: 5,
          ai: {
            suggestion: {
              systemPromptSuffix: 'Describe the environment strategy (dev, staging, prod) and CI/CD approach.',
              guidance: 'Describe dev, staging, and production environments.',
              format: 'prose',
            },
          },
        },
        {
          name: 'security',
          label: 'Data Security & Access',
          type: 'textarea',
          placeholder: 'Security requirements and access controls',
          required: false,
          rows: 4,
          ai: {
            suggestion: {
              systemPromptSuffix: 'Define security controls including authentication, authorization, encryption, and compliance requirements.',
              guidance: 'Define authentication, authorization, and encryption approach.',
              format: 'bullets',
            },
          },
        },
      ],
    },
    {
      id: 'delivery',
      title: 'Delivery',
      description: 'Dependencies, risks, and completion criteria',
      fields: [
        {
          name: 'dependencies',
          label: 'Dependencies',
          type: 'textarea',
          placeholder: 'What does this project depend on?',
          required: false,
          rows: 4,
          ai: {
            suggestion: {
              systemPromptSuffix: 'List project dependencies (teams, systems, third parties). Use bullet points.',
              guidance: 'List 4-6 dependencies.',
              format: 'bullets',
            },
          },
        },
        {
          name: 'risks',
          label: 'Risks',
          type: 'textarea',
          placeholder: 'What are the potential risks?',
          required: false,
          rows: 4,
          ai: {
            suggestion: {
              systemPromptSuffix: 'Identify project risks with mitigations. Format: Risk: [description] | Mitigation: [approach]',
              guidance: 'Identify 3-5 risks with mitigations.',
              format: 'table',
            },
          },
        },
        {
          name: 'nextSteps',
          label: 'Next Steps',
          type: 'textarea',
          placeholder: 'Immediate actions to take',
          required: true,
          rows: 4,
          ai: {
            suggestion: {
              systemPromptSuffix: 'List immediate next steps to kick off this project. Use numbered list.',
              guidance: 'List 4-6 immediate next steps.',
              format: 'numbered',
            },
          },
        },
        {
          name: 'dod',
          label: 'Definition of Done',
          type: 'textarea',
          placeholder: 'When is this project considered complete?',
          required: true,
          rows: 4,
          ai: {
            suggestion: {
              systemPromptSuffix: 'Define the Definition of Done criteria for this project. Use bullet points.',
              guidance: 'Define 5-7 Definition of Done criteria.',
              format: 'bullets',
            },
          },
        },
        {
          name: 'approvers',
          label: 'Approvers',
          type: 'textarea',
          placeholder: 'Who needs to sign off?',
          required: false,
          rows: 3,
          ai: {
            suggestion: {
              systemPromptSuffix: 'List required approvers with their roles. Format: Name/Role - Type of approval',
              guidance: 'List 3-5 required approvers.',
              format: 'table',
            },
          },
        },
      ],
    },
  ],

  // Output Sections
  outputSections: [
    { id: 'objective', num: 1, title: 'Objective', dataKeys: ['objective'], render: { type: 'text' } },
    { id: 'background', num: 2, title: 'Background & Context', dataKeys: ['background'], render: { type: 'text' } },
    {
      id: 'scope', num: 3, title: 'Scope', dataKeys: ['inScope', 'outOfScope'],
      render: {
        type: 'subsections',
        subsections: [
          { title: 'In Scope', dataKey: 'inScope' },
          { title: 'Out of Scope', dataKey: 'outOfScope' },
        ],
      },
    },
    { id: 'assumptions', num: 4, title: 'Assumptions', dataKeys: ['assumptions'], render: { type: 'list', list: { style: 'bullet' } } },
    { id: 'arch-overview', num: 5, title: 'High-Level Architecture Overview', dataKeys: ['architectureOverview'], render: { type: 'diagram' } },
    {
      id: 'arch-diagrams', num: 6, title: 'Architecture Diagrams', dataKeys: [],
      render: { type: 'embed', embed: { type: 'mermaid', fallbackMessage: 'Generate a diagram in the Blueprint tab to include it here.' } },
    },
    {
      id: 'team', num: 7, title: 'Team & Roles', dataKeys: ['teams'],
      render: { type: 'table', table: { columns: [{ header: 'Role' }, { header: 'Responsibility' }], parseMode: 'lines' } },
    },
    { id: 'environments', num: 8, title: 'Environments & CI/CD Strategy', dataKeys: ['environments'], render: { type: 'text' } },
    { id: 'security', num: 9, title: 'Data Security & Access Controls', dataKeys: ['security'], render: { type: 'list', list: { style: 'bullet' } } },
    { id: 'datastores', num: 10, title: 'Data Stores, Services & Interfaces', dataKeys: ['dataStores'], render: { type: 'text' } },
    {
      id: 'features', num: 11, title: 'Key Features & User Stories', dataKeys: ['features', 'userStories'],
      render: { type: 'composite', composite: { separator: '\n\n', addSubheaders: true, subheaderPrefix: '### ' } },
    },
    { id: 'nfrs', num: 12, title: 'Non-Functional Requirements (NFRs)', dataKeys: ['nfrs'], render: { type: 'list', list: { style: 'bullet' } } },
    {
      id: 'deps-risks', num: 13, title: 'Dependencies & Risks', dataKeys: ['dependencies', 'risks'],
      render: {
        type: 'subsections',
        subsections: [
          { title: 'Dependencies', dataKey: 'dependencies' },
          { title: 'Risks', dataKey: 'risks' },
        ],
      },
    },
    { id: 'deliverables', num: 14, title: 'Deliverables', dataKeys: ['deliverables'], render: { type: 'list', list: { style: 'bullet' } } },
    { id: 'nextsteps', num: 15, title: 'Next Steps', dataKeys: ['nextSteps'], render: { type: 'list', list: { style: 'numbered' } } },
    { id: 'dod', num: 16, title: 'Definition of Done (DoD)', dataKeys: ['dod'], render: { type: 'checklist' } },
    {
      id: 'approvers', num: 17, title: 'Approvals & Sign-Offs', dataKeys: ['approvers'],
      render: { type: 'table', table: { columns: [{ header: 'Approver' }, { header: 'Role' }, { header: 'Status', default: 'Pending' }], parseMode: 'lines' } },
    },
  ],

  // AI Configuration
  ai: {
    enabled: true,
    baseSystemPrompt: `You are an expert technical writer helping to create comprehensive software project epics.
Provide concise, professional content suitable for a technical design document.
Be specific and actionable. Use bullet points or numbered lists where appropriate.
Do not include any preamble or explanation - just provide the content directly.`,
    defaultTemperature: 0.7,
    defaultMaxTokens: 4096,
    fields: {}, // Per-field configs are in stage.fields[].ai
  },

  // Diagram Configuration
  diagrams: {
    enabled: true,
    typeSelection: {
      default: 'c4-container',
      rules: [
        { type: 'c4-container', condition: { hasFields: ['architectureOverview'] }, scoreBoost: 5 },
        { type: 'sequence', condition: { hasFields: ['userStories'], fieldContains: { field: 'userStories', keywords: ['flow', 'when', 'then'] } }, scoreBoost: 5 },
        { type: 'deployment', condition: { hasFields: ['environments'], fieldContains: { field: 'environments', keywords: ['kubernetes', 'docker', 'deploy'] } }, scoreBoost: 5 },
      ],
    },
    types: {
      'c4-container': { sourceFields: ['architectureOverview', 'dataStores'], direction: 'LR', maxNodes: 20 },
      'sequence': { sourceFields: ['userStories'], maxNodes: 15 },
      'deployment': { sourceFields: ['environments'], direction: 'TB', maxNodes: 15 },
      'flowchart': { sourceFields: ['architectureOverview', 'features'], direction: 'LR', maxNodes: 20 },
      'class': { sourceFields: ['dataStores'], maxNodes: 15 },
      'state': { sourceFields: ['features'], maxNodes: 12 },
      'er': { sourceFields: ['dataStores'], maxNodes: 10 },
      'gantt': { sourceFields: ['nextSteps', 'deliverables'], maxNodes: 20 },
      'pie': { sourceFields: [], maxNodes: 10 },
      'mindmap': { sourceFields: ['features', 'objective'], maxNodes: 15 },
      'c4-component': { sourceFields: ['architectureOverview'], maxNodes: 20 },
    },
    styling: {
      theme: 'base',
      colorScheme: 'default',
    },
  },
};
```

---

## Self-Critique (Iteration 7)

**Positive:**
- Complete working example of the Technical Architect template as blueprint
- Blueprint loader handles validation and normalization
- Auto-derivation of populatesSections reduces redundancy
- Custom validator/renderer registration enables extensibility

**Concerns:**
- Blueprint file is large (~400 lines) - could split AI prompts into separate file
- Need to ensure the loader can handle partial blueprints gracefully
- Runtime type checking may have performance implications for large blueprints

**Decisions Made:**
1. Keep full example blueprint in one file for clarity
2. Validation is opt-in but recommended
3. Support both TypeScript and JSON blueprints

---

### Iteration 8 - 2026-01-24
**Focus:** Dynamic Wizard Renderer Architecture, State Management Redesign

---

## Dynamic Wizard Renderer Architecture

### Component Hierarchy

```mermaid
flowchart TD
    subgraph App["App Component"]
        BP[BlueprintProvider]
    end

    subgraph Provider["Blueprint Context"]
        STORE[BlueprintStore]
        STATE[WizardState]
    end

    subgraph Wizard["Dynamic Wizard"]
        WR[WizardRenderer]
        SR[StageRenderer]
        FR[FieldRenderer]
    end

    subgraph Fields["Field Components"]
        TXT[TextField]
        TXA[TextareaField]
        SEL[SelectField]
        TBL[TableField]
        LST[ListField]
    end

    subgraph Output["Output Generation"]
        EG[EpicGenerator]
        SR2[SectionRenderer]
    end

    BP --> STORE
    BP --> STATE

    STORE --> WR
    STATE --> WR

    WR --> SR
    SR --> FR

    FR --> TXT
    FR --> TXA
    FR --> SEL
    FR --> TBL
    FR --> LST

    STORE --> EG
    STATE --> EG
    EG --> SR2
```

### Blueprint Context Provider

```typescript
// =============================================================================
// BLUEPRINT CONTEXT
// =============================================================================

import { createContext, useContext, useReducer, useCallback, useMemo } from 'react';
import type { WizardBlueprint, BlueprintStage, BlueprintField, BlueprintSection } from './blueprint-schema';

// State interface
export interface WizardState {
  // Current position
  currentStageIndex: number;

  // Field data
  formData: Record<string, string>;          // Current form inputs
  refinedData: Record<string, RefinedFieldData>;  // Refined data with AI enhancements

  // UI state
  loadingSuggestion: Record<string, boolean>;
  alternatives: Record<string, string[]>;
  editingRefined: Record<string, boolean>;

  // Generation state
  generatedDocument: string | null;
  isGenerating: boolean;
  generationProgress: { current: number; total: number; section: string };

  // Diagram state
  diagramCode: string;
  diagramType: string;
}

export interface RefinedFieldData {
  original: string;
  refined: string;
  diagramNode?: string;
}

// Actions
type WizardAction =
  | { type: 'SET_FIELD'; fieldName: string; value: string }
  | { type: 'SET_REFINED'; fieldName: string; data: RefinedFieldData }
  | { type: 'SET_LOADING'; fieldName: string; loading: boolean }
  | { type: 'SET_ALTERNATIVES'; fieldName: string; alternatives: string[] }
  | { type: 'NEXT_STAGE' }
  | { type: 'PREV_STAGE' }
  | { type: 'GO_TO_STAGE'; index: number }
  | { type: 'SET_GENERATING'; generating: boolean }
  | { type: 'SET_PROGRESS'; progress: { current: number; total: number; section: string } }
  | { type: 'SET_DOCUMENT'; document: string }
  | { type: 'SET_DIAGRAM'; code: string; type: string }
  | { type: 'RESET' };

// Context value
interface BlueprintContextValue {
  // Blueprint data
  blueprint: WizardBlueprint;

  // Derived data
  currentStage: BlueprintStage;
  stages: BlueprintStage[];
  sections: BlueprintSection[];
  isFirstStage: boolean;
  isLastStage: boolean;
  totalStages: number;
  populatedSections: Set<string>;

  // State
  state: WizardState;

  // Actions
  setFieldValue: (fieldName: string, value: string) => void;
  setRefinedData: (fieldName: string, data: RefinedFieldData) => void;
  nextStage: () => Promise<void>;
  prevStage: () => void;
  goToStage: (index: number) => void;
  generateDocument: () => Promise<void>;
  getSuggestion: (fieldName: string, mode: 'with-context' | 'auto') => Promise<void>;

  // Helpers
  getFieldConfig: (fieldName: string) => BlueprintField | undefined;
  getSectionConfig: (sectionId: string) => BlueprintSection | undefined;
  getContext: () => Record<string, string>;
}

// Initial state factory
function createInitialState(): WizardState {
  return {
    currentStageIndex: 0,
    formData: {},
    refinedData: {},
    loadingSuggestion: {},
    alternatives: {},
    editingRefined: {},
    generatedDocument: null,
    isGenerating: false,
    generationProgress: { current: 0, total: 0, section: '' },
    diagramCode: '',
    diagramType: '',
  };
}

// Reducer
function wizardReducer(state: WizardState, action: WizardAction): WizardState {
  switch (action.type) {
    case 'SET_FIELD':
      return { ...state, formData: { ...state.formData, [action.fieldName]: action.value } };

    case 'SET_REFINED':
      return { ...state, refinedData: { ...state.refinedData, [action.fieldName]: action.data } };

    case 'SET_LOADING':
      return { ...state, loadingSuggestion: { ...state.loadingSuggestion, [action.fieldName]: action.loading } };

    case 'SET_ALTERNATIVES':
      return { ...state, alternatives: { ...state.alternatives, [action.fieldName]: action.alternatives } };

    case 'NEXT_STAGE':
      return { ...state, currentStageIndex: state.currentStageIndex + 1, formData: {}, alternatives: {}, editingRefined: {} };

    case 'PREV_STAGE':
      return { ...state, currentStageIndex: Math.max(0, state.currentStageIndex - 1) };

    case 'GO_TO_STAGE':
      return { ...state, currentStageIndex: action.index };

    case 'SET_GENERATING':
      return { ...state, isGenerating: action.generating };

    case 'SET_PROGRESS':
      return { ...state, generationProgress: action.progress };

    case 'SET_DOCUMENT':
      return { ...state, generatedDocument: action.document };

    case 'SET_DIAGRAM':
      return { ...state, diagramCode: action.code, diagramType: action.type };

    case 'RESET':
      return createInitialState();

    default:
      return state;
  }
}

// Context
const BlueprintContext = createContext<BlueprintContextValue | null>(null);

// Provider component
export function BlueprintProvider({
  blueprint,
  children,
}: {
  blueprint: WizardBlueprint;
  children: React.ReactNode;
}) {
  const [state, dispatch] = useReducer(wizardReducer, undefined, createInitialState);

  // Derived values
  const stages = blueprint.stages;
  const sections = blueprint.outputSections;
  const currentStage = stages[state.currentStageIndex];
  const isFirstStage = state.currentStageIndex === 0;
  const isLastStage = state.currentStageIndex === stages.length - 1;
  const totalStages = stages.length;

  // Calculate populated sections
  const populatedSections = useMemo(() => {
    const populated = new Set<string>();
    stages.slice(0, state.currentStageIndex + 1).forEach(stage => {
      const hasData = stage.fields.some(f => state.refinedData[f.name]?.refined);
      if (hasData && stage.populatesSections) {
        stage.populatesSections.forEach(s => populated.add(s));
      }
    });
    return populated;
  }, [stages, state.currentStageIndex, state.refinedData]);

  // Get context for AI
  const getContext = useCallback(() => {
    const context: Record<string, string> = {};
    // Include current form data
    Object.entries(state.formData).forEach(([key, value]) => {
      context[key] = value;
    });
    // Include refined data originals
    Object.entries(state.refinedData).forEach(([key, value]) => {
      context[key] = value.original;
    });
    return context;
  }, [state.formData, state.refinedData]);

  // Actions
  const setFieldValue = useCallback((fieldName: string, value: string) => {
    dispatch({ type: 'SET_FIELD', fieldName, value });
  }, []);

  const setRefinedData = useCallback((fieldName: string, data: RefinedFieldData) => {
    dispatch({ type: 'SET_REFINED', fieldName, data });
  }, []);

  const nextStage = useCallback(async () => {
    // Refine current stage fields before moving
    // ... refinement logic
    if (isLastStage) {
      // Generate document
      await generateDocument();
    } else {
      dispatch({ type: 'NEXT_STAGE' });
    }
  }, [isLastStage]);

  const prevStage = useCallback(() => {
    dispatch({ type: 'PREV_STAGE' });
  }, []);

  const goToStage = useCallback((index: number) => {
    dispatch({ type: 'GO_TO_STAGE', index });
  }, []);

  const generateDocument = useCallback(async () => {
    dispatch({ type: 'SET_GENERATING', generating: true });
    // ... generation logic using blueprint.outputSections
    dispatch({ type: 'SET_GENERATING', generating: false });
  }, []);

  const getSuggestion = useCallback(async (fieldName: string, mode: 'with-context' | 'auto') => {
    dispatch({ type: 'SET_LOADING', fieldName, loading: true });
    // ... AI suggestion logic
    dispatch({ type: 'SET_LOADING', fieldName, loading: false });
  }, []);

  // Helpers
  const getFieldConfig = useCallback((fieldName: string): BlueprintField | undefined => {
    for (const stage of stages) {
      const field = stage.fields.find(f => f.name === fieldName);
      if (field) return field;
    }
    return undefined;
  }, [stages]);

  const getSectionConfig = useCallback((sectionId: string): BlueprintSection | undefined => {
    return sections.find(s => s.id === sectionId);
  }, [sections]);

  // Context value
  const value: BlueprintContextValue = {
    blueprint,
    currentStage,
    stages,
    sections,
    isFirstStage,
    isLastStage,
    totalStages,
    populatedSections,
    state,
    setFieldValue,
    setRefinedData,
    nextStage,
    prevStage,
    goToStage,
    generateDocument,
    getSuggestion,
    getFieldConfig,
    getSectionConfig,
    getContext,
  };

  return (
    <BlueprintContext.Provider value={value}>
      {children}
    </BlueprintContext.Provider>
  );
}

// Hook to use context
export function useBlueprint(): BlueprintContextValue {
  const context = useContext(BlueprintContext);
  if (!context) {
    throw new Error('useBlueprint must be used within a BlueprintProvider');
  }
  return context;
}
```

### Dynamic Field Renderer

```typescript
// =============================================================================
// DYNAMIC FIELD RENDERER
// =============================================================================

import type { BlueprintField, FieldType } from './blueprint-schema';
import { useBlueprint } from './BlueprintContext';

// Field component registry
const fieldComponents: Record<FieldType, React.ComponentType<FieldProps>> = {
  'text': TextField,
  'textarea': TextareaField,
  'markdown': MarkdownField,
  'select': SelectField,
  'multi-select': MultiSelectField,
  'checkbox': CheckboxField,
  'list': ListField,
  'table': TableField,
  // ... other field types
};

interface FieldProps {
  field: BlueprintField;
  value: string;
  onChange: (value: string) => void;
  onSuggest: (mode: 'with-context' | 'auto') => void;
  isLoading: boolean;
  refined?: RefinedFieldData;
  alternatives?: string[];
}

// Main field renderer
export function FieldRenderer({ field }: { field: BlueprintField }) {
  const {
    state,
    setFieldValue,
    getSuggestion,
  } = useBlueprint();

  const value = state.formData[field.name] || '';
  const isLoading = state.loadingSuggestion[field.name] || false;
  const refined = state.refinedData[field.name];
  const alternatives = state.alternatives[field.name];

  // Check visibility condition
  if (field.visibleIf) {
    const conditionField = state.formData[field.visibleIf.field] || state.refinedData[field.visibleIf.field]?.original;
    const conditionMet = evaluateCondition(field.visibleIf, conditionField);
    if (!conditionMet) return null;
  }

  // Get the appropriate field component
  const FieldComponent = fieldComponents[field.type] || TextField;

  return (
    <div className="field-group">
      <div className="field-label-row">
        <label className="field-label">
          {field.label}
          {field.required && <span className="required-indicator"> *</span>}
        </label>
        {field.ai?.enabled !== false && (
          <div className="suggest-buttons">
            <button
              onClick={() => getSuggestion(field.name, 'with-context')}
              disabled={isLoading || !value.trim()}
            >
              Refine
            </button>
            <button
              onClick={() => getSuggestion(field.name, 'auto')}
              disabled={isLoading}
            >
              Auto
            </button>
          </div>
        )}
      </div>

      <FieldComponent
        field={field}
        value={value}
        onChange={(v) => setFieldValue(field.name, v)}
        onSuggest={(mode) => getSuggestion(field.name, mode)}
        isLoading={isLoading}
        refined={refined}
        alternatives={alternatives}
      />

      {field.helpText && (
        <div className="field-help">{field.helpText}</div>
      )}

      {alternatives && alternatives.length > 0 && (
        <div className="alternatives">
          {alternatives.map((alt, i) => (
            <span
              key={i}
              className="alternative-chip"
              onClick={() => setFieldValue(field.name, alt)}
            >
              {alt.slice(0, 40)}...
            </span>
          ))}
        </div>
      )}

      {refined && (
        <div className="refined-preview">
          <span className="refined-badge">AI Refined</span>
          <div className="refined-content">{refined.refined}</div>
        </div>
      )}
    </div>
  );
}

// Condition evaluator
function evaluateCondition(
  condition: FieldCondition,
  fieldValue: string | undefined
): boolean {
  switch (condition.operator) {
    case 'equals':
      return fieldValue === condition.value;
    case 'notEquals':
      return fieldValue !== condition.value;
    case 'empty':
      return !fieldValue || fieldValue.trim() === '';
    case 'notEmpty':
      return !!fieldValue && fieldValue.trim() !== '';
    case 'contains':
      return !!fieldValue && fieldValue.includes(String(condition.value));
    case 'notContains':
      return !fieldValue || !fieldValue.includes(String(condition.value));
    default:
      return true;
  }
}
```

### Dynamic Stage Renderer

```typescript
// =============================================================================
// DYNAMIC STAGE RENDERER
// =============================================================================

import { useBlueprint } from './BlueprintContext';
import { FieldRenderer } from './FieldRenderer';

export function StageRenderer() {
  const {
    currentStage,
    state,
    isFirstStage,
    isLastStage,
    nextStage,
    prevStage,
    totalStages,
  } = useBlueprint();

  return (
    <div className="stage-card">
      {/* Stage header */}
      <div className="stage-header">
        <h2>Stage {state.currentStageIndex + 1}: {currentStage.title}</h2>
        <p>{currentStage.description}</p>
      </div>

      {/* Fields */}
      <div className="stage-fields">
        {currentStage.fields.map(field => (
          <FieldRenderer key={field.name} field={field} />
        ))}
      </div>

      {/* Navigation */}
      <div className="stage-navigation">
        {!isFirstStage && (
          <button onClick={prevStage}>Previous</button>
        )}
        <button onClick={nextStage}>
          {isLastStage ? 'Generate Document' : 'Next'}
        </button>
      </div>

      {/* Progress indicator */}
      <div className="stage-progress">
        {Array.from({ length: totalStages }).map((_, i) => (
          <div
            key={i}
            className={`progress-dot ${i === state.currentStageIndex ? 'active' : ''} ${i < state.currentStageIndex ? 'completed' : ''}`}
          />
        ))}
      </div>
    </div>
  );
}
```

### Dynamic Document Generator

```typescript
// =============================================================================
// DYNAMIC DOCUMENT GENERATOR
// =============================================================================

import type { WizardBlueprint, BlueprintSection, SectionRenderConfig } from './blueprint-schema';

export class DocumentGenerator {
  constructor(private blueprint: WizardBlueprint) {}

  generate(refinedData: Record<string, RefinedFieldData>, diagramCode?: string): string {
    const projectName = refinedData['projectName']?.original || 'Untitled';
    const title = this.blueprint.config.documentTitle.replace('{{projectName}}', projectName);

    let doc = `# ${title}\n\n`;
    doc += `*Generated on ${new Date().toLocaleDateString()}*\n\n---\n\n`;

    for (const section of this.blueprint.outputSections) {
      // Check visibility condition
      if (section.visibleIf) {
        const conditionMet = this.evaluateCondition(section.visibleIf, refinedData);
        if (!conditionMet) continue;
      }

      // Check if should exclude when empty
      if (section.excludeIfEmpty) {
        const hasData = section.dataKeys.some(key => refinedData[key]?.refined);
        if (!hasData) continue;
      }

      doc += `## ${section.num}. ${section.title}\n\n`;
      doc += this.renderSection(section, refinedData, diagramCode);
      doc += '\n\n';
    }

    return doc;
  }

  private renderSection(
    section: BlueprintSection,
    data: Record<string, RefinedFieldData>,
    diagramCode?: string
  ): string {
    const render = section.render;

    switch (render.type) {
      case 'text':
        return this.renderTextSection(section, data);

      case 'subsections':
        return this.renderSubsections(section, data, render);

      case 'table':
        return this.renderTable(section, data, render);

      case 'list':
        return this.renderList(section, data, render);

      case 'checklist':
        return this.renderChecklist(section, data);

      case 'diagram':
        return this.renderDiagram(section, data);

      case 'embed':
        return this.renderEmbed(section, data, render, diagramCode);

      case 'composite':
        return this.renderComposite(section, data, render);

      default:
        return this.renderTextSection(section, data);
    }
  }

  private renderTextSection(section: BlueprintSection, data: Record<string, RefinedFieldData>): string {
    const content = section.dataKeys
      .map(key => data[key]?.refined)
      .filter(Boolean)
      .join('\n\n');
    return content || '_To be defined_';
  }

  private renderSubsections(
    section: BlueprintSection,
    data: Record<string, RefinedFieldData>,
    render: SectionRenderConfig
  ): string {
    if (!render.subsections) return this.renderTextSection(section, data);

    let result = '';
    render.subsections.forEach((sub, idx) => {
      const content = data[sub.dataKey]?.refined || '_To be defined_';
      result += `### ${section.num}.${idx + 1} ${sub.title}\n\n${content}\n\n`;
    });
    return result;
  }

  private renderTable(
    section: BlueprintSection,
    data: Record<string, RefinedFieldData>,
    render: SectionRenderConfig
  ): string {
    if (!render.table) return this.renderTextSection(section, data);

    const columns = render.table.columns;
    let result = '| ' + columns.map(c => c.header).join(' | ') + ' |\n';
    result += '|' + columns.map(() => '------').join('|') + '|\n';

    const rawData = data[section.dataKeys[0]]?.refined || '';
    const lines = rawData.split('\n').filter(Boolean);

    lines.forEach(line => {
      const cells = line.split(/[-|]/).map(s => s.trim()).filter(Boolean);
      const row = columns.map((col, i) => cells[i] || col.default || '').join(' | ');
      result += `| ${row} |\n`;
    });

    return result;
  }

  private renderList(
    section: BlueprintSection,
    data: Record<string, RefinedFieldData>,
    render: SectionRenderConfig
  ): string {
    const rawData = data[section.dataKeys[0]]?.refined || '';
    const lines = rawData.split('\n').filter(Boolean);
    const style = render.list?.style || 'bullet';

    return lines.map((line, i) => {
      const prefix = style === 'numbered' ? `${i + 1}. ` : '- ';
      return prefix + line.replace(/^[-*\d.]+\s*/, '');
    }).join('\n');
  }

  private renderChecklist(section: BlueprintSection, data: Record<string, RefinedFieldData>): string {
    const rawData = data[section.dataKeys[0]]?.refined || '';
    const lines = rawData.split('\n').filter(Boolean);

    return lines.map(line => {
      const cleaned = line.replace(/^[-*\d.\[\]x\s]+/i, '').trim();
      return `- [ ] ${cleaned}`;
    }).join('\n');
  }

  private renderDiagram(section: BlueprintSection, data: Record<string, RefinedFieldData>): string {
    const content = data[section.dataKeys[0]]?.refined || '_Architecture details to be defined_';
    return content;
  }

  private renderEmbed(
    section: BlueprintSection,
    data: Record<string, RefinedFieldData>,
    render: SectionRenderConfig,
    diagramCode?: string
  ): string {
    if (!render.embed) return '';

    if (render.embed.type === 'mermaid' && diagramCode) {
      return '```mermaid\n' + diagramCode + '\n```\n\n> *Diagram auto-generated from content.*';
    }

    return render.embed.fallbackMessage || '';
  }

  private renderComposite(
    section: BlueprintSection,
    data: Record<string, RefinedFieldData>,
    render: SectionRenderConfig
  ): string {
    const separator = render.composite?.separator || '\n\n';
    const addSubheaders = render.composite?.addSubheaders || false;
    const prefix = render.composite?.subheaderPrefix || '### ';

    return section.dataKeys.map((key, i) => {
      const content = data[key]?.refined || '';
      if (!content) return '';

      if (addSubheaders) {
        const field = this.blueprint.stages
          .flatMap(s => s.fields)
          .find(f => f.name === key);
        const header = field?.label || key;
        return `${prefix}${header}\n\n${content}`;
      }
      return content;
    }).filter(Boolean).join(separator);
  }

  private evaluateCondition(condition: FieldCondition, data: Record<string, RefinedFieldData>): boolean {
    const value = data[condition.field]?.refined || data[condition.field]?.original;
    // ... evaluate condition
    return true;
  }
}
```

---

## State Management Comparison

### Current State (App.tsx)
```typescript
// Multiple useState hooks spread across component
const [state, setState] = useState<EpicState>(initialState);
const [formData, setFormData] = useState<Record<string, string>>({});
const [editingRefined, setEditingRefined] = useState<Record<string, boolean>>({});
const [loadingSuggestion, setLoadingSuggestion] = useState<Record<string, boolean>>({});
const [alternatives, setAlternatives] = useState<Record<string, string[]>>({});
const [isRefining, setIsRefining] = useState(false);
// ... 30+ more useState hooks
```

### Proposed State (BlueprintContext)
```typescript
// Unified state in context with reducer
interface WizardState {
  currentStageIndex: number;
  formData: Record<string, string>;
  refinedData: Record<string, RefinedFieldData>;
  loadingSuggestion: Record<string, boolean>;
  alternatives: Record<string, string[]>;
  editingRefined: Record<string, boolean>;
  generatedDocument: string | null;
  isGenerating: boolean;
  generationProgress: ProgressState;
  diagramCode: string;
  diagramType: string;
}
```

### Benefits of New Architecture:
1. **Single source of truth** - All wizard state in one place
2. **Testable** - Reducer can be unit tested
3. **Predictable** - Actions describe state changes
4. **Blueprint-driven** - State shape derived from blueprint
5. **Composable** - Components use hooks to access only what they need

---

## Self-Critique (Iteration 8)

**Positive:**
- Clear separation between blueprint (config) and state (runtime)
- Field components are truly pluggable via registry
- Document generation is fully dynamic
- Context pattern enables efficient re-renders

**Concerns:**
- Large context value may cause unnecessary re-renders
- Need memoization strategy for expensive derived values
- Migration from 30+ useState to context requires careful refactoring

**Decisions Made:**
1. Use React Context + useReducer over external state library
2. Field component registry allows runtime extension
3. DocumentGenerator is a class for testability

---

### Iteration 9 - 2026-01-24
**Focus:** Template Selector UI, Persistence Strategy, Migration Plan

---

## Template Selector UI Design

### Template Gallery Component

```typescript
// =============================================================================
// TEMPLATE SELECTOR
// =============================================================================

interface TemplateInfo {
  id: string;
  name: string;
  description: string;
  stageCount: number;
  sectionCount: number;
  fieldCount: number;
  category: string;
  icon: string;
  preview?: string;        // Preview image URL
  author?: string;
  version: string;
  createdAt?: string;
  tags?: string[];
}

interface TemplateSelectorProps {
  templates: TemplateInfo[];
  selectedId?: string;
  onSelect: (templateId: string) => void;
  onPreview?: (templateId: string) => void;
}

export function TemplateSelector({
  templates,
  selectedId,
  onSelect,
  onPreview,
}: TemplateSelectorProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');

  // Group templates by category
  const categories = useMemo(() => {
    const cats = new Set(templates.map(t => t.category));
    return ['all', ...Array.from(cats)];
  }, [templates]);

  // Filter templates
  const filteredTemplates = useMemo(() => {
    return templates.filter(t => {
      const matchesSearch = !searchTerm ||
        t.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.tags?.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
      const matchesCategory = categoryFilter === 'all' || t.category === categoryFilter;
      return matchesSearch && matchesCategory;
    });
  }, [templates, searchTerm, categoryFilter]);

  return (
    <div className="template-selector">
      {/* Header */}
      <div className="template-selector-header">
        <h2>Select a Template</h2>
        <p>Choose a template to start your document</p>
      </div>

      {/* Search and filters */}
      <div className="template-selector-filters">
        <input
          type="text"
          placeholder="Search templates..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="template-search"
        />
        <select
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          className="template-category-filter"
        >
          {categories.map(cat => (
            <option key={cat} value={cat}>
              {cat === 'all' ? 'All Categories' : cat}
            </option>
          ))}
        </select>
      </div>

      {/* Template grid */}
      <div className="template-grid">
        {filteredTemplates.map(template => (
          <TemplateCard
            key={template.id}
            template={template}
            isSelected={template.id === selectedId}
            onSelect={() => onSelect(template.id)}
            onPreview={() => onPreview?.(template.id)}
          />
        ))}
      </div>

      {filteredTemplates.length === 0 && (
        <div className="template-empty">
          No templates found matching your criteria.
        </div>
      )}
    </div>
  );
}

// Individual template card
function TemplateCard({
  template,
  isSelected,
  onSelect,
  onPreview,
}: {
  template: TemplateInfo;
  isSelected: boolean;
  onSelect: () => void;
  onPreview?: () => void;
}) {
  return (
    <div
      className={`template-card ${isSelected ? 'selected' : ''}`}
      onClick={onSelect}
    >
      {/* Preview image or icon */}
      <div className="template-card-preview">
        {template.preview ? (
          <img src={template.preview} alt={template.name} />
        ) : (
          <div className="template-card-icon">{template.icon}</div>
        )}
      </div>

      {/* Info */}
      <div className="template-card-info">
        <h3>{template.name}</h3>
        <p>{template.description}</p>

        {/* Stats */}
        <div className="template-card-stats">
          <span>{template.stageCount} stages</span>
          <span>{template.sectionCount} sections</span>
          <span>{template.fieldCount} fields</span>
        </div>

        {/* Tags */}
        {template.tags && template.tags.length > 0 && (
          <div className="template-card-tags">
            {template.tags.slice(0, 3).map(tag => (
              <span key={tag} className="template-tag">{tag}</span>
            ))}
          </div>
        )}
      </div>

      {/* Actions */}
      <div className="template-card-actions">
        {onPreview && (
          <button
            onClick={(e) => { e.stopPropagation(); onPreview(); }}
            className="template-preview-btn"
          >
            Preview
          </button>
        )}
        <button
          onClick={(e) => { e.stopPropagation(); onSelect(); }}
          className="template-select-btn"
        >
          {isSelected ? 'Selected' : 'Use Template'}
        </button>
      </div>
    </div>
  );
}
```

### Template Preview Modal

```typescript
// Template preview shows full structure before selection
function TemplatePreviewModal({
  blueprint,
  onClose,
  onSelect,
}: {
  blueprint: WizardBlueprint;
  onClose: () => void;
  onSelect: () => void;
}) {
  const [activeTab, setActiveTab] = useState<'stages' | 'sections' | 'preview'>('stages');

  return (
    <div className="modal-overlay">
      <div className="template-preview-modal">
        <div className="modal-header">
          <h2>{blueprint.name}</h2>
          <button onClick={onClose}>Close</button>
        </div>

        <div className="modal-tabs">
          <button className={activeTab === 'stages' ? 'active' : ''} onClick={() => setActiveTab('stages')}>
            Stages ({blueprint.stages.length})
          </button>
          <button className={activeTab === 'sections' ? 'active' : ''} onClick={() => setActiveTab('sections')}>
            Output Sections ({blueprint.outputSections.length})
          </button>
          <button className={activeTab === 'preview' ? 'active' : ''} onClick={() => setActiveTab('preview')}>
            Sample Output
          </button>
        </div>

        <div className="modal-content">
          {activeTab === 'stages' && (
            <div className="preview-stages">
              {blueprint.stages.map((stage, i) => (
                <div key={stage.id} className="preview-stage">
                  <h4>Stage {i + 1}: {stage.title}</h4>
                  <p>{stage.description}</p>
                  <ul>
                    {stage.fields.map(field => (
                      <li key={field.name}>
                        <strong>{field.label}</strong>
                        {field.required && <span className="required"> (required)</span>}
                        <span className="field-type">{field.type}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'sections' && (
            <div className="preview-sections">
              {blueprint.outputSections.map(section => (
                <div key={section.id} className="preview-section">
                  <span className="section-num">{section.num}</span>
                  <span className="section-title">{section.title}</span>
                  <span className="section-type">{section.render.type}</span>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'preview' && (
            <div className="preview-sample">
              <MarkdownPreview content={generateSampleDocument(blueprint)} />
            </div>
          )}
        </div>

        <div className="modal-footer">
          <button onClick={onClose} className="btn-secondary">Cancel</button>
          <button onClick={onSelect} className="btn-primary">Use This Template</button>
        </div>
      </div>
    </div>
  );
}
```

---

## Template Persistence Strategy

### Storage Options

| Storage | Pros | Cons | Use Case |
|---------|------|------|----------|
| localStorage | Simple, no server | Size limit (5MB), browser-specific | User drafts |
| IndexedDB | Large storage, structured | Complex API | Template library |
| File System | Full blueprints, portable | Requires user action | Export/Import |
| Remote API | Shared, versioned | Requires backend | Team templates |

### Recommended Hybrid Approach

```typescript
// =============================================================================
// TEMPLATE STORAGE SERVICE
// =============================================================================

interface TemplateStorage {
  // Built-in templates (bundled with app)
  getBuiltInTemplates(): Promise<TemplateInfo[]>;
  loadBuiltInTemplate(id: string): Promise<WizardBlueprint>;

  // User templates (localStorage + IndexedDB)
  getUserTemplates(): Promise<TemplateInfo[]>;
  saveUserTemplate(blueprint: WizardBlueprint): Promise<void>;
  deleteUserTemplate(id: string): Promise<void>;
  loadUserTemplate(id: string): Promise<WizardBlueprint>;

  // Import/Export (File System)
  importTemplate(file: File): Promise<WizardBlueprint>;
  exportTemplate(id: string): Promise<Blob>;

  // Draft persistence (localStorage)
  saveDraft(templateId: string, state: WizardState): void;
  loadDraft(templateId: string): WizardState | null;
  clearDraft(templateId: string): void;
}

class TemplateStorageService implements TemplateStorage {
  private static readonly STORAGE_KEY = 'epic-generator-templates';
  private static readonly DRAFT_KEY_PREFIX = 'epic-generator-draft-';

  // Built-in templates (imported at build time)
  private builtInTemplates: Map<string, WizardBlueprint> = new Map([
    ['technical-architect', TechnicalArchitectBlueprint],
    // Add more built-in templates here
  ]);

  async getBuiltInTemplates(): Promise<TemplateInfo[]> {
    return Array.from(this.builtInTemplates.entries()).map(([id, bp]) => ({
      id,
      name: bp.name,
      description: bp.description,
      stageCount: bp.stages.length,
      sectionCount: bp.outputSections.length,
      fieldCount: bp.stages.reduce((sum, s) => sum + s.fields.length, 0),
      category: 'Built-in',
      icon: 'document',
      version: bp.version,
      author: bp.author,
    }));
  }

  async loadBuiltInTemplate(id: string): Promise<WizardBlueprint> {
    const blueprint = this.builtInTemplates.get(id);
    if (!blueprint) {
      throw new Error(`Built-in template not found: ${id}`);
    }
    return blueprint;
  }

  async getUserTemplates(): Promise<TemplateInfo[]> {
    const stored = localStorage.getItem(TemplateStorageService.STORAGE_KEY);
    if (!stored) return [];

    const templates = JSON.parse(stored) as Record<string, WizardBlueprint>;
    return Object.entries(templates).map(([id, bp]) => ({
      id,
      name: bp.name,
      description: bp.description,
      stageCount: bp.stages.length,
      sectionCount: bp.outputSections.length,
      fieldCount: bp.stages.reduce((sum, s) => sum + s.fields.length, 0),
      category: 'My Templates',
      icon: 'user',
      version: bp.version,
      createdAt: bp.createdAt,
    }));
  }

  async saveUserTemplate(blueprint: WizardBlueprint): Promise<void> {
    const stored = localStorage.getItem(TemplateStorageService.STORAGE_KEY);
    const templates = stored ? JSON.parse(stored) : {};
    templates[blueprint.id] = {
      ...blueprint,
      updatedAt: new Date().toISOString(),
    };
    localStorage.setItem(TemplateStorageService.STORAGE_KEY, JSON.stringify(templates));
  }

  async deleteUserTemplate(id: string): Promise<void> {
    const stored = localStorage.getItem(TemplateStorageService.STORAGE_KEY);
    if (!stored) return;

    const templates = JSON.parse(stored);
    delete templates[id];
    localStorage.setItem(TemplateStorageService.STORAGE_KEY, JSON.stringify(templates));
  }

  async loadUserTemplate(id: string): Promise<WizardBlueprint> {
    const stored = localStorage.getItem(TemplateStorageService.STORAGE_KEY);
    if (!stored) {
      throw new Error(`User template not found: ${id}`);
    }

    const templates = JSON.parse(stored);
    const blueprint = templates[id];
    if (!blueprint) {
      throw new Error(`User template not found: ${id}`);
    }

    return BlueprintLoader.load(blueprint);
  }

  async importTemplate(file: File): Promise<WizardBlueprint> {
    const text = await file.text();
    const json = JSON.parse(text);
    return BlueprintLoader.load(json);
  }

  async exportTemplate(id: string): Promise<Blob> {
    let blueprint: WizardBlueprint;
    if (this.builtInTemplates.has(id)) {
      blueprint = await this.loadBuiltInTemplate(id);
    } else {
      blueprint = await this.loadUserTemplate(id);
    }

    const json = JSON.stringify(blueprint, null, 2);
    return new Blob([json], { type: 'application/json' });
  }

  saveDraft(templateId: string, state: WizardState): void {
    const key = TemplateStorageService.DRAFT_KEY_PREFIX + templateId;
    localStorage.setItem(key, JSON.stringify(state));
  }

  loadDraft(templateId: string): WizardState | null {
    const key = TemplateStorageService.DRAFT_KEY_PREFIX + templateId;
    const stored = localStorage.getItem(key);
    return stored ? JSON.parse(stored) : null;
  }

  clearDraft(templateId: string): void {
    const key = TemplateStorageService.DRAFT_KEY_PREFIX + templateId;
    localStorage.removeItem(key);
  }
}

// Singleton instance
export const templateStorage = new TemplateStorageService();
```

---

## Migration Plan: Hardcoded to Dynamic

### Phase 1: Foundation (Week 1-2)

**Tasks:**
1. Create blueprint schema types (`src/blueprint/schema.ts`)
2. Create blueprint loader with validation (`src/blueprint/loader.ts`)
3. Create Technical Architect blueprint file (`src/blueprints/technical-architect.ts`)
4. Add blueprint context provider (`src/blueprint/BlueprintContext.tsx`)

**Files to Add:**
```
src/
  blueprint/
    schema.ts           # TypeScript interfaces
    loader.ts           # Blueprint loading/validation
    BlueprintContext.tsx # React context + hooks
    DocumentGenerator.ts # Dynamic document generation
  blueprints/
    technical-architect.ts  # First blueprint
    index.ts                # Blueprint registry
```

**Backward Compatibility:**
- Keep existing STAGES and EPIC_SECTIONS as fallback
- Blueprint context wraps existing App when no template selected

### Phase 2: Component Migration (Week 3-4)

**Tasks:**
1. Create FieldRenderer registry (`src/components/fields/`)
2. Create StageRenderer component
3. Create dynamic SectionPreview component
4. Refactor renderWizard() to use components

**Files to Modify:**
- `src/App.tsx` - Replace renderWizard() with <StageRenderer />
- Extract field rendering to individual components

**Migration Strategy:**
```typescript
// Gradual migration flag
const USE_DYNAMIC_WIZARD = true;

function App() {
  if (USE_DYNAMIC_WIZARD && blueprint) {
    return (
      <BlueprintProvider blueprint={blueprint}>
        <DynamicWizard />
      </BlueprintProvider>
    );
  }
  // Fallback to existing hardcoded wizard
  return <LegacyWizard />;
}
```

### Phase 3: AI Integration (Week 5)

**Tasks:**
1. Extract AI prompts from skills.ts to blueprint
2. Create AIService that reads from blueprint
3. Migrate diagram generation to use blueprint config

**Files to Modify:**
- `src/skills.ts` - Refactor to accept blueprint config
- Remove hardcoded fieldPrompts, use blueprint.ai.fields

### Phase 4: Document Generation (Week 6)

**Tasks:**
1. Replace generateEpic() with DocumentGenerator class
2. Implement all render types (table, list, subsections, etc.)
3. Test output parity with existing generator

**Validation:**
- Generate document with old and new systems
- Diff outputs to ensure identical results

### Phase 5: Template System (Week 7-8)

**Tasks:**
1. Add template selector UI
2. Add template persistence
3. Add template import/export
4. Add template editor (optional, future)

**Files to Add:**
```
src/
  components/
    TemplateSelector/
      TemplateSelector.tsx
      TemplateCard.tsx
      TemplatePreviewModal.tsx
```

### Phase 6: Cleanup (Week 9)

**Tasks:**
1. Remove hardcoded STAGES array usage
2. Remove hardcoded EPIC_SECTIONS array usage
3. Remove hardcoded AI prompts from skills.ts
4. Update tests for dynamic system
5. Performance optimization

**Files to Clean:**
- `src/types.ts` - Remove STAGES, EPIC_SECTIONS (or deprecate)
- `src/skills.ts` - Remove fieldPrompts, fieldGuidance

---

## Migration Risk Assessment

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| Output differs from current | Medium | High | Extensive testing, diff comparison |
| Performance regression | Low | Medium | Memoization, lazy loading |
| Breaking existing drafts | Medium | Medium | Draft migration script |
| AI prompts behave differently | Low | Medium | Test each field prompt |
| Complex field types break | Medium | Medium | Phased rollout, feature flags |

---

## Self-Critique (Iteration 9)

**Positive:**
- Comprehensive migration plan with clear phases
- Risk assessment identifies key concerns
- Template selector UI supports discovery and preview
- Persistence strategy covers all use cases

**Concerns:**
- 9-week timeline is optimistic for a single developer
- Need to maintain backward compatibility during transition
- Test coverage for dynamic system needs to match existing

**Decisions Made:**
1. Use feature flag for gradual migration
2. Keep fallback to hardcoded system during transition
3. Validate output parity before removing legacy code

---

### Iteration 10 - 2026-01-24
**Focus:** Detailed Implementation Tasks, Testing Strategy, Breaking Changes Analysis

---

## Implementation Tasks - Prioritized

### Priority 1: Foundation (Critical Path)

| ID | Task | Est. Hours | Dependencies | Files |
|----|------|------------|--------------|-------|
| F1 | Create blueprint schema TypeScript interfaces | 4 | None | `src/blueprint/schema.ts` |
| F2 | Create blueprint loader with validation | 6 | F1 | `src/blueprint/loader.ts` |
| F3 | Create Technical Architect blueprint from current STAGES/EPIC_SECTIONS | 8 | F1 | `src/blueprints/technical-architect.ts` |
| F4 | Create blueprint validation tests | 4 | F2 | `src/test/blueprint.test.ts` |
| F5 | Create BlueprintContext provider | 8 | F1 | `src/blueprint/BlueprintContext.tsx` |
| F6 | Create useBlueprint hook | 2 | F5 | `src/blueprint/hooks.ts` |

**Subtotal: 32 hours**

### Priority 2: Field Components (Core UI)

| ID | Task | Est. Hours | Dependencies | Files |
|----|------|------------|--------------|-------|
| C1 | Create field component interface | 2 | F1 | `src/components/fields/types.ts` |
| C2 | Create TextField component | 2 | C1 | `src/components/fields/TextField.tsx` |
| C3 | Create TextareaField component | 3 | C1 | `src/components/fields/TextareaField.tsx` |
| C4 | Create SelectField component | 3 | C1 | `src/components/fields/SelectField.tsx` |
| C5 | Create ListField component | 4 | C1 | `src/components/fields/ListField.tsx` |
| C6 | Create TableField component | 6 | C1 | `src/components/fields/TableField.tsx` |
| C7 | Create field component registry | 2 | C2-C6 | `src/components/fields/registry.ts` |
| C8 | Create FieldRenderer dynamic component | 4 | C7 | `src/components/fields/FieldRenderer.tsx` |
| C9 | Create field component tests | 8 | C8 | `src/test/fields.test.tsx` |

**Subtotal: 34 hours**

### Priority 3: Wizard Renderer (Dynamic Navigation)

| ID | Task | Est. Hours | Dependencies | Files |
|----|------|------------|--------------|-------|
| W1 | Create StageRenderer component | 6 | C8, F5 | `src/components/wizard/StageRenderer.tsx` |
| W2 | Create StageNavigation component | 3 | F5 | `src/components/wizard/StageNavigation.tsx` |
| W3 | Create StageProgress component | 3 | F5 | `src/components/wizard/StageProgress.tsx` |
| W4 | Create SectionPreview component | 4 | F5 | `src/components/wizard/SectionPreview.tsx` |
| W5 | Create DynamicWizard container | 4 | W1-W4 | `src/components/wizard/DynamicWizard.tsx` |
| W6 | Create wizard component tests | 6 | W5 | `src/test/wizard.test.tsx` |

**Subtotal: 26 hours**

### Priority 4: Document Generation (Output)

| ID | Task | Est. Hours | Dependencies | Files |
|----|------|------------|--------------|-------|
| G1 | Create DocumentGenerator class | 8 | F1 | `src/blueprint/DocumentGenerator.ts` |
| G2 | Implement text section renderer | 2 | G1 | (in DocumentGenerator.ts) |
| G3 | Implement subsections renderer | 3 | G1 | (in DocumentGenerator.ts) |
| G4 | Implement table renderer | 4 | G1 | (in DocumentGenerator.ts) |
| G5 | Implement list/checklist renderer | 3 | G1 | (in DocumentGenerator.ts) |
| G6 | Implement embed renderer | 3 | G1 | (in DocumentGenerator.ts) |
| G7 | Implement composite renderer | 2 | G1 | (in DocumentGenerator.ts) |
| G8 | Create output parity tests | 8 | G7 | `src/test/generator.test.ts` |

**Subtotal: 33 hours**

### Priority 5: AI Integration (Skills Migration)

| ID | Task | Est. Hours | Dependencies | Files |
|----|------|------------|--------------|-------|
| A1 | Create AIService interface | 3 | F1 | `src/blueprint/AIService.ts` |
| A2 | Refactor getSuggestion to use blueprint | 6 | A1, F3 | `src/skills.ts` (modify) |
| A3 | Refactor runSkill to use blueprint AI config | 6 | A1, F3 | `src/skills.ts` (modify) |
| A4 | Migrate diagram generation config | 4 | F3 | `src/skills.ts` (modify) |
| A5 | Create AI integration tests | 6 | A4 | `src/test/ai.test.ts` |

**Subtotal: 25 hours**

### Priority 6: Template System (User-Facing)

| ID | Task | Est. Hours | Dependencies | Files |
|----|------|------------|--------------|-------|
| T1 | Create TemplateSelector component | 6 | F1 | `src/components/templates/TemplateSelector.tsx` |
| T2 | Create TemplateCard component | 3 | T1 | `src/components/templates/TemplateCard.tsx` |
| T3 | Create TemplatePreviewModal | 4 | T1 | `src/components/templates/TemplatePreviewModal.tsx` |
| T4 | Create TemplateStorageService | 6 | F2 | `src/services/TemplateStorage.ts` |
| T5 | Create template import/export | 4 | T4 | `src/services/TemplateStorage.ts` |
| T6 | Create template persistence tests | 4 | T5 | `src/test/templates.test.ts` |

**Subtotal: 27 hours**

### Priority 7: App Integration (Migration)

| ID | Task | Est. Hours | Dependencies | Files |
|----|------|------------|--------------|-------|
| I1 | Add feature flag for dynamic wizard | 2 | All above | `src/App.tsx` (modify) |
| I2 | Integrate BlueprintProvider in App | 4 | F5 | `src/App.tsx` (modify) |
| I3 | Replace renderWizard() calls | 8 | W5 | `src/App.tsx` (modify) |
| I4 | Replace generateEpic() calls | 4 | G1 | `src/App.tsx` (modify) |
| I5 | Integration testing | 8 | I4 | `src/test/integration.test.tsx` |
| I6 | Remove legacy code (post-validation) | 4 | I5 | Multiple files |

**Subtotal: 30 hours**

### Total Estimated Hours: 207 hours (~5-6 weeks at 40 hrs/week)

---

## Testing Strategy

### Unit Tests

| Component | Test Coverage | Priority |
|-----------|--------------|----------|
| BlueprintLoader | validate(), load(), derivePopulatesSections() | High |
| Blueprint Schema | Type validation, required fields | High |
| Field Components | Render, onChange, validation | High |
| DocumentGenerator | All render types, edge cases | High |
| AIService | Prompt building, fallbacks | Medium |
| TemplateStorage | CRUD operations, import/export | Medium |

### Integration Tests

| Scenario | Description | Priority |
|----------|-------------|----------|
| Full wizard flow | Complete 6 stages, generate document | High |
| Output parity | Compare dynamic vs legacy output | Critical |
| Draft persistence | Save and restore wizard state | Medium |
| Template switching | Change template mid-flow | Medium |
| Error handling | Invalid blueprint, network errors | Medium |

### Output Parity Test

```typescript
// Critical test: ensure dynamic generator produces identical output
describe('Output Parity', () => {
  it('produces identical output to legacy generator', async () => {
    // Generate with legacy system
    const legacyOutput = await legacyGenerateEpic(testData);

    // Generate with dynamic system
    const dynamicGenerator = new DocumentGenerator(TechnicalArchitectBlueprint);
    const dynamicOutput = dynamicGenerator.generate(testData);

    // Compare (ignoring whitespace differences)
    expect(normalizeMarkdown(dynamicOutput)).toBe(normalizeMarkdown(legacyOutput));
  });
});
```

### Test Data

```typescript
// Comprehensive test data for all 19 fields
const testData: Record<string, RefinedFieldData> = {
  projectName: { original: 'Test Project', refined: 'Test Project', diagramNode: '' },
  background: { original: 'Test background...', refined: 'Enhanced background...', diagramNode: '' },
  objective: { original: 'Test objective...', refined: 'Enhanced objective...', diagramNode: '' },
  // ... all 19 fields
};
```

---

## Breaking Changes Analysis

### API Changes

| Change | Type | Impact | Migration |
|--------|------|--------|-----------|
| STAGES array deprecated | Deprecation | Low | Use blueprint.stages instead |
| EPIC_SECTIONS array deprecated | Deprecation | Low | Use blueprint.outputSections instead |
| runSkill() signature change | Breaking | Medium | Add blueprint parameter |
| getSuggestion() signature change | Breaking | Medium | Add blueprint parameter |
| generateEpic() deprecated | Deprecation | Medium | Use DocumentGenerator |

### State Shape Changes

| Change | Type | Impact | Migration |
|--------|------|--------|-----------|
| EpicState to WizardState | Breaking | High | Migration function needed |
| formData location | Internal | Low | Handled by context |
| refinedData structure | Internal | Low | Compatible structure |

### Draft Migration

```typescript
// Migrate saved drafts from old format to new
function migrateDraft(legacyState: EpicState): WizardState {
  return {
    currentStageIndex: legacyState.currentStage,
    formData: {}, // No form data in legacy drafts
    refinedData: legacyState.data,
    loadingSuggestion: {},
    alternatives: {},
    editingRefined: {},
    generatedDocument: legacyState.generatedEpic,
    isGenerating: false,
    generationProgress: { current: 0, total: 0, section: '' },
    diagramCode: '',
    diagramType: '',
  };
}
```

### Feature Flags

```typescript
// Feature flags for gradual rollout
const FEATURES = {
  DYNAMIC_WIZARD: true,      // Enable dynamic wizard renderer
  DYNAMIC_GENERATOR: true,   // Enable dynamic document generator
  TEMPLATE_SELECTOR: true,   // Enable template selection UI
  BLUEPRINT_AI: true,        // Use blueprint AI config
  LEGACY_FALLBACK: true,     // Fallback to legacy if dynamic fails
};
```

---

## File Structure After Implementation

```
src/
  blueprint/
    schema.ts               # Blueprint TypeScript interfaces
    loader.ts               # Blueprint loading and validation
    BlueprintContext.tsx    # React context provider
    hooks.ts                # useBlueprint and related hooks
    DocumentGenerator.ts    # Dynamic document generation
    AIService.ts            # Blueprint-aware AI service

  blueprints/
    technical-architect.ts  # Technical Architect template
    simple-proposal.ts      # Simple 3-stage proposal template
    index.ts                # Blueprint registry

  components/
    fields/
      types.ts              # Field component interface
      TextField.tsx
      TextareaField.tsx
      SelectField.tsx
      ListField.tsx
      TableField.tsx
      MarkdownField.tsx
      registry.ts           # Field component registry
      FieldRenderer.tsx     # Dynamic field renderer

    wizard/
      DynamicWizard.tsx     # Main dynamic wizard
      StageRenderer.tsx     # Single stage renderer
      StageNavigation.tsx   # Prev/Next buttons
      StageProgress.tsx     # Progress indicator
      SectionPreview.tsx    # Output section preview

    templates/
      TemplateSelector.tsx
      TemplateCard.tsx
      TemplatePreviewModal.tsx

  services/
    TemplateStorage.ts      # Template persistence

  test/
    blueprint.test.ts       # Blueprint schema tests
    fields.test.tsx         # Field component tests
    wizard.test.tsx         # Wizard component tests
    generator.test.ts       # Document generator tests
    templates.test.ts       # Template storage tests
    integration.test.tsx    # Full flow tests
    parity.test.ts          # Output parity tests

  // Existing files (modified)
  App.tsx                   # Add feature flags, BlueprintProvider
  types.ts                  # Keep for backward compat, deprecate STAGES
  skills.ts                 # Refactor to use blueprint config
  config.ts                 # No changes needed
```

---

## Self-Critique (Iteration 10)

**Positive:**
- Detailed task breakdown with time estimates
- Clear dependency graph between tasks
- Comprehensive testing strategy
- Breaking changes documented with migration paths

**Concerns:**
- 207 hours is substantial - may need to prioritize MVP
- Some estimates may be optimistic (especially integration)
- Need to maintain existing functionality throughout

**Decisions Made:**
1. Foundation and Output parity are critical path
2. Template selector can be deferred to later phase
3. Feature flags enable gradual rollout
4. Legacy fallback ensures safety during migration

---

### Iteration 11 - 2026-01-24
**Focus:** MVP Definition, Backward Compatibility Layer, API Migration Guide

---

## MVP (Minimum Viable Product) Definition

### MVP Scope

The MVP delivers the core dynamic template architecture while maintaining full backward compatibility. Users should not notice any change in behavior.

**In MVP:**
1. Blueprint schema and loader
2. Technical Architect blueprint (exact replica of current)
3. Dynamic document generator (parity with current)
4. Basic field components (text, textarea only - current types)
5. Feature flag for gradual rollout
6. Output parity validation

**Deferred to Post-MVP:**
- Template selector UI
- Additional field types (select, list, table)
- Template import/export
- Template editor
- Multiple built-in templates

### MVP Task List (72 hours)

| ID | Task | Est. Hours | Sprint |
|----|------|------------|--------|
| M1 | Blueprint schema (minimal) | 3 | 1 |
| M2 | Blueprint loader (minimal) | 4 | 1 |
| M3 | Technical Architect blueprint | 6 | 1 |
| M4 | Blueprint validation tests | 3 | 1 |
| M5 | DocumentGenerator (all render types) | 12 | 2 |
| M6 | Output parity tests | 8 | 2 |
| M7 | BlueprintContext (minimal) | 6 | 2 |
| M8 | TextField component | 2 | 3 |
| M9 | TextareaField component | 3 | 3 |
| M10 | FieldRenderer (text/textarea only) | 3 | 3 |
| M11 | StageRenderer | 5 | 3 |
| M12 | Feature flag integration | 4 | 4 |
| M13 | App.tsx integration | 8 | 4 |
| M14 | Integration tests | 5 | 4 |

**Total: 72 hours (~2 weeks)**

### MVP Success Criteria

1. **Output Parity:** Dynamic generator produces identical markdown to current generator
2. **Feature Flag:** Can toggle between legacy and dynamic at runtime
3. **No Regressions:** All existing tests pass
4. **Zero UI Change:** Users cannot tell the difference (same wizard, same output)

---

## Backward Compatibility Layer

### Legacy Adapter Pattern

```typescript
// =============================================================================
// LEGACY ADAPTER
// =============================================================================

import type { Stage, EpicSection } from '../types';
import type { WizardBlueprint, BlueprintStage, BlueprintSection, BlueprintField } from './schema';
import { STAGES, EPIC_SECTIONS } from '../types';

/**
 * Convert legacy STAGES array to blueprint format
 */
export function legacyStagesToBlueprint(stages: Stage[]): BlueprintStage[] {
  return stages.map(stage => ({
    id: stage.id,
    title: stage.title,
    description: stage.description,
    fields: stage.fields.map(field => ({
      name: field.name,
      label: field.label,
      placeholder: field.placeholder,
      type: field.type as 'text' | 'textarea',
      required: field.required,
    })),
    populatesSections: stage.populatesSections.map(num => `section-${num}`),
  }));
}

/**
 * Convert legacy EPIC_SECTIONS array to blueprint format
 */
export function legacySectionsToBlueprint(sections: typeof EPIC_SECTIONS): BlueprintSection[] {
  return sections.map(section => {
    // Determine render type from legacy flags
    let renderType: 'text' | 'subsections' | 'table' | 'embed' = 'text';
    if (section.subsections) renderType = 'subsections';
    else if (section.isTable) renderType = 'table';
    else if (section.isReference) renderType = 'embed';

    const blueprintSection: BlueprintSection = {
      id: `section-${section.num}`,
      num: section.num,
      title: section.title,
      dataKeys: section.dataKeys,
      render: { type: renderType },
    };

    // Add render config based on type
    if (section.subsections) {
      blueprintSection.render.subsections = section.subsections.map((title, i) => ({
        title,
        dataKey: section.dataKeys[i],
      }));
    }

    if (section.isTable && section.dataKeys[0] === 'teams') {
      blueprintSection.render.table = {
        columns: [{ header: 'Role' }, { header: 'Responsibility' }],
        parseMode: 'lines',
      };
    }

    if (section.isTable && section.dataKeys[0] === 'approvers') {
      blueprintSection.render.table = {
        columns: [{ header: 'Approver' }, { header: 'Role' }, { header: 'Status', default: 'Pending' }],
        parseMode: 'lines',
      };
    }

    if (section.isReference) {
      blueprintSection.render.embed = {
        type: 'mermaid',
        fallbackMessage: 'Generate a diagram in the Blueprint tab to include it here.',
      };
    }

    return blueprintSection;
  });
}

/**
 * Create a full blueprint from legacy arrays
 */
export function createLegacyBlueprint(): WizardBlueprint {
  return {
    id: 'technical-architect-legacy',
    name: 'Technical Architect (Legacy)',
    version: '1.0.0-legacy',
    description: 'Auto-generated from legacy STAGES and EPIC_SECTIONS',
    config: {
      documentTitle: 'Technical Design Epic: {{projectName}}',
      autoRefineOnNext: true,
      showSectionPreview: true,
      contextFields: ['projectName', 'objective', 'background'],
    },
    stages: legacyStagesToBlueprint(STAGES),
    outputSections: legacySectionsToBlueprint(EPIC_SECTIONS),
    ai: {
      enabled: true,
      baseSystemPrompt: 'You are an expert technical writer...',
      fields: {}, // Will be populated from skills.ts
    },
  };
}

/**
 * Convert blueprint back to legacy format (for gradual migration)
 */
export function blueprintToLegacyStages(blueprint: WizardBlueprint): Stage[] {
  return blueprint.stages.map(stage => ({
    id: stage.id,
    title: stage.title,
    description: stage.description,
    fields: stage.fields.map(field => ({
      name: field.name,
      label: field.label,
      placeholder: field.placeholder || '',
      type: field.type as 'text' | 'textarea',
      required: field.required || false,
    })),
    populatesSections: stage.populatesSections?.map(id => parseInt(id.replace('section-', ''))) || [],
  }));
}
```

### Compatibility Shims

```typescript
// =============================================================================
// COMPATIBILITY SHIMS
// =============================================================================

import { FEATURES } from './features';
import type { WizardBlueprint } from './schema';
import type { RefinedData } from '../types';
import { DocumentGenerator } from './DocumentGenerator';

/**
 * Generate epic - routes to appropriate generator based on feature flag
 */
export async function generateEpicCompat(
  data: RefinedData,
  projectName: string,
  blueprintCode?: string,
  blueprint?: WizardBlueprint
): Promise<{ epic: string; diagram: string }> {
  if (FEATURES.DYNAMIC_GENERATOR && blueprint) {
    const generator = new DocumentGenerator(blueprint);
    const epic = generator.generate(
      convertRefinedDataToNew(data),
      blueprintCode
    );
    return { epic, diagram: '' };
  }

  // Fall back to legacy generator
  const { runSkill } = await import('../skills');
  return runSkill('generate', { data, projectName, blueprintCode }) as Promise<{ epic: string; diagram: string }>;
}

/**
 * Get AI suggestion - routes based on feature flag
 */
export async function getSuggestionCompat(
  stageId: string,
  fieldName: string,
  context: Record<string, string>,
  mode: 'with-context' | 'auto',
  blueprint?: WizardBlueprint
): Promise<{ suggestion: string; alternatives?: string[] }> {
  if (FEATURES.BLUEPRINT_AI && blueprint) {
    const aiService = new AIService(blueprint);
    return aiService.getSuggestion(stageId, fieldName, context, mode);
  }

  // Fall back to legacy suggestion
  const { getSuggestion } = await import('../skills');
  return getSuggestion(stageId, fieldName, context, mode);
}

/**
 * Convert old RefinedData format to new format
 */
function convertRefinedDataToNew(data: RefinedData): Record<string, RefinedFieldData> {
  const result: Record<string, RefinedFieldData> = {};
  Object.entries(data).forEach(([key, value]) => {
    result[key] = {
      original: value.original,
      refined: value.refined,
      diagramNode: value.diagramNode,
    };
  });
  return result;
}
```

---

## API Migration Guide

### For Developers Extending Epic Generator

#### Migrating from STAGES to Blueprint

**Before (Legacy):**
```typescript
import { STAGES } from './types';

// Get stage by index
const currentStage = STAGES[stageIndex];

// Get all fields
const allFields = STAGES.flatMap(s => s.fields);

// Check if field exists
const hasField = STAGES.some(s => s.fields.some(f => f.name === fieldName));
```

**After (Blueprint):**
```typescript
import { useBlueprint } from './blueprint/BlueprintContext';

// In a component
function MyComponent() {
  const { currentStage, stages, getFieldConfig } = useBlueprint();

  // Get current stage
  // currentStage is automatically tracked

  // Get all fields
  const allFields = stages.flatMap(s => s.fields);

  // Check if field exists
  const fieldConfig = getFieldConfig(fieldName);
}

// Outside a component
import { TechnicalArchitectBlueprint } from './blueprints/technical-architect';

const allFields = TechnicalArchitectBlueprint.stages.flatMap(s => s.fields);
```

#### Migrating from EPIC_SECTIONS to Blueprint

**Before (Legacy):**
```typescript
import { EPIC_SECTIONS } from './types';

// Get section by number
const section = EPIC_SECTIONS.find(s => s.num === sectionNum);

// Check for table rendering
if (section.isTable) {
  // Render as table
}

// Check for subsections
if (section.subsections) {
  section.subsections.forEach((title, i) => {
    const dataKey = section.dataKeys[i];
  });
}
```

**After (Blueprint):**
```typescript
import { useBlueprint } from './blueprint/BlueprintContext';

function MyComponent() {
  const { sections, getSectionConfig } = useBlueprint();

  // Get section by ID
  const section = getSectionConfig('scope');

  // Check for table rendering
  if (section.render.type === 'table') {
    const columns = section.render.table?.columns;
  }

  // Check for subsections
  if (section.render.type === 'subsections') {
    section.render.subsections?.forEach(sub => {
      const { title, dataKey } = sub;
    });
  }
}
```

#### Migrating generateEpic()

**Before (Legacy):**
```typescript
import { runSkill } from './skills';

const result = await runSkill('generate', {
  data: state.data,
  projectName,
  blueprintCode,
}) as { epic: string; diagram: string };
```

**After (Blueprint):**
```typescript
import { DocumentGenerator } from './blueprint/DocumentGenerator';
import { TechnicalArchitectBlueprint } from './blueprints/technical-architect';

const generator = new DocumentGenerator(TechnicalArchitectBlueprint);
const epic = generator.generate(state.refinedData, blueprintCode);
```

**With Compatibility Layer:**
```typescript
import { generateEpicCompat } from './blueprint/compat';

const result = await generateEpicCompat(
  state.data,
  projectName,
  blueprintCode,
  currentBlueprint // Optional: uses legacy if not provided
);
```

#### Migrating AI Prompts

**Before (Legacy - in skills.ts):**
```typescript
const fieldPrompts: Record<string, Record<string, string>> = {
  project: {
    projectName: 'Generate a professional project name...',
    background: 'Write a project background section...',
  },
  // ...
};
```

**After (Blueprint):**
```typescript
// In blueprint definition
const blueprint: WizardBlueprint = {
  // ...
  stages: [
    {
      id: 'project',
      fields: [
        {
          name: 'projectName',
          ai: {
            suggestion: {
              systemPromptSuffix: 'Generate a professional project name...',
              guidance: 'Generate a professional, concise project name.',
            },
          },
        },
        // ...
      ],
    },
  ],
};
```

### Type Migration Table

| Legacy Type | Blueprint Type | Notes |
|-------------|----------------|-------|
| `Stage` | `BlueprintStage` | Extended with render config |
| `StageField` | `BlueprintField` | Extended with AI, validation |
| `EpicSection` | `BlueprintSection` | Extended with render config |
| `EpicState` | `WizardState` | Restructured for context |
| `RefinedData` | `Record<string, RefinedFieldData>` | Same structure |

---

## Self-Critique (Iteration 11)

**Positive:**
- MVP scope is realistic and achievable in 2 weeks
- Backward compatibility layer provides safe migration path
- API migration guide helps developers adapt

**Concerns:**
- Legacy adapter adds maintenance burden
- Need to ensure compatibility layer performance is acceptable
- Some edge cases in section rendering may not be covered

**Decisions Made:**
1. MVP focuses on parity, not new features
2. Compatibility shims enable incremental migration
3. Feature flags provide rollback capability

---

### Iteration 12 - 2026-01-24
**Focus:** Data Flow Diagrams, Edge Case Analysis, Render Type Refinement

---

## Complete Data Flow Architecture

### Wizard Data Flow

```mermaid
flowchart TD
    subgraph User["User Interaction"]
        INPUT[User Types in Field]
        CLICK_SUGGEST[Click Suggest/Auto]
        CLICK_NEXT[Click Next Stage]
        CLICK_GEN[Click Generate]
    end

    subgraph State["State Management"]
        FORM[formData<br/>Record string string]
        REFINED[refinedData<br/>Record string RefinedFieldData]
        STAGE[currentStageIndex<br/>number]
        DOC[generatedDocument<br/>string]
    end

    subgraph AI["AI Processing"]
        GET_SUGGEST[getSuggestion<br/>skills.ts]
        REFINE[refineStage<br/>skills.ts]
        DIAG_GEN[generateDiagram<br/>skills.ts]
    end

    subgraph Output["Document Generation"]
        DOC_GEN[DocumentGenerator<br/>generate]
        SECT_RENDER[Section Renderers<br/>text/table/list/etc]
    end

    INPUT --> FORM
    CLICK_SUGGEST --> GET_SUGGEST
    GET_SUGGEST --> FORM

    CLICK_NEXT --> REFINE
    REFINE --> REFINED
    REFINED --> |increment| STAGE

    CLICK_GEN --> DIAG_GEN
    DIAG_GEN --> DOC_GEN
    REFINED --> DOC_GEN
    DOC_GEN --> SECT_RENDER
    SECT_RENDER --> DOC
```

### Blueprint Loading Flow

```mermaid
flowchart LR
    subgraph Sources["Blueprint Sources"]
        FILE[JSON File]
        TS[TypeScript Import]
        STORAGE[LocalStorage]
    end

    subgraph Loader["Blueprint Loader"]
        PARSE[Parse JSON]
        VALIDATE[Validate Schema]
        NORMALIZE[Normalize Defaults]
        DERIVE[Derive populatesSections]
    end

    subgraph Runtime["Runtime Usage"]
        CONTEXT[BlueprintContext]
        WIZARD[DynamicWizard]
        GENERATOR[DocumentGenerator]
    end

    FILE --> PARSE
    TS --> VALIDATE
    STORAGE --> PARSE

    PARSE --> VALIDATE
    VALIDATE --> NORMALIZE
    NORMALIZE --> DERIVE
    DERIVE --> CONTEXT

    CONTEXT --> WIZARD
    CONTEXT --> GENERATOR
```

### AI Integration Flow

```mermaid
sequenceDiagram
    participant User
    participant Field as FieldRenderer
    participant Context as BlueprintContext
    participant AI as AIService
    participant API as OpenAI/Azure

    User->>Field: Type in field
    Field->>Context: setFieldValue(name, value)

    User->>Field: Click "Auto" or "Refine"
    Field->>Context: getSuggestion(fieldName, mode)
    Context->>AI: getSuggestion(stageId, fieldName, context, mode)

    AI->>AI: Build system prompt from blueprint.ai
    AI->>AI: Build user prompt with context
    AI->>API: Send chat completion request

    API-->>AI: Return suggestion
    AI-->>Context: Return { suggestion, alternatives }
    Context-->>Field: Update formData via typewriter effect
```

---

## Edge Case Analysis

### Field Edge Cases

| Edge Case | Current Handling | Blueprint Handling |
|-----------|-----------------|-------------------|
| Empty required field | Validation on next | `field.required` + `field.validation` |
| Very long input (>10k chars) | Truncated in AI | `field.validation.maxLength` |
| Special characters in input | Passed through | Consider `field.validation.pattern` |
| HTML/Markdown in textarea | Rendered in preview | Sanitization configurable |
| Field depends on hidden field | N/A (no conditionals) | `field.visibleIf` + `field.dependsOn` |
| Default value not set | Empty string | `field.defaultValue` |
| AI returns empty/error | Shows error toast | `field.ai.fallback.behavior` |

### Stage Navigation Edge Cases

| Edge Case | Current Handling | Blueprint Handling |
|-----------|-----------------|-------------------|
| Navigate to invalid stage | Clamped to bounds | `goToStage` validates index |
| Skip stages (not sequential) | Allowed | Optional `stage.validation` |
| All fields empty | Allowed to proceed | `stage.validation.requireAtLeastOne` |
| Stage becomes hidden mid-flow | N/A | Re-evaluate `stage.visibleIf` |
| Draft restore with different template | Shows old data | Version check, migration prompt |

### Section Rendering Edge Cases

| Edge Case | Current Handling | Blueprint Handling |
|-----------|-----------------|-------------------|
| Empty section | "_To be defined_" | `section.excludeIfEmpty` or placeholder |
| Table with no rows | Empty table header | Configurable fallback message |
| Subsection missing one part | Shows placeholder | Render available, note missing |
| Diagram embed with no code | Fallback message | `render.embed.fallbackMessage` |
| Composite with one empty key | Skips empty | Configurable behavior |
| List with non-list input | Splits by newline | `render.list.parseMode` |

### Rendering Implementation Details

```typescript
// =============================================================================
// EDGE CASE HANDLING IN RENDER TYPES
// =============================================================================

interface RenderOptions {
  emptyPlaceholder?: string;
  excludeIfEmpty?: boolean;
  sanitizeHtml?: boolean;
}

class DocumentGenerator {
  private renderSection(
    section: BlueprintSection,
    data: Record<string, RefinedFieldData>,
    options: RenderOptions = {}
  ): string | null {
    const { emptyPlaceholder = '_To be defined_', excludeIfEmpty = false } = options;

    // Check if section has any data
    const hasData = section.dataKeys.some(key => {
      const content = data[key]?.refined || data[key]?.original;
      return content && content.trim().length > 0;
    });

    // Handle empty section
    if (!hasData) {
      if (excludeIfEmpty || section.excludeIfEmpty) {
        return null; // Skip entirely
      }
      return emptyPlaceholder;
    }

    // Render based on type
    switch (section.render.type) {
      case 'text':
        return this.renderText(section, data, emptyPlaceholder);

      case 'table':
        return this.renderTable(section, data, emptyPlaceholder);

      case 'list':
        return this.renderList(section, data, emptyPlaceholder);

      case 'subsections':
        return this.renderSubsections(section, data, emptyPlaceholder);

      case 'embed':
        return this.renderEmbed(section, data);

      case 'composite':
        return this.renderComposite(section, data, emptyPlaceholder);

      default:
        return this.renderText(section, data, emptyPlaceholder);
    }
  }

  private renderTable(
    section: BlueprintSection,
    data: Record<string, RefinedFieldData>,
    placeholder: string
  ): string {
    const tableConfig = section.render.table;
    if (!tableConfig) return placeholder;

    const content = data[section.dataKeys[0]]?.refined || '';
    if (!content.trim()) return placeholder;

    // Parse content into rows
    let rows: string[][] = [];
    switch (tableConfig.parseMode) {
      case 'lines':
        rows = content.split('\n')
          .filter(line => line.trim())
          .map(line => this.parseTableLine(line, tableConfig.columns.length));
        break;

      case 'delimiter':
        const delimiter = tableConfig.delimiter || '|';
        rows = content.split('\n')
          .filter(line => line.trim())
          .map(line => line.split(delimiter).map(cell => cell.trim()));
        break;

      case 'json':
        try {
          const jsonData = JSON.parse(content);
          if (Array.isArray(jsonData)) {
            rows = jsonData.map(item =>
              tableConfig.columns.map(col => String(item[col.dataPath || col.header] || col.default || ''))
            );
          }
        } catch {
          rows = [[content]];
        }
        break;

      default:
        rows = content.split('\n')
          .filter(line => line.trim())
          .map(line => this.parseTableLine(line, tableConfig.columns.length));
    }

    // Handle empty rows
    if (rows.length === 0) {
      return placeholder;
    }

    // Build markdown table
    const headers = tableConfig.columns.map(c => c.header);
    let table = '| ' + headers.join(' | ') + ' |\n';
    table += '|' + headers.map(() => '------').join('|') + '|\n';

    rows.forEach(row => {
      // Ensure row has correct number of cells
      while (row.length < tableConfig.columns.length) {
        const colIndex = row.length;
        row.push(tableConfig.columns[colIndex]?.default || '');
      }
      table += '| ' + row.join(' | ') + ' |\n';
    });

    return table;
  }

  private parseTableLine(line: string, columnCount: number): string[] {
    // Smart parsing for "Role - Responsibility" or "Name | Role | Status" formats
    const separators = [' - ', ' | ', '\t', '  '];

    for (const sep of separators) {
      if (line.includes(sep)) {
        const parts = line.split(sep).map(p => p.trim());
        // Pad or truncate to column count
        while (parts.length < columnCount) {
          parts.push('');
        }
        return parts.slice(0, columnCount);
      }
    }

    // No separator found - put entire line in first column
    const result = [line.trim()];
    while (result.length < columnCount) {
      result.push('');
    }
    return result;
  }

  private renderList(
    section: BlueprintSection,
    data: Record<string, RefinedFieldData>,
    placeholder: string
  ): string {
    const listConfig = section.render.list;
    const content = data[section.dataKeys[0]]?.refined || '';

    if (!content.trim()) return placeholder;

    // Parse content into items
    let items: string[] = [];

    switch (listConfig?.parseMode) {
      case 'delimiter':
        items = content.split(listConfig.delimiter || ',').map(s => s.trim()).filter(Boolean);
        break;

      case 'lines':
      default:
        items = content.split('\n').map(s => s.trim()).filter(Boolean);
        break;
    }

    if (items.length === 0) return placeholder;

    // Clean items (remove existing list markers)
    items = items.map(item => item.replace(/^[-*\d.\[\]x]\s*/i, '').trim());

    // Format based on style
    const style = listConfig?.style || 'bullet';
    return items.map((item, i) => {
      switch (style) {
        case 'numbered':
          return `${i + 1}. ${item}`;
        case 'checkbox':
          return `- [ ] ${item}`;
        case 'bullet':
        default:
          return `- ${item}`;
      }
    }).join('\n');
  }

  private renderSubsections(
    section: BlueprintSection,
    data: Record<string, RefinedFieldData>,
    placeholder: string
  ): string {
    const subsections = section.render.subsections;
    if (!subsections) return this.renderText(section, data, placeholder);

    let result = '';
    subsections.forEach((sub, idx) => {
      const content = data[sub.dataKey]?.refined || placeholder;
      result += `### ${section.num}.${idx + 1} ${sub.title}\n\n${content}\n\n`;
    });

    return result;
  }

  private renderEmbed(
    section: BlueprintSection,
    data: Record<string, RefinedFieldData>,
    diagramCode?: string
  ): string {
    const embedConfig = section.render.embed;
    if (!embedConfig) return '';

    switch (embedConfig.type) {
      case 'mermaid':
        if (diagramCode && diagramCode.trim()) {
          return '```mermaid\n' + diagramCode.trim() + '\n```\n\n> *Diagram auto-generated from content.*';
        }
        return embedConfig.fallbackMessage || '';

      case 'code':
        const sourceContent = embedConfig.sourceField ? data[embedConfig.sourceField]?.refined : '';
        if (sourceContent) {
          const lang = embedConfig.language || '';
          return '```' + lang + '\n' + sourceContent + '\n```';
        }
        return embedConfig.fallbackMessage || '';

      case 'image':
        // Placeholder for future image embedding
        return embedConfig.fallbackMessage || '';

      default:
        return embedConfig.fallbackMessage || '';
    }
  }

  private renderComposite(
    section: BlueprintSection,
    data: Record<string, RefinedFieldData>,
    placeholder: string
  ): string {
    const compositeConfig = section.render.composite;
    const separator = compositeConfig?.separator || '\n\n';
    const addSubheaders = compositeConfig?.addSubheaders || false;
    const prefix = compositeConfig?.subheaderPrefix || '### ';

    const parts: string[] = [];

    section.dataKeys.forEach(key => {
      const content = data[key]?.refined || '';
      if (!content.trim()) return; // Skip empty

      if (addSubheaders) {
        // Find field label for subheader
        const field = this.findField(key);
        const header = field?.label || key;
        parts.push(`${prefix}${header}\n\n${content}`);
      } else {
        parts.push(content);
      }
    });

    if (parts.length === 0) return placeholder;
    return parts.join(separator);
  }
}
```

---

## Self-Critique (Iteration 12)

**Positive:**
- Comprehensive data flow diagrams clarify architecture
- Edge cases systematically documented
- Render type implementations handle real-world input variations

**Concerns:**
- Table parsing heuristics may not cover all formats
- Need to test with real user input data
- Performance of smart parsing not evaluated

**Decisions Made:**
1. Default to lenient parsing (don't fail, show what we have)
2. Configurable parseMode allows users to choose behavior
3. Always provide fallback/placeholder for empty sections

---

### Iteration 13 - 2026-01-24
**Focus:** AI Prompt Template System, Performance Optimization, Error Handling

---

## AI Prompt Template System

### Prompt Construction Pipeline

```mermaid
flowchart LR
    subgraph Config["Blueprint AI Config"]
        BASE[baseSystemPrompt]
        FIELD_AI[field.ai.suggestion]
        CONTEXT_FIELDS[config.contextFields]
    end

    subgraph Builder["Prompt Builder"]
        SYS[buildSystemPrompt]
        USER[buildUserPrompt]
        CTX[buildContext]
    end

    subgraph Output["API Request"]
        MESSAGES[messages array]
        PARAMS[temperature, maxTokens]
    end

    BASE --> SYS
    FIELD_AI --> SYS

    CONTEXT_FIELDS --> CTX
    CTX --> USER
    FIELD_AI --> USER

    SYS --> MESSAGES
    USER --> MESSAGES
    FIELD_AI --> PARAMS
```

### AIService Implementation

```typescript
// =============================================================================
// AI SERVICE - BLUEPRINT-AWARE
// =============================================================================

import type { WizardBlueprint, FieldAIConfig } from './schema';
import { callOpenAI, callAzureOpenAI } from '../config';

interface AIRequestOptions {
  temperature?: number;
  maxTokens?: number;
  stopSequences?: string[];
}

interface AIResponse {
  content: string;
  usage?: {
    promptTokens: number;
    completionTokens: number;
  };
}

export class AIService {
  private blueprint: WizardBlueprint;
  private cache: Map<string, AIResponse> = new Map();

  constructor(blueprint: WizardBlueprint) {
    this.blueprint = blueprint;
  }

  /**
   * Get AI suggestion for a field
   */
  async getSuggestion(
    stageId: string,
    fieldName: string,
    context: Record<string, string>,
    mode: 'with-context' | 'auto'
  ): Promise<{ suggestion: string; alternatives?: string[] }> {
    // Check if AI is enabled
    if (!this.blueprint.ai.enabled) {
      return { suggestion: '' };
    }

    // Get field-specific AI config
    const fieldConfig = this.getFieldAIConfig(fieldName);
    if (fieldConfig?.enabled === false) {
      return this.handleDisabledAI(fieldConfig);
    }

    // Build prompts
    const systemPrompt = this.buildSystemPrompt(fieldName, fieldConfig);
    const userPrompt = this.buildUserPrompt(fieldName, context, mode, fieldConfig);

    // Check cache
    const cacheKey = this.getCacheKey(fieldName, userPrompt);
    const cached = this.cache.get(cacheKey);
    if (cached) {
      return { suggestion: cached.content };
    }

    // Make API request
    const options: AIRequestOptions = {
      temperature: fieldConfig?.suggestion?.temperature ?? this.blueprint.ai.defaultTemperature ?? 0.7,
      maxTokens: fieldConfig?.suggestion?.maxTokens ?? this.blueprint.ai.defaultMaxTokens ?? 2048,
    };

    try {
      const response = await this.callAI(systemPrompt, userPrompt, options);

      // Cache response
      this.cache.set(cacheKey, response);

      return {
        suggestion: response.content,
        alternatives: this.extractAlternatives(response.content),
      };
    } catch (error) {
      console.error('AI suggestion failed:', error);
      return this.handleAIError(fieldConfig);
    }
  }

  /**
   * Refine user input with AI
   */
  async refineInput(
    fieldName: string,
    input: string,
    context: Record<string, string>
  ): Promise<{ refined: string; diagramNode?: string }> {
    if (!this.blueprint.ai.enabled || !input.trim()) {
      return { refined: input };
    }

    const fieldConfig = this.getFieldAIConfig(fieldName);
    if (fieldConfig?.enabled === false) {
      return { refined: input };
    }

    const systemPrompt = this.buildRefinementSystemPrompt(fieldName, fieldConfig);
    const userPrompt = this.buildRefinementUserPrompt(input, context, fieldConfig);

    try {
      const response = await this.callAI(systemPrompt, userPrompt, {
        temperature: 0.3, // Lower temperature for refinement
        maxTokens: 2048,
      });

      return {
        refined: response.content,
        diagramNode: this.extractDiagramNode(fieldName, response.content),
      };
    } catch (error) {
      console.error('AI refinement failed:', error);
      return { refined: input }; // Fallback to original
    }
  }

  /**
   * Build system prompt for suggestions
   */
  private buildSystemPrompt(fieldName: string, fieldConfig?: FieldAIConfig): string {
    let prompt = this.blueprint.ai.baseSystemPrompt;

    // Add field-specific suffix
    if (fieldConfig?.suggestion?.systemPromptSuffix) {
      prompt += '\n\n' + fieldConfig.suggestion.systemPromptSuffix;
    }

    // Add format guidance
    if (fieldConfig?.suggestion?.format) {
      prompt += '\n\n' + this.getFormatGuidance(fieldConfig.suggestion.format);
    }

    return prompt;
  }

  /**
   * Build user prompt with context
   */
  private buildUserPrompt(
    fieldName: string,
    context: Record<string, string>,
    mode: 'with-context' | 'auto',
    fieldConfig?: FieldAIConfig
  ): string {
    let prompt = '';

    // Add project context
    const contextFields = this.blueprint.config.contextFields || ['projectName', 'objective', 'background'];
    contextFields.forEach(field => {
      if (context[field]) {
        prompt += `${this.capitalizeField(field)}: ${context[field]}\n`;
      }
    });

    // Add additional context fields from field config
    fieldConfig?.suggestion?.contextFields?.forEach(field => {
      if (context[field] && !contextFields.includes(field)) {
        prompt += `${this.capitalizeField(field)}: ${context[field]}\n`;
      }
    });

    // Add user hint for with-context mode
    if (mode === 'with-context' && context['_userHint']) {
      prompt += `\nUser's keywords/ideas to incorporate: ${context['_userHint']}\n`;
      prompt += `\nBased on these keywords, generate appropriate content for the "${fieldName}" field.`;
    } else {
      prompt += `\nGenerate content for the "${fieldName}" field based on the project context above.`;
    }

    // Add guidance
    if (fieldConfig?.suggestion?.guidance) {
      prompt += '\n' + fieldConfig.suggestion.guidance;
    }

    // Add examples if available
    if (fieldConfig?.suggestion?.examples && fieldConfig.suggestion.examples.length > 0) {
      prompt += '\n\nExamples:\n';
      fieldConfig.suggestion.examples.forEach((example, i) => {
        prompt += `${i + 1}. ${example}\n`;
      });
    }

    return prompt;
  }

  /**
   * Get format guidance string
   */
  private getFormatGuidance(format: string): string {
    const guides: Record<string, string> = {
      prose: 'Write in clear, professional paragraphs.',
      bullets: 'Use bullet points, one item per line. Start each line with "- ".',
      numbered: 'Use a numbered list. Start each line with "1. ", "2. ", etc.',
      table: 'Format as key-value pairs separated by " - " (e.g., "Role - Responsibility").',
      structured: 'Use a structured format appropriate for the content type.',
    };
    return guides[format] || '';
  }

  /**
   * Get field AI config from blueprint
   */
  private getFieldAIConfig(fieldName: string): FieldAIConfig | undefined {
    // First check ai.fields
    if (this.blueprint.ai.fields[fieldName]) {
      return this.blueprint.ai.fields[fieldName];
    }

    // Then check field definition in stages
    for (const stage of this.blueprint.stages) {
      const field = stage.fields.find(f => f.name === fieldName);
      if (field?.ai) {
        return field.ai;
      }
    }

    return undefined;
  }

  /**
   * Handle disabled AI for a field
   */
  private handleDisabledAI(config?: FieldAIConfig): { suggestion: string } {
    const behavior = config?.fallback?.behavior || 'skip';
    switch (behavior) {
      case 'use-default':
        return { suggestion: config?.fallback?.defaultValue || '' };
      case 'skip':
      default:
        return { suggestion: '' };
    }
  }

  /**
   * Handle AI error
   */
  private handleAIError(config?: FieldAIConfig): { suggestion: string } {
    const behavior = config?.fallback?.behavior || 'skip';
    switch (behavior) {
      case 'use-default':
        return { suggestion: config?.fallback?.defaultValue || '' };
      case 'skip':
      default:
        return { suggestion: '' };
    }
  }

  // Helper methods...
  private getCacheKey(fieldName: string, prompt: string): string {
    return `${fieldName}:${hashString(prompt)}`;
  }

  private capitalizeField(field: string): string {
    return field.charAt(0).toUpperCase() + field.slice(1).replace(/([A-Z])/g, ' $1');
  }

  private extractAlternatives(content: string): string[] | undefined {
    // Could implement alternative extraction logic here
    return undefined;
  }

  private extractDiagramNode(fieldName: string, content: string): string {
    return `${fieldName}["${content.slice(0, 30)}..."]`;
  }

  private async callAI(
    systemPrompt: string,
    userPrompt: string,
    options: AIRequestOptions
  ): Promise<AIResponse> {
    // Delegate to appropriate API based on config
    // This would use the existing config.ts infrastructure
    const messages = [
      { role: 'system' as const, content: systemPrompt },
      { role: 'user' as const, content: userPrompt },
    ];

    // Implementation depends on AI provider
    return { content: '' };
  }
}

function hashString(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return hash.toString(36);
}
```

---

## Performance Optimization Strategies

### 1. Lazy Loading Blueprints

```typescript
// Lazy load blueprints only when needed
const blueprintRegistry: Record<string, () => Promise<WizardBlueprint>> = {
  'technical-architect': () => import('./blueprints/technical-architect').then(m => m.default),
  'simple-proposal': () => import('./blueprints/simple-proposal').then(m => m.default),
};

async function loadBlueprint(id: string): Promise<WizardBlueprint> {
  const loader = blueprintRegistry[id];
  if (!loader) {
    throw new Error(`Blueprint not found: ${id}`);
  }
  return loader();
}
```

### 2. Memoization Strategy

```typescript
// Memoize expensive computations
const useBlueprintMemo = () => {
  const { blueprint, state } = useBlueprint();

  // Memoize field lookup map
  const fieldMap = useMemo(() => {
    const map = new Map<string, BlueprintField>();
    blueprint.stages.forEach(stage => {
      stage.fields.forEach(field => {
        map.set(field.name, field);
      });
    });
    return map;
  }, [blueprint]);

  // Memoize populated sections calculation
  const populatedSections = useMemo(() => {
    const populated = new Set<string>();
    blueprint.stages.slice(0, state.currentStageIndex + 1).forEach(stage => {
      const hasData = stage.fields.some(f => state.refinedData[f.name]?.refined);
      if (hasData && stage.populatesSections) {
        stage.populatesSections.forEach(s => populated.add(s));
      }
    });
    return populated;
  }, [blueprint.stages, state.currentStageIndex, state.refinedData]);

  // Memoize section config lookup
  const sectionMap = useMemo(() => {
    const map = new Map<string, BlueprintSection>();
    blueprint.outputSections.forEach(section => {
      map.set(section.id, section);
    });
    return map;
  }, [blueprint.outputSections]);

  return { fieldMap, populatedSections, sectionMap };
};
```

### 3. Virtualized Rendering for Large Templates

```typescript
// For templates with many fields, virtualize the field list
import { FixedSizeList } from 'react-window';

function VirtualizedFieldList({ fields }: { fields: BlueprintField[] }) {
  const ITEM_HEIGHT = 150; // Approximate height per field

  return (
    <FixedSizeList
      height={600}
      width="100%"
      itemCount={fields.length}
      itemSize={ITEM_HEIGHT}
    >
      {({ index, style }) => (
        <div style={style}>
          <FieldRenderer field={fields[index]} />
        </div>
      )}
    </FixedSizeList>
  );
}
```

### 4. Debounced State Updates

```typescript
// Debounce field changes to reduce re-renders
import { useDebouncedCallback } from 'use-debounce';

function useFieldInput(fieldName: string) {
  const { setFieldValue } = useBlueprint();
  const [localValue, setLocalValue] = useState('');

  const debouncedSetValue = useDebouncedCallback(
    (value: string) => setFieldValue(fieldName, value),
    300
  );

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setLocalValue(e.target.value);
    debouncedSetValue(e.target.value);
  };

  return { value: localValue, onChange: handleChange };
}
```

### Performance Budget

| Operation | Target | Current Est. |
|-----------|--------|--------------|
| Blueprint load | < 50ms | 20ms |
| Stage render | < 16ms | 10ms |
| Field render | < 8ms | 5ms |
| Document generation | < 100ms | 50ms |
| AI suggestion | < 3000ms | 2000ms (API bound) |

---

## Error Handling Patterns

### Error Boundary for Wizard

```typescript
// Error boundary catches rendering errors
class WizardErrorBoundary extends React.Component<
  { children: React.ReactNode; fallback: React.ReactNode },
  { hasError: boolean; error?: Error }
> {
  state = { hasError: false, error: undefined };

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('Wizard error:', error, errorInfo);
    // Report to error tracking service
  }

  render() {
    if (this.state.hasError) {
      return this.props.fallback;
    }
    return this.props.children;
  }
}

// Usage
function App() {
  return (
    <WizardErrorBoundary fallback={<WizardErrorFallback />}>
      <BlueprintProvider blueprint={blueprint}>
        <DynamicWizard />
      </BlueprintProvider>
    </WizardErrorBoundary>
  );
}
```

### Validation Error Display

```typescript
// Display validation errors inline
interface ValidationError {
  field: string;
  code: string;
  message: string;
}

function useValidation() {
  const { currentStage, state } = useBlueprint();
  const [errors, setErrors] = useState<ValidationError[]>([]);

  const validate = useCallback((): boolean => {
    const newErrors: ValidationError[] = [];

    currentStage.fields.forEach(field => {
      const value = state.formData[field.name] || '';

      // Check required
      if (field.required && !value.trim()) {
        newErrors.push({
          field: field.name,
          code: 'REQUIRED',
          message: `${field.label} is required`,
        });
      }

      // Check validation rules
      if (field.validation) {
        if (field.validation.minLength && value.length < field.validation.minLength) {
          newErrors.push({
            field: field.name,
            code: 'MIN_LENGTH',
            message: `${field.label} must be at least ${field.validation.minLength} characters`,
          });
        }
        // ... more validation rules
      }
    });

    setErrors(newErrors);
    return newErrors.length === 0;
  }, [currentStage, state.formData]);

  const getFieldError = (fieldName: string): string | undefined => {
    return errors.find(e => e.field === fieldName)?.message;
  };

  return { validate, errors, getFieldError };
}
```

### AI Error Recovery

```typescript
// Graceful AI error handling with retry
async function withRetry<T>(
  fn: () => Promise<T>,
  options: {
    maxRetries?: number;
    delayMs?: number;
    backoffMultiplier?: number;
    onRetry?: (attempt: number, error: Error) => void;
  } = {}
): Promise<T> {
  const {
    maxRetries = 3,
    delayMs = 1000,
    backoffMultiplier = 2,
    onRetry,
  } = options;

  let lastError: Error;
  let delay = delayMs;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error as Error;
      onRetry?.(attempt, lastError);

      if (attempt < maxRetries) {
        await new Promise(resolve => setTimeout(resolve, delay));
        delay *= backoffMultiplier;
      }
    }
  }

  throw lastError!;
}

// Usage in AIService
async getSuggestion(fieldName: string, ...args) {
  return withRetry(
    () => this.callAI(...),
    {
      maxRetries: 3,
      onRetry: (attempt, error) => {
        console.warn(`AI retry ${attempt}:`, error.message);
      },
    }
  );
}
```

---

## Self-Critique (Iteration 13)

**Positive:**
- Comprehensive AI prompt system with full configurability
- Performance optimizations address real concerns
- Error handling provides good UX even when things fail

**Concerns:**
- AI caching strategy may need invalidation logic
- Virtualization may not be needed for typical 6-stage templates
- Need to test error recovery with real API failures

**Decisions Made:**
1. AI prompts are fully configurable per-field
2. Use memoization for expensive lookups
3. Provide graceful fallbacks for all error scenarios

---

### Iteration 14 - 2026-01-24
**Focus:** Alternative Template Examples, Extensibility Patterns, Architecture Summary

---

## Alternative Template Example: Simple Project Proposal

This demonstrates how a simpler 3-stage, 5-section template would look:

```typescript
// simple-proposal.blueprint.ts
import type { WizardBlueprint } from '../blueprint/schema';

export const SimpleProposalBlueprint: WizardBlueprint = {
  id: 'simple-proposal',
  name: 'Simple Project Proposal',
  version: '1.0.0',
  description: 'A lightweight 3-stage proposal for quick project briefs',
  author: 'Epic Generator Team',

  config: {
    documentTitle: 'Project Proposal: {{projectName}}',
    autoRefineOnNext: true,
    showSectionPreview: true,
    contextFields: ['projectName', 'objective'],
    exportFormats: ['markdown'],
  },

  stages: [
    {
      id: 'overview',
      title: 'Project Overview',
      description: 'Basic project information',
      fields: [
        {
          name: 'projectName',
          label: 'Project Name',
          type: 'text',
          placeholder: 'Enter project name',
          required: true,
        },
        {
          name: 'objective',
          label: 'Objective',
          type: 'textarea',
          placeholder: 'What is the goal of this project?',
          required: true,
          rows: 4,
        },
        {
          name: 'background',
          label: 'Background',
          type: 'textarea',
          placeholder: 'Why is this project needed?',
          required: false,
          rows: 4,
        },
      ],
    },
    {
      id: 'scope',
      title: 'Scope & Requirements',
      description: 'Define what is in and out of scope',
      fields: [
        {
          name: 'requirements',
          label: 'Key Requirements',
          type: 'textarea',
          placeholder: 'List the main requirements',
          required: true,
          rows: 6,
        },
        {
          name: 'outOfScope',
          label: 'Out of Scope',
          type: 'textarea',
          placeholder: 'What is explicitly excluded?',
          required: false,
          rows: 3,
        },
      ],
    },
    {
      id: 'delivery',
      title: 'Delivery Plan',
      description: 'Timeline and deliverables',
      fields: [
        {
          name: 'deliverables',
          label: 'Deliverables',
          type: 'textarea',
          placeholder: 'What will be delivered?',
          required: true,
          rows: 4,
        },
        {
          name: 'timeline',
          label: 'Timeline',
          type: 'textarea',
          placeholder: 'Estimated timeline and milestones',
          required: true,
          rows: 4,
        },
      ],
    },
  ],

  outputSections: [
    { id: 'objective', num: 1, title: 'Objective', dataKeys: ['objective'], render: { type: 'text' } },
    { id: 'background', num: 2, title: 'Background', dataKeys: ['background'], render: { type: 'text' }, excludeIfEmpty: true },
    {
      id: 'requirements', num: 3, title: 'Requirements & Scope', dataKeys: ['requirements', 'outOfScope'],
      render: {
        type: 'subsections',
        subsections: [
          { title: 'Requirements', dataKey: 'requirements' },
          { title: 'Out of Scope', dataKey: 'outOfScope' },
        ],
      },
    },
    { id: 'deliverables', num: 4, title: 'Deliverables', dataKeys: ['deliverables'], render: { type: 'list', list: { style: 'bullet' } } },
    { id: 'timeline', num: 5, title: 'Timeline', dataKeys: ['timeline'], render: { type: 'text' } },
  ],

  ai: {
    enabled: true,
    baseSystemPrompt: 'You are a helpful assistant creating concise project proposals.',
    fields: {},
  },
};
```

**Comparison:**

| Aspect | Technical Architect | Simple Proposal |
|--------|--------------------|-----------------|
| Stages | 6 | 3 |
| Fields | 19 | 7 |
| Output Sections | 17 | 5 |
| AI Prompts | Detailed per-field | Minimal |
| Diagrams | Full Mermaid support | None |
| Use Case | Complex technical projects | Quick briefs |

---

## Extensibility Patterns

### 1. Custom Field Type Plugin

```typescript
// Register a custom field type
import { registerFieldType } from './blueprint/fieldRegistry';

// Custom "user-story" field type
registerFieldType('user-story', {
  component: UserStoryField,
  validator: (value: string) => {
    // Validate "As a X, I want Y, so that Z" format
    const pattern = /^As a .+, I want .+, so that .+$/i;
    return pattern.test(value);
  },
  transformer: (value: string) => {
    // Parse into structured format
    const match = value.match(/^As a (.+), I want (.+), so that (.+)$/i);
    if (match) {
      return { role: match[1], want: match[2], benefit: match[3] };
    }
    return value;
  },
});

// Use in blueprint
const blueprint: WizardBlueprint = {
  stages: [{
    fields: [{
      name: 'userStory1',
      type: 'user-story', // Custom type
      label: 'User Story',
    }],
  }],
};
```

### 2. Custom Section Renderer Plugin

```typescript
// Register a custom section renderer
import { registerSectionRenderer } from './blueprint/sectionRegistry';

// Custom "kanban" renderer for tasks
registerSectionRenderer('kanban', {
  render: (section, data, options) => {
    const tasks = parseTasksFromContent(data[section.dataKeys[0]]?.refined);

    const columns = {
      todo: tasks.filter(t => t.status === 'todo'),
      inProgress: tasks.filter(t => t.status === 'in-progress'),
      done: tasks.filter(t => t.status === 'done'),
    };

    let md = '';
    md += '| To Do | In Progress | Done |\n';
    md += '|-------|-------------|------|\n';

    const maxRows = Math.max(columns.todo.length, columns.inProgress.length, columns.done.length);
    for (let i = 0; i < maxRows; i++) {
      md += `| ${columns.todo[i]?.title || ''} | ${columns.inProgress[i]?.title || ''} | ${columns.done[i]?.title || ''} |\n`;
    }

    return md;
  },
});

// Use in blueprint
const blueprint: WizardBlueprint = {
  outputSections: [{
    id: 'tasks',
    num: 1,
    title: 'Task Board',
    dataKeys: ['tasks'],
    render: { type: 'kanban' }, // Custom renderer
  }],
};
```

### 3. Custom Validation Plugin

```typescript
// Register a custom validator
import { registerValidator } from './blueprint/validatorRegistry';

// Custom "no-profanity" validator
registerValidator('no-profanity', {
  validate: (value: string, params?: { wordList?: string[] }) => {
    const profanityList = params?.wordList || ['badword1', 'badword2'];
    const lower = value.toLowerCase();
    const hasProfanity = profanityList.some(word => lower.includes(word));
    return !hasProfanity;
  },
  message: 'Content must not contain inappropriate language',
});

// Use in blueprint
const blueprint: WizardBlueprint = {
  stages: [{
    fields: [{
      name: 'description',
      validation: {
        custom: [{
          validator: 'no-profanity',
          params: { wordList: ['internal-list'] },
          message: 'Please keep content professional',
        }],
      },
    }],
  }],
};
```

### 4. Blueprint Inheritance

```typescript
// Extend a base blueprint
function extendBlueprint(
  base: WizardBlueprint,
  extensions: Partial<WizardBlueprint>
): WizardBlueprint {
  return {
    ...base,
    ...extensions,
    id: extensions.id || `${base.id}-extended`,
    name: extensions.name || `${base.name} (Extended)`,
    version: extensions.version || base.version,

    // Merge stages
    stages: extensions.stages
      ? mergeStages(base.stages, extensions.stages)
      : base.stages,

    // Merge sections
    outputSections: extensions.outputSections
      ? mergeSections(base.outputSections, extensions.outputSections)
      : base.outputSections,

    // Merge AI config
    ai: {
      ...base.ai,
      ...extensions.ai,
      fields: {
        ...base.ai.fields,
        ...extensions.ai?.fields,
      },
    },
  };
}

// Usage: Add security section to simple proposal
const SecureProposalBlueprint = extendBlueprint(SimpleProposalBlueprint, {
  id: 'secure-proposal',
  name: 'Secure Project Proposal',
  stages: [
    ...SimpleProposalBlueprint.stages,
    {
      id: 'security',
      title: 'Security Considerations',
      description: 'Security requirements for the project',
      fields: [
        { name: 'securityReqs', label: 'Security Requirements', type: 'textarea', required: true },
        { name: 'dataClassification', label: 'Data Classification', type: 'select', options: { choices: [
          { value: 'public', label: 'Public' },
          { value: 'internal', label: 'Internal' },
          { value: 'confidential', label: 'Confidential' },
        ]}},
      ],
    },
  ],
  outputSections: [
    ...SimpleProposalBlueprint.outputSections,
    { id: 'security', num: 6, title: 'Security', dataKeys: ['securityReqs', 'dataClassification'], render: { type: 'text' } },
  ],
});
```

---

## Architecture Refinement Complete - Summary

### Key Design Decisions

| Decision | Rationale |
|----------|-----------|
| Blueprint as single source of truth | Enables runtime configurability without code changes |
| Context + Reducer for state | Predictable state updates, testable, no external deps |
| Field component registry | Extensible field types without modifying core code |
| Section render type system | Declarative rendering covers common patterns |
| AI prompt templating | Full control over AI behavior per-field |
| Backward compatibility layer | Safe migration path, feature flags for rollback |

### Design Patterns Used

1. **Strategy Pattern** - Field renderers, section renderers
2. **Observer Pattern** - React context subscriptions
3. **Factory Pattern** - Blueprint loader, component registry
4. **Adapter Pattern** - Legacy compatibility layer
5. **Template Method** - AI prompt construction
6. **Decorator Pattern** - Blueprint extension/inheritance

### Architecture Strengths

1. **Flexibility** - Supports templates from 3 to 50+ stages
2. **Extensibility** - Plugins for fields, renderers, validators
3. **Maintainability** - Clear separation of concerns
4. **Testability** - Reducers, generators, validators all unit testable
5. **Performance** - Lazy loading, memoization, virtualization ready

### Architecture Weaknesses

1. **Complexity** - More concepts to learn vs hardcoded approach
2. **Blueprint size** - Large blueprints can be verbose
3. **Runtime overhead** - Blueprint parsing on every load
4. **Type safety** - JSON blueprints lose some TypeScript benefits

---

## Self-Critique (Iteration 14)

**Positive:**
- Architecture refinement phase is complete
- Alternative template example demonstrates flexibility
- Extensibility patterns enable future growth

**Concerns:**
- Extensibility plugins add API surface to maintain
- Blueprint inheritance could lead to confusing structures
- Need comprehensive documentation for developers

**Decisions Made:**
1. Extensibility is opt-in via registries
2. Keep core simple, advanced features are additive
3. TypeScript blueprints preferred over JSON for type safety

---

### Iteration 15 - 2026-01-24
**Focus:** Complete Testing Strategy, Test Matrix, CI/CD Integration

---

## Complete Test Matrix

### Unit Test Coverage

| Component | Test File | Test Cases | Priority |
|-----------|-----------|------------|----------|
| **Blueprint Schema** | | | |
| BlueprintLoader.validate() | blueprint-loader.test.ts | Valid blueprint, Missing id, Missing stages, Invalid field type, Empty fields | P1 |
| BlueprintLoader.load() | blueprint-loader.test.ts | Load with defaults, Custom config, Derive populatesSections | P1 |
| BlueprintLoader.normalize() | blueprint-loader.test.ts | Default values applied, Existing values preserved | P2 |
| **Document Generator** | | | |
| DocumentGenerator.generate() | document-generator.test.ts | Full document, Empty data, Missing sections | P1 |
| renderText() | document-generator.test.ts | Normal text, Empty, Special characters | P1 |
| renderTable() | document-generator.test.ts | Lines parse, Delimiter parse, Empty rows, Malformed input | P1 |
| renderList() | document-generator.test.ts | Bullet, Numbered, Checkbox, Lines vs delimiter | P1 |
| renderSubsections() | document-generator.test.ts | All subsections, Partial data, Missing subsection | P1 |
| renderEmbed() | document-generator.test.ts | Mermaid with code, No code fallback, Other embed types | P2 |
| renderComposite() | document-generator.test.ts | Multiple keys, With subheaders, Empty keys | P2 |
| **AI Service** | | | |
| AIService.getSuggestion() | ai-service.test.ts | With context, Auto mode, Disabled AI, Error fallback | P1 |
| AIService.refineInput() | ai-service.test.ts | Normal refine, Empty input, AI error | P2 |
| buildSystemPrompt() | ai-service.test.ts | Base only, With suffix, With format guide | P2 |
| buildUserPrompt() | ai-service.test.ts | Full context, Minimal context, With hint | P2 |
| **Blueprint Context** | | | |
| BlueprintProvider | blueprint-context.test.tsx | Provides values, Updates on dispatch | P1 |
| useBlueprint() | blueprint-context.test.tsx | Returns context, Throws outside provider | P1 |
| wizardReducer | blueprint-context.test.ts | SET_FIELD, NEXT_STAGE, PREV_STAGE, SET_REFINED, RESET | P1 |
| populatedSections | blueprint-context.test.ts | Empty, Partial, Full | P2 |
| **Field Components** | | | |
| TextField | text-field.test.tsx | Render, Change, Disabled, Validation error | P1 |
| TextareaField | textarea-field.test.tsx | Render, Change, Rows prop, Refined preview | P1 |
| SelectField | select-field.test.tsx | Render options, Change, No options | P2 |
| ListField | list-field.test.tsx | Add item, Remove item, Reorder, Max items | P2 |
| TableField | table-field.test.tsx | Add row, Edit cell, Remove row, Columns config | P2 |
| FieldRenderer | field-renderer.test.tsx | Routes to correct component, Unknown type fallback | P1 |
| **Wizard Components** | | | |
| StageRenderer | stage-renderer.test.tsx | Renders fields, Navigation buttons, Stage title | P1 |
| StageNavigation | stage-navigation.test.tsx | Next enabled, Prev disabled on first, Generate on last | P1 |
| SectionPreview | section-preview.test.tsx | Shows sections, Highlights populated | P2 |
| DynamicWizard | dynamic-wizard.test.tsx | Full flow, Error boundary | P1 |

### Integration Test Coverage

| Scenario | Test File | Description | Priority |
|----------|-----------|-------------|----------|
| Full wizard flow | wizard-flow.test.tsx | Complete 6 stages, generate document | P1 |
| Output parity | output-parity.test.ts | Dynamic output matches legacy output | P1 |
| Draft persistence | draft-persistence.test.ts | Save draft, restore draft, clear draft | P2 |
| Template switching | template-switch.test.tsx | Change template, data migration | P3 |
| AI integration | ai-integration.test.ts | Suggestion flow, refinement flow | P2 |
| Error recovery | error-recovery.test.tsx | AI failure, validation failure | P2 |

### Snapshot Tests

```typescript
// Output parity snapshot tests
describe('Output Parity Snapshots', () => {
  const testCases = [
    { name: 'minimal-data', data: minimalTestData },
    { name: 'full-data', data: fullTestData },
    { name: 'special-characters', data: specialCharTestData },
    { name: 'empty-optional', data: emptyOptionalTestData },
    { name: 'long-content', data: longContentTestData },
  ];

  testCases.forEach(({ name, data }) => {
    it(`generates correct output for ${name}`, () => {
      const generator = new DocumentGenerator(TechnicalArchitectBlueprint);
      const output = generator.generate(data);
      expect(output).toMatchSnapshot();
    });
  });
});
```

### E2E Test Coverage

| Flow | Test File | Steps | Priority |
|------|-----------|-------|----------|
| New document | e2e/new-document.spec.ts | Select template, Fill stages, Generate, Export | P1 |
| Load and edit | e2e/load-edit.spec.ts | Load existing, Edit sections, Save | P2 |
| AI suggestions | e2e/ai-suggestions.spec.ts | Click suggest, Accept, Click auto | P2 |
| GitLab publish | e2e/gitlab-publish.spec.ts | Connect GitLab, Publish epic | P3 |

---

## Test Data Fixtures

```typescript
// test/fixtures/test-data.ts

export const minimalTestData: Record<string, RefinedFieldData> = {
  projectName: { original: 'Test Project', refined: 'Test Project' },
  objective: { original: 'Test objective', refined: 'Enhanced objective' },
  background: { original: '', refined: '' },
  // ... minimal required fields
};

export const fullTestData: Record<string, RefinedFieldData> = {
  projectName: { original: 'Full Test Project', refined: 'Full Test Project' },
  background: { original: 'Background context...', refined: 'Enhanced background...' },
  objective: { original: 'Clear objective...', refined: 'Enhanced objective...' },
  inScope: { original: '- Item 1\n- Item 2', refined: '- Enhanced Item 1\n- Enhanced Item 2' },
  outOfScope: { original: '- Not this\n- Not that', refined: '- Not this\n- Not that' },
  assumptions: { original: '- Assumption 1', refined: '- Assumption 1' },
  architectureOverview: { original: 'Microservices architecture...', refined: 'Enhanced architecture...' },
  dataStores: { original: 'PostgreSQL, Redis', refined: 'PostgreSQL for primary, Redis for caching' },
  features: { original: '1. Feature A\n2. Feature B', refined: '1. Feature A\n2. Feature B' },
  userStories: { original: 'As a user...', refined: 'As a user...' },
  nfrs: { original: '99.9% uptime', refined: '99.9% availability SLA' },
  deliverables: { original: '- API\n- UI', refined: '- REST API\n- Web UI' },
  teams: { original: 'Dev Lead - Architecture\nEngineer - Implementation', refined: 'Dev Lead - Architecture decisions\nEngineer - Implementation' },
  environments: { original: 'Dev, Staging, Prod', refined: 'Development, Staging, Production' },
  security: { original: 'OAuth2 auth', refined: 'OAuth2 authentication' },
  dependencies: { original: '- Team X\n- Service Y', refined: '- Team X\n- Service Y' },
  risks: { original: 'Risk 1 | Mitigation 1', refined: 'Risk 1 - Mitigation 1' },
  nextSteps: { original: '1. Step 1\n2. Step 2', refined: '1. Step 1\n2. Step 2' },
  dod: { original: '- Tests pass\n- Reviewed', refined: '- All tests pass\n- Code reviewed' },
  approvers: { original: 'PM - Sign off', refined: 'Product Manager - Final approval' },
};

export const specialCharTestData: Record<string, RefinedFieldData> = {
  projectName: { original: 'Project "Test" <v1.0>', refined: 'Project Test v1.0' },
  background: { original: "User's data & requirements", refined: "User's data and requirements" },
  // Test special characters that might break markdown
};

export const emptyOptionalTestData: Record<string, RefinedFieldData> = {
  projectName: { original: 'Test', refined: 'Test' },
  objective: { original: 'Objective', refined: 'Objective' },
  // Only required fields, all optional empty
};
```

---

## CI/CD Integration

### GitHub Actions Workflow

```yaml
# .github/workflows/ci.yml
name: CI

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'

      - name: Install dependencies
        run: npm ci

      - name: Run type check
        run: npm run type-check

      - name: Run linter
        run: npm run lint

      - name: Run unit tests
        run: npm run test:coverage

      - name: Upload coverage
        uses: codecov/codecov-action@v4
        with:
          files: ./coverage/lcov.info

      - name: Run output parity tests
        run: npm run test:parity

  build:
    runs-on: ubuntu-latest
    needs: test

    steps:
      - uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'

      - name: Install dependencies
        run: npm ci

      - name: Build
        run: npm run build

      - name: Upload build artifacts
        uses: actions/upload-artifact@v4
        with:
          name: dist
          path: dist/

  e2e:
    runs-on: ubuntu-latest
    needs: build

    steps:
      - uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'

      - name: Install dependencies
        run: npm ci

      - name: Install Playwright
        run: npx playwright install --with-deps

      - name: Download build
        uses: actions/download-artifact@v4
        with:
          name: dist
          path: dist/

      - name: Run E2E tests
        run: npm run test:e2e

      - name: Upload test results
        if: failure()
        uses: actions/upload-artifact@v4
        with:
          name: playwright-report
          path: playwright-report/
```

### Package.json Scripts

```json
{
  "scripts": {
    "test": "vitest",
    "test:run": "vitest run",
    "test:coverage": "vitest run --coverage",
    "test:parity": "vitest run --project=parity",
    "test:e2e": "playwright test",
    "test:e2e:ui": "playwright test --ui",
    "type-check": "tsc --noEmit",
    "lint": "eslint src --ext .ts,.tsx"
  }
}
```

### Vitest Configuration

```typescript
// vitest.config.ts
import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  test: {
    environment: 'jsdom',
    setupFiles: ['./src/test/setup.ts'],
    coverage: {
      provider: 'v8',
      reporter: ['text', 'lcov'],
      exclude: [
        'node_modules',
        'src/test',
        '**/*.test.ts',
        '**/*.test.tsx',
      ],
      thresholds: {
        lines: 80,
        functions: 80,
        branches: 75,
        statements: 80,
      },
    },
    projects: [
      {
        // Unit tests
        test: {
          name: 'unit',
          include: ['src/**/*.test.ts', 'src/**/*.test.tsx'],
          exclude: ['src/test/parity/**'],
        },
      },
      {
        // Parity tests (separate project for CI)
        test: {
          name: 'parity',
          include: ['src/test/parity/**/*.test.ts'],
        },
      },
    ],
  },
});
```

---

## Test Coverage Requirements

| Category | Minimum Coverage | Target Coverage |
|----------|-----------------|-----------------|
| Blueprint Schema | 90% | 95% |
| Document Generator | 90% | 95% |
| AI Service | 80% | 90% |
| Field Components | 85% | 90% |
| Wizard Components | 85% | 90% |
| Context/Hooks | 90% | 95% |
| **Overall** | **80%** | **90%** |

---

## Self-Critique (Iteration 15)

**Positive:**
- Comprehensive test matrix covers all components
- Output parity tests are critical and well-defined
- CI/CD pipeline ensures quality gates

**Concerns:**
- 80+ test cases is significant effort
- E2E tests may be flaky with AI integration
- Need mock AI service for deterministic tests

**Decisions Made:**
1. Output parity tests are P1 - must pass before release
2. AI tests use mocked responses for determinism
3. Coverage thresholds enforced in CI

---

### Iteration 16 - 2026-01-24
**Focus:** Risk Assessment, Executive Summary, Quick-Start Guide

---

## Risk Assessment

### Technical Risks

| Risk | Probability | Impact | Severity | Mitigation |
|------|-------------|--------|----------|------------|
| **Output parity failure** | Medium | Critical | High | Extensive snapshot testing, diff comparison tools, gradual rollout |
| **Performance regression** | Low | High | Medium | Performance benchmarks in CI, lazy loading, profiling |
| **Blueprint schema changes** | Medium | Medium | Medium | Semantic versioning, migration scripts, backward compat |
| **AI prompt quality variance** | Medium | Medium | Medium | Prompt testing, A/B testing, fallback prompts |
| **Browser compatibility** | Low | Medium | Low | Test in multiple browsers, use polyfills |
| **Large blueprint memory** | Low | Low | Low | Lazy loading, virtualization for large templates |

### Operational Risks

| Risk | Probability | Impact | Severity | Mitigation |
|------|-------------|--------|----------|------------|
| **User confusion during migration** | Medium | Medium | Medium | Clear documentation, feature flags, opt-in rollout |
| **Draft data loss** | Low | High | Medium | Draft migration script, backup before migration |
| **Template corruption** | Low | High | Medium | Validation on load, auto-repair, backup copies |
| **API breaking changes** | Medium | High | High | Deprecation warnings, compatibility layer, version checks |

### Project Risks

| Risk | Probability | Impact | Severity | Mitigation |
|------|-------------|--------|----------|------------|
| **Scope creep** | High | Medium | Medium | MVP definition, phased rollout, feature freeze |
| **Timeline slippage** | Medium | Medium | Medium | Buffer time, prioritized tasks, scope reduction options |
| **Developer bandwidth** | Medium | High | High | Clear priorities, documentation, modular design |
| **Testing coverage gaps** | Medium | High | High | Test matrix, coverage requirements, code review |

### Risk Severity Matrix

```
         High Impact    Medium Impact    Low Impact
High     [AI prompts]   [Scope creep]
Prob     [Breaking API] [User confusion]

Medium   [Output parity][Draft loss]     [Browser compat]
Prob     [Timeline]     [Schema change]

Low      [Perf regress] [Corruption]     [Large blueprints]
Prob     [Test gaps]    [Bandwidth]
```

### Contingency Plans

1. **If output parity fails:**
   - Keep feature flag OFF
   - Debug specific sections
   - Implement section-by-section migration

2. **If migration causes data loss:**
   - Provide rollback instructions
   - Export all drafts before migration
   - Implement automatic backup

3. **If performance is unacceptable:**
   - Profile and optimize hot paths
   - Consider server-side generation
   - Implement progressive loading

---

## Executive Summary

### Project Overview

The **Dynamic Template Architecture** transforms Epic Generator v4 from a hardcoded 6-stage, 17-section wizard into a flexible, blueprint-driven system capable of supporting any number of stages and sections.

### Business Value

| Value | Description |
|-------|-------------|
| **Flexibility** | Create templates for different use cases (technical, business, simple, complex) |
| **Scalability** | Support teams with different documentation standards |
| **Maintainability** | Changes to templates don't require code changes |
| **Extensibility** | Add new field types, renderers, and validators via plugins |

### Technical Approach

```
+------------------+     +------------------+     +------------------+
|   Blueprint      |     |   Runtime        |     |   Output         |
|   (JSON/TS)      | --> |   (React)        | --> |   (Markdown)     |
+------------------+     +------------------+     +------------------+
| - Stages         |     | - BlueprintCtx   |     | - Document       |
| - Fields         |     | - StageRenderer  |     | - Diagrams       |
| - Sections       |     | - FieldRenderer  |     | - Tables         |
| - AI Prompts     |     | - AIService      |     | - Lists          |
+------------------+     +------------------+     +------------------+
```

### Key Deliverables

1. **Blueprint Schema** - TypeScript interfaces defining template structure
2. **Blueprint Loader** - Validates and loads blueprints at runtime
3. **Dynamic Renderer** - React components that render any blueprint
4. **Document Generator** - Produces markdown from any blueprint
5. **AI Service** - Blueprint-aware AI suggestions and refinement
6. **Technical Architect Blueprint** - Current 6-stage template as blueprint

### Timeline

| Phase | Duration | Milestone |
|-------|----------|-----------|
| Foundation | 2 weeks | Blueprint schema, loader, validation |
| Components | 2 weeks | Field components, renderers |
| Integration | 1 week | App integration, feature flag |
| Testing | 1 week | Parity tests, coverage |
| Rollout | 1 week | Gradual enablement, monitoring |
| **Total** | **7 weeks** | |

### Success Metrics

| Metric | Target | Measurement |
|--------|--------|-------------|
| Output Parity | 100% | Diff comparison of generated documents |
| Test Coverage | 80%+ | Vitest coverage report |
| Performance | < 100ms generation | Performance benchmarks |
| User Impact | Zero regressions | User feedback, error rates |

### Recommendations

1. **Start with MVP** - Foundation + parity testing first
2. **Feature flag everything** - Enable gradual rollout
3. **Test extensively** - Output parity is critical
4. **Document thoroughly** - API migration guide for developers
5. **Monitor closely** - Error rates, performance metrics

---

## Quick-Start Guide

### For Developers: Creating a New Template

#### Step 1: Create the Blueprint File

```typescript
// src/blueprints/my-template.ts
import type { WizardBlueprint } from '../blueprint/schema';

export const MyTemplateBlueprint: WizardBlueprint = {
  id: 'my-template',
  name: 'My Custom Template',
  version: '1.0.0',
  description: 'A custom template for X use case',

  config: {
    documentTitle: 'Document: {{projectName}}',
    contextFields: ['projectName'],
  },

  stages: [
    {
      id: 'stage1',
      title: 'First Stage',
      description: 'Enter basic info',
      fields: [
        {
          name: 'projectName',
          label: 'Project Name',
          type: 'text',
          required: true,
        },
        {
          name: 'description',
          label: 'Description',
          type: 'textarea',
          required: true,
          rows: 4,
        },
      ],
    },
  ],

  outputSections: [
    {
      id: 'intro',
      num: 1,
      title: 'Introduction',
      dataKeys: ['projectName', 'description'],
      render: { type: 'text' },
    },
  ],

  ai: {
    enabled: true,
    baseSystemPrompt: 'You are a helpful assistant.',
    fields: {},
  },
};
```

#### Step 2: Register the Blueprint

```typescript
// src/blueprints/index.ts
import { MyTemplateBlueprint } from './my-template';
import { TechnicalArchitectBlueprint } from './technical-architect';

export const blueprintRegistry = {
  'technical-architect': TechnicalArchitectBlueprint,
  'my-template': MyTemplateBlueprint,
};

export function getBlueprint(id: string): WizardBlueprint {
  const blueprint = blueprintRegistry[id];
  if (!blueprint) {
    throw new Error(`Blueprint not found: ${id}`);
  }
  return blueprint;
}
```

#### Step 3: Use the Blueprint

```typescript
// In your component
import { BlueprintProvider, useBlueprint } from './blueprint/BlueprintContext';
import { getBlueprint } from './blueprints';

function App() {
  const blueprint = getBlueprint('my-template');

  return (
    <BlueprintProvider blueprint={blueprint}>
      <DynamicWizard />
    </BlueprintProvider>
  );
}
```

### For Users: Using Templates

1. **Select a Template** - Choose from available templates (Technical Architect, Simple Proposal, etc.)
2. **Fill in Stages** - Complete each stage of the wizard
3. **Use AI Suggestions** - Click "Auto" or "Refine" for AI assistance
4. **Generate Document** - Click "Generate" on the final stage
5. **Export or Publish** - Download markdown or publish to GitLab

### Adding a New Field Type

```typescript
// 1. Define the component
function CustomField({ field, value, onChange }: FieldProps) {
  return (
    <div className="custom-field">
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={field.placeholder}
      />
    </div>
  );
}

// 2. Register it
import { registerFieldType } from './blueprint/fieldRegistry';

registerFieldType('custom', {
  component: CustomField,
});

// 3. Use it in a blueprint
{
  name: 'myCustomField',
  type: 'custom',
  label: 'Custom Field',
}
```

### Adding a New Section Renderer

```typescript
// 1. Define the renderer
function renderTimeline(section, data): string {
  const items = parseTimelineItems(data[section.dataKeys[0]]?.refined);
  return items.map(item => `**${item.date}**: ${item.event}`).join('\n\n');
}

// 2. Register it
import { registerSectionRenderer } from './blueprint/sectionRegistry';

registerSectionRenderer('timeline', {
  render: renderTimeline,
});

// 3. Use it in a blueprint
{
  id: 'milestones',
  num: 5,
  title: 'Milestones',
  dataKeys: ['milestones'],
  render: { type: 'timeline' },
}
```

---

## Self-Critique (Iteration 16)

**Positive:**
- Comprehensive risk assessment identifies key concerns
- Executive summary provides clear business value
- Quick-start guide enables immediate productivity

**Concerns:**
- Timeline estimate may be optimistic
- Risk mitigations need monitoring
- Documentation needs to be maintained

**Decisions Made:**
1. Prioritize output parity as success metric
2. Feature flags for all new functionality
3. Provide clear migration path for developers

---

### Iteration 17 - 2026-01-24
**Focus:** Final Architecture Diagrams, Design Consistency Review

---

## Final Architecture Diagrams

### System Overview

```mermaid
flowchart TB
    subgraph UI["User Interface Layer"]
        TS[Template Selector]
        DW[Dynamic Wizard]
        EE[Epic Editor]
        BP[Blueprint Tab]
    end

    subgraph Core["Core Logic Layer"]
        BC[Blueprint Context]
        DG[Document Generator]
        AS[AI Service]
        VS[Validation Service]
    end

    subgraph Data["Data Layer"]
        BL[Blueprint Loader]
        BR[Blueprint Registry]
        ST[Storage Service]
        CF[Config Service]
    end

    subgraph External["External Services"]
        AI[OpenAI/Azure]
        GL[GitLab API]
        FS[File System]
    end

    TS --> BL
    BL --> BR
    BR --> BC

    DW --> BC
    DW --> AS
    DW --> VS

    BC --> DG
    DG --> EE

    AS --> AI
    EE --> GL
    ST --> FS

    style Core fill:#e1f5fe
    style Data fill:#fff3e0
    style External fill:#fce4ec
```

### Component Architecture

```mermaid
classDiagram
    class WizardBlueprint {
        +id: string
        +name: string
        +version: string
        +stages: BlueprintStage[]
        +outputSections: BlueprintSection[]
        +ai: BlueprintAIConfig
    }

    class BlueprintStage {
        +id: string
        +title: string
        +fields: BlueprintField[]
        +populatesSections: string[]
    }

    class BlueprintField {
        +name: string
        +type: FieldType
        +required: boolean
        +ai: FieldAIConfig
        +validation: FieldValidation
    }

    class BlueprintSection {
        +id: string
        +num: number
        +title: string
        +dataKeys: string[]
        +render: SectionRenderConfig
    }

    class BlueprintContext {
        +blueprint: WizardBlueprint
        +state: WizardState
        +setFieldValue()
        +nextStage()
        +generateDocument()
    }

    class DocumentGenerator {
        -blueprint: WizardBlueprint
        +generate(data, diagramCode): string
        -renderSection(section, data): string
    }

    class AIService {
        -blueprint: WizardBlueprint
        +getSuggestion(field, context): Promise
        +refineInput(field, input): Promise
    }

    WizardBlueprint "1" *-- "many" BlueprintStage
    BlueprintStage "1" *-- "many" BlueprintField
    WizardBlueprint "1" *-- "many" BlueprintSection
    BlueprintContext --> WizardBlueprint
    DocumentGenerator --> WizardBlueprint
    AIService --> WizardBlueprint
```

### State Flow Diagram

```mermaid
stateDiagram-v2
    [*] --> Idle: App Loaded

    Idle --> BlueprintLoaded: Load Blueprint
    BlueprintLoaded --> Stage1: Initialize

    state "Wizard Flow" as WF {
        Stage1 --> Stage2: Next
        Stage2 --> Stage3: Next
        Stage3 --> Stage4: Next
        Stage4 --> Stage5: Next
        Stage5 --> Stage6: Next

        Stage2 --> Stage1: Prev
        Stage3 --> Stage2: Prev
        Stage4 --> Stage3: Prev
        Stage5 --> Stage4: Prev
        Stage6 --> Stage5: Prev
    }

    Stage6 --> Generating: Generate
    Generating --> DiagramGen: Start
    DiagramGen --> DocGen: Complete
    DocGen --> Complete: Complete

    Complete --> EpicEditor: View
    EpicEditor --> Publishing: Publish
    Publishing --> Published: Success

    Complete --> [*]: Exit
    Published --> [*]: Exit
```

### Data Transformation Pipeline

```mermaid
flowchart LR
    subgraph Input["User Input"]
        RI[Raw Input]
        FD[Form Data]
    end

    subgraph Processing["AI Processing"]
        SUG[Suggestion]
        REF[Refinement]
    end

    subgraph Storage["State Storage"]
        RFD[Refined Data]
        CTX[Context]
    end

    subgraph Output["Document Output"]
        SEC[Sections]
        MD[Markdown]
    end

    RI --> FD
    FD --> SUG
    SUG --> FD

    FD --> REF
    REF --> RFD

    RFD --> CTX
    CTX --> SEC
    SEC --> MD
```

---

## Design Consistency Review

### Naming Conventions

| Category | Convention | Example |
|----------|------------|---------|
| Blueprint types | PascalCase with Blueprint suffix | `WizardBlueprint`, `BlueprintStage` |
| Field config | camelCase | `fieldName`, `aiConfig` |
| Component names | PascalCase | `FieldRenderer`, `StageNavigation` |
| Hook names | camelCase with use prefix | `useBlueprint`, `useValidation` |
| Service names | PascalCase with Service suffix | `AIService`, `StorageService` |
| Test files | kebab-case with .test suffix | `document-generator.test.ts` |

### Interface Consistency

All blueprint interfaces follow this pattern:
```typescript
interface Blueprint{Entity} {
  // Identity
  id: string;
  name?: string;

  // Configuration
  config?: {Entity}Config;

  // Children
  {children}?: Blueprint{Child}[];

  // Behavior
  {behavior}?: {BehaviorConfig};
}
```

### Error Message Consistency

All errors follow this format:
```typescript
{
  code: 'ERROR_CODE',        // UPPER_SNAKE_CASE
  message: 'Human message',  // Sentence case
  path?: 'json.path',        // dot notation
  details?: {...}            // Additional context
}
```

### API Consistency

All async operations return:
```typescript
// Success
{ success: true, data: T }

// Error
{ success: false, error: { code, message } }
```

---

## Design Verification Checklist

### Schema Design
- [x] All types have clear documentation
- [x] Optional vs required fields are explicit
- [x] Union types use discriminated unions where possible
- [x] Validation rules are expressible in schema
- [x] AI configuration is per-field
- [x] Render types cover all current section patterns

### Component Design
- [x] Components accept blueprint config, not hardcoded values
- [x] State is managed in context, not prop drilling
- [x] Field components are pluggable via registry
- [x] Section renderers are pluggable via registry
- [x] Error boundaries protect against crashes

### Migration Design
- [x] Backward compatibility layer exists
- [x] Feature flags enable gradual rollout
- [x] Legacy adapter converts old formats
- [x] Draft migration script planned
- [x] API migration guide documented

### Testing Design
- [x] Unit tests for all core logic
- [x] Integration tests for full flows
- [x] Output parity tests defined
- [x] Test data fixtures created
- [x] CI/CD pipeline configured

---

## Self-Critique (Iteration 17)

**Positive:**
- Architecture diagrams provide clear visual understanding
- Design consistency review ensures maintainability
- Verification checklist confirms completeness

**Concerns:**
- Diagrams may need updates as implementation progresses
- Some edge cases may emerge during implementation

**Decisions Made:**
1. Use Mermaid for all diagrams (consistent with existing codebase)
2. Maintain naming conventions strictly
3. Update diagrams when design changes

---

### Iteration 18 - 2026-01-24
**Focus:** Implementation Checklist, Known Limitations

---

## Implementation Checklist

### Phase 1: Foundation (Week 1-2)

```markdown
# Foundation Checklist

## Schema & Types
- [ ] Create `src/blueprint/schema.ts` with all TypeScript interfaces
- [ ] Add JSDoc comments to all exported types
- [ ] Export types from `src/blueprint/index.ts`

## Blueprint Loader
- [ ] Create `src/blueprint/loader.ts`
- [ ] Implement `validate()` function
- [ ] Implement `load()` function
- [ ] Implement `derivePopulatesSections()` function
- [ ] Implement `normalizeBlueprint()` function
- [ ] Create `BlueprintValidationError` class

## Technical Architect Blueprint
- [ ] Create `src/blueprints/technical-architect.ts`
- [ ] Map all 6 current stages
- [ ] Map all 19 current fields
- [ ] Map all 17 output sections
- [ ] Extract all AI prompts from skills.ts
- [ ] Add diagram configuration
- [ ] Validate output matches current STAGES/EPIC_SECTIONS

## Tests
- [ ] Create `src/test/blueprint-loader.test.ts`
- [ ] Test valid blueprint loading
- [ ] Test validation error cases
- [ ] Test normalization defaults
- [ ] Create `src/test/fixtures/test-blueprints.ts`
```

### Phase 2: Document Generator (Week 2-3)

```markdown
# Document Generator Checklist

## Core Generator
- [ ] Create `src/blueprint/DocumentGenerator.ts`
- [ ] Implement `generate()` method
- [ ] Implement `renderSection()` dispatch

## Render Types
- [ ] Implement `renderText()`
- [ ] Implement `renderSubsections()`
- [ ] Implement `renderTable()`
- [ ] Implement `renderList()`
- [ ] Implement `renderChecklist()`
- [ ] Implement `renderEmbed()`
- [ ] Implement `renderComposite()`

## Edge Cases
- [ ] Handle empty sections
- [ ] Handle missing data keys
- [ ] Handle special characters
- [ ] Handle very long content

## Tests
- [ ] Create `src/test/document-generator.test.ts`
- [ ] Test each render type
- [ ] Create output parity tests
- [ ] Compare with legacy output
```

### Phase 3: React Components (Week 3-4)

```markdown
# React Components Checklist

## Blueprint Context
- [ ] Create `src/blueprint/BlueprintContext.tsx`
- [ ] Implement `BlueprintProvider`
- [ ] Implement `useBlueprint` hook
- [ ] Implement `wizardReducer`
- [ ] Implement derived values (populatedSections, etc.)

## Field Components
- [ ] Create `src/components/fields/types.ts`
- [ ] Create `src/components/fields/TextField.tsx`
- [ ] Create `src/components/fields/TextareaField.tsx`
- [ ] Create `src/components/fields/FieldRenderer.tsx`
- [ ] Create `src/components/fields/registry.ts`

## Wizard Components
- [ ] Create `src/components/wizard/StageRenderer.tsx`
- [ ] Create `src/components/wizard/StageNavigation.tsx`
- [ ] Create `src/components/wizard/StageProgress.tsx`
- [ ] Create `src/components/wizard/SectionPreview.tsx`
- [ ] Create `src/components/wizard/DynamicWizard.tsx`

## Tests
- [ ] Create `src/test/blueprint-context.test.tsx`
- [ ] Create `src/test/field-renderer.test.tsx`
- [ ] Create `src/test/stage-renderer.test.tsx`
```

### Phase 4: AI Service (Week 4-5)

```markdown
# AI Service Checklist

## AI Service
- [ ] Create `src/blueprint/AIService.ts`
- [ ] Implement `getSuggestion()` with blueprint config
- [ ] Implement `refineInput()` with blueprint config
- [ ] Implement prompt building functions
- [ ] Implement caching
- [ ] Implement error handling and fallbacks

## Skills Migration
- [ ] Refactor `src/skills.ts` to accept blueprint parameter
- [ ] Add compatibility shim for legacy calls
- [ ] Remove hardcoded field prompts (use blueprint)
- [ ] Update diagram generation to use blueprint config

## Tests
- [ ] Create `src/test/ai-service.test.ts`
- [ ] Mock AI responses for deterministic tests
- [ ] Test prompt building
- [ ] Test fallback behavior
```

### Phase 5: Integration (Week 5-6)

```markdown
# Integration Checklist

## App.tsx Integration
- [ ] Add feature flag constants
- [ ] Import BlueprintProvider
- [ ] Conditionally render DynamicWizard vs legacy
- [ ] Update generateEpic calls
- [ ] Update AI suggestion calls

## Backward Compatibility
- [ ] Create `src/blueprint/compat.ts`
- [ ] Implement legacy adapter functions
- [ ] Implement `generateEpicCompat()`
- [ ] Implement `getSuggestionCompat()`

## Testing
- [ ] Run full integration tests
- [ ] Verify output parity
- [ ] Test feature flag toggling
- [ ] Test draft persistence

## Documentation
- [ ] Update CLAUDE.md with new architecture
- [ ] Add inline code comments
- [ ] Create migration guide
```

### Phase 6: Template System (Week 6-7)

```markdown
# Template System Checklist (Post-MVP)

## Template Storage
- [ ] Create `src/services/TemplateStorage.ts`
- [ ] Implement `getBuiltInTemplates()`
- [ ] Implement `getUserTemplates()`
- [ ] Implement `saveUserTemplate()`
- [ ] Implement `importTemplate()` / `exportTemplate()`

## Template UI
- [ ] Create `src/components/templates/TemplateSelector.tsx`
- [ ] Create `src/components/templates/TemplateCard.tsx`
- [ ] Create `src/components/templates/TemplatePreviewModal.tsx`

## Additional Templates
- [ ] Create `src/blueprints/simple-proposal.ts`
- [ ] Test new template end-to-end
```

---

## Known Limitations

### Current Design Limitations

| Limitation | Description | Workaround | Future Consideration |
|------------|-------------|------------|----------------------|
| **Field types** | MVP supports only text/textarea | Use textarea for all | Add select, list, table in Phase 2 |
| **Validation** | Basic required/length only | Custom validation via code | Add pattern, custom validators |
| **Conditional fields** | Not in MVP | Pre-fill defaults | Add visibleIf, requiredIf |
| **Multi-language** | English only | None | i18n support in future |
| **Offline mode** | Requires internet for AI | Use without AI suggestions | Service worker caching |
| **Large blueprints** | May affect performance | Keep < 20 stages | Virtualization, lazy loading |
| **Nested fields** | Not supported | Flatten structure | Consider for complex templates |
| **File uploads** | Not supported | External links | Add file field type |

### Technical Limitations

| Limitation | Description | Impact | Resolution |
|------------|-------------|--------|------------|
| **JSON blueprint size** | LocalStorage limit 5MB | Can't store very large templates | Use IndexedDB |
| **AI token limits** | Context window limits | May truncate long fields | Summarization |
| **Browser support** | Modern browsers only | No IE11 | Polyfills if needed |
| **Concurrent edits** | No real-time sync | Last save wins | Future: conflict resolution |
| **Undo/redo** | Not implemented | Manual editing only | State history tracking |

### Known Trade-offs

| Trade-off | Benefit | Cost |
|-----------|---------|------|
| Blueprint in code vs DB | Type safety, versioning | Requires deploy for changes |
| React Context vs Redux | Simpler, fewer deps | May have performance issues at scale |
| Mermaid vs custom diagrams | Markdown compatible | Limited styling control |
| MVP field types | Faster delivery | Less flexibility initially |
| Feature flags | Safe rollout | Code complexity |

---

## Self-Critique (Iteration 18)

**Positive:**
- Comprehensive implementation checklist provides clear path forward
- Known limitations are documented honestly
- Trade-offs are explicit with rationale

**Concerns:**
- Checklist is long - need to prioritize ruthlessly for MVP
- Some limitations may frustrate power users
- Post-MVP features may never get implemented

**Decisions Made:**
1. MVP checklist is Phases 1-5 (exclude Template System)
2. Limitations are acceptable for initial release
3. Trade-offs favor simplicity and safety

---

## Final Summary - Iteration 19

### What Was Accomplished

Over 19 iterations, this document provides a complete architecture design for transforming Epic Generator v4 from a hardcoded 6-stage wizard into a dynamic, blueprint-driven system. Key accomplishments:

1. **Discovery Phase (Iterations 1-3)**
   - Fully analyzed existing codebase structure
   - Identified all hardcoded dependencies
   - Documented current rendering patterns

2. **Pattern Extraction Phase (Iterations 4-5)**
   - Defined 20+ field types for extensibility
   - Designed flexible validation rules
   - Created AI prompt registry structure
   - Specified 7 render types for output sections

3. **Blueprint Schema Design (Iterations 6-7)**
   - Created comprehensive TypeScript schema (~300 lines)
   - Designed blueprint loader with validation
   - Created full Technical Architect template example

4. **Architecture Design (Iterations 8-9)**
   - Designed React component architecture
   - Created BlueprintContext state management
   - Planned template selector UI
   - Documented migration strategy

5. **Implementation Planning (Iterations 10-11)**
   - Created prioritized task list (207 hours)
   - Defined MVP scope (72 hours)
   - Documented API migration guide
   - Designed backward compatibility layer

6. **Architecture Refinement (Iterations 12-14)**
   - Created comprehensive data flow diagrams
   - Analyzed all edge cases
   - Designed AI prompt template system
   - Documented extensibility patterns

7. **Finalization (Iterations 15-18)**
   - Created test matrix (80+ test cases)
   - Defined CI/CD pipeline
   - Completed risk assessment
   - Created executive summary and quick-start guide
   - Documented implementation checklist
   - Listed known limitations and trade-offs

### Key Recommendations

1. **Start with MVP** - Foundation + output parity is the critical path
2. **Use feature flags** - Enable safe, gradual rollout
3. **Test extensively** - Output parity tests are mandatory
4. **Maintain compatibility** - Backward compatibility layer enables migration
5. **Document everything** - This design doc should evolve with implementation

### Files to Create (MVP)

```
src/blueprint/
  schema.ts           # Blueprint TypeScript interfaces
  loader.ts           # Blueprint loading and validation
  BlueprintContext.tsx # React context provider
  DocumentGenerator.ts # Dynamic document generation
  AIService.ts        # Blueprint-aware AI service
  compat.ts           # Backward compatibility layer

src/blueprints/
  technical-architect.ts  # Current template as blueprint
  index.ts                # Blueprint registry

src/components/
  fields/
    TextField.tsx
    TextareaField.tsx
    FieldRenderer.tsx
    registry.ts
  wizard/
    StageRenderer.tsx
    StageNavigation.tsx
    DynamicWizard.tsx
```

### Success Criteria

1. Output parity: 100% match with legacy generator
2. Test coverage: 80%+ across all modules
3. Performance: < 100ms document generation
4. User impact: Zero visible changes (feature flagged)

---

### Iteration 20 - 2026-01-24 (FINAL)
**Focus:** Final Self-Critique, Closing Recommendations

---

## Final Self-Critique

### Strengths of This Design

1. **Comprehensive Analysis** - Every major source file was analyzed with specific line references
2. **Incremental Progress** - Each iteration built on previous findings
3. **Practical Examples** - Complete TypeScript code for all major components
4. **Risk Awareness** - Explicit trade-offs and limitations documented
5. **Actionable Output** - Clear implementation checklist with time estimates

### Weaknesses / Areas for Improvement

1. **Schema Complexity** - The blueprint schema is comprehensive but may be over-engineered for MVP
2. **Time Estimates** - Estimates are theoretical; actual implementation may vary
3. **Testing Coverage** - Test matrix is extensive but implementation effort may be underestimated
4. **UI Design** - Template selector UI is conceptual; needs actual UX design
5. **Performance Testing** - No actual benchmarks; performance claims are theoretical

### Assumptions Made

1. React Context is sufficient for state management (no Redux needed)
2. TypeScript blueprints are preferred over JSON (for type safety)
3. Current STAGES/EPIC_SECTIONS structure is optimal (just needs to be dynamic)
4. AI providers will remain OpenAI/Azure (no new providers planned)
5. Team has bandwidth for 7-week implementation

### Questions for Implementation Phase

1. Should we support JSON blueprints from remote URLs?
2. What is the maximum reasonable number of stages/fields?
3. Should templates be shareable between users?
4. Do we need a visual template editor?
5. Should we consider server-side rendering for large documents?

---

## Closing Recommendations

### Immediate Next Steps

1. **Review this document with the team** - Validate assumptions and priorities
2. **Create a GitHub project board** - Track implementation tasks
3. **Set up the file structure** - Create empty files with interfaces
4. **Start with schema and loader** - Foundation must be solid
5. **Write output parity tests first** - TDD for critical functionality

### Long-Term Considerations

1. **Template Marketplace** - Allow users to share custom templates
2. **Template Analytics** - Track which templates are most used
3. **AI-Assisted Template Creation** - Generate blueprints from descriptions
4. **Real-Time Collaboration** - Multiple users editing same document
5. **Version History** - Track changes to templates and documents

### Final Thoughts

This architecture design transforms a well-built but inflexible wizard into a truly dynamic system. The key insight is that the current codebase is already largely dynamic - it iterates over arrays and uses field names as keys. The main work is extracting hardcoded data into configuration and ensuring output parity.

The MVP can be delivered in approximately 2 weeks by focusing on:
- Blueprint schema and loader
- Document generator with all render types
- Basic field components (text/textarea only)
- Feature flag integration
- Output parity testing

Everything else (template UI, additional field types, extensibility) can be deferred to post-MVP phases.

---

## Document Complete

This design document is now complete and ready for implementation.

**Total Document Size:** ~3,500 lines of markdown
**Total Design Time:** 20 iterations
**Key Deliverables:**
- Complete Blueprint TypeScript schema
- Technical Architect template as blueprint
- Dynamic renderer architecture
- AI prompt template system
- Implementation checklist
- Test matrix
- Risk assessment

**Author:** Claude Opus 4.5 (via autonomous iterative analysis)
**Date:** 2026-01-24

---

*End of Document*
