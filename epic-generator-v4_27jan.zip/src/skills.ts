// Epic Generator Skills & Prompts

import { EPIC_SECTIONS, STAGES, type RefinedData, type SectionFeedback, type EpicQualityReport } from './types';
import { type AppConfig, callAI } from './config';

// Skill Types
export interface RefineResult {
  refined: string;
  diagramNode: string;
  suggestions?: string[];
}

export interface GenerateResult {
  epic: string;
  diagram: string;
}

export interface SuggestionResult {
  suggestion: string;
  alternatives?: string[];
}

// Store config reference for AI calls
let currentConfig: AppConfig | null = null;

export function setConfig(config: AppConfig) {
  currentConfig = config;
}

// Get AI suggestion for a field using Azure OpenAI
// mode: 'with-context' uses user's keywords to tailor suggestion
// mode: 'auto' generates from scratch using project context
export async function getSuggestion(
  stageId: string,
  fieldName: string,
  context: Record<string, string>,
  mode: 'with-context' | 'auto' = 'auto'
): Promise<SuggestionResult> {
  if (!currentConfig) {
    throw new Error('Azure OpenAI is not configured. Please check Settings.');
  }

  const userHint = context['_userHint'];
  const systemPrompt = getSystemPromptForField(stageId, fieldName);
  const userPrompt = buildUserPrompt(stageId, fieldName, context, userHint, mode);

  const aiResponse = await callAI(currentConfig, systemPrompt, userPrompt);

  return {
    suggestion: aiResponse.trim(),
    alternatives: [],
  };
}

// Get system prompt for a specific field
function getSystemPromptForField(stageId: string, fieldName: string): string {
  const basePrompt = `You are an expert technical writer helping to create comprehensive software project epics.
Provide concise, professional content suitable for a technical design document.
Be specific and actionable. Use bullet points or numbered lists where appropriate.
Do not include any preamble or explanation - just provide the content directly.`;

  const fieldPrompts: Record<string, Record<string, string>> = {
    project: {
      projectName: `${basePrompt}\nGenerate a professional project name (2-4 words, no quotes).`,
      background: `${basePrompt}\nWrite a project background section explaining why this initiative exists and its business context.`,
    },
    objective_scope: {
      objective: `${basePrompt}\nWrite a clear, measurable project objective with success criteria.`,
      inScope: `${basePrompt}\nList items that are IN SCOPE for this project. Use bullet points, one item per line.`,
      outOfScope: `${basePrompt}\nList items that are OUT OF SCOPE for this project. Use bullet points, one item per line.`,
    },
    architecture: {
      assumptions: `${basePrompt}\nList technical and business assumptions for this project. Use bullet points.`,
      architectureOverview: `${basePrompt}\nDescribe the high-level system architecture including components, technologies, and how they interact.`,
      dataStores: `${basePrompt}\nDescribe the data stores, databases, caching layers, and data flow for this system.`,
    },
    features: {
      features: `${basePrompt}\nList the key features for this project. Use numbered list format.`,
      userStories: `${basePrompt}\nWrite user stories in the format "As a [role], I want [feature] so that [benefit]".`,
      nfrs: `${basePrompt}\nDefine non-functional requirements including performance, scalability, security, and availability targets.`,
      deliverables: `${basePrompt}\nList project deliverables. Use bullet points.`,
    },
    team_env: {
      teams: `${basePrompt}\nDefine team roles and responsibilities. Format: Role - Responsibility`,
      environments: `${basePrompt}\nDescribe the environment strategy (dev, staging, prod) and CI/CD approach.`,
      security: `${basePrompt}\nDefine security controls including authentication, authorization, encryption, and compliance requirements.`,
    },
    delivery: {
      dependencies: `${basePrompt}\nList project dependencies (teams, systems, third parties). Use bullet points.`,
      risks: `${basePrompt}\nIdentify project risks with mitigations. Format: Risk: [description] | Mitigation: [approach]`,
      nextSteps: `${basePrompt}\nList immediate next steps to kick off this project. Use numbered list.`,
      dod: `${basePrompt}\nDefine the Definition of Done criteria for this project. Use bullet points.`,
      approvers: `${basePrompt}\nList required approvers with their roles. Format: Name/Role - Type of approval`,
    },
  };

  return fieldPrompts[stageId]?.[fieldName] || basePrompt;
}

// Build user prompt based on context
function buildUserPrompt(
  _stageId: string,
  fieldName: string,
  context: Record<string, string>,
  userHint: string | undefined,
  mode: 'with-context' | 'auto'
): string {
  let prompt = '';

  // Add project context if available
  if (context.projectName) {
    prompt += `Project: ${context.projectName}\n`;
  }
  if (context.objective) {
    prompt += `Objective: ${context.objective}\n`;
  }
  if (context.background) {
    prompt += `Background: ${context.background}\n`;
  }

  // Add user hint if in with-context mode
  if (mode === 'with-context' && userHint) {
    prompt += `\nUser's keywords/ideas to incorporate: ${userHint}\n`;
    prompt += `\nBased on these keywords, generate appropriate content for the "${fieldName}" field.`;
  } else {
    prompt += `\nGenerate content for the "${fieldName}" field based on the project context above.`;
  }

  // Add field-specific guidance
  const fieldGuidance: Record<string, string> = {
    projectName: 'Generate a professional, concise project name.',
    background: 'Write 2-3 paragraphs explaining the business context and need.',
    objective: 'Write a clear objective with measurable success criteria.',
    inScope: 'List 5-8 items that are in scope.',
    outOfScope: 'List 3-5 items explicitly out of scope.',
    assumptions: 'List 4-6 key assumptions.',
    architectureOverview: 'Describe the architecture in 2-3 paragraphs with key components.',
    dataStores: 'Describe databases, caching, and data flow.',
    features: 'List 5-8 key features.',
    userStories: 'Write 3-5 user stories.',
    nfrs: 'Define performance, scalability, security, and availability requirements.',
    deliverables: 'List 5-7 project deliverables.',
    teams: 'Define 5-7 team roles.',
    environments: 'Describe dev, staging, and production environments.',
    security: 'Define authentication, authorization, and encryption approach.',
    dependencies: 'List 4-6 dependencies.',
    risks: 'Identify 3-5 risks with mitigations.',
    nextSteps: 'List 4-6 immediate next steps.',
    dod: 'Define 5-7 Definition of Done criteria.',
    approvers: 'List 3-5 required approvers.',
  };

  if (fieldGuidance[fieldName]) {
    prompt += `\n${fieldGuidance[fieldName]}`;
  }

  return prompt;
}

// Small delay for UI feedback
const mockDelay = () => new Promise(resolve => setTimeout(resolve, 300));

// Refine Skill - Enhances user input at each stage
async function refineInput(
  stageId: string,
  fieldName: string,
  userInput: string,
  _context: Record<string, string>
): Promise<RefineResult> {
  await mockDelay();

  // Mock refinement based on stage and field
  const refinements: Record<string, Record<string, (input: string) => RefineResult>> = {
    project: {
      projectName: (input) => ({
        refined: input,
        diagramNode: `Project["${input}"]`,
      }),
      background: (input) => ({
        refined: `**Context:** ${input}\n\n**Business Need:** This initiative addresses key organizational requirements and strategic objectives.`,
        diagramNode: `Context["Background & Context"]`,
      }),
    },
    objective_scope: {
      objective: (input) => ({
        refined: `**Primary Goal:** ${input}\n\n**Success Metrics:** Measurable outcomes will be defined during implementation.`,
        diagramNode: `Objective["${input.slice(0, 30)}..."]`,
      }),
      inScope: (input) => ({
        refined: input.split('\n').map(line => line.trim()).filter(Boolean).map(line => `- ${line}`).join('\n'),
        diagramNode: `Scope["In Scope Items"]`,
      }),
      outOfScope: (input) => ({
        refined: input ? input.split('\n').map(line => line.trim()).filter(Boolean).map(line => `- ${line}`).join('\n') : '- To be determined based on project constraints',
        diagramNode: `OutScope["Out of Scope"]`,
      }),
    },
    architecture: {
      assumptions: (input) => ({
        refined: input ? input.split('\n').map(line => line.trim()).filter(Boolean).map(line => `- ${line}`).join('\n') : '- Standard infrastructure availability\n- Team availability for implementation',
        diagramNode: `Assumptions["Assumptions"]`,
      }),
      architectureOverview: (input) => ({
        refined: `**System Architecture:**\n\n${input}\n\n**Key Components:** The system follows a modular architecture pattern enabling scalability and maintainability.`,
        diagramNode: `Architecture["System Architecture"]`,
      }),
      dataStores: (input) => ({
        refined: `**Data Layer:**\n\n${input}\n\n**Integration Points:** APIs and services will follow RESTful conventions with appropriate authentication.`,
        diagramNode: `DataStores["Data & Services"]`,
      }),
    },
    features: {
      features: (input) => ({
        refined: input.split('\n').map(line => line.trim()).filter(Boolean).map((line, i) => `${i + 1}. **${line}**`).join('\n'),
        diagramNode: `Features["Key Features"]`,
      }),
      userStories: (input) => ({
        refined: input || 'User stories to be elaborated during sprint planning.',
        diagramNode: `Stories["User Stories"]`,
      }),
      nfrs: (input) => ({
        refined: input ? `**Performance & Quality Requirements:**\n\n${input}` : '- Performance: Response time < 2s\n- Availability: 99.9% uptime\n- Security: Industry standard encryption',
        diagramNode: `NFRs["NFRs"]`,
      }),
      deliverables: (input) => ({
        refined: input.split('\n').map(line => line.trim()).filter(Boolean).map(line => `- [ ] ${line}`).join('\n'),
        diagramNode: `Deliverables["Deliverables"]`,
      }),
    },
    team_env: {
      teams: (input) => ({
        refined: input,
        diagramNode: `Team["Team Structure"]`,
      }),
      environments: (input) => ({
        refined: `**Environment Strategy:**\n\n${input}\n\n**Deployment:** CI/CD pipeline with automated testing and staged rollouts.`,
        diagramNode: `Environments["Environments"]`,
      }),
      security: (input) => ({
        refined: input ? `**Security Controls:**\n\n${input}` : '- Role-based access control (RBAC)\n- Data encryption at rest and in transit\n- Audit logging enabled',
        diagramNode: `Security["Security"]`,
      }),
    },
    delivery: {
      dependencies: (input) => ({
        refined: input ? input.split('\n').map(line => line.trim()).filter(Boolean).map(line => `- ${line}`).join('\n') : '- No critical external dependencies identified',
        diagramNode: `Dependencies["Dependencies"]`,
      }),
      risks: (input) => ({
        refined: input ? input.split('\n').map(line => line.trim()).filter(Boolean).map(line => `- **Risk:** ${line}`).join('\n') : '- Resource availability\n- Timeline constraints',
        diagramNode: `Risks["Risks"]`,
      }),
      nextSteps: (input) => ({
        refined: input.split('\n').map(line => line.trim()).filter(Boolean).map((line, i) => `${i + 1}. ${line}`).join('\n'),
        diagramNode: `NextSteps["Next Steps"]`,
      }),
      dod: (input) => ({
        refined: input.split('\n').map(line => line.trim()).filter(Boolean).map(line => `- [ ] ${line}`).join('\n'),
        diagramNode: `DoD["Definition of Done"]`,
      }),
      approvers: (input) => ({
        refined: input || 'Project stakeholders and technical leads',
        diagramNode: `Approvers["Approvers"]`,
      }),
    },
  };

  const stageRefinements = refinements[stageId];
  if (stageRefinements && stageRefinements[fieldName]) {
    return stageRefinements[fieldName](userInput);
  }

  // Default refinement
  return {
    refined: userInput,
    diagramNode: `Node_${fieldName}["${fieldName}"]`,
  };
}

// Generate Epic Skill - Creates full 17-section epic
async function generateEpic(data: RefinedData, projectName: string, blueprintCode?: string): Promise<GenerateResult> {
  await mockDelay();

  // Build the epic document
  let epic = `# Technical Design Epic: ${projectName}\n\n`;
  epic += `*Generated on ${new Date().toLocaleDateString()}*\n\n---\n\n`;

  // Generate each section
  for (const section of EPIC_SECTIONS) {
    epic += `## ${section.num}. ${section.title}\n\n`;

    if (section.subsections) {
      // Handle sections with subsections (Scope, Dependencies & Risks)
      section.dataKeys.forEach((key, idx) => {
        const subsectionTitle = section.subsections![idx];
        const content = data[key]?.refined || '_To be defined_';
        epic += `### ${section.num}.${idx + 1} ${subsectionTitle}\n\n${content}\n\n`;
      });
    } else if (section.isTable && section.dataKeys[0] === 'teams') {
      // Team & Roles table
      epic += `| Role | Responsibility |\n|------|----------------|\n`;
      const teamData = data['teams']?.refined || 'Team structure to be defined';
      teamData.split('\n').filter(Boolean).forEach(line => {
        epic += `| ${line} | TBD |\n`;
      });
      epic += '\n';
    } else if (section.isTable && section.dataKeys[0] === 'approvers') {
      // Approvals table
      epic += `| Approver | Role | Status |\n|----------|------|--------|\n`;
      const approverData = data['approvers']?.refined || 'Stakeholders';
      approverData.split('\n').filter(Boolean).forEach(line => {
        epic += `| ${line.trim()} | Stakeholder | Pending |\n`;
      });
      epic += '\n';
    } else if (section.hasDiagram) {
      // Architecture overview - no embedded diagram (Blueprint tab has the visual)
      const content = data[section.dataKeys[0]]?.refined || '_Architecture details to be defined_';
      epic += `${content}\n\n`;
    } else if (section.isReference) {
      // Architecture diagrams - embed mermaid if available, otherwise point to Blueprint tab
      if (blueprintCode && blueprintCode.trim()) {
        epic += '```mermaid\n';
        epic += blueprintCode.trim();
        epic += '\n```\n\n';
        epic += `> *Diagram auto-generated from epic content. Regenerate in Blueprint tab to update.*\n\n`;
      } else {
        epic += `> **Note:** Generate a diagram in the **Blueprint** tab to include it here.\n\n`;
      }
    } else {
      // Standard section
      const content = section.dataKeys
        .map(key => data[key]?.refined)
        .filter(Boolean)
        .join('\n\n') || '_To be defined_';
      epic += `${content}\n\n`;
    }
  }

  // Generate the multilayer summary diagram
  const diagram = generateMultilayerDiagram(data, projectName);

  return { epic, diagram };
}

// Generate architecture diagram from refined data
function generateArchitectureDiagram(data: RefinedData): string {
  const hasDataStores = data['dataStores']?.refined;
  const hasFeatures = data['features']?.refined;

  let diagram = 'graph TD\n';
  diagram += '    User[User/Client] --> API[API Gateway]\n';
  diagram += '    API --> Services[Service Layer]\n';

  if (hasFeatures) {
    diagram += '    Services --> Features[Feature Modules]\n';
  }

  if (hasDataStores) {
    diagram += '    Services --> DB[(Database)]\n';
    diagram += '    Services --> Cache[(Cache)]\n';
  } else {
    diagram += '    Services --> DB[(Data Store)]\n';
  }

  diagram += '    Services --> External[External Services]\n';

  return diagram;
}

// Generate multilayer diagram showing the full flow
function generateMultilayerDiagram(_data: RefinedData, projectName: string): string {
  let diagram = 'graph TD\n';

  // Input Layer
  diagram += '    subgraph Input["Input Layer"]\n';
  diagram += '        I1[Project Info]\n';
  diagram += '        I2[Objective & Scope]\n';
  diagram += '        I3[Architecture]\n';
  diagram += '        I4[Features]\n';
  diagram += '        I5[Team & Env]\n';
  diagram += '        I6[Delivery]\n';
  diagram += '    end\n\n';

  // Refinement Layer
  diagram += '    subgraph Refine["AI Refinement Layer"]\n';
  diagram += '        R1[Refined Background]\n';
  diagram += '        R2[Refined Scope]\n';
  diagram += '        R3[Refined Architecture]\n';
  diagram += '        R4[Refined Features]\n';
  diagram += '        R5[Refined Team]\n';
  diagram += '        R6[Refined Delivery]\n';
  diagram += '    end\n\n';

  // Connections
  diagram += '    I1 --> R1\n';
  diagram += '    I2 --> R2\n';
  diagram += '    I3 --> R3\n';
  diagram += '    I4 --> R4\n';
  diagram += '    I5 --> R5\n';
  diagram += '    I6 --> R6\n\n';

  // Epic Document
  diagram += `    subgraph Epic["${projectName} Epic"]\n`;
  diagram += '        E[17-Section Document]\n';
  diagram += '    end\n\n';

  diagram += '    R1 --> E\n';
  diagram += '    R2 --> E\n';
  diagram += '    R3 --> E\n';
  diagram += '    R4 --> E\n';
  diagram += '    R5 --> E\n';
  diagram += '    R6 --> E\n';

  return diagram;
}

// Main skill runner
export async function runSkill(
  skill: 'refine' | 'generate',
  params: {
    stageId?: string;
    fieldName?: string;
    input?: string;
    context?: Record<string, string>;
    data?: RefinedData;
    projectName?: string;
    blueprintCode?: string;
  }
): Promise<RefineResult | GenerateResult> {
  if (skill === 'refine') {
    return refineInput(
      params.stageId!,
      params.fieldName!,
      params.input!,
      params.context || {}
    );
  } else {
    return generateEpic(params.data!, params.projectName!, params.blueprintCode);
  }
}

// ===========================================
// INTELLIGENT PLANTUML GENERATION
// ===========================================

// ===========================================
// DIAGRAM STYLING - Color Palette & Theme
// ===========================================

// Colorful palette for diagrams (Okabe-Ito colorblind-safe)
// Primary=#0072B2, Secondary=#56B4E9, Accent=#009E73, Data=#E69F00, External=#CC79A7

/**
 * Apply colorful theme to a Mermaid diagram
 * Uses Okabe-Ito colorblind-safe palette for clear visual distinction
 */
function applyDiagramTheme(diagramCode: string): string {
  // Don't double-apply theme
  if (diagramCode.includes('%%{init:')) {
    return diagramCode;
  }

  const themeInit = `%%{init: {'theme': 'base', 'themeVariables': {
  'primaryColor': '#0072B2',
  'primaryTextColor': '#ffffff',
  'primaryBorderColor': '#005A8C',
  'secondaryColor': '#56B4E9',
  'secondaryTextColor': '#ffffff',
  'secondaryBorderColor': '#0072B2',
  'tertiaryColor': '#E69F00',
  'tertiaryTextColor': '#000000',
  'tertiaryBorderColor': '#CC8800',
  'lineColor': '#64748B',
  'textColor': '#1F2937',
  'mainBkg': '#FAFAFA',
  'nodeBorder': '#E5E7EB',
  'clusterBkg': '#F0F9FF',
  'clusterBorder': '#BAE6FD',
  'edgeLabelBackground': 'transparent',
  'fontSize': '14px'
}}}%%
`;

  return themeInit + diagramCode;
}

// Diagram types that can be generated based on context
type DiagramType =
  | 'c4-container'      // Best for system architecture overview
  | 'component'         // Best for internal component structure
  | 'sequence'          // Best for user flows and interactions
  | 'deployment';       // Best for infrastructure and environments

interface DiagramContext {
  hasArchitecture: boolean;
  hasFeatures: boolean;
  hasUserStories: boolean;
  hasDataStores: boolean;
  hasEnvironments: boolean;
  hasDeploymentDetails: boolean;
  hasWorkflows: boolean;
  featureCount: number;
  componentCount: number;
  integrationCount: number;
}

// Analyze epic data to understand what type of diagram would be most valuable
function analyzeEpicContext(data: RefinedData): DiagramContext {
  const archText = (data['architectureOverview']?.original || '').toLowerCase();
  const featuresText = data['features']?.original || '';
  const storiesText = data['userStories']?.original || '';
  const dataText = data['dataStores']?.original || '';
  const envsText = data['environments']?.original || '';

  // Count meaningful items
  const featureLines = featuresText.split('\n').filter(l => l.trim().length > 3);
  const componentMatches = archText.match(/\b(service|component|module|layer|api|database|cache|queue|gateway)\b/gi) || [];
  const integrationMatches = archText.match(/\b(integration|external|third-party|api|webhook|oauth|sso)\b/gi) || [];

  return {
    hasArchitecture: archText.length > 50,
    hasFeatures: featureLines.length > 0,
    hasUserStories: storiesText.length > 50,
    hasDataStores: dataText.length > 30,
    hasEnvironments: envsText.length > 30,
    hasDeploymentDetails: envsText.toLowerCase().includes('deploy') || envsText.toLowerCase().includes('kubernetes') || envsText.toLowerCase().includes('docker'),
    hasWorkflows: storiesText.toLowerCase().includes('when') || storiesText.toLowerCase().includes('then') || archText.includes('flow'),
    featureCount: featureLines.length,
    componentCount: new Set(componentMatches.map(m => m.toLowerCase())).size,
    integrationCount: new Set(integrationMatches.map(m => m.toLowerCase())).size,
  };
}

// Intelligently select the best diagram type based on context
function selectBestDiagramType(context: DiagramContext): DiagramType {
  // Priority scoring for diagram types that support horizontal layout
  const scores: Record<string, number> = {
    'c4-container': 2, // Default baseline score
    'component': 0,
    'sequence': 0,
    'deployment': 0,
  };

  // Score based on available data
  if (context.hasArchitecture && context.componentCount >= 3) {
    scores['c4-container'] += 5;
    scores['component'] += 4;
  }

  if (context.hasUserStories && context.hasWorkflows) {
    scores['sequence'] += 5;
  }

  if (context.hasDeploymentDetails && context.hasEnvironments) {
    scores['deployment'] += 5;
  }

  if (context.hasDataStores && context.componentCount >= 2) {
    scores['component'] += 2;
  }

  if (context.integrationCount >= 2) {
    scores['c4-container'] += 3;
    scores['sequence'] += 2;
  }

  // C4 is a good default for architecture-focused epics
  if (context.hasArchitecture) {
    scores['c4-container'] += 2;
  }

  // Find highest scoring type (only from our supported horizontal types)
  let bestType: DiagramType = 'c4-container';
  let highestScore = 0;

  for (const [type, score] of Object.entries(scores)) {
    if (score > highestScore) {
      highestScore = score;
      bestType = type as DiagramType;
    }
  }

  return bestType;
}

// Extract meaningful components from architecture text
function extractComponents(archText: string): string[] {
  const components: string[] = [];
  const lines = archText.split('\n');

  for (const line of lines) {
    // Look for bold items like **Component Name**
    const boldMatches = line.match(/\*\*([^*]+)\*\*/g);
    if (boldMatches) {
      boldMatches.forEach(m => {
        const cleaned = m.replace(/\*\*/g, '').trim();
        if (cleaned.length > 2 && cleaned.length < 40) {
          components.push(cleaned);
        }
      });
    }

    // Look for list items
    const listMatch = line.match(/^[-•*]\s*(.+?)(?:\s*[-:]|$)/);
    if (listMatch && listMatch[1].length > 2 && listMatch[1].length < 40) {
      components.push(listMatch[1].trim());
    }
  }

  return [...new Set(components)].slice(0, 8);
}

// Extract user stories for sequence diagrams
function extractUserFlows(storiesText: string): { actor: string; action: string; target: string }[] {
  const flows: { actor: string; action: string; target: string }[] = [];
  const lines = storiesText.split('\n');

  for (const line of lines) {
    // Parse "As a [role], I want [action] so that [benefit]"
    const storyMatch = line.match(/as\s+(?:a|an)\s+(\w+).*?(?:I want|I need|I can)\s+(.+?)(?:\s+so that|\s+in order|$)/i);
    if (storyMatch) {
      flows.push({
        actor: storyMatch[1].charAt(0).toUpperCase() + storyMatch[1].slice(1),
        action: storyMatch[2].trim().slice(0, 50),
        target: 'System',
      });
    }
  }

  return flows.slice(0, 6);
}

// Generate C4-style Container diagram using Mermaid - great for system overview
function generateC4ContainerDiagram(data: RefinedData, projectName: string): string {
  const arch = data['architectureOverview']?.original || '';
  const dataStores = data['dataStores']?.original || '';

  const components = extractComponents(arch);
  const hasDB = dataStores.toLowerCase().includes('database') || dataStores.toLowerCase().includes('postgres') || dataStores.toLowerCase().includes('mysql') || dataStores.toLowerCase().includes('warehouse');
  const hasCache = dataStores.toLowerCase().includes('cache') || dataStores.toLowerCase().includes('redis') || dataStores.toLowerCase().includes('memcache');
  const hasQueue = dataStores.toLowerCase().includes('queue') || dataStores.toLowerCase().includes('kafka') || dataStores.toLowerCase().includes('rabbit') || dataStores.toLowerCase().includes('streaming');
  const hasNoSQL = dataStores.toLowerCase().includes('nosql') || dataStores.toLowerCase().includes('mongodb') || dataStores.toLowerCase().includes('cassandra');
  const hasFrontend = arch.toLowerCase().includes('frontend') || arch.toLowerCase().includes('react') || arch.toLowerCase().includes('ui') || arch.toLowerCase().includes('user interface');
  const hasAPI = arch.toLowerCase().includes('api') || arch.toLowerCase().includes('gateway') || arch.toLowerCase().includes('rest');
  const hasAnalytics = arch.toLowerCase().includes('analytics') || arch.toLowerCase().includes('machine learning') || arch.toLowerCase().includes('ml');
  const hasExternal = arch.toLowerCase().includes('external') || arch.toLowerCase().includes('third-party') || arch.toLowerCase().includes('integration');

  // Sanitize project name for Mermaid
  const safeProjectName = projectName.replace(/[^a-zA-Z0-9\s]/g, '').trim() || 'System';

  let mermaid = `flowchart LR\n`;

  // User
  mermaid += `    U((User))\n`;

  // Frontend
  if (hasFrontend) {
    mermaid += `    subgraph Frontend["Frontend"]\n`;
    mermaid += `        WA[Web App]\n`;
    mermaid += `    end\n`;
  }

  // Backend
  mermaid += `    subgraph Backend["Backend Services"]\n`;
  if (hasAPI) {
    mermaid += `        API[API Gateway]\n`;
  }
  if (components.length > 0) {
    components.slice(0, 3).forEach((comp, i) => {
      const safeComp = comp.replace(/[^a-zA-Z0-9\s]/g, '').trim().slice(0, 15) || `Service${i}`;
      mermaid += `        SVC${i}[${safeComp}]\n`;
    });
  } else {
    mermaid += `        SVC0[Services]\n`;
  }
  if (hasAnalytics) {
    mermaid += `        ANA[Analytics]\n`;
  }
  mermaid += `    end\n`;

  // Data layer - always include at least a database
  mermaid += `    subgraph Data["Data Layer"]\n`;
  if (hasDB || (!hasCache && !hasQueue && !hasNoSQL)) {
    mermaid += `        DB[(Database)]\n`;
  }
  if (hasCache) {
    mermaid += `        CACHE[(Cache)]\n`;
  }
  if (hasQueue) {
    mermaid += `        QUEUE[(Queue)]\n`;
  }
  if (hasNoSQL) {
    mermaid += `        NOSQL[(NoSQL)]\n`;
  }
  mermaid += `    end\n`;

  if (hasExternal) {
    mermaid += `    EXT{{External API}}\n`;
  }

  // Connections
  if (hasFrontend) {
    mermaid += `    U --> WA\n`;
    if (hasAPI) {
      mermaid += `    WA --> API\n`;
    } else {
      mermaid += `    WA --> SVC0\n`;
    }
  } else if (hasAPI) {
    mermaid += `    U --> API\n`;
  } else {
    mermaid += `    U --> SVC0\n`;
  }

  if (hasAPI) {
    mermaid += `    API --> SVC0\n`;
    if (hasAnalytics) {
      mermaid += `    API --> ANA\n`;
    }
  }

  // Service connections to data - always connect to DB since we always have it
  mermaid += `    SVC0 --> DB\n`;
  if (hasAnalytics) {
    mermaid += `    ANA --> DB\n`;
  }
  if (hasCache) {
    mermaid += `    SVC0 --> CACHE\n`;
  }
  if (hasQueue) {
    mermaid += `    SVC0 --> QUEUE\n`;
  }
  if (hasNoSQL) {
    mermaid += `    SVC0 --> NOSQL\n`;
  }
  if (hasExternal) {
    mermaid += `    SVC0 --> EXT\n`;
  }

  // Colorful styles for architecture diagrams
  mermaid += `\n    %% Colorful Styling\n`;
  if (hasFrontend) {
    mermaid += `    style WA fill:#56B4E9,stroke:#0072B2,color:#fff\n`;
  }
  if (hasAPI) {
    mermaid += `    style API fill:#0072B2,stroke:#005A8C,color:#fff\n`;
  }
  // Style service nodes
  if (components.length > 0) {
    components.slice(0, 3).forEach((_, i) => {
      mermaid += `    style SVC${i} fill:#009E73,stroke:#007A5E,color:#fff\n`;
    });
  } else {
    mermaid += `    style SVC0 fill:#009E73,stroke:#007A5E,color:#fff\n`;
  }
  if (hasAnalytics) {
    mermaid += `    style ANA fill:#CC79A7,stroke:#AA5585,color:#fff\n`;
  }
  // Data layer styling - warm colors
  if (hasDB || (!hasCache && !hasQueue && !hasNoSQL)) {
    mermaid += `    style DB fill:#E69F00,stroke:#CC8800,color:#fff\n`;
  }
  if (hasCache) {
    mermaid += `    style CACHE fill:#E69F00,stroke:#CC8800,color:#fff\n`;
  }
  if (hasQueue) {
    mermaid += `    style QUEUE fill:#009E73,stroke:#007A5E,color:#fff\n`;
  }
  if (hasNoSQL) {
    mermaid += `    style NOSQL fill:#E69F00,stroke:#CC8800,color:#fff\n`;
  }
  if (hasExternal) {
    mermaid += `    style EXT fill:#CC79A7,stroke:#AA5585,color:#fff\n`;
  }

  return mermaid;
}

// Generate Sequence diagram using Mermaid - great for user flows
function generateSequenceDiagram(data: RefinedData, projectName: string): string {
  const stories = data['userStories']?.original || '';
  const flows = extractUserFlows(stories);

  let mermaid = `sequenceDiagram
    autonumber
    participant U as User
    participant UI as Web App
    participant API as API
    participant SVC as Service
    participant DB as Database
`;

  if (flows.length > 0) {
    flows.forEach((flow, index) => {
      // Sanitize the action text
      const safeAction = flow.action.replace(/[^a-zA-Z0-9\s]/g, '').trim().slice(0, 30);
      const shortAction = safeAction.slice(0, 20);

      if (index > 0) mermaid += `\n`;
      mermaid += `    Note over U,DB: ${safeAction}\n`;
      mermaid += `    U->>+UI: ${shortAction}\n`;
      mermaid += `    UI->>+API: Request\n`;
      mermaid += `    API->>+SVC: Process\n`;
      mermaid += `    SVC->>+DB: Query\n`;
      mermaid += `    DB-->>-SVC: Result\n`;
      mermaid += `    SVC-->>-API: Response\n`;
      mermaid += `    API-->>-UI: Data\n`;
      mermaid += `    UI-->>-U: Display\n`;
    });
  } else {
    // Generic flow based on common patterns
    mermaid += `    Note over U,DB: Main Application Flow\n`;
    mermaid += `    U->>+UI: Access Application\n`;
    mermaid += `    UI->>+API: Request Data\n`;
    mermaid += `    API->>+SVC: Process Request\n`;
    mermaid += `    SVC->>+DB: Query Data\n`;
    mermaid += `    DB-->>-SVC: Return Results\n`;
    mermaid += `    SVC-->>-API: Send Response\n`;
    mermaid += `    API-->>-UI: Return Data\n`;
    mermaid += `    UI-->>-U: Display Results\n`;
  }

  return mermaid;
}

// Generate Deployment diagram using Mermaid - great for infrastructure
function generateDeploymentDiagram(data: RefinedData, projectName: string): string {
  const envs = data['environments']?.original || '';

  const hasK8s = envs.toLowerCase().includes('kubernetes') || envs.toLowerCase().includes('k8s');
  const hasDocker = envs.toLowerCase().includes('docker') || envs.toLowerCase().includes('container');

  let mermaid = `flowchart LR
    subgraph CICD["CI/CD Pipeline"]
        BUILD[Build] --> TEST[Test]
        TEST --> DEPLOY[Deploy]
    end

    subgraph Environments["Environments"]
        DEV[Dev]
        STAGE[Staging]
        PROD[Production]
    end

`;

  if (hasK8s) {
    mermaid += `    subgraph Infra["Infrastructure"]
        K8S[Kubernetes]
        DB[(Database)]
    end

`;
  } else if (hasDocker) {
    mermaid += `    subgraph Infra["Infrastructure"]
        DOCKER[Docker]
        DB[(Database)]
    end

`;
  } else {
    mermaid += `    subgraph Infra["Infrastructure"]
        SERVER[Server]
        DB[(Database)]
    end

`;
  }

  // Connections
  mermaid += `    DEPLOY --> DEV\n`;
  mermaid += `    DEPLOY --> STAGE\n`;
  mermaid += `    DEPLOY --> PROD\n`;

  if (hasK8s) {
    mermaid += `    PROD --> K8S\n`;
    mermaid += `    K8S --> DB\n`;
  } else if (hasDocker) {
    mermaid += `    PROD --> DOCKER\n`;
    mermaid += `    DOCKER --> DB\n`;
  } else {
    mermaid += `    PROD --> SERVER\n`;
    mermaid += `    SERVER --> DB\n`;
  }

  // Colorful styles for deployment diagrams
  mermaid += `\n    %% Colorful Styling\n`;
  mermaid += `    style BUILD fill:#64748B,stroke:#475569,color:#fff\n`;
  mermaid += `    style TEST fill:#64748B,stroke:#475569,color:#fff\n`;
  mermaid += `    style DEPLOY fill:#64748B,stroke:#475569,color:#fff\n`;
  mermaid += `    style DEV fill:#56B4E9,stroke:#0072B2,color:#fff\n`;
  mermaid += `    style STAGE fill:#E69F00,stroke:#CC8800,color:#fff\n`;
  mermaid += `    style PROD fill:#D55E00,stroke:#B34D00,color:#fff\n`;
  if (hasK8s) {
    mermaid += `    style K8S fill:#326CE5,stroke:#1A4DB3,color:#fff\n`;
  } else if (hasDocker) {
    mermaid += `    style DOCKER fill:#2496ED,stroke:#1A75C7,color:#fff\n`;
  } else {
    mermaid += `    style SERVER fill:#64748B,stroke:#475569,color:#fff\n`;
  }
  mermaid += `    style DB fill:#E69F00,stroke:#CC8800,color:#fff\n`;

  return mermaid;
}

// Generate Component diagram using Mermaid - for internal structure
function generateComponentDiagram(data: RefinedData, projectName: string): string {
  const arch = data['architectureOverview']?.original || '';
  const features = data['features']?.original || '';
  const components = extractComponents(arch);
  const featureList = features.split('\n').filter(l => l.trim().length > 3).slice(0, 4);

  let mermaid = `flowchart LR
    subgraph Presentation["Presentation Layer"]
        UI[User Interface]
    end

    subgraph API["API Layer"]
        GW[API Gateway]
    end

    subgraph Services["Service Layer"]
`;

  // Add components from architecture or features
  const compIds: string[] = [];
  if (components.length > 0) {
    components.slice(0, 3).forEach((comp, i) => {
      const safeComp = comp.replace(/[^a-zA-Z0-9\s]/g, '').trim().slice(0, 15) || `Service${i}`;
      compIds.push(`COMP${i}`);
      mermaid += `        COMP${i}[${safeComp}]\n`;
    });
  } else if (featureList.length > 0) {
    featureList.slice(0, 3).forEach((feat, i) => {
      const cleanFeat = feat.replace(/^[\d.\-*]+\s*/, '').replace(/[^a-zA-Z0-9\s]/g, '').trim().slice(0, 15) || `Feature${i}`;
      compIds.push(`COMP${i}`);
      mermaid += `        COMP${i}[${cleanFeat}]\n`;
    });
  } else {
    compIds.push('COMP0');
    mermaid += `        COMP0[Service]\n`;
  }

  mermaid += `    end

    subgraph Data["Data Layer"]
        DB[(Database)]
    end

`;

  // Connections
  mermaid += `    UI --> GW\n`;

  if (compIds.length > 0) {
    mermaid += `    GW --> ${compIds[0]}\n`;
    // Chain components
    for (let i = 0; i < compIds.length - 1; i++) {
      mermaid += `    ${compIds[i]} --> ${compIds[i + 1]}\n`;
    }
    mermaid += `    ${compIds[compIds.length - 1]} --> DB\n`;
  } else {
    mermaid += `    GW --> DB\n`;
  }

  // Add color styles for eye-catching visuals
  mermaid += `\n    %% Styling\n`;
  mermaid += `    style UI fill:#0EA5E9,stroke:#0284C7,color:#fff\n`;
  mermaid += `    style GW fill:#4F46E5,stroke:#3730A3,color:#fff\n`;
  // Style component nodes
  compIds.forEach(id => {
    mermaid += `    style ${id} fill:#10B981,stroke:#059669,color:#fff\n`;
  });
  mermaid += `    style DB fill:#F59E0B,stroke:#D97706,color:#fff\n`;

  return mermaid;
}

// Main intelligent blueprint generator
export async function generateIntelligentBlueprint(data: RefinedData, projectName: string): Promise<{ diagram: string; type: DiagramType; reasoning: string }> {
  // Add small delay so UI shows loading state
  await mockDelay();

  // AI-only generation with retry loop for fixing errors
  // NO rule-based fallback - AI fixes its own errors
  if (!currentConfig) {
    throw new Error('AI configuration not available. Please configure Azure OpenAI settings.');
  }

  let lastError = '';
  let diagram = '';
  let reasoning = 'AI-generated architecture diagram';
  let diagramType: DiagramType = 'c4-container';

  // Try AI generation with retry loop (up to 5 attempts)
  for (let attempt = 1; attempt <= 5; attempt++) {
    try {
      if (attempt === 1 || !diagram) {
        // First attempt or no diagram yet: fresh AI generation
        console.log(`[Blueprint] Attempt ${attempt}: Generating with AI...`);
        const result = await generateAIPoweredBlueprint(data, projectName);
        diagram = result.diagram;
        reasoning = result.reasoning;
        diagramType = result.type;
      } else {
        // Subsequent attempts: AI fixes previous error
        console.log(`[Blueprint] Attempt ${attempt}: Using AI to fix error: ${lastError}`);
        diagram = await fixMermaidDiagram(diagram, lastError);
      }

      // Validate the diagram - throws if invalid
      const validated = validateMermaidDiagram(diagram);

      // Success - apply theme and return
      console.log(`[Blueprint] Success on attempt ${attempt}`);
      return {
        diagram: applyDiagramTheme(validated),
        type: diagramType,
        reasoning
      };

    } catch (error) {
      lastError = error instanceof Error ? error.message : String(error);
      console.error(`[Blueprint] Attempt ${attempt} failed:`, lastError);
    }
  }

  // All AI attempts failed - throw error to user (NO silent rule-based fallback)
  throw new Error(`Blueprint generation failed after 5 AI attempts. Last error: ${lastError}`);
}


// AI-powered blueprint generation using Mermaid
async function generateAIPoweredBlueprint(
  data: RefinedData,
  projectName: string
): Promise<{ diagram: string; type: DiagramType; reasoning: string }> {
  const systemPrompt = `You are an expert software architect and data visualization specialist who creates stunning, comprehensive Mermaid.js diagrams.

## YOUR TASK
Analyze the provided epic/project information and generate a beautiful, intelligent, and architecturally accurate Mermaid diagram that fully represents the system. Select the MOST APPROPRIATE diagram type based on content analysis.

---

## PHASE 1: INTELLIGENT DIAGRAM TYPE SELECTION

### Step 1.1 — Content-Driven Diagram Selection

CRITICAL: Analyze the epic content and select the diagram type that best represents the information structure. Do NOT default to flowchart — choose based on what the content actually describes.

| Content Pattern | Keywords/Signals | Diagram Type | Mermaid Syntax |
|-----------------|------------------|--------------|----------------|
| System architecture, microservices, APIs, components | service, API, gateway, backend, frontend, microservice | Architecture | flowchart LR |
| Time-ordered interactions, API calls, request/response | request, response, call, authenticate, flow between actors | Sequence | sequenceDiagram |
| Object structure, classes, inheritance, methods | class, interface, inherit, extend, method, property | Class Diagram | classDiagram |
| Lifecycle, status changes, transitions, states | state, status, transition, pending, approved, workflow | State Diagram | stateDiagram-v2 |
| Project timeline, tasks, milestones, dependencies | task, milestone, deadline, sprint, phase, schedule | Gantt Chart | gantt |
| Git workflow, branches, merges, releases | branch, merge, commit, release, version, git | Git Graph | gitGraph |
| Hierarchical concepts, brainstorming, categories | concept, idea, category, topic, overview, breakdown | Mind Map | mindmap |
| Chronological events, history, milestones | timeline, history, event, year, milestone, era | Timeline | timeline |
| Priority matrix, comparison on two axes | priority, impact, effort, urgency, quadrant, matrix | Quadrant Chart | quadrantChart |
| Flow quantities, conversions, budget allocation | flow, conversion, funnel, allocation, transfer, from/to | Sankey Diagram | sankey-beta |
| Multi-dimensional comparison, skills, ratings | compare, rating, score, skill, dimension, radar | Radar Chart | radar-beta |
| Proportional distribution, percentages, shares | percentage, distribution, share, breakdown, pie | Pie Chart | pie |
| Data trends, metrics over time, statistics | trend, metric, chart, data, x-axis, y-axis | XY Chart | xychart-beta |
| Infrastructure, cloud, deployment, containers | deploy, kubernetes, docker, cloud, server, container | Block Diagram | block-beta |
| Task board, kanban, work items, columns | kanban, board, todo, doing, done, backlog | Kanban | kanban |
| Network packets, protocol, bit fields | packet, protocol, bit, field, header, byte | Packet Diagram | packet-beta |

### Step 1.2 — Decision Heuristics

Apply these rules in order:
1. If content describes TIME-ORDERED interactions between actors → sequenceDiagram
2. If content describes OBJECT/CLASS structure with methods → classDiagram
3. If content describes STATE TRANSITIONS or lifecycle → stateDiagram-v2
4. If content describes PROJECT SCHEDULE with dates → gantt
5. If content describes GIT WORKFLOW → gitGraph
6. If content describes HIERARCHICAL CONCEPTS → mindmap
7. If content describes FLOW QUANTITIES between sources → sankey-beta
8. If content describes PRIORITY/COMPARISON on two axes → quadrantChart
9. If content describes SYSTEM COMPONENTS and their connections → flowchart LR (architecture)
10. When genuinely uncertain → flowchart LR (most versatile)

### Step 1.3 — Assess Complexity Budget

| Epic Scope | Feature Count | Target Nodes | Max Connections |
|------------|---------------|--------------|-----------------|
| Simple | 1–3 features | 8–12 nodes | 15 connections |
| Medium | 4–7 features | 12–18 nodes | 25 connections |
| Complex | 8+ features | 18–25 nodes | 35 connections |

**HARD LIMIT:** Never exceed 25 nodes. For larger systems, focus on the most critical components.

---

## PHASE 2: SEMANTIC COLOR SYSTEM

### Universal Color Palette (Okabe-Ito + Industry Standards)

This palette is colorblind-safe and uses industry-standard semantic associations:

| Semantic Role | Color | Hex Code | Usage |
|---------------|-------|----------|-------|
| Primary/Compute | Blue | #0072B2 | Core services, main components, compute |
| Data/Storage | Orange | #E69F00 | Databases, caches, file storage |
| Security/Auth | Vermillion | #D55E00 | Authentication, authorization, security |
| Async/Events | Teal | #009E73 | Message queues, events, async flows |
| External/3rd Party | Purple | #CC79A7 | External APIs, third-party services |
| Infrastructure | Slate | #64748B | Load balancers, gateways, infra |
| Success/Healthy | Green | #22C55E | Success states, healthy indicators |
| Warning/Pending | Amber | #F59E0B | Warnings, pending states |
| Error/Critical | Red | #EF4444 | Errors, critical alerts |
| Client/UI | Sky Blue | #56B4E9 | User interfaces, client apps |

### Domain-Specific Palette Overrides

| Domain Keywords | Primary | Secondary | Accent | Data | External |
|-----------------|---------|-----------|--------|------|----------|
| bank, finance, payment, transaction | #0369A1 | #0EA5E9 | #059669 | #E69F00 | #CC79A7 |
| health, medical, patient, clinical | #0891B2 | #14B8A6 | #6366F1 | #E69F00 | #CC79A7 |
| shop, cart, order, ecommerce, retail | #7C3AED | #8B5CF6 | #F97316 | #E69F00 | #CC79A7 |
| deploy, kubernetes, docker, cloud, devops | #0072B2 | #56B4E9 | #009E73 | #E69F00 | #CC79A7 |
| learn, course, student, education | #059669 | #10B981 | #0072B2 | #E69F00 | #CC79A7 |
| video, music, game, media, stream | #EC4899 | #F472B6 | #A855F7 | #E69F00 | #CC79A7 |
| AI, machine learning, model, neural | #6366F1 | #8B5CF6 | #EC4899 | #E69F00 | #CC79A7 |
| security, auth, encrypt, identity | #475569 | #64748B | #D55E00 | #E69F00 | #CC79A7 |
| DEFAULT | #0072B2 | #56B4E9 | #009E73 | #E69F00 | #CC79A7 |

### Accessibility Requirements (WCAG 2.1)

| Requirement | Standard | Implementation |
|-------------|----------|----------------|
| Text contrast | 4.5:1 minimum | Use white (#fff) text on dark fills |
| Graphical contrast | 3:1 minimum | Ensure stroke is darker than fill |
| Colorblind safety | 8% of men affected | Use Okabe-Ito palette (already implemented) |
| Shape redundancy | Don't rely on color alone | Different shapes for different component types |

**CRITICAL**: Never differentiate components by color alone. Always use shape + color combination.

### Alternative Industry Palettes (Optional)

**IBM Carbon Design System:**
| Token | Hex | Usage |
|-------|-----|-------|
| Blue 60 | #0F62FE | Interactive elements |
| Cyan 50 | #1192E8 | Links, highlights |
| Teal 50 | #009D9A | Success states |
| Magenta 50 | #EE5396 | Attention |
| Purple 60 | #8A3FFC | Creative elements |

**Material Design 3:**
| Color | Hex | Usage |
|-------|-----|-------|
| Primary | #6750A4 | Key components |
| Secondary | #625B71 | Less prominent |
| Tertiary | #7D5260 | Contrast accents |
| Error | #B3261E | Error states |

The UBS color mapping ensures:
- Consistent brand identity across all diagrams
- Professional, enterprise-appropriate appearance
- Clear visual hierarchy using gray scale + red accent

---

## PHASE 3: CRITICAL MERMAID SYNTAX RULES

VIOLATIONS WILL CAUSE PARSE ERRORS — FOLLOW EXACTLY:

### Rule 1: Node ID Format (MOST IMPORTANT)
Every node MUST have format: ID[Label] or ID[(Label)] etc. Never use bare text after arrows.

WRONG: API Gateway --> User Service --> Database
CORRECT: AG[API Gateway] --> US[User Service]
         US --> DB[(Database)]

### Rule 2: Node IDs — Alphanumeric Only
Use short 2-5 character alphanumeric IDs. No hyphens, underscores, spaces, or special characters in IDs.

WRONG: user-service[User Service]
CORRECT: US[User Service]

### Rule 3: Labels — No Special Characters
Avoid quotes, apostrophes, parentheses, and special characters inside labels.

WRONG: A[User's Data]
WRONG: B[Auth (OAuth2)]
CORRECT: A[User Data]
CORRECT: B[Auth via OAuth2]

### Rule 4: Subgraph Naming
Subgraph names with spaces MUST use quotes.

WRONG: subgraph Data Layer
CORRECT: subgraph DL["Data Layer"]

### Rule 5: One Connection Per Line
Never chain multiple arrows.

WRONG: A --> B --> C --> D
CORRECT:
    A --> B
    B --> C
    C --> D

### Rule 6: Reserved Word "end"
Never use lowercase "end" as a node label — it breaks parsing. Use "End" or "Finish" instead.

### Rule 7: Strict Command Order
1. %%{init:...}%% theme block (FIRST, for flowcharts only)
2. Diagram type declaration
3. Subgraphs and connections
4. linkStyle commands (all together)
5. style commands (LAST)

---

## PHASE 4: NODE SHAPES BY SEMANTIC ROLE

| Component Type | Shape | Syntax | Example |
|----------------|-------|--------|---------|
| Services/APIs | Rectangle | ID[Label] | US[User Service] |
| Processes/Actions | Rounded | ID(Label) | VAL(Validation) |
| Start/End Points | Stadium | ID([Label]) | START([Begin]) |
| Events/Triggers | Circle | ID((Label)) | EVT((Event)) |
| Databases/Storage | Cylinder | ID[(Label)] | DB[(PostgreSQL)] |
| External APIs | Hexagon | ID{{Label}} | STRIPE{{Stripe}} |
| Decisions | Diamond | ID{Label} | CHK{Valid} |
| Input/Output | Parallelogram | ID[/Label/] | IN[/Request/] |
| Subroutines | Framed | ID[[Label]] | SUB[[Process]] |

---

## PHASE 5: ARROW SEMANTICS BY FLOW TYPE

### Line Style as Primary Semantic (Most Important)
- **Solid line (-->)**: Synchronous, blocking calls
- **Dashed line (-.->)**: Asynchronous, non-blocking, events
- **Thick line (==>)**: Critical path, emphasis

### Arrow Colors by Flow Type

| Flow Type | Color | Hex | LinkStyle |
|-----------|-------|-----|-----------|
| User/Client Request | Blue | #0072B2 | stroke:#0072B2,stroke-width:2.5px |
| Service-to-Service | Indigo | #6366F1 | stroke:#6366F1,stroke-width:2px |
| Database Read/Write | Orange | #E69F00 | stroke:#E69F00,stroke-width:2px |
| Async/Event/Queue | Teal | #009E73 | stroke:#009E73,stroke-width:2px,stroke-dasharray:5 |
| External API Call | Purple | #CC79A7 | stroke:#CC79A7,stroke-width:2px |
| Auth/Security Flow | Vermillion | #D55E00 | stroke:#D55E00,stroke-width:2px |
| Response/Return | Gray | #94A3B8 | stroke:#94A3B8,stroke-width:1.5px,stroke-dasharray:3 |
| File/Blob Storage | Amber | #F59E0B | stroke:#F59E0B,stroke-width:2px |
| Monitoring/Logs | Slate | #64748B | stroke:#64748B,stroke-width:1px,stroke-dasharray:3 |

### Link Index Counting
Link styles are applied by 0-based INDEX in order of arrow appearance:

    WEB --> LB      %% Link index 0
    LB --> AUTH     %% Link index 1
    AUTH --> API    %% Link index 2

    linkStyle 0 stroke:#0072B2,stroke-width:2.5px
    linkStyle 1 stroke:#64748B,stroke-width:2px
    linkStyle 2 stroke:#D55E00,stroke-width:2px

### Arrow Labels for Data Flow Description

Use |text| syntax to add descriptive labels to arrows:

\`\`\`
    WEB -->|HTTP Request| LB
    LB -->|Forward| AG
    AG -->|JWT Token| AUTH
    AUTH -.->|Validate| USER
    USER -->|Query| DB
    DB -->|User Record| USER
\`\`\`

**Label Conventions:**
- Protocol: HTTP, gRPC, WebSocket, AMQP, REST
- Action: Query, Insert, Update, Delete, Publish, Subscribe
- Data: Token, Payload, Event, Message, Response, Request

---

## PHASE 6: DIAGRAM-SPECIFIC SYNTAX

### Flowchart (Architecture)
\`\`\`
%%{init: {'theme': 'base', 'themeVariables': {...}}}%%
flowchart LR
    subgraph CL["Clients"]
        WEB[Web App]
    end
    WEB --> API[API Service]
    API --> DB[(Database)]

    linkStyle 0 stroke:#0072B2,stroke-width:2px
    style WEB fill:#56B4E9,stroke:#0072B2,color:#fff
\`\`\`

### Sequence Diagram
\`\`\`
sequenceDiagram
    autonumber
    participant U as User
    participant API as API Gateway
    participant DB as Database
    
    U->>API: POST /login
    activate API
    API->>DB: Query user
    DB-->>API: User data
    API-->>U: JWT token
    deactivate API
\`\`\`

### State Diagram
\`\`\`
stateDiagram-v2
    [*] --> Draft
    Draft --> Pending: Submit
    Pending --> Approved: Approve
    Pending --> Rejected: Reject
    Approved --> [*]
    Rejected --> Draft: Revise
\`\`\`

### Class Diagram
\`\`\`
classDiagram
    class User {
        +int id
        +String email
        +login()
        +logout()
    }
    class Order {
        +int id
        +Date createdAt
        +calculate()
    }
    User "1" --> "*" Order : places
\`\`\`

### Gantt Chart
\`\`\`
gantt
    title Project Timeline
    dateFormat YYYY-MM-DD
    section Phase 1
        Design    :a1, 2024-01-01, 30d
        Review    :a2, after a1, 7d
    section Phase 2
        Development :b1, after a2, 60d
        Testing     :b2, after b1, 14d
\`\`\`

### Git Graph
\`\`\`
gitGraph
    commit id: "Initial"
    branch develop
    checkout develop
    commit id: "Feature A"
    checkout main
    merge develop
    commit id: "Release v1.0" tag: "v1.0"
\`\`\`

### Mind Map
\`\`\`
mindmap
    root((Project))
        Backend
            API Gateway
            Services
            Database
        Frontend
            Web App
            Mobile App
        Infrastructure
            AWS
            Kubernetes
\`\`\`

### Quadrant Chart
\`\`\`
quadrantChart
    title Priority Matrix
    x-axis Low Effort --> High Effort
    y-axis Low Impact --> High Impact
    quadrant-1 Do First
    quadrant-2 Schedule
    quadrant-3 Delegate
    quadrant-4 Eliminate
    Feature A: [0.8, 0.9]
    Feature B: [0.3, 0.7]
    Feature C: [0.6, 0.2]
\`\`\`

### Sankey Diagram
\`\`\`
sankey-beta
    Users,API Gateway,1000
    API Gateway,Auth Service,1000
    Auth Service,Success,850
    Auth Service,Failed,150
\`\`\`

### Timeline
\`\`\`
timeline
    title Product Evolution
    2022 : MVP Launch
         : First 100 users
    2023 : Series A
         : 10K users
    2024 : Enterprise Launch
         : 100K users
\`\`\`

### Pie Chart
\`\`\`
pie showData
    title Traffic Sources
    "Organic" : 45
    "Paid" : 30
    "Referral" : 15
    "Direct" : 10
\`\`\`

### XY Chart
\`\`\`
xychart-beta
    title "Monthly Revenue"
    x-axis [Jan, Feb, Mar, Apr, May]
    y-axis "Revenue (K)" 0 --> 100
    bar [30, 45, 60, 75, 90]
    line [30, 45, 60, 75, 90]
\`\`\`

### Block Diagram
\`\`\`
block-beta
    columns 3
    Frontend:1
    space:1
    Backend:1
    
    block:Frontend
        Web["Web App"]
        Mobile["Mobile"]
    end
    
    block:Backend
        API["API"]
        DB[("DB")]
    end
\`\`\`

### Kanban
\`\`\`
kanban
    Todo
        Task 1
        Task 2
    In Progress
        Task 3
    Done
        Task 4
\`\`\`

### Requirement Diagram
\`\`\`
requirementDiagram
    requirement req1 {
        id: REQ-001
        text: User Authentication
        risk: high
        verifymethod: test
    }

    requirement req2 {
        id: REQ-002
        text: Data Encryption
        risk: medium
        verifymethod: inspection
    }

    element auth_service {
        type: service
    }

    auth_service - satisfies -> req1
    auth_service - satisfies -> req2
\`\`\`

---

## PHASE 7: THEME CONFIGURATION (Flowcharts Only)

Place at VERY START of flowchart diagrams:

\`\`\`
%%{init: {
  'theme': 'base',
  'themeVariables': {
    'primaryColor': '#0072B2',
    'primaryTextColor': '#FFFFFF',
    'primaryBorderColor': '#005A8C',
    'secondaryColor': '#56B4E9',
    'secondaryTextColor': '#FFFFFF',
    'tertiaryColor': '#E69F00',
    'lineColor': '#64748B',
    'textColor': '#1F2937',
    'clusterBkg': '#F0F9FF',
    'clusterBorder': '#BAE6FD'
  }
}}%%
\`\`\`

---

## PHASE 8: NODE STYLING BY COMPONENT TYPE

Apply AFTER all connections and linkStyle commands:

| Component Type | Style |
|----------------|-------|
| Client/UI | fill:#56B4E9,stroke:#0072B2,color:#fff |
| Gateway/Infra | fill:#64748B,stroke:#475569,color:#fff |
| Core Services | fill:#0072B2,stroke:#005A8C,color:#fff |
| Databases | fill:#E69F00,stroke:#CC8800,color:#fff |
| Caches | fill:#E69F00,stroke:#CC8800,color:#fff |
| Message Queues | fill:#009E73,stroke:#007A5E,color:#fff |
| External APIs | fill:#CC79A7,stroke:#AA5A87,color:#fff |
| Auth/Security | fill:#D55E00,stroke:#B34700,color:#fff |

---

## PHASE 8.5: REUSABLE STYLE DEFINITIONS (classDef)

Use classDef to define reusable style classes, then apply with ::: syntax:

\`\`\`
%%{init: {...}}%%
flowchart LR
    %% Define reusable style classes
    classDef client fill:#56B4E9,stroke:#0072B2,color:#fff,stroke-width:2px
    classDef service fill:#0072B2,stroke:#005A8C,color:#fff,stroke-width:2px
    classDef database fill:#E69F00,stroke:#CC8800,color:#fff,stroke-width:2px
    classDef external fill:#CC79A7,stroke:#AA5A87,color:#fff,stroke-width:2px
    classDef queue fill:#009E73,stroke:#007A5E,color:#fff,stroke-width:2px
    classDef auth fill:#D55E00,stroke:#B34700,color:#fff,stroke-width:2px

    %% Apply classes using ::: syntax
    WEB[Web App]:::client
    MOB[Mobile App]:::client
    API[API Service]:::service
    AUTH[Auth Service]:::auth
    DB[(Database)]:::database
    REDIS[(Redis)]:::database
    KAFKA([Kafka]):::queue
    STRIPE{{Stripe}}:::external
\`\`\`

**Benefits of classDef:**
- Cleaner diagram code (no repeated style commands)
- Consistent styling across nodes of same type
- Easier to maintain and modify
- Reduces diagram size and complexity

### Subgraph Styling

Style subgraphs for visual grouping by architectural layer:

\`\`\`
flowchart LR
    subgraph CL["Client Layer"]
        WEB[Web]
        MOB[Mobile]
    end

    subgraph SVC["Service Layer"]
        API[API]
    end

    %% Style entire subgraphs
    style CL fill:#DBEAFE,stroke:#93C5FD,stroke-width:2px
    style SVC fill:#F0F9FF,stroke:#BAE6FD,stroke-width:2px
\`\`\`

**Subgraph color by layer:**
| Layer | Background | Border |
|-------|------------|--------|
| Client | #DBEAFE (Light Blue) | #93C5FD |
| Gateway | #F1F5F9 (Slate-100) | #CBD5E1 |
| Services | #F0F9FF (Sky-50) | #BAE6FD |
| Data | #FEF3C7 (Amber-100) | #FCD34D |
| External | #FCE7F3 (Pink-100) | #F9A8D4 |

---

## PHASE 9: ARCHITECTURAL LAYERS (for Architecture Diagrams)

Organize left-to-right (LR) or top-to-bottom (TB):

### Layer 1: Client Layer
- Web apps, SPAs, mobile apps
- CLI tools, desktop apps

### Layer 2: Gateway Layer
- Load balancers, API gateways
- Auth, rate limiting

### Layer 3: Service Layer
- Microservices, business logic
- Background workers

### Layer 4: Data Layer
- Databases (PostgreSQL, MySQL, MongoDB)
- Caches (Redis, Memcached)
- Queues (Kafka, RabbitMQ)
- Search (Elasticsearch)
- Storage (S3)

### Layer 5: External Layer
- Payment (Stripe, PayPal)
- Email (SendGrid)
- Third-party APIs

---

## PHASE 10: COMPLETE ARCHITECTURE EXAMPLE (UBS Brand)

\`\`\`
%%{init: {
  'theme': 'base',
  'themeVariables': {
    'primaryColor': '#E60000',
    'primaryTextColor': '#FFFFFF',
    'primaryBorderColor': '#BD000C',
    'secondaryColor': '#5A5D5C',
    'lineColor': '#5A5D5C',
    'clusterBkg': '#ECEBE4',
    'clusterBorder': '#E5E5E5'
  }
}}%%
flowchart LR
    subgraph CL["Clients"]
        WEB[Web App]
        MOB[Mobile App]
    end
    
    subgraph GW["Gateway"]
        LB[Load Balancer]
        AG[API Gateway]
        AUTH[Auth Service]
    end
    
    subgraph SVC["Services"]
        USER[User Service]
        ORD[Order Service]
        PAY[Payment Service]
    end
    
    subgraph DATA["Data Layer"]
        PG[(PostgreSQL)]
        REDIS[(Redis)]
        KAFKA([Kafka])
    end
    
    subgraph EXT["External"]
        STRIPE{{Stripe}}
    end
    
    WEB --> LB
    MOB --> LB
    LB --> AG
    AG --> AUTH
    AUTH --> USER
    AG --> ORD
    ORD --> PAY
    PAY --> STRIPE
    ORD -.-> KAFKA
    USER --> PG
    ORD --> PG
    USER --> REDIS

    linkStyle 0,1 stroke:#BD000C,stroke-width:2.5px
    linkStyle 2 stroke:#5A5D5C,stroke-width:2px
    linkStyle 3 stroke:#BD000C,stroke-width:2px
    linkStyle 4 stroke:#BD000C,stroke-width:2px
    linkStyle 5,6 stroke:#8E8D83,stroke-width:2px
    linkStyle 7 stroke:#E60000,stroke-width:2px
    linkStyle 8 stroke:#5A5D5C,stroke-width:2px,stroke-dasharray:5
    linkStyle 9,10 stroke:#CCCABC,stroke-width:2px
    linkStyle 11 stroke:#CCCABC,stroke-width:2px

    style WEB fill:#E60000,stroke:#BD000C,color:#fff
    style MOB fill:#E60000,stroke:#BD000C,color:#fff
    style LB fill:#5A5D5C,stroke:#000000,color:#fff
    style AG fill:#5A5D5C,stroke:#000000,color:#fff
    style AUTH fill:#BD000C,stroke:#000000,color:#fff
    style USER fill:#8E8D83,stroke:#5A5D5C,color:#fff
    style ORD fill:#8E8D83,stroke:#5A5D5C,color:#fff
    style PAY fill:#8E8D83,stroke:#5A5D5C,color:#fff
    style PG fill:#CCCABC,stroke:#8E8D83,color:#000
    style REDIS fill:#CCCABC,stroke:#8E8D83,color:#000
    style KAFKA fill:#5A5D5C,stroke:#000000,color:#fff
    style STRIPE fill:#E60000,stroke:#BD000C,color:#fff
\`\`\`

---

## PHASE 11: ERROR RECOVERY

1. Remove theme block — test basic structure first
2. Simplify subgraph names — use single words
3. Check labels — remove ALL special characters
4. Recount linkStyle indices — verify 0-based counting
5. Check for "end" keyword — capitalize as "End"
6. Reduce complexity — remove nodes incrementally

---

## PHASE 12: PRE-OUTPUT VALIDATION CHECKLIST

### Syntax Checks
[ ] Diagram type matches content (not defaulting to flowchart)
[ ] Every node uses ID[Label] format
[ ] Node IDs are alphanumeric only
[ ] No special characters in labels
[ ] No lowercase "end" in labels
[ ] Subgraph names properly quoted
[ ] One connection per line
[ ] Theme block at start (flowcharts only)
[ ] linkStyle after connections
[ ] style commands last

### Semantic Checks
[ ] Arrow colors match flow types
[ ] Node colors match component types
[ ] Async flows use dashed lines
[ ] Databases use cylinder shape
[ ] External services use hexagon shape

---

## OUTPUT FORMAT

Return response in this EXACT format with no markdown code fences:

TYPE: [architecture|sequence|er|class|state|gantt|gitgraph|mindmap|timeline|quadrant|sankey|pie|xychart|block|kanban]
REASONING: [One sentence explaining why this diagram type was selected]
DIAGRAM:
[Complete Mermaid diagram code]`;

  const epicSummary = buildEpicSummary(data, projectName);

  const response = await callAI(currentConfig!, systemPrompt, epicSummary);

  // Parse AI response
  const typeMatch = response.match(/TYPE:\s*(\S+)/i);
  const reasoningMatch = response.match(/REASONING:\s*(.+?)(?=DIAGRAM:|$)/is);

  // CRITICAL FIX: Extract content AFTER "DIAGRAM:" marker first
  // This prevents matching "gantt" in "TYPE: gantt" instead of the actual diagram
  let diagramSection = response;
  const diagramMarkerMatch = response.match(/DIAGRAM:\s*([\s\S]*)/i);
  if (diagramMarkerMatch) {
    diagramSection = diagramMarkerMatch[1];
  }

  // Strip code fence wrappers from the diagram section
  diagramSection = diagramSection
    .replace(/^```(?:mermaid)?\s*\n?/i, '')  // Remove opening fence
    .replace(/\n?```\s*$/i, '')               // Remove closing fence
    .trim();

  // Match any Mermaid diagram type (now searches only diagram section)
  const diagramPatterns = [
    /%%\{init:[\s\S]*?\}%%\s*(flowchart|graph)\s+(?:LR|TB|TD|RL|BT)[\s\S]*/i,
    /(flowchart|graph)\s+(?:LR|TB|TD|RL|BT)[\s\S]*/i,
    /(sequenceDiagram[\s\S]*)/i,
    /(classDiagram[\s\S]*)/i,
    /(stateDiagram-v2[\s\S]*)/i,
    /(stateDiagram[\s\S]*)/i,
    /(gantt[\s\S]*)/i,
    /(gitGraph[\s\S]*)/i,
    /(mindmap[\s\S]*)/i,
    /(timeline[\s\S]*)/i,
    /(quadrantChart[\s\S]*)/i,
    /(sankey-beta[\s\S]*)/i,
    /(pie[\s\S]*)/i,
    /(xychart-beta[\s\S]*)/i,
    /(block-beta[\s\S]*)/i,
    /(kanban[\s\S]*)/i,
    /(requirementDiagram[\s\S]*)/i,
    /(radar-beta[\s\S]*)/i,
  ];

  let diagram = '';
  for (const pattern of diagramPatterns) {
    const match = diagramSection.match(pattern);  // Now searches only diagram section!
    if (match) {
      diagram = match[0].trim();
      break;
    }
  }

  const type = (typeMatch?.[1]?.toLowerCase().replace('-', '_') as DiagramType) || 'architecture';
  const reasoning = reasoningMatch?.[1]?.trim() || 'AI-generated based on epic content.';

  // Validate the diagram
  if (!diagram) {
    throw new Error('AI did not return a diagram. Response may have been empty or malformed.');
  }

  // Validate - throws if invalid, caller will use AI to fix
  diagram = validateMermaidDiagram(diagram);

  return { diagram, type, reasoning };
}

// Validate Mermaid diagram and fix common issues
// Throws error if invalid - caller should use AI to fix errors
function validateMermaidDiagram(mermaid: string): string {
  // Remove any code fence markers
  mermaid = mermaid.replace(/```mermaid\s*/gi, '').replace(/```\s*/g, '').trim();

  // Valid Mermaid diagram starters
  const validStarts = [
    'flowchart',
    'graph',
    'sequenceDiagram',
    'classDiagram',
    'stateDiagram',
    'gantt',
    'gitGraph',
    'mindmap',
    'timeline',
    'quadrantChart',
    'sankey-beta',
    'pie',
    'xychart-beta',
    'block-beta',
    'kanban',
    'requirementDiagram',  // NEW: Requirements traceability
    'radar-beta',          // NEW: Multi-dimensional comparison
    '%%{init'  // Theme block before flowchart
  ];

  const hasValidStart = validStarts.some(start =>
    mermaid.toLowerCase().startsWith(start.toLowerCase())
  );

  if (!hasValidStart) {
    // Throw error instead of silent fallback - AI will fix this
    throw new Error(`Invalid Mermaid syntax: diagram must start with a valid type (flowchart, gantt, sequenceDiagram, etc). Found: "${mermaid.substring(0, 60)}..."`);
  }

  // Fix common issues
  
  // Fix lowercase "end" that breaks parsing (but not "End" or "END")
  mermaid = mermaid.replace(/\[end\]/g, '[Finish]');
  mermaid = mermaid.replace(/\(end\)/g, '(Finish)');
  
  // Remove any trailing content after diagram
  const endMarkers = ['TYPE:', 'REASONING:', '---'];
  for (const marker of endMarkers) {
    const idx = mermaid.indexOf(marker);
    if (idx > 0) {
      mermaid = mermaid.substring(0, idx).trim();
    }
  }

  return mermaid;
}

// Build a summary of the epic for AI consumption
function buildEpicSummary(data: RefinedData, projectName: string): string {
  let summary = `Project: ${projectName}\n\n`;

  if (data['objective']?.original) {
    summary += `OBJECTIVE:\n${data['objective'].original}\n\n`;
  }
  if (data['architectureOverview']?.original) {
    summary += `ARCHITECTURE:\n${data['architectureOverview'].original}\n\n`;
  }
  if (data['features']?.original) {
    summary += `FEATURES:\n${data['features'].original}\n\n`;
  }
  if (data['userStories']?.original) {
    summary += `USER STORIES:\n${data['userStories'].original}\n\n`;
  }
  if (data['dataStores']?.original) {
    summary += `DATA STORES:\n${data['dataStores'].original}\n\n`;
  }
  if (data['teams']?.original) {
    summary += `TEAMS:\n${data['teams'].original}\n\n`;
  }
  if (data['environments']?.original) {
    summary += `ENVIRONMENTS:\n${data['environments'].original}\n\n`;
  }

  return summary;
}

// Generate Mermaid Blueprint - Multilayer Epic Overview Diagram (renamed from PlantUML)
export function generatePlantUMLBlueprint(data: RefinedData, projectName: string): string {
  // Extract key data for the diagram
  const features = data['features']?.original?.split('\n').filter(Boolean).slice(0, 4) || ['Feature 1', 'Feature 2'];
  const teams = data['teams']?.original?.split('\n').filter(Boolean).slice(0, 3) || ['Team'];
  const hasDataStores = data['dataStores']?.original ? true : false;
  const deliverables = data['deliverables']?.original?.split('\n').filter(Boolean).slice(0, 3) || ['Deliverable'];

  // Sanitize function
  const sanitize = (s: string) => s.replace(/[^a-zA-Z0-9\s]/g, '').trim().slice(0, 20);

  let mermaid = `flowchart TB
    subgraph Stakeholders["1. Stakeholders"]
        PO((Product Owner))
        TL((Tech Lead))
        BIZ((Business))
    end

    subgraph Requirements["2. Requirements"]
`;

  // Add features
  features.forEach((f, i) => {
    mermaid += `        F${i}[${sanitize(f)}]\n`;
  });

  mermaid += `    end

    subgraph Architecture["3. Architecture"]
        UI[Frontend]
        API[API Gateway]
        SVC[Services]
`;

  if (hasDataStores) {
    mermaid += `        DB[(Database)]
        CACHE[(Cache)]
    end
`;
  } else {
    mermaid += `        DB[(Database)]
    end
`;
  }

  mermaid += `
    subgraph Team["4. Team & Execution"]
`;

  teams.forEach((t, i) => {
    mermaid += `        TM${i}[${sanitize(t)}]\n`;
  });

  mermaid += `        subgraph Pipeline["CI/CD"]
            BUILD[Build] --> TEST[Test] --> DEPLOY[Deploy]
        end
    end

    subgraph Environments["5. Environments"]
        DEV[Development]
        STG[Staging]
        PROD[Production]
    end

    subgraph Deliverables["6. Deliverables"]
`;

  deliverables.forEach((d, i) => {
    mermaid += `        D${i}[${sanitize(d)}]\n`;
  });

  mermaid += `    end

    %% Connections
    PO --> Requirements
    TL --> Requirements
    BIZ --> Requirements

    Requirements --> Architecture
    UI --> API
    API --> SVC
    SVC --> DB
`;

  if (hasDataStores) {
    mermaid += `    SVC --> CACHE
`;
  }

  mermaid += `
    Architecture --> Team
    Team --> Pipeline
    DEPLOY --> DEV
    DEV --> STG
    STG --> PROD

    PROD --> Deliverables
`;

  return mermaid;
}

// ===========================================
// EPIC FEEDBACK CHAT FUNCTIONS
// ===========================================

// Analyze user feedback to determine which section they want to modify
export async function analyzeUserFeedback(
  feedback: string,
  epicSections: string[]
): Promise<{ needsClarification: boolean; suggestedSection?: number; followUpQuestion?: string }> {
  if (!currentConfig) {
    throw new Error('Azure OpenAI is not configured. Please check Settings.');
  }

  const systemPrompt = `You are an assistant helping users modify their epic document.
Analyze the user's feedback to determine which section they want to modify.

Available sections:
${epicSections.map((s, i) => `${i + 1}. ${s}`).join('\n')}

Based on the user's feedback:
1. Can you confidently identify which section(s) the user is referring to?
2. Do you need more information to make the change?

Return a JSON object (no markdown, just raw JSON):
{
  "needsClarification": boolean,
  "suggestedSection": number or null (1-17),
  "followUpQuestion": "question to ask user" or null
}

If the feedback clearly mentions a specific section (by name or number), set needsClarification to false and suggestedSection to that section number.
If the feedback is vague or could apply to multiple sections, set needsClarification to true and ask a clarifying question.`;

  const userPrompt = `User feedback: "${feedback}"

Return JSON only:`;

  const response = await callAI(currentConfig, systemPrompt, userPrompt);

  // Clean up response and parse JSON
  let cleanResponse = response.trim();
  // Remove markdown code fences if present
  cleanResponse = cleanResponse.replace(/```json\s*/gi, '').replace(/```\s*/g, '').trim();

  try {
    return JSON.parse(cleanResponse);
  } catch {
    // If parsing fails, ask for clarification
    return {
      needsClarification: true,
      suggestedSection: undefined,
      followUpQuestion: 'Which section would you like me to update?'
    };
  }
}

// Process user feedback and generate updated section content
export async function processFeedback(
  feedback: string,
  currentEpic: string,
  targetSection: number,
  additionalContext?: string
): Promise<{ updatedSection: string; explanation: string }> {
  if (!currentConfig) {
    throw new Error('Azure OpenAI is not configured. Please check Settings.');
  }

  const sectionTitle = EPIC_SECTIONS[targetSection - 1]?.title || `Section ${targetSection}`;

  const systemPrompt = `You are an expert technical writer helping to modify an epic document.
The user wants to modify section "${sectionTitle}" of their epic document.

RULES:
1. Only modify the specified section - do not touch other sections
2. Return the updated section content in markdown format
3. Preserve the section header format: "## ${targetSection}. ${sectionTitle}"
4. Keep the same style and tone as the rest of the document
5. Be concise but thorough
6. If the section has subsections, preserve them
7. Do not add unnecessary fluff - make meaningful improvements based on the feedback

Return a JSON object (no markdown, just raw JSON):
{
  "updatedSection": "## ${targetSection}. ${sectionTitle}\\n\\n[updated content here]",
  "explanation": "Brief 1-2 sentence explanation of changes made"
}`;

  const userPrompt = `CURRENT EPIC DOCUMENT:
${currentEpic}

USER FEEDBACK: ${feedback}
${additionalContext ? `\nADDITIONAL CONTEXT: ${additionalContext}` : ''}

TARGET SECTION: ${targetSection}. ${sectionTitle}

Return JSON only:`;

  const response = await callAI(currentConfig, systemPrompt, userPrompt);

  // Clean up response and parse JSON
  let cleanResponse = response.trim();
  cleanResponse = cleanResponse.replace(/```json\s*/gi, '').replace(/```\s*/g, '').trim();

  try {
    return JSON.parse(cleanResponse);
  } catch {
    // If parsing fails, return a generic error response
    throw new Error('Failed to parse AI response. Please try again.');
  }
}

// Fix Mermaid diagram syntax errors using AI
export async function fixMermaidDiagram(
  failedCode: string,
  errorMessage: string
): Promise<string> {
  if (!currentConfig) {
    throw new Error('Config not set. Cannot fix diagram without AI.');
  }

  const systemPrompt = `You are a Mermaid.js syntax expert.
A diagram failed to render with the following error. Fix the syntax while keeping the EXACT same structure, nodes, and connections.

RULES:
1. Return ONLY the fixed Mermaid code - no explanations, no markdown
2. Keep the same diagram type (flowchart/sequence/etc)
3. DO NOT simplify or remove any nodes/connections - only fix syntax errors
4. Ensure all node IDs are valid (alphanumeric, underscores allowed, no spaces or special chars)
5. Ensure all labels are properly quoted with double quotes if they contain special characters
6. Fix any invalid arrow syntax or subgraph definitions
7. Ensure subgraphs have proper opening and closing
8. Do NOT include markdown code fences like \`\`\`mermaid or \`\`\``;

  const userPrompt = `ERROR MESSAGE:
${errorMessage}

FAILED MERMAID CODE:
${failedCode}

Return ONLY the fixed Mermaid code:`;

  const response = await callAI(currentConfig, systemPrompt, userPrompt);

  // Clean up response - remove any code fences
  let fixed = response
    .replace(/```mermaid\s*/gi, '')
    .replace(/```\s*/g, '')
    .trim();

  return fixed;
}

// ======================================================
// AI REFINEMENT - Epic Quality Analysis & Scoring
// ======================================================

/**
 * Parse epic markdown to extract section contents
 */
function parseEpicSections(epicContent: string): Map<number, string> {
  const sections = new Map<number, string>();

  // Match section headers like "## 1. Objective" or "## 15. Next Steps"
  const sectionRegex = /##\s*(\d+)\.\s*([^\n]+)\n([\s\S]*?)(?=##\s*\d+\.|$)/g;

  let match;
  while ((match = sectionRegex.exec(epicContent)) !== null) {
    const sectionNum = parseInt(match[1], 10);
    const content = match[3].trim();
    sections.set(sectionNum, content);
  }

  return sections;
}

/**
 * Parse epic markdown back into stage data (reverse of generateEpic)
 * Used by Smart Refine to extract content for re-refinement
 */
export function parseEpicToStageData(
  epicMarkdown: string
): { data: RefinedData; missingFields: string[]; projectName: string } {
  const data: RefinedData = {};
  const missingFields: string[] = [];

  // Extract project name from title: "# Technical Design Epic: {PROJECT_NAME}"
  const titleMatch = epicMarkdown.match(/^#\s*(?:Technical Design Epic:\s*)?(.+?)(?:\n|$)/m);
  const projectName = titleMatch ? titleMatch[1].trim() : 'Untitled Project';

  // Parse all sections
  const parsedSections = parseEpicSections(epicMarkdown);

  // Map each EPIC_SECTION back to its dataKeys
  for (const section of EPIC_SECTIONS) {
    const sectionContent = parsedSections.get(section.num) || '';

    // Skip reference-only sections (like Architecture Diagrams)
    if (section.isReference || section.dataKeys.length === 0) {
      continue;
    }

    // Handle sections with subsections (like Scope, Dependencies & Risks)
    if (section.subsections && section.subsections.length > 0) {
      // Parse subsections: "### In Scope" and "### Out of Scope"
      const subsectionParts: string[] = [];

      for (let i = 0; i < section.subsections.length; i++) {
        const subsectionTitle = section.subsections[i];
        const dataKey = section.dataKeys[i];

        // Try to find subsection content
        const subsectionRegex = new RegExp(
          `###\\s*(?:\\d+\\.\\d+\\.?\\s*)?${subsectionTitle}\\s*\\n([\\s\\S]*?)(?=###|$)`,
          'i'
        );
        const subsectionMatch = sectionContent.match(subsectionRegex);

        if (subsectionMatch) {
          const content = subsectionMatch[1].trim();
          data[dataKey] = {
            original: content,
            refined: content,
            diagramNode: `${dataKey}["${subsectionTitle}"]`,
          };

          if (!content || content.length < 10) {
            missingFields.push(dataKey);
          }
        } else {
          // No subsection found
          data[dataKey] = {
            original: '',
            refined: '',
            diagramNode: '',
          };
          missingFields.push(dataKey);
        }
      }
    } else {
      // Single dataKey for this section
      const dataKey = section.dataKeys[0];

      if (dataKey) {
        const content = sectionContent.trim();

        data[dataKey] = {
          original: content,
          refined: content,
          diagramNode: `${dataKey}["${section.title}"]`,
        };

        // Check if content is missing or too short
        if (!content || content.length < 10) {
          missingFields.push(dataKey);
        }
      }
    }

    // Handle multi-dataKey sections without subsections (like Features & User Stories)
    if (!section.subsections && section.dataKeys.length > 1) {
      // Split content intelligently or assign to first key
      const content = sectionContent.trim();

      // For section 11 (Features & User Stories), try to split
      if (section.num === 11) {
        // Look for "User Stories" header within the content
        const userStoriesMatch = content.match(/([\s\S]*?)(?:###?\s*User Stories|As a\s)/i);

        if (userStoriesMatch) {
          data['features'] = {
            original: userStoriesMatch[1].trim(),
            refined: userStoriesMatch[1].trim(),
            diagramNode: 'features["Key Features"]',
          };

          const userStoriesPart = content.replace(userStoriesMatch[1], '').trim();
          data['userStories'] = {
            original: userStoriesPart,
            refined: userStoriesPart,
            diagramNode: 'userStories["User Stories"]',
          };
        } else {
          // Assign all to features
          data['features'] = {
            original: content,
            refined: content,
            diagramNode: 'features["Key Features"]',
          };
          data['userStories'] = {
            original: '',
            refined: '',
            diagramNode: '',
          };
          missingFields.push('userStories');
        }
      }
    }
  }

  // Add projectName to data
  data['projectName'] = {
    original: projectName,
    refined: projectName,
    diagramNode: `project["${projectName}"]`,
  };

  return { data, missingFields, projectName };
}

/**
 * Determine section status based on score
 */
function getStatusFromScore(score: number): 'strong' | 'adequate' | 'weak' | 'missing' {
  if (score === 0) return 'missing';
  if (score >= 8) return 'strong';
  if (score >= 5) return 'adequate';
  return 'weak';
}

/**
 * Analyze and score an epic document, providing detailed feedback
 */
export async function analyzeAndRefineEpic(
  epicContent: string
): Promise<EpicQualityReport> {
  if (!currentConfig) {
    throw new Error('AI is not configured. Please check Settings.');
  }

  // Parse existing sections
  const parsedSections = parseEpicSections(epicContent);

  const systemPrompt = `You are a demanding technical reviewer who provides honest, actionable feedback on epic documents.

CRITICAL RULES:
1. Be direct and specific - never say "looks good" without evidence
2. Flag every vague statement, missing metric, or unclear ownership
3. If a section is weak, explain exactly WHY and HOW to fix it
4. Score harshly but fairly - a 10/10 is rare and earned
5. Identify what's MISSING, not just what's wrong
6. Prioritize actionability - feedback should be immediately usable

SCORING RUBRIC:
- 10: Exceptional - comprehensive, clear, actionable with concrete details
- 8-9: Strong - well-written with minor improvements possible
- 6-7: Adequate - meets basic requirements but lacks depth or specificity
- 4-5: Weak - significant gaps, vague language, or unclear content
- 1-3: Poor - critical information missing or very unclear
- 0: Missing - section not present or just placeholder text

For each section, assess:
- COMPLETENESS: Is all required information present?
- CLARITY: Would a new team member understand this?
- SPECIFICITY: Are there concrete details, metrics, dates, owners?
- ACTIONABILITY: Can someone execute on this?

COMMON ISSUES TO FLAG:
- Vague statements like "improve performance" without metrics
- Missing owners, dates, or timelines
- Placeholder text or TODOs
- Scope creep or conflicting requirements
- Missing success criteria
- Generic descriptions without project-specific details`;

  const sectionsList = EPIC_SECTIONS.map(s => `${s.num}. ${s.title}`).join('\n');

  const userPrompt = `Analyze this epic document and provide detailed feedback.

EXPECTED SECTIONS:
${sectionsList}

EPIC CONTENT:
${epicContent}

Respond with ONLY valid JSON in this exact format (no markdown, no code fences):
{
  "overallScore": <number 0-10>,
  "summary": "<one paragraph honest assessment of overall quality>",
  "criticalIssues": ["<critical issue 1>", "<critical issue 2>"],
  "strengthAreas": ["<strength 1>", "<strength 2>"],
  "missingRequired": ["<missing required item 1>"],
  "sections": [
    {
      "sectionNum": <number>,
      "sectionTitle": "<title>",
      "score": <number 0-10>,
      "issues": ["<specific issue>"],
      "suggestions": ["<specific actionable suggestion>"]
    }
  ]
}

IMPORTANT:
- Include feedback for ALL 17 sections
- If a section is missing, score it 0 with status "Section not found in document"
- Be specific and actionable in suggestions
- Do not be overly generous with scores`;

  const response = await callAI(currentConfig, systemPrompt, userPrompt);

  // Clean up response and parse JSON
  let cleanResponse = response.trim();
  cleanResponse = cleanResponse.replace(/```json\s*/gi, '').replace(/```\s*/g, '').trim();

  try {
    const parsed = JSON.parse(cleanResponse);

    // Build the full report with status for each section
    const sectionFeedback: SectionFeedback[] = [];

    // Process each of the 17 sections
    for (const epicSection of EPIC_SECTIONS) {
      const parsedSection = parsed.sections?.find((s: { sectionNum: number }) => s.sectionNum === epicSection.num);

      if (parsedSection) {
        sectionFeedback.push({
          sectionNum: parsedSection.sectionNum,
          sectionTitle: epicSection.title,
          score: parsedSection.score || 0,
          status: getStatusFromScore(parsedSection.score || 0),
          issues: parsedSection.issues || [],
          suggestions: parsedSection.suggestions || [],
        });
      } else {
        // Section wasn't analyzed by AI - check if it exists in the document
        const hasContent = parsedSections.has(epicSection.num) &&
                          parsedSections.get(epicSection.num)!.length > 10;

        sectionFeedback.push({
          sectionNum: epicSection.num,
          sectionTitle: epicSection.title,
          score: hasContent ? 5 : 0,
          status: hasContent ? 'adequate' : 'missing',
          issues: hasContent ? ['Section not fully analyzed'] : ['Section not found in document'],
          suggestions: hasContent ? ['Review section content manually'] : ['Add this section to your epic'],
        });
      }
    }

    return {
      overallScore: parsed.overallScore || 0,
      summary: parsed.summary || 'Unable to generate summary.',
      sections: sectionFeedback,
      criticalIssues: parsed.criticalIssues || [],
      strengthAreas: parsed.strengthAreas || [],
      missingRequired: parsed.missingRequired || [],
    };
  } catch {
    throw new Error('Failed to parse AI response. Please try again.');
  }
}

/**
 * Generate improved content for a weak section
 */
export async function generateSectionImprovement(
  sectionNum: number,
  currentContent: string,
  issues: string[],
  epicContext: string
): Promise<string> {
  if (!currentConfig) {
    throw new Error('AI is not configured. Please check Settings.');
  }

  const section = EPIC_SECTIONS.find(s => s.num === sectionNum);
  if (!section) {
    throw new Error(`Unknown section number: ${sectionNum}`);
  }

  const systemPrompt = `You are a technical writer improving epic documentation.
Rewrite the section to address the identified issues while maintaining the original intent.

RULES:
1. Keep the same section header format: "## ${sectionNum}. ${section.title}"
2. Be specific and actionable
3. Add concrete details, metrics, and owners where appropriate
4. Use professional language suitable for technical documentation
5. Structure content with bullet points or numbered lists where appropriate
6. DO NOT add placeholder text like [TBD] or [insert here]`;

  const userPrompt = `SECTION: ${sectionNum}. ${section.title}

CURRENT CONTENT:
${currentContent || '(empty)'}

ISSUES TO ADDRESS:
${issues.map(i => `- ${i}`).join('\n')}

EPIC CONTEXT (for reference):
${epicContext.slice(0, 2000)}

Write an improved version of this section:`;

  const response = await callAI(currentConfig, systemPrompt, userPrompt);

  return response.trim();
}

// ===========================================
// USER STORY PARSING & ISSUE MANAGEMENT
// ===========================================

export interface ParsedUserStory {
  id: string;
  rawText: string;
  title: string;
  description: string;
  persona?: string;
  goal?: string;
  benefit?: string;
  acceptanceCriteria?: string[];
  hasExistingIssue: boolean;
  matchedIssueId?: number;
  matchedIssueIid?: number;
  similarityScore?: number;
}

/**
 * Parse user stories from epic markdown content
 * Looks for Section 11 (Key Features & User Stories) and extracts stories
 */
export function parseUserStoriesFromEpic(epicContent: string): ParsedUserStory[] {
  const stories: ParsedUserStory[] = [];

  // Find the User Stories section (Section 11)
  const section11Match = epicContent.match(/##\s*11\.\s*Key Features\s*&?\s*User Stories[\s\S]*?(?=##\s*\d+\.|$)/i);

  if (!section11Match) {
    // Try alternative patterns
    const userStoriesMatch = epicContent.match(/###?\s*User Stories[\s\S]*?(?=###?\s*[A-Z]|##\s*\d+\.|$)/i);
    if (!userStoriesMatch) {
      console.log('[parseUserStories] No user stories section found');
      return stories;
    }
  }

  const sectionContent = section11Match ? section11Match[0] : epicContent;

  // Pattern 1: "As a [persona], I want [goal] so that [benefit]"
  const asAPattern = /[-*]\s*(?:As an?\s+)([^,]+),?\s*I\s+want\s+([^,]+?)(?:,?\s*so\s+that\s+([^.\n]+))?[.\n]/gi;

  // Pattern 2: Simple bullet points under User Stories
  const bulletPattern = /[-*]\s+(?!\s*As\s)([^\n]+)/g;

  // Extract "As a..." format stories
  let match;
  while ((match = asAPattern.exec(sectionContent)) !== null) {
    const persona = match[1]?.trim();
    const goal = match[2]?.trim();
    const benefit = match[3]?.trim();

    const rawText = match[0].trim();
    const title = goal ? `${goal.charAt(0).toUpperCase()}${goal.slice(1)}` : rawText;

    stories.push({
      id: `story-${stories.length + 1}-${Date.now()}`,
      rawText,
      title: title.length > 100 ? title.slice(0, 97) + '...' : title,
      description: `**User Story**\n\n${rawText}\n\n**Persona:** ${persona || 'User'}\n**Goal:** ${goal || 'N/A'}\n**Benefit:** ${benefit || 'N/A'}`,
      persona,
      goal,
      benefit,
      hasExistingIssue: false
    });
  }

  // If no "As a..." stories found, try bullet points
  if (stories.length === 0) {
    // Reset regex
    bulletPattern.lastIndex = 0;

    // Only look in the User Stories subsection
    const userStoriesSubsection = sectionContent.match(/User Stories[\s\S]*?(?=###|##|$)/i);
    const searchContent = userStoriesSubsection ? userStoriesSubsection[0] : sectionContent;

    while ((match = bulletPattern.exec(searchContent)) !== null) {
      const text = match[1]?.trim();
      if (text && text.length > 10 && !text.toLowerCase().startsWith('as a')) {
        stories.push({
          id: `story-${stories.length + 1}-${Date.now()}`,
          rawText: text,
          title: text.length > 100 ? text.slice(0, 97) + '...' : text,
          description: `**User Story**\n\n${text}`,
          hasExistingIssue: false
        });
      }
    }
  }

  console.log(`[parseUserStories] Found ${stories.length} user stories`);
  return stories;
}

/**
 * Use LLM to check if a user story is similar to existing issues
 * Returns similarity analysis to avoid creating duplicates
 */
export async function analyzeStoryDuplicates(
  stories: ParsedUserStory[],
  existingIssues: Array<{ id: number; iid: number; title: string; description?: string }>
): Promise<ParsedUserStory[]> {
  if (!currentConfig) {
    console.log('[analyzeStoryDuplicates] No config, skipping analysis');
    return stories;
  }

  if (existingIssues.length === 0) {
    console.log('[analyzeStoryDuplicates] No existing issues, all stories are new');
    return stories;
  }

  const systemPrompt = `You are an expert at detecting duplicate or similar issues in project management.
Given a list of user stories and existing issues, identify which stories are duplicates or very similar to existing issues.

RULES:
1. A story is a DUPLICATE if it describes essentially the same functionality (>80% similar)
2. A story is SIMILAR if it overlaps significantly (50-80% similar)
3. A story is UNIQUE if it describes different functionality (<50% similar)
4. Consider semantic meaning, not just keyword matching
5. Be conservative - when in doubt, mark as unique to avoid missing important stories

OUTPUT FORMAT (JSON):
{
  "analysis": [
    {
      "storyId": "story-1-xxx",
      "status": "duplicate|similar|unique",
      "similarityScore": 0-100,
      "matchedIssueIid": 123 or null,
      "reason": "brief explanation"
    }
  ]
}`;

  const existingIssuesList = existingIssues.map(i =>
    `- Issue #${i.iid}: ${i.title}`
  ).join('\n');

  const storiesList = stories.map(s =>
    `- ${s.id}: ${s.title}`
  ).join('\n');

  const userPrompt = `EXISTING ISSUES:
${existingIssuesList}

USER STORIES TO ANALYZE:
${storiesList}

Analyze each story and identify duplicates. Return JSON only.`;

  try {
    const response = await callAI(currentConfig, systemPrompt, userPrompt);

    // Parse JSON response
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      console.log('[analyzeStoryDuplicates] Could not parse LLM response');
      return stories;
    }

    const analysis = JSON.parse(jsonMatch[0]);

    // Update stories with analysis results
    const updatedStories = stories.map(story => {
      const storyAnalysis = analysis.analysis?.find(
        (a: { storyId: string }) => a.storyId === story.id
      );

      if (storyAnalysis) {
        const matchedIssue = storyAnalysis.matchedIssueIid
          ? existingIssues.find(i => i.iid === storyAnalysis.matchedIssueIid)
          : null;

        return {
          ...story,
          hasExistingIssue: storyAnalysis.status === 'duplicate',
          matchedIssueId: matchedIssue?.id,
          matchedIssueIid: matchedIssue?.iid,
          similarityScore: storyAnalysis.similarityScore
        };
      }
      return story;
    });

    console.log('[analyzeStoryDuplicates] Analysis complete');
    return updatedStories;
  } catch (e) {
    console.error('[analyzeStoryDuplicates] Error:', e);
    return stories;
  }
}

/**
 * Generate a well-formatted issue description from a user story
 */
export async function generateIssueDescription(
  story: ParsedUserStory,
  epicTitle: string,
  epicContext: string
): Promise<string> {
  if (!currentConfig) {
    // Return basic description if no AI available
    return story.description;
  }

  const systemPrompt = `You are a technical writer creating GitLab issue descriptions.
Create a clear, actionable issue description from the user story.

FORMAT:
## Description
[Clear description of what needs to be done]

## User Story
[Original user story]

## Acceptance Criteria
- [ ] Criterion 1
- [ ] Criterion 2
- [ ] Criterion 3

## Technical Notes
[Any technical considerations]

## Related Epic
[Epic reference]

RULES:
1. Be specific and actionable
2. Include 3-5 acceptance criteria
3. Keep it concise but complete
4. Use markdown formatting`;

  const userPrompt = `EPIC: ${epicTitle}

USER STORY: ${story.rawText}

EPIC CONTEXT (for reference):
${epicContext.slice(0, 1500)}

Generate a well-formatted issue description:`;

  try {
    const response = await callAI(currentConfig, systemPrompt, userPrompt);
    return response.trim();
  } catch (e) {
    console.error('[generateIssueDescription] Error:', e);
    return story.description;
  }
}

