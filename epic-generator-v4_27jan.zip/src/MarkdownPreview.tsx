// Markdown Preview with Mermaid Diagram Support
// UBS Brand Theme Compliant

import { useEffect, useRef, useState } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import mermaid from 'mermaid';

// UBS Brand Colors - Official Palette
const UBS_COLORS = {
  // Primary
  ubsRed: '#E60000',
  bordeauxI: '#BD000C',
  black: '#000000',
  white: '#FFFFFF',
  // Grays
  grayI: '#CCCABC',
  grayIII: '#8E8D83',
  grayV: '#5A5D5C',
  // Pastels
  pastelI: '#ECEBE4',
  pastelII: '#F5F0E1',
  // Neutrals
  neutral50: '#FAFAFA',
  neutral200: '#E5E5E5',
};

// Initialize Mermaid for markdown preview
// Edge labels: transparent background
mermaid.initialize({
  startOnLoad: false,
  theme: 'base',
  securityLevel: 'loose',
  fontFamily: 'system-ui, sans-serif',
  themeVariables: {
    edgeLabelBackground: 'transparent',
  },
});

// Mermaid diagram component
function MermaidDiagram({ chart }: { chart: string }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [svg, setSvg] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const renderDiagram = async () => {
      if (!chart.trim()) return;

      try {
        const id = `mermaid-${Math.random().toString(36).substr(2, 9)}`;
        const { svg } = await mermaid.render(id, chart);
        setSvg(svg);
        setError(null);
      } catch (err) {
        setError('Diagram rendering error');
        console.error('Mermaid error:', err);
      }
    };

    renderDiagram();
  }, [chart]);

  if (error) {
    return (
      <div style={{
        padding: '12px',
        backgroundColor: UBS_COLORS.neutral50,
        borderRadius: '6px',
        border: `1px dashed ${UBS_COLORS.neutral200}`,
        color: UBS_COLORS.grayV,
        fontSize: '13px',
        textAlign: 'center',
        fontWeight: 300,
      }}>
        <span style={{ opacity: 0.6 }}>Diagram preview unavailable</span>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      dangerouslySetInnerHTML={{ __html: svg }}
      style={{
        display: 'flex',
        justifyContent: 'center',
        padding: '16px',
        backgroundColor: UBS_COLORS.neutral50,
        borderRadius: '8px',
        overflow: 'auto',
      }}
    />
  );
}

// UBS Brand compliant markdown preview styles
const styles = {
  preview: {
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif',
    fontSize: '14px',
    lineHeight: '1.6',
    fontWeight: 300,
    color: UBS_COLORS.black,
    padding: '24px',
    backgroundColor: UBS_COLORS.white,
  },
  h1: {
    fontSize: '2em',
    fontWeight: '600',
    borderBottom: `1px solid ${UBS_COLORS.neutral200}`,
    paddingBottom: '0.3em',
    marginBottom: '16px',
    marginTop: '24px',
    color: UBS_COLORS.black,
  },
  h2: {
    fontSize: '1.5em',
    fontWeight: '600',
    borderBottom: `1px solid ${UBS_COLORS.neutral200}`,
    paddingBottom: '0.3em',
    marginBottom: '16px',
    marginTop: '24px',
    color: UBS_COLORS.black,
  },
  h3: {
    fontSize: '1.25em',
    fontWeight: '600',
    marginBottom: '16px',
    marginTop: '24px',
    color: UBS_COLORS.black,
  },
  p: {
    marginBottom: '16px',
    fontWeight: 300,
  },
  ul: {
    paddingLeft: '2em',
    marginBottom: '16px',
    fontWeight: 300,
  },
  ol: {
    paddingLeft: '2em',
    marginBottom: '16px',
    fontWeight: 300,
  },
  li: {
    marginBottom: '4px',
    fontWeight: 300,
  },
  table: {
    borderCollapse: 'collapse' as const,
    width: '100%',
    marginBottom: '16px',
  },
  th: {
    border: `1px solid ${UBS_COLORS.neutral200}`,
    padding: '8px 12px',
    backgroundColor: UBS_COLORS.pastelI,
    fontWeight: '600',
    textAlign: 'left' as const,
    color: UBS_COLORS.black,
  },
  td: {
    border: `1px solid ${UBS_COLORS.neutral200}`,
    padding: '8px 12px',
    fontWeight: 300,
  },
  code: {
    backgroundColor: UBS_COLORS.pastelI,
    padding: '0.2em 0.4em',
    borderRadius: '6px',
    fontSize: '85%',
    fontFamily: 'ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace',
  },
  pre: {
    backgroundColor: UBS_COLORS.pastelI,
    padding: '16px',
    borderRadius: '6px',
    overflow: 'auto',
    marginBottom: '16px',
  },
  blockquote: {
    borderLeft: `4px solid ${UBS_COLORS.ubsRed}`,
    padding: '0 16px',
    color: UBS_COLORS.grayIII,
    marginBottom: '16px',
    fontWeight: 300,
  },
  hr: {
    border: 'none',
    borderTop: `1px solid ${UBS_COLORS.neutral200}`,
    margin: '24px 0',
  },
  strong: {
    fontWeight: '600',
  },
  checkbox: {
    marginRight: '8px',
    accentColor: UBS_COLORS.ubsRed,
  },
};

interface MarkdownPreviewProps {
  content: string;
}

export default function MarkdownPreview({ content }: MarkdownPreviewProps) {
  return (
    <div style={styles.preview}>
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          h1: ({ children }) => <h1 style={styles.h1}>{children}</h1>,
          h2: ({ children }) => <h2 style={styles.h2}>{children}</h2>,
          h3: ({ children }) => <h3 style={styles.h3}>{children}</h3>,
          p: ({ children }) => <p style={styles.p}>{children}</p>,
          ul: ({ children }) => <ul style={styles.ul}>{children}</ul>,
          ol: ({ children }) => <ol style={styles.ol}>{children}</ol>,
          li: ({ children, ...props }) => {
            // Handle task list items
            const checked = (props as any).checked;
            if (typeof checked === 'boolean') {
              return (
                <li style={{ ...styles.li, listStyle: 'none', marginLeft: '-1.5em' }}>
                  <input type="checkbox" checked={checked} readOnly style={styles.checkbox} />
                  {children}
                </li>
              );
            }
            return <li style={styles.li}>{children}</li>;
          },
          table: ({ children }) => <table style={styles.table}>{children}</table>,
          th: ({ children }) => <th style={styles.th}>{children}</th>,
          td: ({ children }) => <td style={styles.td}>{children}</td>,
          code: ({ children, className }) => {
            const match = /language-(\w+)/.exec(className || '');
            const language = match ? match[1] : '';

            // Handle Mermaid diagrams
            if (language === 'mermaid') {
              return <MermaidDiagram chart={String(children).trim()} />;
            }

            // Inline code vs code block
            const isBlock = className !== undefined;
            if (isBlock) {
              return (
                <pre style={styles.pre}>
                  <code style={{ ...styles.code, backgroundColor: 'transparent', padding: 0 }}>
                    {children}
                  </code>
                </pre>
              );
            }
            return <code style={styles.code}>{children}</code>;
          },
          pre: ({ children }) => <>{children}</>,
          blockquote: ({ children }) => <blockquote style={styles.blockquote}>{children}</blockquote>,
          hr: () => <hr style={styles.hr} />,
          strong: ({ children }) => <strong style={styles.strong}>{children}</strong>,
          a: ({ href, children }) => (
            <a href={href} style={{ color: UBS_COLORS.ubsRed, textDecoration: 'none', fontWeight: 300 }} target="_blank" rel="noopener noreferrer">
              {children}
            </a>
          ),
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
}
