// PlantUML Service for EPIC Builder Pro
class PlantUMLService {
    constructor() {
        this.components = [];
        this.connections = [];
        this.selectedComponent = null;
        this.connectMode = false;
        this.draggedComponent = null;
        this.patterns = this.initializePatterns();
        this.init();
    }

    init() {
        this.bindEvents();
        this.initializeCanvas();
    }

    // Initialize communication patterns
    initializePatterns() {
        return {
            rest: {
                name: 'REST API Architecture',
                components: [
                    { type: 'api-gateway', x: 50, y: 50, name: 'API Gateway' },
                    { type: 'user-service', x: 200, y: 50, name: 'User Service' },
                    { type: 'order-service', x: 350, y: 50, name: 'Order Service' },
                    { type: 'database', x: 200, y: 200, name: 'Database' },
                    { type: 'cache', x: 350, y: 200, name: 'Redis Cache' }
                ],
                connections: [
                    { from: 'api-gateway', to: 'user-service', type: 'synchronous', protocol: 'http' },
                    { from: 'api-gateway', to: 'order-service', type: 'synchronous', protocol: 'http' },
                    { from: 'user-service', to: 'database', type: 'synchronous', protocol: 'http' },
                    { from: 'order-service', to: 'cache', type: 'synchronous', protocol: 'http' }
                ]
            },
            graphql: {
                name: 'GraphQL Architecture',
                components: [
                    { type: 'api-gateway', x: 50, y: 50, name: 'GraphQL Gateway' },
                    { type: 'user-service', x: 200, y: 30, name: 'User Service' },
                    { type: 'product-service', x: 200, y: 80, name: 'Product Service' },
                    { type: 'order-service', x: 200, y: 130, name: 'Order Service' },
                    { type: 'database', x: 350, y: 50, name: 'Main Database' }
                ],
                connections: [
                    { from: 'api-gateway', to: 'user-service', type: 'synchronous', protocol: 'http' },
                    { from: 'api-gateway', to: 'product-service', type: 'synchronous', protocol: 'http' },
                    { from: 'api-gateway', to: 'order-service', type: 'synchronous', protocol: 'http' },
                    { from: 'user-service', to: 'database', type: 'synchronous', protocol: 'http' },
                    { from: 'product-service', to: 'database', type: 'synchronous', protocol: 'http' }
                ]
            },
            grpc: {
                name: 'gRPC Microservices',
                components: [
                    { type: 'api-gateway', x: 50, y: 50, name: 'gRPC Gateway' },
                    { type: 'user-service', x: 250, y: 30, name: 'User Service' },
                    { type: 'auth-service', x: 250, y: 80, name: 'Auth Service' },
                    { type: 'notification-service', x: 250, y: 130, name: 'Notification Service' },
                    { type: 'database', x: 400, y: 50, name: 'User DB' },
                    { type: 'cache', x: 400, y: 130, name: 'Session Store' }
                ],
                connections: [
                    { from: 'api-gateway', to: 'user-service', type: 'synchronous', protocol: 'tcp' },
                    { from: 'api-gateway', to: 'auth-service', type: 'synchronous', protocol: 'tcp' },
                    { from: 'user-service', to: 'database', type: 'synchronous', protocol: 'tcp' },
                    { from: 'auth-service', to: 'cache', type: 'synchronous', protocol: 'tcp' },
                    { from: 'user-service', to: 'notification-service', type: 'asynchronous', protocol: 'tcp' }
                ]
            },
            event: {
                name: 'Event-Driven Architecture',
                components: [
                    { type: 'api-gateway', x: 50, y: 50, name: 'API Gateway' },
                    { type: 'user-service', x: 200, y: 30, name: 'User Service' },
                    { type: 'order-service', x: 200, y: 80, name: 'Order Service' },
                    { type: 'payment-service', x: 200, y: 130, name: 'Payment Service' },
                    { type: 'message-queue', x: 350, y: 80, name: 'Event Bus' },
                    { type: 'database', x: 500, y: 50, name: 'Event Store' }
                ],
                connections: [
                    { from: 'api-gateway', to: 'user-service', type: 'synchronous', protocol: 'http' },
                    { from: 'user-service', to: 'message-queue', type: 'event', protocol: 'amqp' },
                    { from: 'order-service', to: 'message-queue', type: 'event', protocol: 'amqp' },
                    { from: 'payment-service', to: 'message-queue', type: 'event', protocol: 'amqp' },
                    { from: 'message-queue', to: 'database', type: 'asynchronous', protocol: 'kafka' }
                ]
            }
        };
    }

    // Bind event listeners
    bindEvents() {
        // Pattern buttons
        document.querySelectorAll('.pattern-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const pattern = e.currentTarget.dataset.pattern;
                this.loadPattern(pattern);
            });
        });

        // Component drag and drop
        document.querySelectorAll('.component-item').forEach(item => {
            item.addEventListener('dragstart', (e) => {
                this.draggedComponent = {
                    type: e.target.dataset.type,
                    name: e.target.querySelector('.font-medium').textContent
                };
            });
        });

        // Canvas drop zone
        const canvas = document.getElementById('canvas');
        canvas.addEventListener('dragover', (e) => {
            e.preventDefault();
            canvas.classList.add('drag-over');
        });

        canvas.addEventListener('dragleave', () => {
            canvas.classList.remove('drag-over');
        });

        canvas.addEventListener('drop', (e) => {
            e.preventDefault();
            canvas.classList.remove('drag-over');
            
            if (this.draggedComponent) {
                const rect = canvas.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                
                this.addComponent({
                    ...this.draggedComponent,
                    x: Math.max(0, Math.min(x - 60, rect.width - 120)),
                    y: Math.max(0, Math.min(y - 30, rect.height - 60))
                });
                
                this.draggedComponent = null;
            }
        });

        // Control buttons
        document.getElementById('clearCanvas')?.addEventListener('click', () => this.clearCanvas());
        document.getElementById('autoLayout')?.addEventListener('click', () => this.autoLayout());
        document.getElementById('connectMode')?.addEventListener('click', () => this.toggleConnectMode());
        document.getElementById('refreshCode')?.addEventListener('click', () => this.updatePlantUMLCode());
        document.getElementById('copyCode')?.addEventListener('click', () => this.copyCode());

        // Export buttons
        document.getElementById('exportPNG')?.addEventListener('click', () => this.exportPNG());
        document.getElementById('exportSVG')?.addEventListener('click', () => this.exportSVG());
        document.getElementById('exportRaw')?.addEventListener('click', () => this.exportRaw());
    }

    // Initialize canvas
    initializeCanvas() {
        const canvas = document.getElementById('canvas');
        canvas.addEventListener('click', (e) => {
            if (e.target.classList.contains('component-on-canvas')) {
                this.selectComponent(e.target);
            }
        });
    }

    // Load pattern template
    loadPattern(patternName) {
        const pattern = this.patterns[patternName];
        if (!pattern) return;

        this.clearCanvas();
        
        // Add components
        pattern.components.forEach(comp => {
            this.addComponent(comp);
        });

        // Add connections
        setTimeout(() => {
            pattern.connections.forEach(conn => {
                this.addConnection(conn);
            });
        }, 100);

        EPICBuilder.showNotification(`Loaded ${pattern.name} template`, 'success');
    }

    // Add component to canvas
    addComponent(component) {
        const canvas = document.getElementById('canvas');
        const placeholder = document.getElementById('canvasPlaceholder');
        
        // Hide placeholder
        if (placeholder) {
            placeholder.style.display = 'none';
        }

        // Create component element
        const compElement = document.createElement('div');
        compElement.className = `component-on-canvas absolute p-3 rounded-lg border-2 cursor-pointer transition-all hover:shadow-lg ${this.getComponentStyle(component.type)}`;
        compElement.style.left = `${component.x}px`;
        compElement.style.top = `${component.y}px`;
        compElement.dataset.type = component.type;
        compElement.dataset.id = `comp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        
        compElement.innerHTML = `
            <div class="font-medium text-sm">${component.name}</div>
            <div class="text-xs opacity-75">${this.getComponentDescription(component.type)}</div>
            <button class="absolute -top-2 -right-2 w-5 h-5 bg-red-500 text-white rounded-full text-xs hover:bg-red-600 delete-btn">×</button>
        `;

        // Add delete functionality
        compElement.querySelector('.delete-btn').addEventListener('click', (e) => {
            e.stopPropagation();
            this.removeComponent(compElement);
        });

        // Make draggable within canvas
        this.makeDraggable(compElement);

        canvas.appendChild(compElement);
        this.components.push({
            id: compElement.dataset.id,
            element: compElement,
            type: component.type,
            name: component.name,
            x: component.x,
            y: component.y
        });

        this.updatePlantUMLCode();
    }

    // Remove component
    removeComponent(element) {
        const componentId = element.dataset.id;
        
        // Remove from array
        this.components = this.components.filter(comp => comp.id !== componentId);
        
        // Remove connections
        this.connections = this.connections.filter(conn => 
            conn.from !== componentId && conn.to !== componentId
        );
        
        // Remove element
        element.remove();
        
        // Update connections display
        this.updateConnections();
        this.updatePlantUMLCode();

        // Show placeholder if no components
        if (this.components.length === 0) {
            document.getElementById('canvasPlaceholder').style.display = 'flex';
        }
    }

    // Make element draggable within canvas
    makeDraggable(element) {
        let isDragging = false;
        let startX, startY, initialX, initialY;

        element.addEventListener('mousedown', (e) => {
            if (e.target.classList.contains('delete-btn')) return;
            
            isDragging = true;
            startX = e.clientX;
            startY = e.clientY;
            initialX = parseInt(element.style.left);
            initialY = parseInt(element.style.top);
            
            element.style.zIndex = '1000';
        });

        document.addEventListener('mousemove', (e) => {
            if (!isDragging) return;
            
            const canvas = document.getElementById('canvas');
            const canvasRect = canvas.getBoundingClientRect();
            
            const newX = initialX + (e.clientX - startX);
            const newY = initialY + (e.clientY - startY);
            
            // Constrain to canvas bounds
            const maxX = canvasRect.width - element.offsetWidth;
            const maxY = canvasRect.height - element.offsetHeight;
            
            element.style.left = `${Math.max(0, Math.min(newX, maxX))}px`;
            element.style.top = `${Math.max(0, Math.min(newY, maxY))}px`;
            
            this.updateConnections();
        });

        document.addEventListener('mouseup', () => {
            if (isDragging) {
                isDragging = false;
                element.style.zIndex = 'auto';
                
                // Update component position in data
                const component = this.components.find(comp => comp.id === element.dataset.id);
                if (component) {
                    component.x = parseInt(element.style.left);
                    component.y = parseInt(element.style.top);
                }
                
                this.updatePlantUMLCode();
            }
        });
    }

    // Select component for connection
    selectComponent(element) {
        if (!this.connectMode) return;

        if (this.selectedComponent === null) {
            this.selectedComponent = element;
            element.classList.add('ring-2', 'ring-cyan-500');
        } else if (this.selectedComponent === element) {
            this.selectedComponent.classList.remove('ring-2', 'ring-cyan-500');
            this.selectedComponent = null;
        } else {
            // Create connection
            const connection = {
                from: this.selectedComponent.dataset.id,
                to: element.dataset.id,
                type: document.getElementById('connectionType')?.value || 'synchronous',
                protocol: document.getElementById('connectionProtocol')?.value || 'http'
            };
            
            this.addConnection(connection);
            
            // Clear selection
            this.selectedComponent.classList.remove('ring-2', 'ring-cyan-500');
            this.selectedComponent = null;
        }
    }

    // Add connection
    addConnection(connection) {
        // Check if connection already exists
        const exists = this.connections.some(conn => 
            (conn.from === connection.from && conn.to === connection.to) ||
            (conn.from === connection.to && conn.to === connection.from)
        );
        
        if (exists) return;

        this.connections.push(connection);
        this.updateConnections();
        this.updatePlantUMLCode();
    }

    // Update connections display
    updateConnections() {
        const svg = document.getElementById('connectionSvg');
        
        // Clear existing connections
        svg.querySelectorAll('.connection-line').forEach(line => line.remove());
        
        // Draw connections
        this.connections.forEach(conn => {
            const fromComp = this.components.find(comp => comp.id === conn.from);
            const toComp = this.components.find(comp => comp.id === conn.to);
            
            if (fromComp && toComp) {
                const fromElement = fromComp.element;
                const toElement = toComp.element;
                
                const fromX = parseInt(fromElement.style.left) + fromElement.offsetWidth;
                const fromY = parseInt(fromElement.style.top) + fromElement.offsetHeight / 2;
                const toX = parseInt(toElement.style.left);
                const toY = parseInt(toElement.style.top) + toElement.offsetHeight / 2;
                
                // Create line
                const line = document.createElementNS('http://www.w3.org/2000/svg', 'path');
                const midX = (fromX + toX) / 2;
                const d = `M ${fromX} ${fromY} Q ${midX} ${fromY} ${midX} ${(fromY + toY) / 2} Q ${midX} ${toY} ${toX} ${toY}`;
                
                line.setAttribute('d', d);
                line.classList.add('connection-line');
                line.style.stroke = this.getConnectionColor(conn.type);
                line.style.strokeDasharray = this.getConnectionDash(conn.type);
                
                svg.appendChild(line);
            }
        });
    }

    // Toggle connect mode
    toggleConnectMode() {
        this.connectMode = !this.connectMode;
        const button = document.getElementById('connectMode');
        
        if (this.connectMode) {
            button.textContent = 'Connect Mode (On)';
            button.classList.add('bg-green-600', 'hover:bg-green-700');
            button.classList.remove('bg-cyan-600', 'hover:bg-cyan-700');
            EPICBuilder.showNotification('Connect mode enabled. Click components to connect them.', 'info');
        } else {
            button.textContent = 'Connect Mode (Off)';
            button.classList.add('bg-cyan-600', 'hover:bg-cyan-700');
            button.classList.remove('bg-green-600', 'hover:bg-green-700');
            
            // Clear selection
            if (this.selectedComponent) {
                this.selectedComponent.classList.remove('ring-2', 'ring-cyan-500');
                this.selectedComponent = null;
            }
        }
    }

    // Clear canvas
    clearCanvas() {
        const canvas = document.getElementById('canvas');
        canvas.querySelectorAll('.component-on-canvas').forEach(comp => comp.remove());
        
        this.components = [];
        this.connections = [];
        this.selectedComponent = null;
        this.connectMode = false;
        
        // Reset connect mode button
        const button = document.getElementById('connectMode');
        button.textContent = 'Connect Mode (Off)';
        button.classList.add('bg-cyan-600', 'hover:bg-cyan-700');
        button.classList.remove('bg-green-600', 'hover:bg-green-700');
        
        // Show placeholder
        document.getElementById('canvasPlaceholder').style.display = 'flex';
        
        this.updatePlantUMLCode();
        EPICBuilder.showNotification('Canvas cleared', 'info');
    }

    // Auto layout components
    autoLayout() {
        if (this.components.length === 0) return;
        
        const canvas = document.getElementById('canvas');
        const canvasRect = canvas.getBoundingClientRect();
        
        const cols = Math.ceil(Math.sqrt(this.components.length));
        const rows = Math.ceil(this.components.length / cols);
        
        const compWidth = 120;
        const compHeight = 60;
        const padding = 20;
        
        const startX = (canvasRect.width - (cols * (compWidth + padding))) / 2;
        const startY = (canvasRect.height - (rows * (compHeight + padding))) / 2;
        
        this.components.forEach((comp, index) => {
            const col = index % cols;
            const row = Math.floor(index / cols);
            
            const x = startX + col * (compWidth + padding);
            const y = startY + row * (compHeight + padding);
            
            comp.element.style.left = `${x}px`;
            comp.element.style.top = `${y}px`;
            comp.x = x;
            comp.y = y;
        });
        
        this.updateConnections();
        this.updatePlantUMLCode();
        EPICBuilder.showNotification('Auto layout applied', 'success');
    }

    // Update PlantUML code
    updatePlantUMLCode() {
        const code = this.generatePlantUMLCode();
        const codeElement = document.getElementById('plantumlCode');
        if (codeElement) {
            codeElement.value = code;
            this.highlightSyntax(codeElement);
        }
    }

    // Generate PlantUML code
    generatePlantUMLCode() {
        let code = '@startuml\n';
        code += '!define RECTANGLE class\n\n';
        
        // Define components
        this.components.forEach(comp => {
            const stereotype = this.getComponentStereotype(comp.type);
            code += `${comp.id} ${stereotype} ${comp.name}\n`;
        });
        
        code += '\n';
        
        // Define connections
        this.connections.forEach(conn => {
            const arrow = this.getConnectionArrow(conn.type);
            const label = conn.protocol ? `: ${conn.protocol}` : '';
            code += `${conn.from} ${arrow} ${conn.to}${label}\n`;
        });
        
        code += '\n@enduml';
        return code;
    }

    // Copy code to clipboard
    copyCode() {
        const codeElement = document.getElementById('plantumlCode');
        if (codeElement) {
            navigator.clipboard.writeText(codeElement.value).then(() => {
                EPICBuilder.showNotification('Code copied to clipboard!', 'success');
            });
        }
    }

    // Export functions
    exportPNG() {
        EPICBuilder.showNotification('PNG export feature coming soon!', 'info');
    }

    exportSVG() {
        EPICBuilder.showNotification('SVG export feature coming soon!', 'info');
    }

    exportRaw() {
        const code = this.generatePlantUMLCode();
        const blob = new Blob([code], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'architecture.puml';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        
        EPICBuilder.showNotification('PlantUML file exported!', 'success');
    }

    // Helper methods
    getComponentStyle(type) {
        const styles = {
            'api-gateway': 'bg-blue-100 border-blue-200 text-blue-900',
            'user-service': 'bg-green-100 border-green-200 text-green-900',
            'database': 'bg-purple-100 border-purple-200 text-purple-900',
            'cache': 'bg-yellow-100 border-yellow-200 text-yellow-900',
            'message-queue': 'bg-red-100 border-red-200 text-red-900',
            'external-api': 'bg-indigo-100 border-indigo-200 text-indigo-900'
        };
        return styles[type] || 'bg-gray-100 border-gray-200 text-gray-900';
    }

    getComponentDescription(type) {
        const descriptions = {
            'api-gateway': 'Entry point',
            'user-service': 'Business logic',
            'database': 'Data storage',
            'cache': 'Performance',
            'message-queue': 'Async processing',
            'external-api': 'Third-party'
        };
        return descriptions[type] || 'Component';
    }

    getComponentStereotype(type) {
        const stereotypes = {
            'api-gateway': '<<Gateway>>',
            'user-service': '<<Service>>',
            'database': '<<Database>>',
            'cache': '<<Cache>>',
            'message-queue': '<<Queue>>',
            'external-api': '<<External>>'
        };
        return stereotypes[type] || '<<Component>>';
    }

    getConnectionArrow(type) {
        const arrows = {
            'synchronous': '-->',
            'asynchronous': '-->>',
            'event': '--o',
            'stream': '--)'
        };
        return arrows[type] || '-->';
    }

    getConnectionColor(type) {
        const colors = {
            'synchronous': '#64748b',
            'asynchronous': '#00d4ff',
            'event': '#10b981',
            'stream': '#f59e0b'
        };
        return colors[type] || '#64748b';
    }

    getConnectionDash(type) {
        const dashes = {
            'synchronous': 'none',
            'asynchronous': '5,5',
            'event': '10,2',
            'stream': '3,3'
        };
        return dashes[type] || 'none';
    }

    // Syntax highlighting for PlantUML code
    highlightSyntax(element) {
        const code = element.value;
        const highlighted = code
            .replace(/(@\w+)/g, '<span class="keyword">$1</span>')
            .replace(/('[^']*')/g, '<span class="string">$1</span>')
            .replace(/(\/\/.*$)/gm, '<span class="comment">$1</span>')
            .replace(/(<<[^>>]*>>)/g, '<span class="entity">$1</span>');
        
        // This is a simplified version - in a real implementation,
        // you'd use a proper syntax highlighting library
    }
}

// Initialize PlantUML Service when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const plantUMLService = new PlantUMLService();
});