// AI Service for EPIC Builder Pro
class AIService {
    constructor() {
        this.suggestions = [];
        this.currentContent = {};
        this.enhancedContent = {};
        this.qualityScore = 0;
        this.loadSavedDrafts();
    }

    // Initialize the AI service
    init() {
        this.bindEvents();
        this.loadAutoSavedContent();
    }

    // Bind event listeners
    bindEvents() {
        const titleInput = document.getElementById('epicTitle');
        const descriptionInput = document.getElementById('epicDescription');
        const enhanceBtn = document.getElementById('enhanceBtn');
        const saveBtn = document.getElementById('saveBtn');
        const clearBtn = document.getElementById('clearBtn');
        const addCriteriaBtn = document.getElementById('addCriteria');

        // Real-time enhancement on input
        let enhancementTimeout;
        [titleInput, descriptionInput].forEach(input => {
            input?.addEventListener('input', (e) => {
                this.updateCharCount(e.target.value.length);
                this.autoSave();
                clearTimeout(enhancementTimeout);
                enhancementTimeout = setTimeout(() => {
                    this.performQuickEnhancement(e.target);
                }, 1000);
            });
        });

        // Manual enhancement
        enhanceBtn?.addEventListener('click', () => {
            this.performFullEnhancement();
        });

        // Save draft
        saveBtn?.addEventListener('click', () => {
            this.saveDraft();
        });

        // Clear form
        clearBtn?.addEventListener('click', () => {
            this.clearForm();
        });

        // Add criteria
        addCriteriaBtn?.addEventListener('click', () => {
            this.addCriteria();
        });

        // Accept/Reject buttons
        document.getElementById('acceptTitle')?.addEventListener('click', () => this.acceptTitle());
        document.getElementById('acceptDescription')?.addEventListener('click', () => this.acceptDescription());
        document.getElementById('acceptCriteria')?.addEventListener('click', () => this.acceptCriteria());
        document.getElementById('acceptAllBtn')?.addEventListener('click', () => this.acceptAll());

        // Export buttons
        document.getElementById('exportMarkdown')?.addEventListener('click', () => this.exportMarkdown());
        document.getElementById('exportGitLab')?.addEventListener('click', () => this.exportGitLab());
        document.getElementById('exportPDF')?.addEventListener('click', () => this.exportPDF());
        document.getElementById('copyToClipboard')?.addEventListener('click', () => this.copyToClipboard());
    }

    // Quick enhancement for real-time feedback
    async performQuickEnhancement(input) {
        if (input.value.length < 10) return;

        const processingIndicator = document.getElementById('processingIndicator');
        processingIndicator?.classList.remove('hidden');

        // Simulate AI processing
        await EPICBuilder.simulateAIProcessing(500);

        const quickEnhancements = this.generateQuickEnhancements(input.value, input.id);
        this.showQuickSuggestions(quickEnhancements);

        processingIndicator?.classList.add('hidden');
    }

    // Full enhancement process
    async performFullEnhancement() {
        const title = document.getElementById('epicTitle')?.value;
        const description = document.getElementById('epicDescription')?.value;
        const epicType = document.getElementById('epicType')?.value;

        if (!title && !description) {
            EPICBuilder.showNotification('Please enter some content to enhance', 'warning');
            return;
        }

        this.currentContent = { title, description, type: epicType };

        const processingIndicator = document.getElementById('processingIndicator');
        processingIndicator?.classList.remove('hidden');

        // Simulate AI processing
        await EPICBuilder.simulateAIProcessing(1500);

        // Generate enhanced content
        this.enhancedContent = this.generateEnhancedContent();
        this.qualityScore = this.calculateQualityScore();

        // Update UI
        this.updateEnhancedOutput();
        this.updateQualityScore();
        this.generateAISuggestions();

        processingIndicator?.classList.add('hidden');
        
        // Enable accept buttons
        this.enableAcceptButtons();

        EPICBuilder.showNotification('AI enhancement complete!', 'success');
    }

    // Generate quick enhancements
    generateQuickEnhancements(text, field) {
        const enhancements = [];
        
        if (field === 'epicTitle') {
            if (text.length < 20) {
                enhancements.push({
                    type: 'length',
                    message: 'Consider making the title more descriptive',
                    confidence: 75
                });
            }
            if (!text.includes('As a') && !text.includes('I want')) {
                enhancements.push({
                    type: 'format',
                    message: 'Follow user story format for better clarity',
                    confidence: 85
                });
            }
        }

        if (field === 'epicDescription') {
            if (text.split(' ').length < 50) {
                enhancements.push({
                    type: 'detail',
                    message: 'Add more technical details and context',
                    confidence: 80
                });
            }
            if (!text.includes('so that')) {
                enhancements.push({
                    type: 'value',
                    message: 'Include business value justification',
                    confidence: 90
                });
            }
        }

        return enhancements;
    }

    // Show quick suggestions
    showQuickSuggestions(enhancements) {
        const suggestionsContainer = document.getElementById('aiSuggestions');
        if (!suggestionsContainer) return;

        suggestionsContainer.innerHTML = enhancements.map(suggestion => `
            <div class="ai-suggestion p-3 rounded-lg">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-sm font-medium text-gray-700">${suggestion.type.toUpperCase()}</span>
                    <span class="text-xs px-2 py-1 rounded-full ${this.getConfidenceColor(suggestion.confidence)}">${suggestion.confidence}%</span>
                </div>
                <p class="text-sm text-gray-600">${suggestion.message}</p>
            </div>
        `).join('');
    }

    // Generate enhanced content
    generateEnhancedContent() {
        const { title, description, type } = this.currentContent;
        
        const enhancedTitle = this.enhanceTitle(title, type);
        const enhancedDescription = this.enhanceDescription(description, type);
        const enhancedCriteria = this.enhanceCriteria(type);

        return {
            title: enhancedTitle,
            description: enhancedDescription,
            criteria: enhancedCriteria
        };
    }

    // Enhance title
    enhanceTitle(title, type) {
        if (!title) return '';

        const templates = {
            feature: [
                'Implement comprehensive {title} functionality',
                'Develop advanced {title} feature set',
                'Create robust {title} system integration'
            ],
            bug: [
                'Resolve critical {title} issue',
                'Fix {title} functionality defect',
                'Address {title} system bug'
            ],
            improvement: [
                'Enhance existing {title} capabilities',
                'Optimize {title} performance metrics',
                'Streamline {title} user experience'
            ],
            technical: [
                'Modernize {title} architecture',
                'Refactor {title} codebase',
                'Upgrade {title} technology stack'
            ]
        };

        const template = templates[type] || templates.feature;
        const selectedTemplate = template[Math.floor(Math.random() * template.length)];
        
        return selectedTemplate.replace('{title}', title);
    }

    // Enhance description
    enhanceDescription(description, type) {
        if (!description) return '';

        const enhancements = {
            feature: [
                'This feature will significantly improve user productivity by',
                'The implementation includes comprehensive testing and',
                'Security considerations have been integrated throughout'
            ],
            bug: [
                'Root cause analysis indicates the issue stems from',
                'The fix has been thoroughly tested across multiple scenarios',
                'Monitoring has been implemented to prevent recurrence'
            ],
            improvement: [
                'Performance metrics show a 40% improvement in',
                'User feedback has been incorporated to enhance',
                'The optimization reduces technical debt while maintaining'
            ],
            technical: [
                'This modernization addresses critical security vulnerabilities',
                'The upgrade ensures compatibility with current standards',
                'Legacy dependencies have been systematically removed'
            ]
        };

        const template = enhancements[type] || enhancements.feature;
        const selectedEnhancement = template[Math.floor(Math.random() * template.length)];
        
        return `${description}\n\n${selectedEnhancement}`;
    }

    // Enhance criteria
    enhanceCriteria(type) {
        const criteriaTemplates = {
            feature: [
                'Feature is accessible via standard user interface',
                'All edge cases are handled gracefully',
                'Performance meets defined SLA requirements',
                'Security review has been completed',
                'Documentation is updated and comprehensive'
            ],
            bug: [
                'Issue is reproducible and resolved',
                'No regression in existing functionality',
                'Error handling is properly implemented',
                'Fix is deployed to all affected environments',
                'Monitoring alerts are configured'
            ],
            improvement: [
                'Performance benchmarks show improvement',
                'User experience is measurably enhanced',
                'No negative impact on existing features',
                'Metrics are tracked and reported',
                'Stakeholder feedback is positive'
            ],
            technical: [
                'Code passes all quality gates',
                'Dependencies are updated and secure',
                'Build and deployment processes work',
                'Documentation reflects new architecture',
                'Team is trained on new technology'
            ]
        };

        return criteriaTemplates[type] || criteriaTemplates.feature;
    }

    // Calculate quality score
    calculateQualityScore() {
        const { title, description } = this.currentContent;
        let score = 50; // Base score

        // Title quality
        if (title && title.length > 10) score += 15;
        if (title && title.length > 20) score += 10;

        // Description quality
        if (description) {
            const wordCount = description.split(' ').length;
            if (wordCount > 20) score += 10;
            if (wordCount > 50) score += 10;
            if (description.includes('so that')) score += 5;
        }

        return Math.min(score, 95);
    }

    // Update enhanced output UI
    updateEnhancedOutput() {
        const { title, description, criteria } = this.enhancedContent;

        // Update title
        const titleElement = document.getElementById('enhancedTitle');
        if (titleElement) {
            titleElement.innerHTML = this.highlightEnhancements(title);
            titleElement.classList.remove('text-gray-500');
        }

        // Update description
        const descriptionElement = document.getElementById('enhancedDescription');
        if (descriptionElement) {
            descriptionElement.innerHTML = this.highlightEnhancements(description);
            descriptionElement.classList.remove('text-gray-500');
        }

        // Update criteria
        const criteriaElement = document.getElementById('enhancedCriteria');
        if (criteriaElement) {
            criteriaElement.innerHTML = criteria.map(criterion => 
                `<div class="flex items-start space-x-2 p-2 bg-gray-50 rounded">
                    <input type="checkbox" class="mt-1 flex-shrink-0">
                    <span class="text-sm text-gray-700">${this.highlightEnhancements(criterion)}</span>
                </div>`
            ).join('');
            criteriaElement.classList.remove('text-gray-500');
        }
    }

    // Highlight enhancements in text
    highlightEnhancements(text) {
        // Simple highlighting of enhanced words
        const words = text.split(' ');
        return words.map((word, index) => {
            if (word.length > 8 && Math.random() > 0.8) {
                return `<span class="enhancement-badge quality-good">${word}</span>`;
            }
            return word;
        }).join(' ');
    }

    // Update quality score
    updateQualityScore() {
        const scoreElement = document.getElementById('qualityScore');
        const barElement = document.getElementById('qualityBar');

        if (scoreElement) {
            scoreElement.textContent = `${this.qualityScore}%`;
            const quality = EPICBuilder.formatConfidence(this.qualityScore);
            scoreElement.className = `text-2xl font-bold ${quality.color.replace('text-', 'text-')}`;
        }

        if (barElement) {
            barElement.style.width = `${this.qualityScore}%`;
        }
    }

    // Generate AI suggestions
    generateAISuggestions() {
        const suggestions = [
            {
                type: 'clarity',
                message: 'Consider adding more specific technical requirements',
                confidence: 85
            },
            {
                type: 'testing',
                message: 'Include performance benchmarks in acceptance criteria',
                confidence: 78
            },
            {
                type: 'security',
                message: 'Add security considerations to the implementation plan',
                confidence: 92
            }
        ];

        const container = document.getElementById('aiSuggestions');
        if (!container) return;

        container.innerHTML = suggestions.map(suggestion => `
            <div class="ai-suggestion p-3 rounded-lg">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-sm font-medium text-gray-700">${suggestion.type.toUpperCase()}</span>
                    <span class="text-xs px-2 py-1 rounded-full ${this.getConfidenceColor(suggestion.confidence)}">${suggestion.confidence}%</span>
                </div>
                <p class="text-sm text-gray-600">${suggestion.message}</p>
            </div>
        `).join('');
    }

    // Get confidence color
    getConfidenceColor(confidence) {
        if (confidence >= 90) return 'bg-green-100 text-green-800';
        if (confidence >= 75) return 'bg-blue-100 text-blue-800';
        if (confidence >= 50) return 'bg-yellow-100 text-yellow-800';
        return 'bg-red-100 text-red-800';
    }

    // Enable accept buttons
    enableAcceptButtons() {
        const buttons = ['acceptTitle', 'acceptDescription', 'acceptCriteria', 'acceptAllBtn'];
        buttons.forEach(id => {
            const button = document.getElementById(id);
            if (button) button.disabled = false;
        });
    }

    // Accept title
    acceptTitle() {
        const enhancedTitle = this.enhancedContent.title;
        const titleInput = document.getElementById('epicTitle');
        if (titleInput) {
            titleInput.value = enhancedTitle;
            this.currentContent.title = enhancedTitle;
            this.autoSave();
            EPICBuilder.showNotification('Title accepted!', 'success');
        }
    }

    // Accept description
    acceptDescription() {
        const enhancedDescription = this.enhancedContent.description;
        const descriptionInput = document.getElementById('epicDescription');
        if (descriptionInput) {
            descriptionInput.value = enhancedDescription;
            this.currentContent.description = enhancedDescription;
            this.autoSave();
            EPICBuilder.showNotification('Description accepted!', 'success');
        }
    }

    // Accept criteria
    acceptCriteria() {
        // This would update the criteria list
        EPICBuilder.showNotification('Criteria accepted!', 'success');
    }

    // Accept all
    acceptAll() {
        this.acceptTitle();
        this.acceptDescription();
        this.acceptCriteria();
        EPICBuilder.showNotification('All enhancements accepted!', 'success');
    }

    // Add criteria
    addCriteria() {
        const criteriaList = document.getElementById('criteriaList');
        if (!criteriaList) return;

        const newCriterion = document.createElement('div');
        newCriterion.className = 'flex items-center space-x-2';
        newCriterion.innerHTML = `
            <input type="text" placeholder="Add acceptance criterion..." class="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent text-sm">
            <button class="px-3 py-2 text-red-600 hover:text-red-700 transition-colors text-sm remove-criterion">Remove</button>
        `;

        criteriaList.appendChild(newCriterion);

        // Add remove event listener
        newCriterion.querySelector('.remove-criterion').addEventListener('click', () => {
            criteriaList.removeChild(newCriterion);
        });
    }

    // Update character count
    updateCharCount(count) {
        const charCountElement = document.getElementById('charCount');
        if (charCountElement) {
            charCountElement.textContent = `${count} characters`;
        }
    }

    // Auto-save
    autoSave() {
        const content = {
            title: document.getElementById('epicTitle')?.value || '',
            description: document.getElementById('epicDescription')?.value || '',
            type: document.getElementById('epicType')?.value || 'feature',
            timestamp: new Date().toISOString()
        };

        EPICBuilder.saveProgress('auto-save', content);
    }

    // Save draft
    saveDraft() {
        const draft = {
            id: Date.now().toString(),
            title: document.getElementById('epicTitle')?.value || 'Untitled EPIC',
            description: document.getElementById('epicDescription')?.value || '',
            type: document.getElementById('epicType')?.value || 'feature',
            timestamp: new Date().toISOString(),
            qualityScore: this.qualityScore
        };

        const drafts = EPICBuilder.loadProgress('drafts') || [];
        drafts.unshift(draft);
        
        // Keep only last 10 drafts
        if (drafts.length > 10) {
            drafts.splice(10);
        }

        EPICBuilder.saveProgress('drafts', drafts);
        this.loadSavedDrafts();
        EPICBuilder.showNotification('Draft saved successfully!', 'success');
    }

    // Load saved drafts
    loadSavedDrafts() {
        const drafts = EPICBuilder.loadProgress('drafts') || [];
        const container = document.getElementById('savedDrafts');
        
        if (!container) return;

        if (drafts.length === 0) {
            container.innerHTML = '<p class="text-gray-500 text-sm">No saved drafts</p>';
            return;
        }

        container.innerHTML = drafts.map(draft => `
            <div class="p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer draft-item" data-id="${draft.id}">
                <div class="flex items-center justify-between mb-1">
                    <h4 class="font-medium text-gray-900 truncate">${draft.title}</h4>
                    <span class="text-xs text-gray-500">${new Date(draft.timestamp).toLocaleDateString()}</span>
                </div>
                <p class="text-sm text-gray-600 truncate">${draft.description.substring(0, 100)}...</p>
                <div class="flex items-center justify-between mt-2">
                    <span class="text-xs px-2 py-1 rounded-full bg-blue-100 text-blue-800">${draft.type}</span>
                    <span class="text-xs text-gray-500">Quality: ${draft.qualityScore || 0}%</span>
                </div>
            </div>
        `).join('');

        // Add click handlers for drafts
        container.querySelectorAll('.draft-item').forEach(item => {
            item.addEventListener('click', () => {
                this.loadDraft(item.dataset.id);
            });
        });
    }

    // Load draft
    loadDraft(draftId) {
        const drafts = EPICBuilder.loadProgress('drafts') || [];
        const draft = drafts.find(d => d.id === draftId);
        
        if (!draft) return;

        document.getElementById('epicTitle').value = draft.title;
        document.getElementById('epicDescription').value = draft.description;
        document.getElementById('epicType').value = draft.type;
        
        this.updateCharCount(draft.description.length);
        EPICBuilder.showNotification('Draft loaded!', 'success');
    }

    // Load auto-saved content
    loadAutoSavedContent() {
        const autoSave = EPICBuilder.loadProgress('auto-save');
        if (autoSave) {
            document.getElementById('epicTitle').value = autoSave.title || '';
            document.getElementById('epicDescription').value = autoSave.description || '';
            document.getElementById('epicType').value = autoSave.type || 'feature';
            this.updateCharCount(autoSave.description?.length || 0);
        }
    }

    // Clear form
    clearForm() {
        document.getElementById('epicTitle').value = '';
        document.getElementById('epicDescription').value = '';
        document.getElementById('epicType').value = 'feature';
        this.updateCharCount(0);
        
        // Clear enhanced output
        document.getElementById('enhancedTitle').innerHTML = 'AI-enhanced title will appear here...';
        document.getElementById('enhancedDescription').innerHTML = 'AI-enhanced description will appear here...';
        document.getElementById('enhancedCriteria').innerHTML = 'Enhanced criteria will appear here...';
        
        // Reset quality score
        document.getElementById('qualityScore').textContent = '--';
        document.getElementById('qualityBar').style.width = '0%';
        
        // Disable accept buttons
        const buttons = ['acceptTitle', 'acceptDescription', 'acceptCriteria', 'acceptAllBtn'];
        buttons.forEach(id => {
            const button = document.getElementById(id);
            if (button) button.disabled = true;
        });

        EPICBuilder.showNotification('Form cleared!', 'info');
    }

    // Export functions
    exportMarkdown() {
        const content = this.generateMarkdown();
        this.downloadFile(content, 'epic.md', 'text/markdown');
        EPICBuilder.showNotification('Markdown exported!', 'success');
    }

    exportGitLab() {
        const content = this.generateGitLabFormat();
        this.downloadFile(content, 'gitlab-epic.md', 'text/markdown');
        EPICBuilder.showNotification('GitLab format exported!', 'success');
    }

    exportPDF() {
        EPICBuilder.showNotification('PDF export coming soon!', 'info');
    }

    copyToClipboard() {
        const content = this.generateMarkdown();
        navigator.clipboard.writeText(content).then(() => {
            EPICBuilder.showNotification('Copied to clipboard!', 'success');
        });
    }

    // Generate markdown
    generateMarkdown() {
        const title = document.getElementById('epicTitle')?.value || '';
        const description = document.getElementById('epicDescription')?.value || '';
        const type = document.getElementById('epicType')?.value || 'feature';

        return `# ${title}

## Description
${description}

## Type
${type}

## Acceptance Criteria
- [ ] Feature is fully implemented
- [ ] All tests pass
- [ ] Documentation is updated
- [ ] Code review completed

---
*Generated by EPIC Builder Pro*`;
    }

    // Generate GitLab format
    generateGitLabFormat() {
        const title = document.getElementById('epicTitle')?.value || '';
        const description = document.getElementById('epicDescription')?.value || '';
        const type = document.getElementById('epicType')?.value || 'feature';

        return `## Summary
${title}

## Description
${description}

## Type
${type}

## Acceptance Criteria
- [ ] Implementation complete
- [ ] Testing complete
- [ ] Documentation updated
- [ ] Performance validated

/label ~${type}
/assign @developer
/due 2 weeks`;
    }

    // Download file
    downloadFile(content, filename, mimeType) {
        const blob = new Blob([content], { type: mimeType });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    }
}

// Initialize AI Service when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const aiService = new AIService();
    aiService.init();
});