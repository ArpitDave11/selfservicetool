// Epic Builder Type Definitions

export type EpicStatus = 'draft' | 'in_review' | 'approved' | 'published';
export type SuggestionSeverity = 'high' | 'medium' | 'low';
export type SuggestionStatus = 'pending' | 'accepted' | 'discarded' | 'overridden';
export type VersionCreator = 'user' | 'llm' | 'chat';

// Wizard step configuration
export interface WizardStep {
  id: number;
  title: string;
  description: string;
  fields: WizardField[];
}

export interface WizardField {
  name: string;
  label: string;
  placeholder: string;
  type: 'text' | 'textarea' | 'date' | 'tags';
  required: boolean;
  minLength?: number;
}

// Epic form data structure
export interface EpicFormData {
  // Step 1: Basics
  projectName: string;
  targetDate: string;
  stakeholders: string[];
  labels: string[];

  // Step 2: Objective & Problem
  objective: string;
  problemStatement: string;

  // Step 3: Scope
  inScope: string;
  outOfScope: string;

  // Step 4: Assumptions & Teams
  assumptions: string;
  constraints: string;
  teamsInvolved: string;
  rolesAndResponsibilities: string;

  // Step 5: Features & NFRs
  features: string;
  userStories: string;
  nfrPriorities: string;
  targetCompletion: string;
}

// Refinement comparison
export interface FieldRefinement {
  fieldName: string;
  originalValue: string;
  refinedValue: string;
  clarifyingQuestions: string[];
  warnings: string[];
  isAccepted: boolean;
}

// Chat message for modifications
export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  appliedChanges?: string;
}

// Application view state
export type AppView = 'dashboard' | 'wizard' | 'workspace';

// Dashboard filter options
export interface DashboardFilters {
  search: string;
  status: EpicStatus | 'all';
  sortBy: 'created' | 'updated' | 'name';
  sortOrder: 'asc' | 'desc';
}

// Wizard step data for form state
export const WIZARD_STEPS: WizardStep[] = [
  {
    id: 1,
    title: 'Basics',
    description: 'Project information and metadata',
    fields: [
      { name: 'projectName', label: 'Project Name', placeholder: 'Enter project name', type: 'text', required: true, minLength: 3 },
      { name: 'targetDate', label: 'Target Date', placeholder: 'YYYY-MM-DD', type: 'date', required: false },
      { name: 'stakeholders', label: 'Stakeholders', placeholder: 'Add stakeholder names', type: 'tags', required: false },
      { name: 'labels', label: 'Labels', placeholder: 'Add labels', type: 'tags', required: false },
    ],
  },
  {
    id: 2,
    title: 'Objective & Problem',
    description: 'Define the goal and problem being solved',
    fields: [
      { name: 'objective', label: 'Objective', placeholder: 'What is the main objective of this epic?', type: 'textarea', required: true, minLength: 20 },
      { name: 'problemStatement', label: 'Problem Statement', placeholder: 'What problem are we solving?', type: 'textarea', required: true, minLength: 20 },
    ],
  },
  {
    id: 3,
    title: 'Scope',
    description: 'Define what is and is not included',
    fields: [
      { name: 'inScope', label: 'In Scope', placeholder: 'What is included in this epic?', type: 'textarea', required: true, minLength: 10 },
      { name: 'outOfScope', label: 'Out of Scope', placeholder: 'What is explicitly excluded?', type: 'textarea', required: false },
    ],
  },
  {
    id: 4,
    title: 'Assumptions & Teams',
    description: 'Assumptions, constraints, and team structure',
    fields: [
      { name: 'assumptions', label: 'Assumptions', placeholder: 'What assumptions are we making?', type: 'textarea', required: false },
      { name: 'constraints', label: 'Constraints', placeholder: 'What constraints exist?', type: 'textarea', required: false },
      { name: 'teamsInvolved', label: 'Teams Involved', placeholder: 'Which teams will work on this?', type: 'textarea', required: true, minLength: 5 },
      { name: 'rolesAndResponsibilities', label: 'Roles & Responsibilities', placeholder: 'Define roles and their responsibilities', type: 'textarea', required: false },
    ],
  },
  {
    id: 5,
    title: 'Features & NFRs',
    description: 'Features, user stories, and non-functional requirements',
    fields: [
      { name: 'features', label: 'Features', placeholder: 'List the main features', type: 'textarea', required: true, minLength: 10 },
      { name: 'userStories', label: 'User Stories', placeholder: 'As a [user], I want [feature] so that [benefit]', type: 'textarea', required: false },
      { name: 'nfrPriorities', label: 'NFR Priorities', placeholder: 'Performance, Security, Scalability, etc.', type: 'textarea', required: false },
      { name: 'targetCompletion', label: 'Target Completion', placeholder: 'Q1 2025, Sprint 10, etc.', type: 'text', required: false },
    ],
  },
];

// Initial form data
export const INITIAL_FORM_DATA: EpicFormData = {
  projectName: '',
  targetDate: '',
  stakeholders: [],
  labels: [],
  objective: '',
  problemStatement: '',
  inScope: '',
  outOfScope: '',
  assumptions: '',
  constraints: '',
  teamsInvolved: '',
  rolesAndResponsibilities: '',
  features: '',
  userStories: '',
  nfrPriorities: '',
  targetCompletion: '',
};

// Severity color mapping
export const SEVERITY_COLORS: Record<SuggestionSeverity, { bg: string; text: string; border: string }> = {
  high: { bg: 'bg-red-50', text: 'text-red-700', border: 'border-red-200' },
  medium: { bg: 'bg-orange-50', text: 'text-orange-700', border: 'border-orange-200' },
  low: { bg: 'bg-yellow-50', text: 'text-yellow-700', border: 'border-yellow-200' },
};

// Status badge colors
export const STATUS_COLORS: Record<EpicStatus, { bg: string; text: string }> = {
  draft: { bg: 'bg-gray-100', text: 'text-gray-700' },
  in_review: { bg: 'bg-blue-100', text: 'text-blue-700' },
  approved: { bg: 'bg-green-100', text: 'text-green-700' },
  published: { bg: 'bg-purple-100', text: 'text-purple-700' },
};
