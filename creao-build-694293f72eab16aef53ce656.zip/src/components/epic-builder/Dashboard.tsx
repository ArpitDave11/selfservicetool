import { useState, useEffect } from 'react';
import { Search, Plus, FileText, Calendar, Tag, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { type EpicSessionModel, EpicSessionStatus, EpicSessionORM } from '@/components/data/orm/orm_epic_session';
import { type EpicStatus, STATUS_COLORS, type DashboardFilters } from '@/types/epic';
import { cn } from '@/lib/utils';

interface DashboardProps {
  onCreateNew: () => void;
  onOpenSession: (session: EpicSessionModel) => void;
}

function getStatusLabel(status: EpicSessionStatus): EpicStatus {
  switch (status) {
    case EpicSessionStatus.Draft: return 'draft';
    case EpicSessionStatus.InReview: return 'in_review';
    case EpicSessionStatus.Approved: return 'approved';
    case EpicSessionStatus.Published: return 'published';
    default: return 'draft';
  }
}

function formatDate(timestamp: string): string {
  if (!timestamp) return 'N/A';
  const date = new Date(parseInt(timestamp) * 1000);
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

export function Dashboard({ onCreateNew, onOpenSession }: DashboardProps) {
  const [sessions, setSessions] = useState<EpicSessionModel[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState<DashboardFilters>({
    search: '',
    status: 'all',
    sortBy: 'updated',
    sortOrder: 'desc',
  });

  useEffect(() => {
    async function loadSessions() {
      setLoading(true);
      try {
        const orm = EpicSessionORM.getInstance();
        const allSessions = await orm.getAllEpicSession();
        setSessions(allSessions);
      } catch (error) {
        console.error('Failed to load sessions:', error);
      } finally {
        setLoading(false);
      }
    }
    loadSessions();
  }, []);

  const filteredSessions = sessions
    .filter(session => {
      const matchesSearch = session.project_name.toLowerCase().includes(filters.search.toLowerCase());
      const matchesStatus = filters.status === 'all' || getStatusLabel(session.status) === filters.status;
      return matchesSearch && matchesStatus;
    })
    .sort((a, b) => {
      const aValue = filters.sortBy === 'name' ? a.project_name : (filters.sortBy === 'created' ? a.create_time : a.update_time);
      const bValue = filters.sortBy === 'name' ? b.project_name : (filters.sortBy === 'created' ? b.create_time : b.update_time);
      const comparison = aValue.localeCompare(bValue);
      return filters.sortOrder === 'asc' ? comparison : -comparison;
    });

  return (
    <div className="min-h-screen bg-[#F5F5F5]">
      {/* Header */}
      <header className="bg-white border-b border-[#E6E6E6] px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-[#333333]">Epic Builder</h1>
            <p className="text-sm text-gray-500">Create and manage GitLab Technical Design Epics</p>
          </div>
          <Button
            onClick={onCreateNew}
            className="bg-[#C10024] hover:bg-[#a0001d] text-white"
          >
            <Plus className="h-4 w-4 mr-2" />
            Create New Epic
          </Button>
        </div>
      </header>

      {/* Filters */}
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="bg-white rounded-lg border border-[#E6E6E6] p-4">
          <div className="flex flex-wrap gap-4 items-center">
            <div className="flex-1 min-w-[200px]">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search epics..."
                  value={filters.search}
                  onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
                  className="pl-10"
                />
              </div>
            </div>
            <Select
              value={filters.status}
              onValueChange={(value) => setFilters(prev => ({ ...prev, status: value as DashboardFilters['status'] }))}
            >
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="in_review">In Review</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="published">Published</SelectItem>
              </SelectContent>
            </Select>
            <Select
              value={filters.sortBy}
              onValueChange={(value) => setFilters(prev => ({ ...prev, sortBy: value as DashboardFilters['sortBy'] }))}
            >
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="updated">Last Updated</SelectItem>
                <SelectItem value="created">Created</SelectItem>
                <SelectItem value="name">Name</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Session List */}
      <div className="max-w-7xl mx-auto px-6 pb-8">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#C10024]" />
          </div>
        ) : filteredSessions.length === 0 ? (
          <Card className="border-[#E6E6E6]">
            <CardContent className="py-12 text-center">
              <FileText className="h-12 w-12 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-[#333333] mb-2">No epics found</h3>
              <p className="text-gray-500 mb-4">
                {filters.search || filters.status !== 'all'
                  ? 'Try adjusting your filters'
                  : 'Get started by creating your first epic'}
              </p>
              {!filters.search && filters.status === 'all' && (
                <Button onClick={onCreateNew} className="bg-[#C10024] hover:bg-[#a0001d] text-white">
                  <Plus className="h-4 w-4 mr-2" />
                  Create New Epic
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredSessions.map((session) => {
              const statusLabel = getStatusLabel(session.status);
              const colors = STATUS_COLORS[statusLabel];

              return (
                <Card
                  key={session.id}
                  className="border-[#E6E6E6] hover:border-[#C10024] transition-colors cursor-pointer"
                  onClick={() => onOpenSession(session)}
                >
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between">
                      <CardTitle className="text-lg text-[#333333] line-clamp-1">
                        {session.project_name}
                      </CardTitle>
                      <Badge className={cn(colors.bg, colors.text, 'capitalize')}>
                        {statusLabel.replace('_', ' ')}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 text-sm text-gray-500">
                      {session.target_date && (
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4" />
                          <span>Target: {session.target_date}</span>
                        </div>
                      )}
                      {session.stakeholders && session.stakeholders.length > 0 && (
                        <div className="flex items-center gap-2">
                          <Users className="h-4 w-4" />
                          <span>{session.stakeholders.length} stakeholder(s)</span>
                        </div>
                      )}
                      {session.labels && session.labels.length > 0 && (
                        <div className="flex items-center gap-2 flex-wrap">
                          <Tag className="h-4 w-4" />
                          {session.labels.slice(0, 3).map((label, i) => (
                            <Badge key={i} variant="outline" className="text-xs">
                              {label}
                            </Badge>
                          ))}
                          {session.labels.length > 3 && (
                            <span className="text-xs">+{session.labels.length - 3}</span>
                          )}
                        </div>
                      )}
                      <div className="text-xs text-gray-400 pt-2">
                        Updated {formatDate(session.update_time)}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
