import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Copy, Check, ExternalLink, GitBranch } from 'lucide-react';

interface MermaidDiagramProps {
  diagram: string;
}

export function MermaidDiagram({ diagram }: MermaidDiagramProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(diagram);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  // Generate Mermaid Live Editor URL for preview
  const getMermaidLiveUrl = () => {
    try {
      const state = {
        code: diagram,
        mermaid: { theme: 'default' },
        autoSync: true,
        updateDiagram: true,
      };
      const encoded = btoa(JSON.stringify(state));
      return `https://mermaid.live/edit#base64:${encoded}`;
    } catch {
      return null;
    }
  };

  const liveUrl = getMermaidLiveUrl();

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium text-[#333333]">Architecture Diagram</h3>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleCopy}
            className="text-xs"
          >
            {copied ? (
              <>
                <Check className="h-3 w-3 mr-1" />
                Copied
              </>
            ) : (
              <>
                <Copy className="h-3 w-3 mr-1" />
                Copy
              </>
            )}
          </Button>
          {liveUrl && (
            <Button
              variant="outline"
              size="sm"
              asChild
              className="text-xs"
            >
              <a href={liveUrl} target="_blank" rel="noopener noreferrer">
                <ExternalLink className="h-3 w-3 mr-1" />
                Open in Editor
              </a>
            </Button>
          )}
        </div>
      </div>

      {/* Diagram preview placeholder */}
      <Card className="border-[#E6E6E6]">
        <CardContent className="p-6">
          <div className="flex flex-col items-center justify-center text-center py-4">
            <GitBranch className="h-12 w-12 text-[#C10024] mb-3" />
            <p className="text-sm text-gray-600 mb-2">
              Mermaid diagram generated successfully
            </p>
            <p className="text-xs text-gray-500">
              Click "Open in Editor" to view the rendered diagram, or copy the syntax to use in GitLab/GitHub.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Raw syntax display */}
      <Card className="border-[#E6E6E6]">
        <CardContent className="p-4">
          <h4 className="text-xs font-medium text-gray-500 mb-2">Mermaid Syntax</h4>
          <pre className="text-xs bg-gray-50 p-3 rounded overflow-auto max-h-48 font-mono">
            <code>{diagram}</code>
          </pre>
          <p className="text-xs text-gray-400 mt-2">
            Paste this into GitLab/GitHub markdown or any Mermaid-compatible viewer.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
