import { useState, useCallback } from 'react';
import { type EpicSessionModel, EpicSessionStatus, EpicSessionORM } from '@/components/data/orm/orm_epic_session';
import { type EpicFieldModel, EpicFieldORM } from '@/components/data/orm/orm_epic_field';
import { type EpicVersionModel, EpicVersionCreatedBy, EpicVersionORM } from '@/components/data/orm/orm_epic_version';
import { type ReviewSuggestionModel, ReviewSuggestionStatus, ReviewSuggestionSeverity, ReviewSuggestionORM } from '@/components/data/orm/orm_review_suggestion';
import { type AppView, type EpicFormData, INITIAL_FORM_DATA } from '@/types/epic';
import { Dashboard } from './Dashboard';
import { EpicWizard } from './EpicWizard';
import { EpicWorkspace } from './EpicWorkspace';

export function EpicBuilderApp() {
  const [view, setView] = useState<AppView>('dashboard');
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [formData, setFormData] = useState<EpicFormData>(INITIAL_FORM_DATA);
  const [markdownContent, setMarkdownContent] = useState<string>('');
  const [currentVersionId, setCurrentVersionId] = useState<string | null>(null);

  // Navigate to create new epic
  const handleCreateNew = useCallback(() => {
    setFormData(INITIAL_FORM_DATA);
    setCurrentSessionId(null);
    setMarkdownContent('');
    setCurrentVersionId(null);
    setView('wizard');
  }, []);

  // Open existing epic session
  const handleOpenSession = useCallback(async (session: EpicSessionModel) => {
    setCurrentSessionId(session.id);

    // Load form data from fields
    const fieldORM = EpicFieldORM.getInstance();
    const fields = await fieldORM.getAllEpicField();
    const sessionFields = fields.filter(f => f.session_id === session.id);

    const loadedFormData: EpicFormData = { ...INITIAL_FORM_DATA };
    loadedFormData.projectName = session.project_name;
    loadedFormData.targetDate = session.target_date || '';
    loadedFormData.stakeholders = session.stakeholders || [];
    loadedFormData.labels = session.labels || [];

    sessionFields.forEach(field => {
      const value = field.refined_value || field.original_value || '';
      const key = field.field_name as keyof EpicFormData;
      if (key in loadedFormData && typeof loadedFormData[key] === 'string') {
        (loadedFormData[key] as string) = value;
      }
    });

    setFormData(loadedFormData);

    // Load latest version
    const versionORM = EpicVersionORM.getInstance();
    const versions = await versionORM.getAllEpicVersion();
    const sessionVersions = versions
      .filter(v => v.session_id === session.id)
      .sort((a, b) => b.version_number - a.version_number);

    if (sessionVersions.length > 0) {
      setMarkdownContent(sessionVersions[0].markdown_content);
      setCurrentVersionId(sessionVersions[0].id);
      setView('workspace');
    } else {
      setView('wizard');
    }
  }, []);

  // Complete wizard and generate epic
  const handleWizardComplete = useCallback(async (data: EpicFormData, generatedMarkdown: string, sessionId: string) => {
    setFormData(data);
    setMarkdownContent(generatedMarkdown);
    setCurrentSessionId(sessionId);

    // Create version record
    const versionORM = EpicVersionORM.getInstance();
    const versions = await versionORM.insertEpicVersion([{
      id: '',
      data_creator: '',
      data_updater: '',
      create_time: '',
      update_time: '',
      session_id: sessionId,
      markdown_content: generatedMarkdown,
      version_number: 1,
      created_by: EpicVersionCreatedBy.LLM,
    }]);

    if (versions.length > 0) {
      setCurrentVersionId(versions[0].id);
    }

    // Update session status
    const sessionORM = EpicSessionORM.getInstance();
    const sessions = await sessionORM.getEpicSessionById(sessionId);
    if (sessions.length > 0) {
      await sessionORM.setEpicSessionById(sessionId, {
        ...sessions[0],
        status: EpicSessionStatus.InReview,
      });
    }

    setView('workspace');
  }, []);

  // Update markdown content
  const handleMarkdownUpdate = useCallback(async (newContent: string, createdBy: 'user' | 'llm' | 'chat') => {
    setMarkdownContent(newContent);

    if (currentSessionId) {
      const versionORM = EpicVersionORM.getInstance();
      const versions = await versionORM.getAllEpicVersion();
      const sessionVersions = versions.filter(v => v.session_id === currentSessionId);
      const nextVersionNumber = sessionVersions.length + 1;

      const createdByEnum = createdBy === 'user'
        ? EpicVersionCreatedBy.User
        : createdBy === 'llm'
          ? EpicVersionCreatedBy.LLM
          : EpicVersionCreatedBy.Chat;

      const newVersions = await versionORM.insertEpicVersion([{
        id: '',
        data_creator: '',
        data_updater: '',
        create_time: '',
        update_time: '',
        session_id: currentSessionId,
        markdown_content: newContent,
        version_number: nextVersionNumber,
        created_by: createdByEnum,
      }]);

      if (newVersions.length > 0) {
        setCurrentVersionId(newVersions[0].id);
      }
    }
  }, [currentSessionId]);

  // Navigate back to dashboard
  const handleBackToDashboard = useCallback(() => {
    setView('dashboard');
    setCurrentSessionId(null);
    setFormData(INITIAL_FORM_DATA);
    setMarkdownContent('');
    setCurrentVersionId(null);
  }, []);

  return (
    <div className="min-h-screen bg-[#F5F5F5]">
      {view === 'dashboard' && (
        <Dashboard
          onCreateNew={handleCreateNew}
          onOpenSession={handleOpenSession}
        />
      )}
      {view === 'wizard' && (
        <EpicWizard
          initialData={formData}
          sessionId={currentSessionId}
          onComplete={handleWizardComplete}
          onCancel={handleBackToDashboard}
        />
      )}
      {view === 'workspace' && (
        <EpicWorkspace
          sessionId={currentSessionId!}
          versionId={currentVersionId!}
          markdownContent={markdownContent}
          formData={formData}
          onMarkdownUpdate={handleMarkdownUpdate}
          onBack={handleBackToDashboard}
        />
      )}
    </div>
  );
}
