import { useState, useCallback } from 'react';
import { ChevronLeft, ChevronRight, Sparkles, Check, X, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { EpicSessionORM, EpicSessionStatus } from '@/components/data/orm/orm_epic_session';
import { EpicFieldORM } from '@/components/data/orm/orm_epic_field';
import { type EpicFormData, type FieldRefinement, WIZARD_STEPS, INITIAL_FORM_DATA } from '@/types/epic';
import { useFieldRefinementMutation, useEpicGenerationMutation } from '@/hooks/use-openai-gpt-chat';
import { cn } from '@/lib/utils';

interface EpicWizardProps {
  initialData: EpicFormData;
  sessionId: string | null;
  onComplete: (data: EpicFormData, generatedMarkdown: string, sessionId: string) => void;
  onCancel: () => void;
}

export function EpicWizard({ initialData, sessionId, onComplete, onCancel }: EpicWizardProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<EpicFormData>(initialData);
  const [refinements, setRefinements] = useState<Record<string, FieldRefinement>>({});
  const [tagInputs, setTagInputs] = useState<Record<string, string>>({});
  const [isGenerating, setIsGenerating] = useState(false);

  const fieldRefinement = useFieldRefinementMutation();
  const epicGeneration = useEpicGenerationMutation();

  const currentStepData = WIZARD_STEPS.find(s => s.id === currentStep)!;

  const updateField = useCallback((fieldName: string, value: string | string[]) => {
    setFormData(prev => ({ ...prev, [fieldName]: value }));
  }, []);

  const handleTagAdd = useCallback((fieldName: string) => {
    const input = tagInputs[fieldName]?.trim();
    if (input) {
      const currentTags = (formData[fieldName as keyof EpicFormData] as string[]) || [];
      if (!currentTags.includes(input)) {
        updateField(fieldName, [...currentTags, input]);
      }
      setTagInputs(prev => ({ ...prev, [fieldName]: '' }));
    }
  }, [tagInputs, formData, updateField]);

  const handleTagRemove = useCallback((fieldName: string, tag: string) => {
    const currentTags = (formData[fieldName as keyof EpicFormData] as string[]) || [];
    updateField(fieldName, currentTags.filter(t => t !== tag));
  }, [formData, updateField]);

  const handleEnhanceField = useCallback(async (fieldName: string) => {
    const value = formData[fieldName as keyof EpicFormData];
    if (typeof value !== 'string' || !value.trim()) return;

    const context: Record<string, string> = {};
    Object.entries(formData).forEach(([key, val]) => {
      if (typeof val === 'string' && val.trim() && key !== fieldName) {
        context[key] = val;
      }
    });

    try {
      const result = await fieldRefinement.mutateAsync({
        fieldName,
        originalText: value,
        previousFieldsContext: context,
      });

      setRefinements(prev => ({
        ...prev,
        [fieldName]: {
          fieldName,
          originalValue: value,
          refinedValue: result.refinedText,
          clarifyingQuestions: result.clarifyingQuestions,
          warnings: result.warnings,
          isAccepted: false,
        },
      }));
    } catch (error) {
      console.error('Refinement failed:', error);
    }
  }, [formData, fieldRefinement]);

  const acceptRefinement = useCallback((fieldName: string) => {
    const refinement = refinements[fieldName];
    if (refinement) {
      updateField(fieldName, refinement.refinedValue);
      setRefinements(prev => ({
        ...prev,
        [fieldName]: { ...refinement, isAccepted: true },
      }));
    }
  }, [refinements, updateField]);

  const discardRefinement = useCallback((fieldName: string) => {
    setRefinements(prev => {
      const updated = { ...prev };
      delete updated[fieldName];
      return updated;
    });
  }, []);

  const validateStep = useCallback((): boolean => {
    for (const field of currentStepData.fields) {
      if (field.required) {
        const value = formData[field.name as keyof EpicFormData];
        if (typeof value === 'string' && !value.trim()) return false;
        if (Array.isArray(value) && value.length === 0 && field.required) return false;
        if (field.minLength && typeof value === 'string' && value.length < field.minLength) return false;
      }
    }
    return true;
  }, [currentStepData, formData]);

  const handleNext = useCallback(() => {
    if (currentStep < WIZARD_STEPS.length) {
      setCurrentStep(prev => prev + 1);
    }
  }, [currentStep]);

  const handlePrevious = useCallback(() => {
    if (currentStep > 1) {
      setCurrentStep(prev => prev - 1);
    }
  }, [currentStep]);

  const handleComplete = useCallback(async () => {
    setIsGenerating(true);
    try {
      // Create or update session
      const sessionORM = EpicSessionORM.getInstance();
      let finalSessionId = sessionId;

      if (!sessionId) {
        const sessions = await sessionORM.insertEpicSession([{
          id: '',
          data_creator: '',
          data_updater: '',
          create_time: '',
          update_time: '',
          project_name: formData.projectName,
          status: EpicSessionStatus.Draft,
          target_date: formData.targetDate || null,
          stakeholders: formData.stakeholders.length > 0 ? formData.stakeholders : null,
          labels: formData.labels.length > 0 ? formData.labels : null,
        }]);
        finalSessionId = sessions[0].id;
      }

      // Save fields
      const fieldORM = EpicFieldORM.getInstance();
      const fieldsToSave = WIZARD_STEPS.flatMap(step =>
        step.fields
          .filter(f => f.type !== 'tags')
          .map(field => {
            const value = formData[field.name as keyof EpicFormData];
            const refinement = refinements[field.name];
            return {
              id: '',
              data_creator: '',
              data_updater: '',
              create_time: '',
              update_time: '',
              session_id: finalSessionId!,
              field_name: field.name,
              original_value: typeof value === 'string' ? value : null,
              refined_value: refinement?.isAccepted ? refinement.refinedValue : null,
              step: step.id,
            };
          })
      );

      await fieldORM.insertEpicField(fieldsToSave);

      // Generate epic markdown
      const result = await epicGeneration.mutateAsync({
        objective: formData.objective,
        problemStatement: formData.problemStatement,
        scope: `In Scope: ${formData.inScope}\nOut of Scope: ${formData.outOfScope}`,
        assumptions: `Assumptions: ${formData.assumptions}\nConstraints: ${formData.constraints}`,
        teamsAndRoles: `Teams: ${formData.teamsInvolved}\nRoles: ${formData.rolesAndResponsibilities}`,
        features: formData.features,
        userStories: formData.userStories,
        nfrPriorities: formData.nfrPriorities,
        targetCompletion: formData.targetCompletion,
      });

      onComplete(formData, result.markdownContent, finalSessionId!);
    } catch (error) {
      console.error('Failed to complete wizard:', error);
    } finally {
      setIsGenerating(false);
    }
  }, [formData, sessionId, refinements, epicGeneration, onComplete]);

  return (
    <div className="min-h-screen bg-[#F5F5F5]">
      {/* Header */}
      <header className="bg-white border-b border-[#E6E6E6] px-6 py-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold text-[#333333]">Create Epic</h1>
            <Button variant="ghost" onClick={onCancel}>
              <X className="h-4 w-4 mr-2" />
              Cancel
            </Button>
          </div>

          {/* Step indicator */}
          <div className="flex items-center gap-2">
            {WIZARD_STEPS.map((step, index) => (
              <div key={step.id} className="flex items-center">
                <div
                  className={cn(
                    'flex items-center justify-center w-8 h-8 rounded-full text-sm font-medium transition-colors',
                    currentStep === step.id
                      ? 'bg-[#C10024] text-white'
                      : currentStep > step.id
                        ? 'bg-green-500 text-white'
                        : 'bg-gray-200 text-gray-500'
                  )}
                >
                  {currentStep > step.id ? <Check className="h-4 w-4" /> : step.id}
                </div>
                <span
                  className={cn(
                    'ml-2 text-sm hidden sm:inline',
                    currentStep === step.id ? 'text-[#333333] font-medium' : 'text-gray-500'
                  )}
                >
                  {step.title}
                </span>
                {index < WIZARD_STEPS.length - 1 && (
                  <div className={cn(
                    'w-8 h-0.5 mx-2',
                    currentStep > step.id ? 'bg-green-500' : 'bg-gray-200'
                  )} />
                )}
              </div>
            ))}
          </div>
        </div>
      </header>

      {/* Form Content */}
      <div className="max-w-4xl mx-auto px-6 py-8">
        <Card className="border-[#E6E6E6]">
          <CardHeader>
            <CardTitle className="text-[#333333]">{currentStepData.title}</CardTitle>
            <CardDescription>{currentStepData.description}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {currentStepData.fields.map((field) => {
              const value = formData[field.name as keyof EpicFormData];
              const refinement = refinements[field.name];
              const isRefining = fieldRefinement.isPending && fieldRefinement.variables?.fieldName === field.name;

              return (
                <div key={field.name} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor={field.name} className="text-[#333333]">
                      {field.label}
                      {field.required && <span className="text-[#C10024] ml-1">*</span>}
                    </Label>
                    {field.type === 'textarea' && typeof value === 'string' && value.trim() && (
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => handleEnhanceField(field.name)}
                        disabled={isRefining}
                        className="text-[#C10024] border-[#C10024] hover:bg-[#C10024] hover:text-white"
                      >
                        {isRefining ? (
                          <Loader2 className="h-4 w-4 mr-1 animate-spin" />
                        ) : (
                          <Sparkles className="h-4 w-4 mr-1" />
                        )}
                        Enhance with AI
                      </Button>
                    )}
                  </div>

                  {field.type === 'text' && (
                    <Input
                      id={field.name}
                      value={typeof value === 'string' ? value : ''}
                      onChange={(e) => updateField(field.name, e.target.value)}
                      placeholder={field.placeholder}
                      className="border-[#E6E6E6]"
                    />
                  )}

                  {field.type === 'date' && (
                    <Input
                      id={field.name}
                      type="date"
                      value={typeof value === 'string' ? value : ''}
                      onChange={(e) => updateField(field.name, e.target.value)}
                      className="border-[#E6E6E6]"
                    />
                  )}

                  {field.type === 'textarea' && (
                    <Textarea
                      id={field.name}
                      value={typeof value === 'string' ? value : ''}
                      onChange={(e) => updateField(field.name, e.target.value)}
                      placeholder={field.placeholder}
                      rows={4}
                      className="border-[#E6E6E6]"
                    />
                  )}

                  {field.type === 'tags' && (
                    <div className="space-y-2">
                      <div className="flex gap-2">
                        <Input
                          value={tagInputs[field.name] || ''}
                          onChange={(e) => setTagInputs(prev => ({ ...prev, [field.name]: e.target.value }))}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              handleTagAdd(field.name);
                            }
                          }}
                          placeholder={field.placeholder}
                          className="border-[#E6E6E6]"
                        />
                        <Button type="button" variant="outline" onClick={() => handleTagAdd(field.name)}>
                          Add
                        </Button>
                      </div>
                      {Array.isArray(value) && value.length > 0 && (
                        <div className="flex flex-wrap gap-2">
                          {value.map((tag, i) => (
                            <Badge key={i} variant="secondary" className="gap-1">
                              {tag}
                              <button
                                type="button"
                                onClick={() => handleTagRemove(field.name, tag)}
                                className="hover:text-[#C10024]"
                              >
                                <X className="h-3 w-3" />
                              </button>
                            </Badge>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Refinement comparison */}
                  {refinement && !refinement.isAccepted && (
                    <Card className="border-blue-200 bg-blue-50">
                      <CardContent className="p-4 space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium text-blue-700">AI Suggestion</span>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => acceptRefinement(field.name)}
                              className="text-green-600 border-green-600 hover:bg-green-600 hover:text-white"
                            >
                              <Check className="h-4 w-4 mr-1" />
                              Accept
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => discardRefinement(field.name)}
                              className="text-red-600 border-red-600 hover:bg-red-600 hover:text-white"
                            >
                              <X className="h-4 w-4 mr-1" />
                              Discard
                            </Button>
                          </div>
                        </div>
                        <p className="text-sm text-blue-800">{refinement.refinedValue}</p>
                        {refinement.clarifyingQuestions.length > 0 && (
                          <Alert>
                            <AlertDescription>
                              <strong>Questions:</strong>
                              <ul className="list-disc list-inside mt-1">
                                {refinement.clarifyingQuestions.map((q, i) => (
                                  <li key={i}>{q}</li>
                                ))}
                              </ul>
                            </AlertDescription>
                          </Alert>
                        )}
                        {refinement.warnings.length > 0 && (
                          <Alert variant="destructive">
                            <AlertDescription>
                              <strong>Warnings:</strong>
                              <ul className="list-disc list-inside mt-1">
                                {refinement.warnings.map((w, i) => (
                                  <li key={i}>{w}</li>
                                ))}
                              </ul>
                            </AlertDescription>
                          </Alert>
                        )}
                      </CardContent>
                    </Card>
                  )}
                </div>
              );
            })}
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between mt-6">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentStep === 1}
          >
            <ChevronLeft className="h-4 w-4 mr-2" />
            Previous
          </Button>

          {currentStep < WIZARD_STEPS.length ? (
            <Button
              onClick={handleNext}
              disabled={!validateStep()}
              className="bg-[#C10024] hover:bg-[#a0001d] text-white"
            >
              Next
              <ChevronRight className="h-4 w-4 ml-2" />
            </Button>
          ) : (
            <Button
              onClick={handleComplete}
              disabled={!validateStep() || isGenerating}
              className="bg-[#C10024] hover:bg-[#a0001d] text-white"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Generating Epic...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4 mr-2" />
                  Generate Epic
                </>
              )}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
