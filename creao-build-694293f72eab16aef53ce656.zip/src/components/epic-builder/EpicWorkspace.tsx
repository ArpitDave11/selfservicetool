import { useState, useCallback, useEffect, useRef } from 'react';
import {
  ArrowLeft,
  Download,
  Send,
  PanelRightOpen,
  PanelRightClose,
  Loader2,
  Check,
  X,
  RotateCcw,
  GitBranch,
  Sparkles,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { type EpicFormData, type ChatMessage, type SuggestionSeverity, SEVERITY_COLORS } from '@/types/epic';
import { ReviewSuggestionORM, ReviewSuggestionStatus, ReviewSuggestionSeverity, type ReviewSuggestionModel } from '@/components/data/orm/orm_review_suggestion';
import { ChatChangeORM } from '@/components/data/orm/orm_chat_change';
import { useAIReviewMutation, useChatPatchMutation, useArchitectureDiagramMutation } from '@/hooks/use-openai-gpt-chat';
import { useGithubCreateAnIssueMutation } from '@/hooks/use-github-create-an-issue';
import { cn } from '@/lib/utils';
import { MermaidDiagram } from './MermaidDiagram';
import { MarkdownPreview } from './MarkdownPreview';

interface EpicWorkspaceProps {
  sessionId: string;
  versionId: string;
  markdownContent: string;
  formData: EpicFormData;
  onMarkdownUpdate: (content: string, createdBy: 'user' | 'llm' | 'chat') => void;
  onBack: () => void;
}

export function EpicWorkspace({
  sessionId,
  versionId,
  markdownContent,
  formData,
  onMarkdownUpdate,
  onBack,
}: EpicWorkspaceProps) {
  const [editorContent, setEditorContent] = useState(markdownContent);
  const [suggestions, setSuggestions] = useState<ReviewSuggestionModel[]>([]);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [isReviewPanelOpen, setIsReviewPanelOpen] = useState(false);
  const [mermaidDiagram, setMermaidDiagram] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'suggestions' | 'chat' | 'diagram'>('suggestions');

  const editorRef = useRef<HTMLTextAreaElement>(null);

  const aiReview = useAIReviewMutation();
  const chatPatch = useChatPatchMutation();
  const architectureDiagram = useArchitectureDiagramMutation();
  const createGithubIssue = useGithubCreateAnIssueMutation();

  // Load suggestions on mount
  useEffect(() => {
    async function loadSuggestions() {
      if (versionId) {
        const orm = ReviewSuggestionORM.getInstance();
        const pending = await orm.getReviewSuggestionByStatusVersionId(
          ReviewSuggestionStatus.Pending,
          versionId
        );
        setSuggestions(pending);
      }
    }
    loadSuggestions();
  }, [versionId]);

  // Sync editor content with prop
  useEffect(() => {
    setEditorContent(markdownContent);
  }, [markdownContent]);

  const handleEditorChange = useCallback((e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setEditorContent(e.target.value);
  }, []);

  const handleEditorBlur = useCallback(() => {
    if (editorContent !== markdownContent) {
      onMarkdownUpdate(editorContent, 'user');
    }
  }, [editorContent, markdownContent, onMarkdownUpdate]);

  const handleRunReview = useCallback(async () => {
    try {
      const result = await aiReview.mutateAsync({ markdownContent: editorContent });

      // Save suggestions to database
      const orm = ReviewSuggestionORM.getInstance();
      const suggestionsToSave = result.suggestions.map(s => {
        let severity: ReviewSuggestionSeverity;
        switch (s.severity) {
          case 'high':
            severity = ReviewSuggestionSeverity.High;
            break;
          case 'medium':
            severity = ReviewSuggestionSeverity.Medium;
            break;
          case 'low':
            severity = ReviewSuggestionSeverity.Low;
            break;
          default:
            severity = ReviewSuggestionSeverity.Low;
        }

        return {
          id: '',
          data_creator: '',
          data_updater: '',
          create_time: '',
          update_time: '',
          version_id: versionId,
          section_name: s.sectionName,
          suggestion_text: s.suggestionText,
          severity,
          status: ReviewSuggestionStatus.Pending,
          override_text: null,
        };
      });

      const saved = await orm.insertReviewSuggestion(suggestionsToSave);
      setSuggestions(saved);
      setIsReviewPanelOpen(true);
      setActiveTab('suggestions');
    } catch (error) {
      console.error('Review failed:', error);
    }
  }, [editorContent, versionId, aiReview]);

  const handleAcceptSuggestion = useCallback(async (suggestion: ReviewSuggestionModel) => {
    const orm = ReviewSuggestionORM.getInstance();
    await orm.setReviewSuggestionById(suggestion.id, {
      ...suggestion,
      status: ReviewSuggestionStatus.Accepted,
    });
    setSuggestions(prev => prev.filter(s => s.id !== suggestion.id));
  }, []);

  const handleDiscardSuggestion = useCallback(async (suggestion: ReviewSuggestionModel) => {
    const orm = ReviewSuggestionORM.getInstance();
    await orm.setReviewSuggestionById(suggestion.id, {
      ...suggestion,
      status: ReviewSuggestionStatus.Discarded,
    });
    setSuggestions(prev => prev.filter(s => s.id !== suggestion.id));
  }, []);

  const handleChatSubmit = useCallback(async () => {
    if (!chatInput.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: chatInput,
      timestamp: new Date(),
    };

    setChatMessages(prev => [...prev, userMessage]);
    setChatInput('');

    try {
      const result = await chatPatch.mutateAsync({
        userMessage: chatInput,
        currentMarkdownContent: editorContent,
      });

      const assistantMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: result.appliedChangesDescription,
        timestamp: new Date(),
        appliedChanges: result.appliedChangesDescription,
      };

      setChatMessages(prev => [...prev, assistantMessage]);
      setEditorContent(result.updatedMarkdownContent);
      onMarkdownUpdate(result.updatedMarkdownContent, 'chat');

      // Save chat change
      const orm = ChatChangeORM.getInstance();
      await orm.insertChatChange([{
        id: '',
        data_creator: '',
        data_updater: '',
        create_time: '',
        update_time: '',
        session_id: sessionId,
        user_message: chatInput,
        applied_patch: JSON.stringify({ description: result.appliedChangesDescription }),
        result_version_id: versionId,
      }]);
    } catch (error) {
      console.error('Chat patch failed:', error);
      const errorMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: 'Sorry, I could not apply that change. Please try again.',
        timestamp: new Date(),
      };
      setChatMessages(prev => [...prev, errorMessage]);
    }
  }, [chatInput, editorContent, sessionId, versionId, chatPatch, onMarkdownUpdate]);

  const handleGenerateDiagram = useCallback(async () => {
    try {
      const result = await architectureDiagram.mutateAsync({
        epicContent: {
          objective: formData.objective,
          architectureOverview: formData.inScope,
          components: formData.features,
        },
      });
      setMermaidDiagram(result.mermaidDiagramSyntax);
      setActiveTab('diagram');
      setIsReviewPanelOpen(true);
    } catch (error) {
      console.error('Diagram generation failed:', error);
    }
  }, [formData, architectureDiagram]);

  const handleExport = useCallback(() => {
    const blob = new Blob([editorContent], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${formData.projectName.replace(/\s+/g, '-').toLowerCase()}-epic.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, [editorContent, formData.projectName]);

  const handlePublishToGithub = useCallback(async () => {
    try {
      await createGithubIssue.mutateAsync({
        owner: 'your-org',
        repo: 'epics',
        title: `[Epic] ${formData.projectName}`,
        body: editorContent,
        labels: formData.labels,
      });
      alert('Epic published successfully!');
    } catch (error) {
      console.error('Failed to publish:', error);
      alert('Failed to publish epic. Please try again.');
    }
  }, [formData, editorContent, createGithubIssue]);

  const getSeverityLabel = (severity: ReviewSuggestionSeverity): SuggestionSeverity => {
    switch (severity) {
      case ReviewSuggestionSeverity.High:
        return 'high';
      case ReviewSuggestionSeverity.Medium:
        return 'medium';
      case ReviewSuggestionSeverity.Low:
        return 'low';
      default:
        return 'low';
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F5F5] flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-[#E6E6E6] px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="sm" onClick={onBack}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <h1 className="text-lg font-semibold text-[#333333]">{formData.projectName}</h1>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleGenerateDiagram}
            disabled={architectureDiagram.isPending}
          >
            {architectureDiagram.isPending ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <GitBranch className="h-4 w-4 mr-2" />
            )}
            Generate Diagram
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleRunReview}
            disabled={aiReview.isPending}
          >
            {aiReview.isPending ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Sparkles className="h-4 w-4 mr-2" />
            )}
            AI Review
          </Button>
          <Button variant="outline" size="sm" onClick={handleExport}>
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Button
            size="sm"
            onClick={handlePublishToGithub}
            disabled={createGithubIssue.isPending}
            className="bg-[#C10024] hover:bg-[#a0001d] text-white"
          >
            {createGithubIssue.isPending ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Send className="h-4 w-4 mr-2" />
            )}
            Publish
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsReviewPanelOpen(!isReviewPanelOpen)}
          >
            {isReviewPanelOpen ? (
              <PanelRightClose className="h-4 w-4" />
            ) : (
              <PanelRightOpen className="h-4 w-4" />
            )}
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Editor and Preview */}
        <div className={cn(
          'flex-1 flex transition-all duration-300',
          isReviewPanelOpen ? 'mr-96' : ''
        )}>
          {/* Markdown Editor */}
          <div className="flex-1 p-4">
            <Card className="h-full border-[#E6E6E6]">
              <CardHeader className="py-3 border-b border-[#E6E6E6]">
                <CardTitle className="text-sm text-gray-500">Editor</CardTitle>
              </CardHeader>
              <CardContent className="p-0 h-[calc(100%-50px)]">
                <Textarea
                  ref={editorRef}
                  value={editorContent}
                  onChange={handleEditorChange}
                  onBlur={handleEditorBlur}
                  className="h-full w-full resize-none border-0 rounded-none font-mono text-sm focus-visible:ring-0"
                  placeholder="Your epic markdown content..."
                />
              </CardContent>
            </Card>
          </div>

          {/* Preview */}
          <div className="flex-1 p-4 pl-0">
            <Card className="h-full border-[#E6E6E6] overflow-hidden">
              <CardHeader className="py-3 border-b border-[#E6E6E6]">
                <CardTitle className="text-sm text-gray-500">Preview</CardTitle>
              </CardHeader>
              <CardContent className="p-4 h-[calc(100%-50px)] overflow-auto">
                <MarkdownPreview content={editorContent} />
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Review Panel */}
        <div
          className={cn(
            'fixed right-0 top-[57px] bottom-0 w-96 bg-white border-l border-[#E6E6E6] transition-transform duration-300',
            isReviewPanelOpen ? 'translate-x-0' : 'translate-x-full'
          )}
        >
          <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as typeof activeTab)} className="h-full flex flex-col">
            <TabsList className="w-full justify-start rounded-none border-b border-[#E6E6E6] bg-transparent p-0">
              <TabsTrigger
                value="suggestions"
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-[#C10024] data-[state=active]:bg-transparent"
              >
                Suggestions
                {suggestions.length > 0 && (
                  <Badge variant="secondary" className="ml-2">
                    {suggestions.length}
                  </Badge>
                )}
              </TabsTrigger>
              <TabsTrigger
                value="chat"
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-[#C10024] data-[state=active]:bg-transparent"
              >
                Chat
              </TabsTrigger>
              <TabsTrigger
                value="diagram"
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-[#C10024] data-[state=active]:bg-transparent"
              >
                Diagram
              </TabsTrigger>
            </TabsList>

            <TabsContent value="suggestions" className="flex-1 p-0 m-0 overflow-hidden">
              <ScrollArea className="h-full p-4">
                {suggestions.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <Sparkles className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    <p>No suggestions yet</p>
                    <p className="text-sm">Run AI Review to get suggestions</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {suggestions.map((suggestion) => {
                      const severityLabel = getSeverityLabel(suggestion.severity);
                      const colors = SEVERITY_COLORS[severityLabel];
                      return (
                        <Card
                          key={suggestion.id}
                          className={cn('border', colors.border, colors.bg)}
                        >
                          <CardContent className="p-3">
                            <div className="flex items-start justify-between gap-2 mb-2">
                              <Badge className={cn(colors.bg, colors.text, 'capitalize')}>
                                {severityLabel}
                              </Badge>
                              <span className="text-xs text-gray-500">
                                {suggestion.section_name}
                              </span>
                            </div>
                            <p className={cn('text-sm mb-3', colors.text)}>
                              {suggestion.suggestion_text}
                            </p>
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleAcceptSuggestion(suggestion)}
                                className="flex-1 text-green-600 border-green-600 hover:bg-green-600 hover:text-white"
                              >
                                <Check className="h-3 w-3 mr-1" />
                                Accept
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleDiscardSuggestion(suggestion)}
                                className="flex-1 text-red-600 border-red-600 hover:bg-red-600 hover:text-white"
                              >
                                <X className="h-3 w-3 mr-1" />
                                Discard
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                )}
              </ScrollArea>
            </TabsContent>

            <TabsContent value="chat" className="flex-1 p-0 m-0 flex flex-col overflow-hidden">
              <ScrollArea className="flex-1 p-4">
                <div className="space-y-4">
                  {chatMessages.map((message) => (
                    <div
                      key={message.id}
                      className={cn(
                        'p-3 rounded-lg max-w-[85%]',
                        message.role === 'user'
                          ? 'bg-[#C10024] text-white ml-auto'
                          : 'bg-gray-100 text-[#333333]'
                      )}
                    >
                      <p className="text-sm">{message.content}</p>
                      {message.appliedChanges && (
                        <p className="text-xs mt-2 opacity-75">
                          Changes applied
                        </p>
                      )}
                    </div>
                  ))}
                  {chatPatch.isPending && (
                    <div className="flex items-center gap-2 text-gray-500">
                      <Loader2 className="h-4 w-4 animate-spin" />
                      <span className="text-sm">Applying changes...</span>
                    </div>
                  )}
                </div>
              </ScrollArea>
              <div className="p-4 border-t border-[#E6E6E6]">
                <div className="flex gap-2">
                  <Textarea
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleChatSubmit();
                      }
                    }}
                    placeholder="Request changes... (e.g., 'Update target date to Q3 2025')"
                    className="resize-none"
                    rows={2}
                  />
                  <Button
                    onClick={handleChatSubmit}
                    disabled={!chatInput.trim() || chatPatch.isPending}
                    className="bg-[#C10024] hover:bg-[#a0001d] text-white"
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="diagram" className="flex-1 p-4 m-0 overflow-auto">
              {mermaidDiagram ? (
                <MermaidDiagram diagram={mermaidDiagram} />
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <GitBranch className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p>No diagram generated</p>
                  <p className="text-sm">Click "Generate Diagram" to create one</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
