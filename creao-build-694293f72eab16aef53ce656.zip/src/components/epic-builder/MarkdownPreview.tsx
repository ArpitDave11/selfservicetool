import { useMemo } from 'react';

interface MarkdownPreviewProps {
  content: string;
}

// Simple markdown to HTML converter for preview
function parseMarkdown(markdown: string): string {
  let html = markdown;

  // Escape HTML entities first
  html = html
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');

  // Headers
  html = html.replace(/^### (.*$)/gim, '<h3 class="text-lg font-semibold mt-4 mb-2 text-[#333333]">$1</h3>');
  html = html.replace(/^## (.*$)/gim, '<h2 class="text-xl font-semibold mt-6 mb-3 text-[#333333] border-b border-[#E6E6E6] pb-2">$1</h2>');
  html = html.replace(/^# (.*$)/gim, '<h1 class="text-2xl font-bold mt-8 mb-4 text-[#333333]">$1</h1>');

  // Bold and italic
  html = html.replace(/\*\*\*(.*?)\*\*\*/g, '<strong><em>$1</em></strong>');
  html = html.replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold">$1</strong>');
  html = html.replace(/\*(.*?)\*/g, '<em class="italic">$1</em>');
  html = html.replace(/___(.*?)___/g, '<strong><em>$1</em></strong>');
  html = html.replace(/__(.*?)__/g, '<strong class="font-semibold">$1</strong>');
  html = html.replace(/_(.*?)_/g, '<em class="italic">$1</em>');

  // Code blocks
  html = html.replace(/```(\w+)?\n([\s\S]*?)```/g, '<pre class="bg-gray-100 p-3 rounded my-3 overflow-auto text-sm"><code>$2</code></pre>');
  html = html.replace(/`([^`]+)`/g, '<code class="bg-gray-100 px-1 py-0.5 rounded text-sm text-[#C10024]">$1</code>');

  // Blockquotes
  html = html.replace(/^\> (.*$)/gim, '<blockquote class="border-l-4 border-[#C10024] pl-4 my-3 text-gray-600 italic">$1</blockquote>');

  // Unordered lists
  html = html.replace(/^\- (.*$)/gim, '<li class="ml-4 list-disc">$1</li>');
  html = html.replace(/^\* (.*$)/gim, '<li class="ml-4 list-disc">$1</li>');

  // Ordered lists
  html = html.replace(/^\d+\. (.*$)/gim, '<li class="ml-4 list-decimal">$1</li>');

  // Wrap consecutive li elements in ul/ol
  html = html.replace(/(<li class="ml-4 list-disc">.*<\/li>\n?)+/g, '<ul class="my-2 space-y-1">$&</ul>');
  html = html.replace(/(<li class="ml-4 list-decimal">.*<\/li>\n?)+/g, '<ol class="my-2 space-y-1">$&</ol>');

  // Horizontal rules
  html = html.replace(/^---$/gim, '<hr class="my-6 border-[#E6E6E6]" />');
  html = html.replace(/^\*\*\*$/gim, '<hr class="my-6 border-[#E6E6E6]" />');

  // Links
  html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" class="text-[#C10024] hover:underline" target="_blank" rel="noopener noreferrer">$1</a>');

  // Paragraphs - wrap remaining text in p tags
  html = html
    .split('\n\n')
    .map(block => {
      if (
        block.trim().startsWith('<h') ||
        block.trim().startsWith('<ul') ||
        block.trim().startsWith('<ol') ||
        block.trim().startsWith('<pre') ||
        block.trim().startsWith('<blockquote') ||
        block.trim().startsWith('<hr')
      ) {
        return block;
      }
      if (block.trim()) {
        return `<p class="my-2 text-[#333333] leading-relaxed">${block.replace(/\n/g, '<br />')}</p>`;
      }
      return '';
    })
    .join('\n');

  return html;
}

export function MarkdownPreview({ content }: MarkdownPreviewProps) {
  const htmlContent = useMemo(() => parseMarkdown(content), [content]);

  return (
    <div
      className="prose prose-sm max-w-none"
      dangerouslySetInnerHTML={{ __html: htmlContent }}
    />
  );
}
