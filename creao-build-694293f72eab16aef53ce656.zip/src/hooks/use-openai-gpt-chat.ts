import { useMutation, type UseMutationResult } from '@tanstack/react-query';
import { createChatCompletion } from '@/sdk/api-clients/OpenAIGPTChat';

// ============================================================================
// Type Definitions
// ============================================================================

interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

// Field Refinement Types
export interface FieldRefinementInput {
  fieldName: string;
  originalText: string;
  previousFieldsContext?: Record<string, string>;
}

export interface FieldRefinementResponse {
  refinedText: string;
  clarifyingQuestions: string[];
  warnings: string[];
}

// Epic Generation Types
export interface EpicGenerationInput {
  objective: string;
  problemStatement: string;
  scope: string;
  assumptions: string;
  teamsAndRoles: string;
  features: string;
  userStories: string;
  nfrPriorities: string;
  targetCompletion: string;
}

export interface EpicGenerationResponse {
  markdownContent: string;
}

// AI Review Types
export interface AIReviewInput {
  markdownContent: string;
}

export interface AIReviewSuggestion {
  sectionName: string;
  suggestionText: string;
  severity: 'high' | 'medium' | 'low';
}

export interface AIReviewResponse {
  suggestions: AIReviewSuggestion[];
}

// Chat Patch Types
export interface ChatPatchInput {
  userMessage: string;
  currentMarkdownContent: string;
}

export interface ChatPatchResponse {
  updatedMarkdownContent: string;
  appliedChangesDescription: string;
}

// Architecture Diagram Types
export interface ArchitectureDiagramInput {
  epicContent: {
    objective: string;
    architectureOverview?: string;
    components?: string;
  };
}

export interface ArchitectureDiagramResponse {
  mermaidDiagramSyntax: string;
}

// ============================================================================
// Helper Functions
// ============================================================================

const DEFAULT_MODEL = 'MaaS_4.1';
const API_HEADERS = {
  'X-CREAO-API-NAME': 'OpenAIGPTChat',
  'X-CREAO-API-PATH': '/v1/ai/zWwyutGgvEGWwzSa/chat/completions',
  'X-CREAO-API-ID': '688a0b64dc79a2533460892c',
} as const;

async function callChatCompletion(messages: ChatMessage[]): Promise<string> {
  const response = await createChatCompletion({
    body: {
      model: DEFAULT_MODEL,
      messages,
    },
    headers: API_HEADERS,
  });

  if (response.error) {
    const errorMessage =
      typeof response.error === 'object' && response.error !== null && 'message' in response.error
        ? String((response.error as { message?: unknown }).message)
        : 'Chat completion failed';
    throw new Error(errorMessage);
  }

  if (!response.data?.choices?.[0]?.message?.content) {
    throw new Error('No content returned from chat completion');
  }

  return response.data.choices[0].message.content;
}

function parseJSONResponse<T>(content: string, fallback: T): T {
  try {
    // Try to extract JSON from markdown code blocks
    const jsonMatch = content.match(/```(?:json)?\s*\n?([\s\S]*?)\n?```/);
    const jsonString = jsonMatch ? jsonMatch[1] : content;
    return JSON.parse(jsonString.trim()) as T;
  } catch {
    return fallback;
  }
}

// ============================================================================
// Hook: Field Refinement
// ============================================================================

export function useFieldRefinementMutation(): UseMutationResult<
  FieldRefinementResponse,
  Error,
  FieldRefinementInput
> {
  return useMutation({
    mutationFn: async (input: FieldRefinementInput): Promise<FieldRefinementResponse> => {
      if (!input.fieldName || !input.originalText) {
        throw new Error('Field name and original text are required');
      }

      const contextInfo = input.previousFieldsContext
        ? `\n\nPrevious field context:\n${Object.entries(input.previousFieldsContext)
            .map(([key, value]) => `${key}: ${value}`)
            .join('\n')}`
        : '';

      const messages: ChatMessage[] = [
        {
          role: 'system',
          content: 'You are an AI assistant helping to refine technical documentation fields. Provide refined text, clarifying questions, and warnings in JSON format.',
        },
        {
          role: 'user',
          content: `Please refine the following field for a technical design blueprint:

Field Name: ${input.fieldName}
Original Text: ${input.originalText}${contextInfo}

Respond in JSON format with:
{
  "refinedText": "improved version of the text",
  "clarifyingQuestions": ["question 1", "question 2"],
  "warnings": ["warning 1", "warning 2"]
}`,
        },
      ];

      const content = await callChatCompletion(messages);
      return parseJSONResponse<FieldRefinementResponse>(content, {
        refinedText: input.originalText,
        clarifyingQuestions: [],
        warnings: [],
      });
    },
  });
}

// ============================================================================
// Hook: Epic Generation
// ============================================================================

export function useEpicGenerationMutation(): UseMutationResult<
  EpicGenerationResponse,
  Error,
  EpicGenerationInput
> {
  return useMutation({
    mutationFn: async (input: EpicGenerationInput): Promise<EpicGenerationResponse> => {
      if (!input.objective) {
        throw new Error('Objective is required for epic generation');
      }

      const messages: ChatMessage[] = [
        {
          role: 'system',
          content: `You are an AI assistant that generates Technical Design Blueprint documents in Markdown format.
Follow this exact structure:

# Technical Design Blueprint

## 1. Executive Summary
### Objective
### Problem Statement

## 2. Scope
### In Scope
### Out of Scope

## 3. Assumptions & Constraints
### Assumptions
### Constraints

## 4. Teams & Roles
### Teams Involved
### Roles & Responsibilities

## 5. Features & User Stories
### Features
### User Stories

## 6. Non-Functional Requirements
### Priorities

## 7. Timeline
### Target Completion

Generate a complete, production-ready markdown document.`,
        },
        {
          role: 'user',
          content: `Generate a Technical Design Blueprint with the following information:

Objective: ${input.objective}
Problem Statement: ${input.problemStatement}
Scope: ${input.scope}
Assumptions: ${input.assumptions}
Teams & Roles: ${input.teamsAndRoles}
Features: ${input.features}
User Stories: ${input.userStories}
NFR Priorities: ${input.nfrPriorities}
Target Completion: ${input.targetCompletion}

Please generate the complete markdown document following the template structure.`,
        },
      ];

      const markdownContent = await callChatCompletion(messages);
      return { markdownContent };
    },
  });
}

// ============================================================================
// Hook: AI Review
// ============================================================================

export function useAIReviewMutation(): UseMutationResult<
  AIReviewResponse,
  Error,
  AIReviewInput
> {
  return useMutation({
    mutationFn: async (input: AIReviewInput): Promise<AIReviewResponse> => {
      if (!input.markdownContent) {
        throw new Error('Markdown content is required for AI review');
      }

      const messages: ChatMessage[] = [
        {
          role: 'system',
          content: 'You are an expert technical reviewer. Analyze the provided technical design document and provide structured suggestions in JSON format.',
        },
        {
          role: 'user',
          content: `Please review this Technical Design Blueprint and provide suggestions for improvement:

${input.markdownContent}

Respond in JSON format with:
{
  "suggestions": [
    {
      "sectionName": "Section name",
      "suggestionText": "Specific suggestion",
      "severity": "high|medium|low"
    }
  ]
}`,
        },
      ];

      const content = await callChatCompletion(messages);
      return parseJSONResponse<AIReviewResponse>(content, { suggestions: [] });
    },
  });
}

// ============================================================================
// Hook: Chat Patch
// ============================================================================

export function useChatPatchMutation(): UseMutationResult<
  ChatPatchResponse,
  Error,
  ChatPatchInput
> {
  return useMutation({
    mutationFn: async (input: ChatPatchInput): Promise<ChatPatchResponse> => {
      if (!input.userMessage || !input.currentMarkdownContent) {
        throw new Error('User message and current markdown content are required');
      }

      const messages: ChatMessage[] = [
        {
          role: 'system',
          content: `You are an AI assistant that modifies Technical Design Blueprint documents based on natural language requests.
Respond in JSON format with the updated markdown content and a description of changes applied.`,
        },
        {
          role: 'user',
          content: `Current Technical Design Blueprint:

${input.currentMarkdownContent}

User Request: ${input.userMessage}

Please apply the requested changes and respond in JSON format:
{
  "updatedMarkdownContent": "the full updated markdown document",
  "appliedChangesDescription": "summary of changes made"
}`,
        },
      ];

      const content = await callChatCompletion(messages);
      return parseJSONResponse<ChatPatchResponse>(content, {
        updatedMarkdownContent: input.currentMarkdownContent,
        appliedChangesDescription: 'No changes applied',
      });
    },
  });
}

// ============================================================================
// Hook: Architecture Diagram Generation
// ============================================================================

export function useArchitectureDiagramMutation(): UseMutationResult<
  ArchitectureDiagramResponse,
  Error,
  ArchitectureDiagramInput
> {
  return useMutation({
    mutationFn: async (input: ArchitectureDiagramInput): Promise<ArchitectureDiagramResponse> => {
      if (!input.epicContent.objective) {
        throw new Error('Epic objective is required for architecture diagram generation');
      }

      const messages: ChatMessage[] = [
        {
          role: 'system',
          content: `You are an AI assistant that generates Mermaid diagrams for system architectures.
Generate clean, professional Mermaid diagram syntax based on the provided epic content.`,
        },
        {
          role: 'user',
          content: `Generate a Mermaid architecture diagram for this epic:

Objective: ${input.epicContent.objective}
${input.epicContent.architectureOverview ? `Architecture Overview: ${input.epicContent.architectureOverview}` : ''}
${input.epicContent.components ? `Components: ${input.epicContent.components}` : ''}

Respond in JSON format:
{
  "mermaidDiagramSyntax": "graph TD\\n  A[Component A] --> B[Component B]\\n  ..."
}`,
        },
      ];

      const content = await callChatCompletion(messages);
      return parseJSONResponse<ArchitectureDiagramResponse>(content, {
        mermaidDiagramSyntax: 'graph TD\n  A[Start] --> B[End]',
      });
    },
  });
}
