import { useQuery } from '@tanstack/react-query';
import { callMCPTool, type MCPToolResponse } from '@/sdk/core/mcp-client';

/**
 * Input parameters for listing repository issues from GitHub
 */
export interface ListRepositoryIssuesInput {
  /** The GitHub account owner of the repository. This name is not case-sensitive. */
  owner: string;
  /** The name of the repository, without the `.git` extension. This name is not case-sensitive. */
  repo: string;
  /** Filter issues by assignee's username. Use 'none' for issues with no assignee, or '*' for issues assigned to any user. */
  assignee?: string;
  /** Filter issues by the username of the user who created the issue. */
  creator?: string;
  /** The direction of the sort. */
  direction?: 'asc' | 'desc';
  /** A comma-separated list of label names to filter issues by. Example: 'bug,ui,@high'. */
  labels?: string;
  /** Filter issues by a user mentioned in the issue's description or comments. Provide the username. */
  mentioned?: string;
  /** Filter issues by milestone. Provide the milestone `number` as a string, '*' for issues with any milestone, or 'none' for issues without a milestone. */
  milestone?: string;
  /** Page number for the set of results. Refer to GitHub's REST API documentation for pagination details. */
  page?: number;
  /** Number of results per page (max 100). Refer to GitHub's REST API documentation for pagination details. */
  per_page?: number;
  /** Filters issues to include only those updated at or after the specified time. This should be a timestamp in ISO 8601 format (e.g., `YYYY-MM-DDTHH:MM:SSZ`). */
  since?: string;
  /** The field to sort the results by. */
  sort?: 'created' | 'updated' | 'comments';
  /** Filters issues based on their state. */
  state?: 'open' | 'closed' | 'all';
}

/**
 * Output data from listing repository issues
 */
export interface ListRepositoryIssuesOutput {
  /** Parsed JSON response from GitHub API, typically a list of issues. */
  data: Record<string, unknown>;
  /** Error if any occurred during the execution of the action */
  error: string | null;
  /** Whether or not the action execution was successful or not */
  successful: boolean;
}

/**
 * Hook for listing issues from a GitHub repository
 *
 * @param params - Input parameters including owner, repo, and optional filters
 * @param enabled - Whether the query should execute (default: true)
 * @returns TanStack Query result with issue list data
 */
export function useGithubListRepositoryIssues(
  params?: ListRepositoryIssuesInput,
  enabled: boolean = true
) {
  return useQuery({
    queryKey: ['github-list-repository-issues', params],
    queryFn: async () => {
      if (!params) {
        throw new Error('Parameters are required for this MCP tool call');
      }

      // CRITICAL: Use MCPToolResponse and parse JSON response
      const mcpResponse = await callMCPTool<MCPToolResponse, ListRepositoryIssuesInput>(
        '686de4e26fd1cae1afbb55bc',
        'GITHUB_LIST_REPOSITORY_ISSUES',
        params
      );

      if (!mcpResponse.content?.[0]?.text) {
        throw new Error('Invalid MCP response format: missing content[0].text');
      }

      try {
        const toolData: ListRepositoryIssuesOutput = JSON.parse(mcpResponse.content[0].text);
        return toolData;
      } catch (parseError) {
        throw new Error(`Failed to parse MCP response JSON: ${parseError instanceof Error ? parseError.message : 'Unknown error'}`);
      }
    },
    enabled: enabled && !!params,
    staleTime: 5 * 60 * 1000, // 5 minutes
    retry: 2,
    retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
  });
}
