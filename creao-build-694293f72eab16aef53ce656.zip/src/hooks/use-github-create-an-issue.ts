import { useMutation, useQueryClient } from '@tanstack/react-query';
import { callMCPTool, type MCPToolResponse } from '@/sdk/core/mcp-client';

/**
 * Input parameters for creating a GitHub issue
 */
export interface CreateAnIssueInput {
  /** The GitHub account owner of the repository (case-insensitive). */
  owner: string;
  /** The name of the repository, without the `.git` extension (case-insensitive). */
  repo: string;
  /** The title for the new issue. */
  title: string;
  /** Login for the user to whom this issue should be assigned. NOTE: Only users with push access can set the assignee; it is silently dropped otherwise. **This field is deprecated in favor of `assignees`.** */
  assignee?: string;
  /** GitHub login names for users to assign to this issue. NOTE: Only users with push access can set assignees; they are silently dropped otherwise. */
  assignees?: string[];
  /** The detailed textual contents of the new issue. */
  body?: string;
  /** Label names to associate with this issue (generally case-insensitive). NOTE: Only users with push access can set labels; they are silently dropped otherwise. Pass an empty list to clear all labels. */
  labels?: string[];
  /** The ID of the milestone to associate this issue with (e.g., "5"). NOTE: Only users with push access can set the milestone; it is silently dropped otherwise. */
  milestone?: string;
}

/**
 * Output data from creating a GitHub issue
 */
export interface CreateAnIssueOutput {
  /** A dictionary containing the full data representation of the newly created GitHub issue, including its ID, title, body, state, assignees, labels, etc. */
  data: Record<string, unknown>;
  /** Error if any occurred during the execution of the action */
  error: string | null;
  /** Whether or not the action execution was successful or not */
  successful: boolean;
}

/**
 * Hook for creating a new issue in a GitHub repository
 *
 * @returns TanStack Mutation object for creating issues
 */
export function useGithubCreateAnIssueMutation() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (params: CreateAnIssueInput) => {
      if (!params) {
        throw new Error('Parameters are required for this MCP tool call');
      }

      // CRITICAL: Use MCPToolResponse and parse JSON response
      const mcpResponse = await callMCPTool<MCPToolResponse, CreateAnIssueInput>(
        '686de4e26fd1cae1afbb55bc',
        'GITHUB_CREATE_AN_ISSUE',
        params
      );

      if (!mcpResponse.content?.[0]?.text) {
        throw new Error('Invalid MCP response format: missing content[0].text');
      }

      try {
        const toolData: CreateAnIssueOutput = JSON.parse(mcpResponse.content[0].text);
        return toolData;
      } catch (parseError) {
        throw new Error(`Failed to parse MCP response JSON: ${parseError instanceof Error ? parseError.message : 'Unknown error'}`);
      }
    },
    onSuccess: () => {
      // Invalidate related queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['github-list-repository-issues'] });
    },
    retry: 2,
    retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
  });
}
