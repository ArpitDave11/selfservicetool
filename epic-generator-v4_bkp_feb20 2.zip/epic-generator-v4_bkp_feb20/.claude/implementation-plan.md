# Premium 7-Stage Pipeline Implementation Plan

**Created:** February 5, 2026
**Status:** Planning Complete - Ready for Implementation

---

## Executive Summary

This plan replaces the existing `analyzeAndRefineEpic()` function in Epic Editor with a Premium 5-Stage Pipeline.

---

## Implementation Phases

### Phase 1: Types (types.ts)
- Add 25+ new interfaces
- Pipeline state types
- Stage output types

### Phase 2: Category Config (skills.ts)
- Add CATEGORY_CONFIGS constant
- 7 epic categories with configs

### Phase 3: Stage Functions (skills.ts)
- `runStage1Comprehension()`
- `runStage2Classification()`
- `runStage3Structural()`
- `runStage4Refinement()` (parallel)
- `runStage5Mandatory()` (5A + 5B)

### Phase 4: Orchestrator (skills.ts)
- `runPremiumPipeline()`
- Progress callback
- Backward compatibility wrapper

### Phase 5: UI (App.tsx)
- Pipeline state
- Progress modal
- Results modal
- Updated button

### Phase 6: Testing
- Unit tests per stage
- Integration tests
- 30+ new tests

---

## Critical Integration Points

### Stage 5A: Mermaid Integration
```
runStage5AArchitecture()
  └── Convert RefinementOutput → RefinedData
  └── Call generateIntelligentBlueprint(refinedData, projectName)
  └── Return { diagram, type }
```

### Stage 5B: User Stories
- Uses categoryConfig.storyStyle
- 7 different story formats
- Acceptance criteria per story

---

## Dependencies Flow

```
epicContent
    ↓
Stage 1: Comprehension → projectEssence, gaps, risks
    ↓
Stage 2: Classification → category, config
    ↓
Stage 3: Structural → scores, transformationPlan
    ↓
Stage 4: Refinement (parallel) → refinedSections
    ↓
Stage 5: Mandatory → diagram + stories
```

---

## Files to Modify

| File | Changes |
|------|---------|
| `src/types.ts` | +200 lines (new types) |
| `src/skills.ts` | +800 lines (stages, orchestrator) |
| `src/App.tsx` | +300 lines (state, modals) |
| `src/test/pipeline.test.ts` | NEW (30+ tests) |

---

## Test Strategy

- Mock AI calls for unit tests
- Test each stage independently
- Integration test for full pipeline
- UI component tests
