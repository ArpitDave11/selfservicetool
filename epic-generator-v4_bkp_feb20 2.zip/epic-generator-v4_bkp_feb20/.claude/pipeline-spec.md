# Premium 7-Stage Pipeline Specification

**Purpose:** REPLACE existing refine feature in Epic Editor ONLY
**Scope:** Stages 1-5 (Stage 6-7 future)

---

## Stage 1: DEEP COMPREHENSION

**Goal:** Build complete mental model before touching anything.

**Steps:**
1. Parse full epic content with complete context window
2. Extract semantic meaning of each section (intent vs actual)
3. Build internal model: project, audience, problem, moving parts
4. Identify implicit knowledge author assumed but didn't write
5. Surface hidden assumptions and unstated dependencies
6. Produce Comprehension Summary

**Output → Stage 2:**
```typescript
interface ComprehensionOutput {
  projectEssence: string;           // 2-3 sentences
  keyEntities: EntityRelationship[];
  detectedGaps: string[];           // Referenced but never defined
  implicitRisks: string[];          // Author didn't call out
  semanticSections: SemanticSection[];
}
```

---

## Stage 2: CATEGORY CLASSIFICATION

**Goal:** Determine document type for downstream treatment.

**Categories:**
- Business Requirement
- Technical Design
- Feature Specification
- API Specification
- Infrastructure Design
- Migration Plan
- Integration Spec

**Steps:**
1. Analyze comprehension output against category definitions
2. Assign primary category with confidence score (0-1)
3. Assign secondary category if confidence < 0.85
4. Intent vs Reality check - flag mismatches
5. Select optimal: section structure, tone, architecture focus, user story style

**Output → Stage 3:**
```typescript
interface ClassificationOutput {
  primaryCategory: EpicCategory;
  confidence: number;
  secondaryCategory?: EpicCategory;
  intentMismatch?: {
    authorIntent: string;
    actualCategory: EpicCategory;
  };
  categoryConfig: CategoryConfig;
}
```

---

## Stage 3: STRUCTURAL ASSESSMENT

**Goal:** Score every section, decide transformations.

**Steps:**
1. Score each section on 3 dimensions (1-10):
   - Completeness: covers what it should for category
   - Relevance: belongs here or noise
   - Placement: right position in document flow
2. Compare against categoryConfig.requiredSections
3. Make transformation decision per section:
   - Keep: score ≥ 8 all dimensions
   - Restructure: good content, poor organization
   - Merge: >60% content overlap
   - Split: covers multiple distinct concerns
   - Add: required section missing
4. Generate Transformation Plan with rationale

**Output → Stage 4:**
```typescript
interface StructuralOutput {
  sectionScores: SectionScore[];
  transformationPlan: TransformationAction[];
  missingSections: string[];
  proposedOutline: string[];
}
```

---

## Stage 4: CONTENT REFINEMENT (Parallel)

**Goal:** Rewrite every section to publication-ready quality.

**Steps:**
1. Execute transformation plan (merge, split, reorder first)
2. For each section (parallel):
   a. Feed: comprehension + category config + section + instructions
   b. Apply category-specific standards:
      - Business: executive-friendly, ROI, metrics
      - Technical: precise terminology, no ambiguity
      - Feature: user flow clarity, testable criteria
      - API: exact endpoints, examples, error codes
      - Infrastructure: scaling, monitoring, failure modes
      - Migration: rollback, risk mitigation, timeline
      - Integration: sequence, error handling, retry logic
   c. Apply smart features:
      - Terminology consistency
      - Gap filling with [TODO] flags
      - Cross-reference validation
3. Generate missing sections from comprehension model

**Output → Stage 5:**
```typescript
interface RefinementOutput {
  refinedSections: RefinedSection[];
  terminologyMap: Record<string, string>;
  unresolvedGaps: string[];
}
```

---

## Stage 5: MANDATORY SECTIONS

**Goal:** Generate architecture diagram + user stories.

### 5A: Architecture Diagram
- **USE EXISTING Mermaid generator** (generateIntelligentBlueprint)
- Regenerate button should reflect changes
- Validate: every entity in diagram ↔ sections

### 5B: User Stories
1. Extract ALL user needs from refined content
2. Apply categoryConfig.storyStyle:
   - Business: "As a [business role]..."
   - Technical: "As a [developer/system]..."
   - Feature: "As a [end user]..."
   - API: "As a [consuming system]..."
   - Infrastructure: "As a [ops engineer]..."
   - Migration: "As a [migration lead]..."
   - Integration: "As a [integrating system]..."
3. Each story: acceptance criteria, priority, source section
4. Validate: requirements → stories coverage

**Output → Stage 6:**
```typescript
interface MandatoryOutput {
  architectureDiagram: string;
  userStories: UserStory[];
  coverageReport: CoverageReport;
  fullRefinedEpic: string;
}
```

---

## Data Flow

```
Epic Input
    │
    ▼
┌─────────────────────┐
│ Stage 1: Comprehend  │──→ projectEssence, gaps, risks, entities
└─────────┬───────────┘
          ▼
┌─────────────────────┐
│ Stage 2: Classify    │──→ category, config, intent mismatch
└─────────┬───────────┘
          ▼
┌─────────────────────┐
│ Stage 3: Assess      │──→ section scores, transformation plan
└─────────┬───────────┘
          ▼
┌─────────────────────┐
│ Stage 4: Refine      │──→ refined sections, terminology, gaps
│   (parallel)         │
└─────────┬───────────┘
          ▼
┌─────────────────────┐
│ Stage 5: Mandatory   │──→ architecture diagram, user stories
└─────────┬───────────┘
          ▼
    Ready for Stage 6
```

---

## Integration Points

### Current Critique (analyzeAndRefineEpic)
- Will be REPLACED by this pipeline
- Critique button triggers Stage 1-5 sequence
- Progress shown per stage

### Current Mermaid (generateIntelligentBlueprint)
- REUSED in Stage 5A
- Must pass category context
- Regenerate reflects pipeline output

### UI Changes (Epic Editor)
- Replace simple refine with pipeline progress
- Show stage-by-stage status
- Display comprehension summary
- Show category classification
- Show transformation plan
- Show refined sections with diffs
- Show coverage report

---

## Category Configurations

```typescript
const CATEGORY_CONFIGS: Record<EpicCategory, CategoryConfig> = {
  business_requirement: {
    requiredSections: ['Objective', 'Background', 'Scope', 'Success Metrics', 'Stakeholders'],
    tone: 'executive-friendly',
    storyStyle: 'business',
    architectureFocus: 'high-level'
  },
  technical_design: {
    requiredSections: ['Objective', 'Architecture', 'Data Model', 'API Contracts', 'NFRs'],
    tone: 'precise-technical',
    storyStyle: 'technical',
    architectureFocus: 'detailed-components'
  },
  feature_specification: {
    requiredSections: ['Objective', 'User Flows', 'Acceptance Criteria', 'Edge Cases'],
    tone: 'user-focused',
    storyStyle: 'feature',
    architectureFocus: 'user-interaction'
  },
  api_specification: {
    requiredSections: ['Endpoints', 'Request/Response', 'Error Codes', 'Auth', 'Rate Limits'],
    tone: 'precise-technical',
    storyStyle: 'api',
    architectureFocus: 'api-flow'
  },
  infrastructure_design: {
    requiredSections: ['Architecture', 'Scaling', 'Monitoring', 'Disaster Recovery'],
    tone: 'ops-focused',
    storyStyle: 'infrastructure',
    architectureFocus: 'deployment'
  },
  migration_plan: {
    requiredSections: ['Current State', 'Target State', 'Migration Steps', 'Rollback', 'Timeline'],
    tone: 'procedural',
    storyStyle: 'migration',
    architectureFocus: 'before-after'
  },
  integration_spec: {
    requiredSections: ['Systems', 'Data Flow', 'Error Handling', 'Retry Logic', 'Monitoring'],
    tone: 'precise-technical',
    storyStyle: 'integration',
    architectureFocus: 'sequence'
  }
};
```
