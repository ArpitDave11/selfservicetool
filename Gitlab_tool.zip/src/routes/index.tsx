import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from "@/components/ui/resizable";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { AlertCircle, CheckCircle, XCircle, Lightbulb, Send, FileText, Layout, MessageSquare } from "lucide-react";
import { cn } from "@/lib/utils";
import type {
  Step1Data,
  Step2Data,
  Step3Data,
  Step4Data,
  Step5Data,
  EpicFormData,
  EpicDocument,
  ReviewHighlight,
  ChatMessage,
  TeamType,
  EpicType,
  EpicStatus,
} from "@/types/epic";

export const Route = createFileRoute("/")({
  component: App,
});

function App() {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<EpicFormData>({
    step1: {
      projectName: "",
      epicType: "initiative" as EpicType,
      customType: "",
      status: "draft" as EpicStatus,
      groupProgramId: "",
      targetDate: "",
      stakeholders: "",
    },
    step2: {
      mainObjective: "",
      businessProblem: "",
      technicalProblem: "",
    },
    step3: {
      inScope: "",
      outOfScope: "",
    },
    step4: {
      keyStakeholders: "",
      teamTypes: [],
    },
    step5: {
      features: "",
      nfrPriorities: "",
      targetCompletionDate: "",
    },
  });

  const [llmRefinements, setLlmRefinements] = useState<Record<string, { original: string; refined: string }>>({});
  const [isGeneratingEpic, setIsGeneratingEpic] = useState(false);
  const [epicDocument, setEpicDocument] = useState<EpicDocument | null>(null);
  const [editableEpic, setEditableEpic] = useState("");
  const [reviewHighlights, setReviewHighlights] = useState<ReviewHighlight[]>([]);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [activeView, setActiveView] = useState<"form" | "epic-chat" | "diagram">("form");

  // Simulate LLM refinement (replace with actual OpenAIGPTChat integration)
  const refineWithLLM = async (text: string, fieldName: string) => {
    // This is a placeholder - integrate with <api_tool>OpenAIGPTChat</api_tool>
    await new Promise(resolve => setTimeout(resolve, 500));
    const refined = `${text} [Enhanced by AI: more narrative and streamlined]`;
    return refined;
  };

  const handleFieldBlur = async (fieldName: string, value: string) => {
    if (!value.trim()) return;
    const refined = await refineWithLLM(value, fieldName);
    setLlmRefinements(prev => ({
      ...prev,
      [fieldName]: { original: value, refined },
    }));
  };

  const generateEpic = async () => {
    setIsGeneratingEpic(true);
    // Simulate EPIC generation with LLM
    await new Promise(resolve => setTimeout(resolve, 1500));

    const epic: EpicDocument = {
      projectCapabilityName: formData.step1.projectName,
      epicType: formData.step1.epicType === "custom" ? formData.step1.customType : formData.step1.epicType,
      objective: llmRefinements["mainObjective"]?.refined || formData.step2.mainObjective,
      businessProblem: llmRefinements["businessProblem"]?.refined || formData.step2.businessProblem,
      technicalProblem: llmRefinements["technicalProblem"]?.refined || formData.step2.technicalProblem,
      scopeIn: llmRefinements["inScope"]?.refined || formData.step3.inScope,
      scopeOut: llmRefinements["outOfScope"]?.refined || formData.step3.outOfScope,
      teamAndStakeholders: `${formData.step4.keyStakeholders}\nTeams: ${formData.step4.teamTypes.join(", ")}`,
      featuresAndRequirements: llmRefinements["features"]?.refined || formData.step5.features,
      nfrPriorities: llmRefinements["nfrPriorities"]?.refined || formData.step5.nfrPriorities,
      targetCompletion: formData.step5.targetCompletionDate,
      assumptions: "Generated based on provided inputs",
      architectureSecurity: "Security considerations to be reviewed by architecture team",
    };

    setEpicDocument(epic);
    setEditableEpic(formatEpicAsText(epic));
    setIsGeneratingEpic(false);
    setActiveView("epic-chat");

    // Simulate AI review
    setTimeout(() => performAIReview(epic), 1000);
  };

  const formatEpicAsText = (epic: EpicDocument): string => {
    return `# ${epic.projectCapabilityName}

## EPIC Type
${epic.epicType}

## Objective
${epic.objective}

## Business Problem
${epic.businessProblem}

## Technical Problem
${epic.technicalProblem}

## Scope

### In Scope
${epic.scopeIn}

### Out of Scope
${epic.scopeOut}

## Team and Stakeholders
${epic.teamAndStakeholders}

## Features and Requirements
${epic.featuresAndRequirements}

## NFR Priorities
${epic.nfrPriorities}

## Target Completion
${epic.targetCompletion}

## Assumptions
${epic.assumptions}

## Architecture & Security Considerations
${epic.architectureSecurity}
`;
  };

  const performAIReview = (epic: EpicDocument) => {
    // Simulate AI review with highlights
    const highlights: ReviewHighlight[] = [
      {
        id: "1",
        lineNumber: 5,
        text: epic.objective,
        type: "suggestion",
        comment: "Consider adding specific success metrics to the objective",
        accepted: null,
      },
      {
        id: "2",
        lineNumber: 15,
        text: epic.scopeIn,
        type: "unclear",
        comment: "This scope item could be more specific about deliverables",
        accepted: null,
      },
    ];
    setReviewHighlights(highlights);
  };

  const handleChatSend = async () => {
    if (!chatInput.trim() || !epicDocument) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: "user",
      content: chatInput,
      timestamp: new Date(),
    };

    setChatMessages(prev => [...prev, userMessage]);
    const userRequest = chatInput;
    setChatInput("");

    // Simulate LLM response and apply changes to EPIC in real-time
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Simulate AI making changes to the EPIC based on user request
    // This is a placeholder - integrate with <api_tool>OpenAIGPTChat</api_tool>
    const updatedEpicText = editableEpic + `\n\n## Update (${new Date().toLocaleTimeString()})\n${userRequest} [AI modification applied]`;
    setEditableEpic(updatedEpicText);

    const assistantMessage: ChatMessage = {
      id: (Date.now() + 1).toString(),
      role: "assistant",
      content: `I've updated the EPIC document based on your request: "${userRequest}". The changes are now visible in the live preview.`,
      timestamp: new Date(),
    };

    setChatMessages(prev => [...prev, assistantMessage]);
  };

  return (
    <div className="min-h-screen bg-[#F5F5F5]">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-[#C10024] flex items-center justify-center rounded">
                <FileText className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-2xl font-semibold text-[#333333]" style={{ fontFamily: "'Open Sans', sans-serif" }}>
                GitLab EPIC Builder
              </h1>
            </div>
            <Badge variant="outline" className="text-sm">
              GitLab integration coming soon - using sample data
            </Badge>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <nav className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex gap-8">
            <button
              onClick={() => setActiveView("form")}
              className={cn(
                "px-4 py-3 font-medium text-sm border-b-2 transition-colors",
                activeView === "form"
                  ? "border-[#C10024] text-[#C10024]"
                  : "border-transparent text-[#333333] hover:text-[#C10024]"
              )}
            >
              <Layout className="inline w-4 h-4 mr-2" />
              Create EPIC
            </button>
            <button
              onClick={() => setActiveView("epic-chat")}
              className={cn(
                "px-4 py-3 font-medium text-sm border-b-2 transition-colors",
                activeView === "epic-chat"
                  ? "border-[#C10024] text-[#C10024]"
                  : "border-transparent text-[#333333] hover:text-[#C10024]",
                !epicDocument && "opacity-50 cursor-not-allowed"
              )}
              disabled={!epicDocument}
            >
              <FileText className="inline w-4 h-4 mr-2" />
              EPIC & Modify
            </button>
            <button
              onClick={() => setActiveView("diagram")}
              className={cn(
                "px-4 py-3 font-medium text-sm border-b-2 transition-colors",
                activeView === "diagram"
                  ? "border-[#C10024] text-[#C10024]"
                  : "border-transparent text-[#333333] hover:text-[#C10024]",
                !epicDocument && "opacity-50 cursor-not-allowed"
              )}
              disabled={!epicDocument}
            >
              <Lightbulb className="inline w-4 h-4 mr-2" />
              Architecture
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Form View */}
        {activeView === "form" && (
          <Card className="bg-white">
            <CardHeader>
              <CardTitle className="text-[#333333]">Create New EPIC - Step {currentStep} of 5</CardTitle>
            </CardHeader>
            <CardContent>
              {/* Step 1 */}
              {currentStep === 1 && (
                <div className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="projectName">
                      Project Name <span className="text-[#C10024]">*</span>
                    </Label>
                    <Input
                      id="projectName"
                      value={formData.step1.projectName}
                      onChange={e => setFormData(prev => ({ ...prev, step1: { ...prev.step1, projectName: e.target.value } }))}
                      onBlur={e => handleFieldBlur("projectName", e.target.value)}
                      placeholder="Enter project capability name"
                    />
                    {llmRefinements["projectName"] && (
                      <div className="p-3 bg-green-50 border border-green-200 rounded text-sm">
                        <p className="font-medium text-green-900">AI Enhanced:</p>
                        <p className="text-green-800">{llmRefinements["projectName"].refined}</p>
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="epicType">
                        EPIC Type <span className="text-[#C10024]">*</span>
                      </Label>
                      <Select
                        value={formData.step1.epicType}
                        onValueChange={(value: EpicType) =>
                          setFormData(prev => ({ ...prev, step1: { ...prev.step1, epicType: value } }))
                        }
                      >
                        <SelectTrigger id="epicType">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="initiative">Initiative</SelectItem>
                          <SelectItem value="defect">Defect</SelectItem>
                          <SelectItem value="custom">Custom</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {formData.step1.epicType === "custom" && (
                      <div className="space-y-2">
                        <Label htmlFor="customType">Custom Type</Label>
                        <Input
                          id="customType"
                          value={formData.step1.customType}
                          onChange={e => setFormData(prev => ({ ...prev, step1: { ...prev.step1, customType: e.target.value } }))}
                          placeholder="Specify custom type"
                        />
                      </div>
                    )}

                    <div className="space-y-2">
                      <Label htmlFor="status">
                        Status <span className="text-[#C10024]">*</span>
                      </Label>
                      <Select
                        value={formData.step1.status}
                        onValueChange={(value: EpicStatus) =>
                          setFormData(prev => ({ ...prev, step1: { ...prev.step1, status: value } }))
                        }
                      >
                        <SelectTrigger id="status">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="draft">Draft</SelectItem>
                          <SelectItem value="in-progress">In Progress</SelectItem>
                          <SelectItem value="review">Review</SelectItem>
                          <SelectItem value="approved">Approved</SelectItem>
                          <SelectItem value="completed">Completed</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="groupProgramId">
                      Group Program ID <span className="text-[#C10024]">*</span>
                    </Label>
                    <Select
                      value={formData.step1.groupProgramId}
                      onValueChange={value => setFormData(prev => ({ ...prev, step1: { ...prev.step1, groupProgramId: value } }))}
                    >
                      <SelectTrigger id="groupProgramId">
                        <SelectValue placeholder="Select program" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Program-001">Program-001</SelectItem>
                        <SelectItem value="Program-002">Program-002</SelectItem>
                        <SelectItem value="Program-003">Program-003</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="targetDate">Target Date</Label>
                      <Input
                        id="targetDate"
                        type="date"
                        value={formData.step1.targetDate}
                        onChange={e => setFormData(prev => ({ ...prev, step1: { ...prev.step1, targetDate: e.target.value } }))}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="stakeholders">Stakeholders</Label>
                      <Input
                        id="stakeholders"
                        value={formData.step1.stakeholders}
                        onChange={e => setFormData(prev => ({ ...prev, step1: { ...prev.step1, stakeholders: e.target.value } }))}
                        placeholder="Comma-separated names"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end">
                    <Button onClick={() => setCurrentStep(2)} className="bg-[#C10024] hover:bg-[#A00020]">
                      Next Step
                    </Button>
                  </div>
                </div>
              )}

              {/* Step 2 */}
              {currentStep === 2 && (
                <div className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="mainObjective">
                      Main Objective <span className="text-[#C10024]">*</span>
                    </Label>
                    <Textarea
                      id="mainObjective"
                      value={formData.step2.mainObjective}
                      onChange={e => setFormData(prev => ({ ...prev, step2: { ...prev.step2, mainObjective: e.target.value } }))}
                      onBlur={e => handleFieldBlur("mainObjective", e.target.value)}
                      placeholder="Describe the main objective of this EPIC"
                      rows={4}
                    />
                    {llmRefinements["mainObjective"] && (
                      <div className="p-3 bg-green-50 border border-green-200 rounded text-sm">
                        <p className="font-medium text-green-900">AI Enhanced:</p>
                        <p className="text-green-800">{llmRefinements["mainObjective"].refined}</p>
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="businessProblem">
                      Business Problem <span className="text-[#C10024]">*</span>
                    </Label>
                    <Textarea
                      id="businessProblem"
                      value={formData.step2.businessProblem}
                      onChange={e => setFormData(prev => ({ ...prev, step2: { ...prev.step2, businessProblem: e.target.value } }))}
                      onBlur={e => handleFieldBlur("businessProblem", e.target.value)}
                      placeholder="What business problem does this solve?"
                      rows={4}
                    />
                    {llmRefinements["businessProblem"] && (
                      <div className="p-3 bg-green-50 border border-green-200 rounded text-sm">
                        <p className="font-medium text-green-900">AI Enhanced:</p>
                        <p className="text-green-800">{llmRefinements["businessProblem"].refined}</p>
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="technicalProblem">Technical Problem</Label>
                    <Textarea
                      id="technicalProblem"
                      value={formData.step2.technicalProblem}
                      onChange={e => setFormData(prev => ({ ...prev, step2: { ...prev.step2, technicalProblem: e.target.value } }))}
                      onBlur={e => handleFieldBlur("technicalProblem", e.target.value)}
                      placeholder="What technical challenges need to be addressed?"
                      rows={4}
                    />
                    {llmRefinements["technicalProblem"] && (
                      <div className="p-3 bg-green-50 border border-green-200 rounded text-sm">
                        <p className="font-medium text-green-900">AI Enhanced:</p>
                        <p className="text-green-800">{llmRefinements["technicalProblem"].refined}</p>
                      </div>
                    )}
                  </div>

                  <div className="flex justify-between">
                    <Button onClick={() => setCurrentStep(1)} variant="outline">
                      Previous
                    </Button>
                    <Button onClick={() => setCurrentStep(3)} className="bg-[#C10024] hover:bg-[#A00020]">
                      Next Step
                    </Button>
                  </div>
                </div>
              )}

              {/* Step 3 */}
              {currentStep === 3 && (
                <div className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="inScope">
                      In Scope <span className="text-[#C10024]">*</span>
                    </Label>
                    <Textarea
                      id="inScope"
                      value={formData.step3.inScope}
                      onChange={e => setFormData(prev => ({ ...prev, step3: { ...prev.step3, inScope: e.target.value } }))}
                      onBlur={e => handleFieldBlur("inScope", e.target.value)}
                      placeholder="What is included in this EPIC?"
                      rows={5}
                    />
                    {llmRefinements["inScope"] && (
                      <div className="p-3 bg-green-50 border border-green-200 rounded text-sm">
                        <p className="font-medium text-green-900">AI Enhanced:</p>
                        <p className="text-green-800">{llmRefinements["inScope"].refined}</p>
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="outOfScope">
                      Out of Scope <span className="text-[#C10024]">*</span>
                    </Label>
                    <Textarea
                      id="outOfScope"
                      value={formData.step3.outOfScope}
                      onChange={e => setFormData(prev => ({ ...prev, step3: { ...prev.step3, outOfScope: e.target.value } }))}
                      onBlur={e => handleFieldBlur("outOfScope", e.target.value)}
                      placeholder="What is explicitly excluded from this EPIC?"
                      rows={5}
                    />
                    {llmRefinements["outOfScope"] && (
                      <div className="p-3 bg-green-50 border border-green-200 rounded text-sm">
                        <p className="font-medium text-green-900">AI Enhanced:</p>
                        <p className="text-green-800">{llmRefinements["outOfScope"].refined}</p>
                      </div>
                    )}
                  </div>

                  <div className="flex justify-between">
                    <Button onClick={() => setCurrentStep(2)} variant="outline">
                      Previous
                    </Button>
                    <Button onClick={() => setCurrentStep(4)} className="bg-[#C10024] hover:bg-[#A00020]">
                      Next Step
                    </Button>
                  </div>
                </div>
              )}

              {/* Step 4 */}
              {currentStep === 4 && (
                <div className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="keyStakeholders">
                      Key Stakeholders <span className="text-[#C10024]">*</span>
                    </Label>
                    <Textarea
                      id="keyStakeholders"
                      value={formData.step4.keyStakeholders}
                      onChange={e => setFormData(prev => ({ ...prev, step4: { ...prev.step4, keyStakeholders: e.target.value } }))}
                      onBlur={e => handleFieldBlur("keyStakeholders", e.target.value)}
                      placeholder="List key stakeholders and their roles"
                      rows={4}
                    />
                    {llmRefinements["keyStakeholders"] && (
                      <div className="p-3 bg-green-50 border border-green-200 rounded text-sm">
                        <p className="font-medium text-green-900">AI Enhanced:</p>
                        <p className="text-green-800">{llmRefinements["keyStakeholders"].refined}</p>
                      </div>
                    )}
                  </div>

                  <div className="space-y-3">
                    <Label>
                      Team Types <span className="text-[#C10024]">*</span>
                    </Label>
                    <div className="grid grid-cols-2 gap-3">
                      {(["architecture", "backend", "ux", "database", "devops", "frontend", "qa", "security"] as TeamType[]).map(
                        team => (
                          <div key={team} className="flex items-center space-x-2">
                            <Checkbox
                              id={team}
                              checked={formData.step4.teamTypes.includes(team)}
                              onCheckedChange={checked => {
                                if (checked) {
                                  setFormData(prev => ({
                                    ...prev,
                                    step4: { ...prev.step4, teamTypes: [...prev.step4.teamTypes, team] },
                                  }));
                                } else {
                                  setFormData(prev => ({
                                    ...prev,
                                    step4: { ...prev.step4, teamTypes: prev.step4.teamTypes.filter(t => t !== team) },
                                  }));
                                }
                              }}
                            />
                            <Label htmlFor={team} className="capitalize cursor-pointer">
                              {team}
                            </Label>
                          </div>
                        )
                      )}
                    </div>
                  </div>

                  <div className="flex justify-between">
                    <Button onClick={() => setCurrentStep(3)} variant="outline">
                      Previous
                    </Button>
                    <Button onClick={() => setCurrentStep(5)} className="bg-[#C10024] hover:bg-[#A00020]">
                      Next Step
                    </Button>
                  </div>
                </div>
              )}

              {/* Step 5 */}
              {currentStep === 5 && (
                <div className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="features">
                      Features and Requirements <span className="text-[#C10024]">*</span>
                    </Label>
                    <Textarea
                      id="features"
                      value={formData.step5.features}
                      onChange={e => setFormData(prev => ({ ...prev, step5: { ...prev.step5, features: e.target.value } }))}
                      onBlur={e => handleFieldBlur("features", e.target.value)}
                      placeholder="List key features and requirements"
                      rows={5}
                    />
                    {llmRefinements["features"] && (
                      <div className="p-3 bg-green-50 border border-green-200 rounded text-sm">
                        <p className="font-medium text-green-900">AI Enhanced:</p>
                        <p className="text-green-800">{llmRefinements["features"].refined}</p>
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="nfrPriorities">NFR Priorities</Label>
                    <Textarea
                      id="nfrPriorities"
                      value={formData.step5.nfrPriorities}
                      onChange={e => setFormData(prev => ({ ...prev, step5: { ...prev.step5, nfrPriorities: e.target.value } }))}
                      onBlur={e => handleFieldBlur("nfrPriorities", e.target.value)}
                      placeholder="Non-functional requirements and priorities"
                      rows={4}
                    />
                    {llmRefinements["nfrPriorities"] && (
                      <div className="p-3 bg-green-50 border border-green-200 rounded text-sm">
                        <p className="font-medium text-green-900">AI Enhanced:</p>
                        <p className="text-green-800">{llmRefinements["nfrPriorities"].refined}</p>
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="targetCompletionDate">
                      Target Completion Date <span className="text-[#C10024]">*</span>
                    </Label>
                    <Input
                      id="targetCompletionDate"
                      type="date"
                      value={formData.step5.targetCompletionDate}
                      onChange={e => setFormData(prev => ({ ...prev, step5: { ...prev.step5, targetCompletionDate: e.target.value } }))}
                    />
                  </div>

                  <div className="flex justify-between">
                    <Button onClick={() => setCurrentStep(4)} variant="outline">
                      Previous
                    </Button>
                    <Button onClick={generateEpic} disabled={isGeneratingEpic} className="bg-[#C10024] hover:bg-[#A00020]">
                      {isGeneratingEpic ? "Generating EPIC..." : "Generate EPIC"}
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* EPIC Document & Chat Combined View */}
        {activeView === "epic-chat" && epicDocument && (
          <ResizablePanelGroup direction="horizontal" className="rounded-lg border bg-white">
            {/* Left Panel: EPIC Live Preview */}
            <ResizablePanel defaultSize={40} minSize={30}>
              <div className="h-[calc(100vh-250px)] flex flex-col">
                <div className="px-4 py-3 border-b bg-gray-50">
                  <h3 className="font-semibold text-[#333333]">Live Preview</h3>
                </div>
                <ScrollArea className="flex-1 p-6">
                  <div className="prose prose-sm max-w-none">
                    {editableEpic.split("\n").map((line, idx) => {
                      const highlight = reviewHighlights.find(h => h.lineNumber === idx);
                      return (
                        <div key={idx} className="relative">
                          <p
                            className={cn(
                              "mb-2",
                              highlight && highlight.type === "suggestion" && "bg-yellow-100 px-2 py-1 rounded",
                              highlight && highlight.type === "unclear" && "bg-orange-100 px-2 py-1 rounded",
                              highlight && highlight.type === "error" && "bg-red-100 px-2 py-1 rounded",
                              line.startsWith("#") && "font-bold text-lg mt-4",
                              line.startsWith("##") && "font-semibold text-base mt-3"
                            )}
                          >
                            {line}
                          </p>
                          {highlight && (
                            <div className="ml-4 mb-3 p-3 bg-blue-50 border-l-4 border-blue-400 text-sm">
                              <div className="flex items-start gap-2">
                                <Lightbulb className="w-4 h-4 mt-0.5 text-blue-600" />
                                <div className="flex-1">
                                  <p className="font-medium text-blue-900">AI Suggestion:</p>
                                  <p className="text-blue-800">{highlight.comment}</p>
                                  <div className="flex gap-2 mt-2">
                                    <Button
                                      size="sm"
                                      onClick={() =>
                                        setReviewHighlights(prev =>
                                          prev.map(h => (h.id === highlight.id ? { ...h, accepted: true } : h))
                                        )
                                      }
                                      className="h-7 text-xs bg-green-600 hover:bg-green-700"
                                    >
                                      <CheckCircle className="w-3 h-3 mr-1" />
                                      Accept
                                    </Button>
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() =>
                                        setReviewHighlights(prev => prev.filter(h => h.id !== highlight.id))
                                      }
                                      className="h-7 text-xs"
                                    >
                                      <XCircle className="w-3 h-3 mr-1" />
                                      Discard
                                    </Button>
                                  </div>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </ScrollArea>
              </div>
            </ResizablePanel>
            <ResizableHandle withHandle />

            {/* Middle Panel: Edit Mode */}
            <ResizablePanel defaultSize={30} minSize={25}>
              <div className="h-[calc(100vh-250px)] flex flex-col">
                <div className="px-4 py-3 border-b bg-gray-50">
                  <h3 className="font-semibold text-[#333333]">Edit Mode</h3>
                </div>
                <ScrollArea className="flex-1">
                  <Textarea
                    value={editableEpic}
                    onChange={e => setEditableEpic(e.target.value)}
                    className="min-h-full border-0 rounded-none font-mono text-sm resize-none focus-visible:ring-0"
                    style={{ minHeight: "calc(100vh - 300px)" }}
                  />
                </ScrollArea>
              </div>
            </ResizablePanel>
            <ResizableHandle withHandle />

            {/* Right Panel: Chat Interface */}
            <ResizablePanel defaultSize={30} minSize={25}>
              <div className="h-[calc(100vh-250px)] flex flex-col">
                <div className="px-4 py-3 border-b bg-gray-50">
                  <h3 className="font-semibold text-[#333333]">Modify with AI</h3>
                </div>
                <ScrollArea className="flex-1 p-4">
                  {chatMessages.length === 0 && (
                    <div className="text-center text-gray-500 py-8">
                      <MessageSquare className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                      <p className="text-sm">Start a conversation to modify your EPIC</p>
                      <p className="text-xs mt-2 text-gray-400">
                        Try: "Change the target date to Q3 2024"
                      </p>
                    </div>
                  )}
                  {chatMessages.map(msg => (
                    <div
                      key={msg.id}
                      className={cn(
                        "mb-4 p-3 rounded-lg max-w-[90%]",
                        msg.role === "user"
                          ? "ml-auto bg-[#C10024] text-white"
                          : "mr-auto bg-white border border-gray-200"
                      )}
                    >
                      <p className="text-sm">{msg.content}</p>
                      <p className="text-xs mt-1 opacity-70">
                        {msg.timestamp.toLocaleTimeString()}
                      </p>
                    </div>
                  ))}
                </ScrollArea>
                <div className="p-4 border-t bg-white">
                  <div className="flex gap-2">
                    <Input
                      value={chatInput}
                      onChange={e => setChatInput(e.target.value)}
                      onKeyDown={e => e.key === "Enter" && handleChatSend()}
                      placeholder="Describe changes..."
                      className="flex-1"
                    />
                    <Button onClick={handleChatSend} className="bg-[#C10024] hover:bg-[#A00020]">
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </ResizablePanel>
          </ResizablePanelGroup>
        )}

        {/* Architecture Diagram View */}
        {activeView === "diagram" && epicDocument && (
          <Card className="bg-white">
            <CardHeader>
              <CardTitle className="text-[#333333]">Architecture Blueprint</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="min-h-[500px] border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center bg-gray-50">
                <div className="text-center space-y-4">
                  <div className="flex flex-wrap justify-center gap-4 max-w-4xl">
                    {formData.step4.teamTypes.map(team => (
                      <div
                        key={team}
                        className="bg-white border-2 border-[#C10024] rounded-lg p-6 shadow-sm min-w-[150px]"
                      >
                        <div className="text-sm font-medium text-[#333333] capitalize">{team}</div>
                        <div className="text-xs text-gray-600 mt-2">Component</div>
                      </div>
                    ))}
                  </div>
                  <p className="text-gray-600 mt-8">
                    Architecture diagram showing {formData.step4.teamTypes.length} team components
                  </p>
                  <p className="text-sm text-gray-500">Based on selected team types and features</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

      </main>
    </div>
  );
}
