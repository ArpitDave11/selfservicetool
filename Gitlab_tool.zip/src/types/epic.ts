// EPIC data structure types

export type EpicType = 'initiative' | 'defect' | 'custom';
export type EpicStatus = 'draft' | 'in-progress' | 'review' | 'approved' | 'completed';
export type TeamType = 'architecture' | 'backend' | 'ux' | 'database' | 'devops' | 'frontend' | 'qa' | 'security';

export interface Step1Data {
  projectName: string;
  epicType: EpicType;
  customType: string;
  status: EpicStatus;
  groupProgramId: string;
  targetDate: string;
  stakeholders: string;
}

export interface Step2Data {
  mainObjective: string;
  businessProblem: string;
  technicalProblem: string;
}

export interface Step3Data {
  inScope: string;
  outOfScope: string;
}

export interface Step4Data {
  keyStakeholders: string;
  teamTypes: TeamType[];
}

export interface Step5Data {
  features: string;
  nfrPriorities: string;
  targetCompletionDate: string;
}

export interface EpicFormData {
  step1: Step1Data;
  step2: Step2Data;
  step3: Step3Data;
  step4: Step4Data;
  step5: Step5Data;
}

export interface LLMRefinement {
  original: string;
  refined: string;
  fieldName: string;
}

export interface EpicDocument {
  projectCapabilityName: string;
  epicType: string;
  objective: string;
  businessProblem: string;
  technicalProblem: string;
  scopeIn: string;
  scopeOut: string;
  teamAndStakeholders: string;
  featuresAndRequirements: string;
  nfrPriorities: string;
  targetCompletion: string;
  assumptions: string;
  architectureSecurity: string;
}

export interface ReviewHighlight {
  id: string;
  lineNumber: number;
  text: string;
  type: 'suggestion' | 'unclear' | 'error';
  comment: string;
  accepted: boolean | null;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export interface EpicVersion {
  id: string;
  epicDocument: EpicDocument;
  timestamp: Date;
  changeDescription: string;
}
