# Blueprint Diagram Rendering Fix - January 2026

## Problem Statement
The Blueprint diagram was NOT visible on screen despite:
- Mermaid code being valid (shown in editable textarea)
- SVG download working
- PNG download working

## Root Cause Analysis

### Primary Issue: Component Remounting
The `MermaidBlueprint` component was defined **inside** the `App` function component. This caused:
1. React to create a new function reference on every App re-render
2. React treating it as a different component type each time
3. The component being unmounted and remounted on every parent render
4. All internal state (including the rendered SVG) being lost

### Secondary Issues Discovered:
1. **Infinite render loop** - Callback props (`onRequestFix`, `onSvgReady`) in useEffect dependencies caused re-renders
2. **HTML entity escaping** - Mermaid code sometimes contained `&gt;` instead of `>`, causing parse errors

## Changes Made

### 1. Moved MermaidBlueprint Component Outside App (CRITICAL FIX)
**File:** `src/App.tsx`
**Location:** Moved from ~line 1357 (inside App) to ~line 466 (before App)

```typescript
// BEFORE (broken): Component defined inside App
export default function App() {
  // ... many lines of code ...

  const MermaidBlueprint = ({ code, zoom, ... }) => {
    // Component would be recreated on every App render
  };

  // ... rest of App ...
}

// AFTER (fixed): Component defined outside App
const MermaidBlueprint = ({ code, zoom, ... }) => {
  // Component identity is stable, state persists
};

export default function App() {
  // ... App code ...
}
```

### 2. Used Refs for Callback Props
**Purpose:** Prevent useEffect from re-running when callback references change

```typescript
// Store callbacks in refs
const onRequestFixRef = useRef(onRequestFix);
const onSvgReadyRef = useRef(onSvgReady);

// Update refs when callbacks change (doesn't trigger re-render)
useEffect(() => {
  onRequestFixRef.current = onRequestFix;
  onSvgReadyRef.current = onSvgReady;
}, [onRequestFix, onSvgReady]);

// Use refs inside the render effect
useEffect(() => {
  // ... render logic ...
  if (onSvgReadyRef.current) {
    onSvgReadyRef.current(renderedSvg);
  }
}, [code]); // Only depends on code, not callbacks
```

### 3. Added Render ID Tracking
**Purpose:** Handle concurrent renders gracefully (e.g., from React Strict Mode)

```typescript
const renderIdRef = useRef(0);

useEffect(() => {
  renderIdRef.current += 1;
  const currentRenderId = renderIdRef.current;

  const renderDiagram = async () => {
    const { svg } = await mermaid.render(id, code);

    // Discard result if a newer render started
    if (currentRenderId !== renderIdRef.current) {
      return;
    }

    setSvg(svg);
  };

  renderDiagram();
}, [code]);
```

### 4. HTML Entity Unescaping
**Purpose:** Handle cases where `>` becomes `&gt;` during storage/transport

```typescript
const unescapedCode = code
  .replace(/&gt;/g, '>')
  .replace(/&lt;/g, '<')
  .replace(/&amp;/g, '&')
  .replace(/&quot;/g, '"')
  .replace(/&#39;/g, "'");

const { svg } = await mermaid.render(id, unescapedCode);
```

### 5. Simplified useEffect Dependencies
**Before:** `[code, hasAttemptedFix, onRequestFix, onSvgReady]` - caused multiple triggers
**After:** `[code]` - only re-renders when code actually changes

## Testing Results
- All 63 existing tests pass
- Diagram renders correctly in live preview
- Zoom controls work (25% - 200%)
- SVG download works
- PNG download works
- Fullscreen mode works
- AI fix feature works (when enabled)

### 6. Extended Zoom Range
**Purpose:** Allow more flexibility in diagram viewing

| Setting | Before | After |
|---------|--------|-------|
| Minimum | 25% | 10% |
| Maximum | 200% | 400% |
| Step | 1% | 5% |
| Slider Width | 140px | 160px (180px fullscreen) |

Both regular view and fullscreen view sliders updated.

## Files Modified
- `src/App.tsx` - MermaidBlueprint component restructured, zoom range extended

## Debugging Approach Used
1. Added console.log statements to trace render flow
2. Used Puppeteer for automated E2E testing
3. Analyzed browser console output to identify:
   - Render loop patterns
   - State persistence issues
   - Component remounting evidence (render ID resetting to 1)

## Key Lesson Learned
**Never define React components inside other components.** The inner component will be recreated on every render of the outer component, causing:
- Loss of all internal state
- Unnecessary DOM operations
- Potential infinite loops if state updates trigger parent re-renders
